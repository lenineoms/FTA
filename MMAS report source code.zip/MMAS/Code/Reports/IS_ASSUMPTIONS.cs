using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	
	public class IS_ASSUMPTIONS:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.IS_Assumption_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,3);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);
			
			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG,rm.GetString("isaIncStmt"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			// SPA - Sales 1
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6050)"));

			if (RG.GetDetailCalcs("ACCT(6050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			// SPA - Sales 2
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6070)"));

			if (RG.GetDetailCalcs("ACCT(6070)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6070)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Sales 3
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6100)"));

			if (RG.GetDetailCalcs("ACCT(6100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Ret & Allow
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6150)"));

			if (RG.GetDetailCalcs("ACCT(6150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Discounts
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6200)"));

			if (RG.GetDetailCalcs("ACCT(6200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - COGS 1
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6250)"));

			if (RG.GetDetailCalcs("ACCT(6250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - COGS 2
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6270)"));

			if (RG.GetDetailCalcs("ACCT(6270)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6270)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6270)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6270)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6270)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - COGS 3
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6300)"));

			if (RG.GetDetailCalcs("ACCT(6300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - COGS Deprec
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6350)"));

			if (RG.GetDetailCalcs("ACCT(6350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Op Inc
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6400)"));

			if (RG.GetDetailCalcs("ACCT(6400)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6400)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Selling Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6420)"));

			if (RG.GetDetailCalcs("ACCT(6420)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6420)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Gen & Admin Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6450)"));

			if (RG.GetDetailCalcs("ACCT(6450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Oth Gen & Admin Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6470)"));

			if (RG.GetDetailCalcs("ACCT(6470)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6470)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Post Ret Ben Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6490)"));

			if (RG.GetDetailCalcs("ACCT(6490)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6490)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6490)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6490)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6490)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Officers' Comp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6550)"));

			if (RG.GetDetailCalcs("ACCT(6550)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6550)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Personel Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6560)"));

			if (RG.GetDetailCalcs("ACCT(6560)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6560)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6560)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6560)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6560)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Lease Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6570)"));

			if (RG.GetDetailCalcs("ACCT(6570)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6570)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6570)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6570)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6570)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - R & D
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6580)"));

			if (RG.GetDetailCalcs("ACCT(6580)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6580)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6580)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6580)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6580)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Deprec
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6600)"));

			if (RG.GetDetailCalcs("ACCT(6600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6600)")));
			Utility.PrintSummary(RG, rm.GetString("isa%GFA"), RG.GetPrintOrderCalc(RG.GetCalc("%GrsFxdAsts(6600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Amort
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6650)"));

			if (RG.GetDetailCalcs("ACCT(6650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6650)")));
			Utility.PrintSummary(RG, rm.GetString("isa%Intang"), RG.GetPrintOrderCalc(RG.GetCalc("%Intang(6650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Op Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6500)"));

			if (RG.GetDetailCalcs("ACCT(6500)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6500)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Bad Debt Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6700)"));

			if (RG.GetDetailCalcs("ACCT(6700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Oth Op Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6750)"));

			if (RG.GetDetailCalcs("ACCT(6750)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6750)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - ESOP Trust
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7530)"));

			if (RG.GetDetailCalcs("ACCT(7530)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7530)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Int Inc
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6800)"));

			if (RG.GetDetailCalcs("ACCT(6800)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6800)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Int Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6850)"));

			if (RG.GetDetailCalcs("ACCT(6850)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6850)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Def Int Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6870)"));

			if (RG.GetDetailCalcs("ACCT(6870)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6870)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6870)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6870)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6870)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Cap Int
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6880)"));

			if (RG.GetDetailCalcs("ACCT(6880)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6880)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6880)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6880)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6880)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Inc Sub/Joint Vent
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(6900)"));

			if (RG.GetDetailCalcs("ACCT(6900)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(6900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(6900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(6900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(6900)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Non-Cash Inc
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7000)"));

			if (RG.GetDetailCalcs("ACCT(7000)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7000)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7000)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7000)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7000)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Non-Cash Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7010)"));

			if (RG.GetDetailCalcs("ACCT(7010)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7010)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7010)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7010)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7010)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);
			
			// KCZ Added Account 7040 Version V 6-11-03 Gain on Derivative
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7040)"));

			if (RG.GetDetailCalcs("ACCT(7040)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7040)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7040)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7040)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7040)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// KCZ End of Addition

            // Tony Added Account 9953 Gain on Asset Revaluation
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(9953)"));

            if (RG.GetDetailCalcs("ACCT(9953)").GetTotals(RG).NonZero)
                RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(9953)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
            ///CPF 6/24/03  This is so that we don't round these items.
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
            Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(9953)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(9953)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            if (RG.GetDetailCalcs("ACCT(9953)").GetTotals(RG).NonZero)
                Utility.Skip(RG, 1);

            //amit: End 
            Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
            //amit: start
            Utility.mT.AddStartRow(Utility.nRow + 1);           

			// SPA - Oth Inc
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7050)"));

			if (RG.GetDetailCalcs("ACCT(7050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// KCZ Add Account 7090 Loss on Derivatives Version V 6-11-03 
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7090)"));

			if (RG.GetDetailCalcs("ACCT(7090)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7090)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7090)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7090)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7090)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// KCZ end of addition

            // Tony Added Account 9954 Loss on Asset Revaluation (-)
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(9954)"));

            if (RG.GetDetailCalcs("ACCT(9954)").GetTotals(RG).NonZero)
                RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(9954)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
            ///CPF 6/24/03  This is so that we don't round these items.
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
            Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(9954)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(9954)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            if (RG.GetDetailCalcs("ACCT(9954)").GetTotals(RG).NonZero)
                Utility.Skip(RG, 1);

            //amit: End 
            Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
            //amit: start
            Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Oth Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7100)"));

			if (RG.GetDetailCalcs("ACCT(7100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Commitment Fees
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7120)"));

			if (RG.GetDetailCalcs("ACCT(7120)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7120)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7120)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7120)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7120)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - G/L Asset Sale
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7150)"));

			if (RG.GetDetailCalcs("ACCT(7150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Curr Inc Tax
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7250)"));

			if (RG.GetDetailCalcs("ACCT(7250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7250)")));
			Utility.PrintSummary(RG, rm.GetString("isa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%PBT(7250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Def Inc Tax
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7300)"));

			if (RG.GetDetailCalcs("ACCT(7300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7300)")));
			Utility.PrintSummary(RG, rm.GetString("isa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%PBT(7300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Inc Tax Credit
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7320)"));

			if (RG.GetDetailCalcs("ACCT(7320)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7320)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7320)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7320)")));
			Utility.PrintSummary(RG, rm.GetString("isa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%PBT(7320)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7320)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Minority Interest
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7230)"));

			if (RG.GetDetailCalcs("ACCT(7230)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7230)")));
			Utility.PrintSummary(RG, rm.GetString("isa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%PBT(7230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7230)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Extra G/L
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7200)"));

			if (RG.GetDetailCalcs("ACCT(7200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Aft Tax Inc
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7350)"));

			if (RG.GetDetailCalcs("ACCT(7350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Aft Tax Exp
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7400)"));

			if (RG.GetDetailCalcs("ACCT(7400)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7400)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Cum Eff of Acctg Chg
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7470)"));

			if (RG.GetDetailCalcs("ACCT(7470)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7470)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7470)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Oth Non-Cash Aft Tax Items
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7480)"));

			if (RG.GetDetailCalcs("ACCT(7480)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7480)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7480)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7480)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7480)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Unreal G/L on Mkt Sec
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7700)"));

			if (RG.GetDetailCalcs("ACCT(7700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - OCI Foreign Cur Translat
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7720)"));

			if (RG.GetDetailCalcs("ACCT(7720)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7720)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7720)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7720)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7720)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Min Pension Liab Adj
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7740)"));

			if (RG.GetDetailCalcs("ACCT(7740)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7740)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Oth OCI Adj
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7760)"));

			if (RG.GetDetailCalcs("ACCT(7760)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7760)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7760)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7760)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7760)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Def Hedging G/L
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7780)"));

			if (RG.GetDetailCalcs("ACCT(7780)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7780)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7780)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7780)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7780)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// KCZ Added 7790 Version V 6-11-03 Derivatives - FMV Adjustment
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7790)"));

			if (RG.GetDetailCalcs("ACCT(7790)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(7790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7790)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);
			// KCZ end of addition 7790

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Pref Div
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7500)"));

			if (RG.GetDetailCalcs("ACCT(7500)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetPft"), RG.GetPrintOrderCalc(RG.GetCalc("%NetProfit(7500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7500)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Common Div
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7520)"));

			if (RG.GetDetailCalcs("ACCT(7520)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7520)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7520)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetPft"), RG.GetPrintOrderCalc(RG.GetCalc("%NetProfit(7520)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7520)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Stock Div
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7450)"));

			if (RG.GetDetailCalcs("ACCT(7450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetPft"), RG.GetPrintOrderCalc(RG.GetCalc("%NetProfit(7450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Withdrawals
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7550)"));

			if (RG.GetDetailCalcs("ACCT(7550)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("isa%NetPft"), RG.GetPrintOrderCalc(RG.GetCalc("%NetProfit(7550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7550)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - PP Adj
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7600)"));

			if (RG.GetDetailCalcs("ACCT(7600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// SPA - Adj to RE
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(7650)"));

			if (RG.GetDetailCalcs("ACCT(7650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("isaActIcrDcrPrior"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(7650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("isa%IcrDcrPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(7650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(7650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);


			Utility.UnderlinePage(RG, 2);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: start
			Utility.mT.AddEndRow(Utility.nRow);
			Utility.CloseReport(RG);

		}
	}
}
