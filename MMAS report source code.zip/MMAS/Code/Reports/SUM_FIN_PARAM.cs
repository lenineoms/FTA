using System.Collections;
using System.Threading;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
	public class SUM_FIN_PARAM:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG, true);

			FormatCommands.LoadFormatDefaults(RG);

			///This variable will store the stmt index of the base comparison stmt
			int PBaseId;
			int BaseId = RG.BaseStatementID;
			PBaseId = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);
			StatementConstant sc = (StatementConstant)RG.Customer.Model.StatementConstants[SCON.AuditMthd - 1];

			string s0 = "";
			string s1 = "";
			string s2 = "";
			string sSpace = " ";
			string sDot = ".";
			string sTimePeriod = "";
			string sDate = Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString();
			string sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToUpper();
			string sCurrencyTarget = RG.TARGETCURRENCY(0)[0]?.ToString(); //Customer.TargetCurrency.ToString();
			int intPeriod = (int)(RG.STMT_PERIODS()[PBaseId]);
			int intMonth = (int)(RG.STMT_MONTH()[PBaseId]);
			int intYear = (int)(RG.STMT_YEAR()[PBaseId]);

			///If the base stmt is annual, then describe the comparison stmt as such.
			if (intPeriod == 12)
				sTimePeriod = string.Format(rm.GetString("sfpAnnual"), intYear);
			else
				sTimePeriod = string.Format(rm.GetString("sfpInterim"), intPeriod, sDate);

			///This case transform abreviation to the normal words for audit method:
			//If the audit method is Unqualified:
			if (sAdtMthVal.ToUpper() == rm.GetString("sfpUnqlUC"))
			{
				s0 = rm.GetString("sfpUnqlLC") + sSpace;
				s1 = "";
			}
				//If the audit method is Qualified:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpQualUC"))
			{
				s0 = rm.GetString("sfpQualLC") + sSpace;
				s1 = "";
			}
				//If the audit method is Reviewed:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpRevUC"))
			{
				s0 = rm.GetString("sfpRevLC") + sSpace;
				s1 = "";
			}
				//If the audit method is Disclaimer:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpDisclUC"))
			{
				s0 = "";
				s1 = rm.GetString("sfpDisclLC") + sSpace;
			}
				//If the audit method is Compiled:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpCompUC"))
			{
				s0 = rm.GetString("sfpCompLC") + sSpace;
				s1 = "";
			}
				//If the audit method is Company Prepared:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpCoPpdUC"))
			{
				s0 = rm.GetString("sfpCoPpdLC") + sSpace;
				s1 = "";
			}
				//If the audit method is Adverse:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpAdvUC"))
			{
				s0 = "";
				s1 = rm.GetString("sfpAdvLC") + sSpace;
			}
				//If the audit method is Tax Return:
			else if (sAdtMthVal.ToUpper() == rm.GetString("sfpTaxRetUC"))
			{
				s0 = "";
				s1 = rm.GetString("sfpTaxRetLC") + sSpace;
			}
				///This section is for if the audit method is anything other than those 
				///listed above... (for example, empty).
			else if (sAdtMthVal == " ")
				s0 = "";
			else if (sAdtMthVal == "")
				s0 = "";
			else
				s1 = sAdtMthVal.ToLower() + sSpace;
			
			///Print the first line.
			s1 = string.Format(rm.GetString("sfpBaseOn") + sDot, s0, s1, sTimePeriod);
			Utility.PrintParagraph(RG, s1);
			
			// Skiped line between paragraph
			///This is the equivalent of skip when you don't have a table yet.
			Utility.PrintParagraph(RG, " ");

			s0 = "";
			s1 = "";
			//Line #2 starts with target currency if it is defined (s0).
			if (!string.IsNullOrWhiteSpace(sCurrencyTarget))
				s0 = string.Format(rm.GetString("sfpFinInfoTarget"), sCurrencyTarget);

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");

			//Then adding the detailed description of the size (s1, s2)
			if (RG.IND(94) > 0)
			{
				//The peer ...
				if (RG.IND(7) == 1)
					s2 = rm.GetString("sfpSingular");
				else
					s2 = rm.GetString("sfpPlural");
				s2 = string.Format(rm.GetString("sfpPeerGroup"), RG.IND(7), s2);

				if ((RG.IND_Category == (int)ePeerCategory.Assets) || (RG.IND_Category == (int)ePeerCategory.Sales))
				{
					// For comparative purposes, the analysis of this company uses RG.IND(94)
					s1 = string.Format(rm.GetString("sfpForCompPurp") + rm.GetString("sfpCompAnls") + sSpace +
						rm.GetString("sfpUse"), RG.IND(94));
					// data for the industry code ..., ... sorted by
					s1 = s1 + sSpace + string.Format(rm.GetString("sfpDataDescr"), RG.PEER_CODE, RG.IND_DESC);
					//assets size or sales size: 
					if (RG.IND_Category == (int)ePeerCategory.Assets)
						s1 = s1 + rm.GetString("sfpAssetsSize");
					else if (RG.IND_Category == (int)ePeerCategory.Sales)
						s1 = s1 + rm.GetString("sfpSalesSize");
					else
						s1 = s1 + "";
					// range.
					s1 = s1 + sSpace + string.Format(rm.GetString("sfpRange"), (RG.IND_SIZE).ToLower());
				}
				else if (RG.IND_Category ==(int)ePeerCategory.Totals)
				{
					//For all companies in the industry:
					s1 = string.Format(rm.GetString("sfpCapFirstLetter") + rm.GetString("sfpCompAnls") + sSpace + rm.GetString("sfpUse"), RG.IND(94));
					s1 = s1 + sSpace + string.Format(rm.GetString("sfpAllCompIn"), RG.PEER_CODE, RG.IND_DESC);
				}
				else
				{
					s1 = rm.GetString("sfpCapFirstLetter") + rm.GetString("sfpCompAnls") + sSpace + rm.GetString("sfpNoCompData");
					s2 = "";
				}
				s1 = s1 + s2;
			}
			else
			{
				if (RG.PEER_TYPE() == ePeerType.None)
					s1 = rm.GetString("sfpCapFirstLetter") + rm.GetString("sfpCompAnls") + sSpace + rm.GetString("sfpNoCompData");
				else if ((RG.IND_Category == (int)ePeerCategory.Assets) || (RG.IND_Category == (int)ePeerCategory.Sales) || (RG.IND_Category ==(int)ePeerCategory.Totals))
					s1 = string.Format(rm.GetString("sfpForCompPurp") + rm.GetString("sfpCompAnls") + sSpace + rm.GetString("sfpUse") + sDot, RG.IND_DESC);
			}
			///This is the equivalent of skip when you don't have a table yet.
			Utility.PrintParagraph(RG, s0 + sSpace + s1);
			Utility.PrintParagraph(RG, " ");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			//Table with numbers:
			Utility.CreateTable(RG, 3);
			FormatCommands.LoadFormatDefaults(RG);
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "10");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN, "15");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");

			//Create and print headers
			string[] Justif = new string[3];
			Justif[0] = Justif[1] = Justif[2] = "Left";

			string[] Labels = new string[3];
			Labels[0] = "";
			Labels[1] = rm.GetString("sfpModerate");
			Labels[2] = rm.GetString("sfpSignificant");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);
			
			Justif[0] = "Left";
			Justif[1] = Justif[2] = "Right";
			Labels[1] = "";
			Labels[2] = "";
			Utility.PrintColumnLabels(RG, Labels, false, Justif);
			
			//Print rows with values
			Labels[0] = rm.GetString("sfpSalesGwth");
			Labels[1] = RG.PARM(1).ToString("F2");
			Labels[2] = RG.PARM(2).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);
			
			Labels[0] = rm.GetString("sfpGrsMgnChg");
			Labels[1] = RG.PARM(3).ToString("F2");
			Labels[2] = RG.PARM(4).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpOpExpChg");
			Labels[1] = RG.PARM(5).ToString("F2");
			Labels[2] = RG.PARM(6).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpARDaysChg");
			Labels[1] = RG.PARM(7).ToString("F2");
			Labels[2] = RG.PARM(8).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpInvDaysChg");
			Labels[1] = RG.PARM(9).ToString("F2");
			Labels[2] = RG.PARM(10).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpAPDaysChg");
			Labels[1] = RG.PARM(11).ToString("F2");
			Labels[2] = RG.PARM(12).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpUCACFChg");
			Labels[1] = RG.PARM(15).ToString("F2");
			Labels[2] = RG.PARM(16).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpNetIncDpAmtCPLTDChg");
			Labels[1] = RG.PARM(17).ToString("F2");
			Labels[2] = RG.PARM(18).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpDbtTangWrthChg");
			Labels[1] = RG.PARM(19).ToString("F2");
			Labels[2] = RG.PARM(20).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpNtMgnChg");
			Labels[1] = RG.PARM(13).ToString("F2");
			Labels[2] = RG.PARM(14).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpEBITIntChg");
			Labels[1] = RG.PARM(21).ToString("F2");
			Labels[2] = RG.PARM(22).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpCurrRatio");
			Labels[1] = RG.PARM(25).ToString("F2");
			Labels[2] = RG.PARM(26).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpQuickRatio");
			Labels[1] = RG.PARM(27).ToString("F2");
			Labels[2] = RG.PARM(28).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpPBTTotTNW");
			Labels[1] = RG.PARM(32).ToString("F2");
			Labels[2] = RG.PARM(33).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;
			Utility.PrintParagraph(RG, " ");

			Labels[0] = rm.GetString("sfpPBTTotAst");
			Labels[1] = RG.PARM(34).ToString("F2");
			Labels[2] = RG.PARM(35).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpNetSalesFA");
			Labels[1] = RG.PARM(36).ToString("F2");
			Labels[2] = RG.PARM(37).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpNetSlsTotAst");
			Labels[1] = RG.PARM(38).ToString("F2");
			Labels[2] = RG.PARM(39).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpOpPftMgn");
			Labels[1] = RG.PARM(40).ToString("F2");
			Labels[2] = RG.PARM(42).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

            //log#1580 Label should say Operating Leverage
			//Labels[0] = rm.GetString("sfpOpExpGrsMgn");
            Labels[0] = rm.GetString("sfpOpLeverage");
			Labels[1] = RG.PARM(41).ToString("F2");
			Labels[2] = RG.PARM(43).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[2] = "";
			Labels[0] = rm.GetString("sfpCapExpOver");
			Labels[1] = RG.PARM(24).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpCapExpUnder");
			Labels[1] = RG.PARM(23).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			//Couple blank rows
			Labels[0] = "";
			Labels[1] = "";
			Labels[2] = "";
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Justif[0] = Justif[1] = Justif[2] = "Left";
			Labels[1] = rm.GetString("sfpAdeqt");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Justif[0] = "Left";
			Justif[1] = Justif[2] = "Right";
			Labels[1] = "";
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpUCACF");
			Labels[1] = RG.PARM(29).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpNetIncDpAmtCPLTD");
			Labels[1] = RG.PARM(31).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Labels[0] = rm.GetString("sfpEBITInt");
			Labels[1] = RG.PARM(30).ToString("F2");
			Utility.PrintColumnLabels(RG, Labels, false, Justif);;

			Utility.CloseReport(RG);
		}
	}
}
