using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
    /// <summary>
    /// Summary description for INPUT_CF_DIR.
    /// </summary>
    public class INPUT_CF_DIR : FinancialAnalyst.IReport
    {
        PRINTCOMMANDS Utility = new PRINTCOMMANDS();
        ReportGenerator RG = null;
        public void Execute(ReportGenerator RGG)
        {
            RG = RGG;
            CALCULATIONS Calcs = new CALCULATIONS();
            Calcs.InputCashFlowCalcs(RG);
            FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();
            Calcs.InputCFDIR_Calcs(RG);

            ///Load the resource manager.
            ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

            FormatCommands.LoadFormatDefaults(RG);

            ///This is where we load the standard column headers.
            Utility.LoadColumnHeadingDefaults(RG);
            //Remove the Audit Method & Accountant stmt constants added in the default.
            Utility.arrColHead.RemoveRange(1, 1);
            Utility.arrColHead.RemoveRange(2, 1);

            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
            RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
            RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows

            ///***CPF 3/11/02 This creates the standard page header for the report.  If
            ///this as new report, make sure the NewReport parm is "True"
            Utility.CreatePageHeader(RG);

            ///***CPF 3/11/02 This prints the statement constant rows
            Utility.PrintStmtConstRows(RG, 1);

            //amit: Start of the outer Group (Full Report)
            Utility.mT.AddStartRow(Utility.nRow + 1);

            int line406 = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_307")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_308")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_309")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_310")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_311")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_312")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_313"));

            int line407 = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_301")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_302")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_303")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_304")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_305")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_306"));


            int line408 = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_314")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_315")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_316")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_317")) +
                            FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_318")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_319"));


            int lineOther = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("F_320"));

            //Print OPERATING ACTIVITIES
            Utility.mT.AddStartRow(Utility.nRow + 1);
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");
            //amit: log# 1997
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            Utility.Skip(RG, 1);

            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            if (line406 > 0)
            {
                Utility.PrintLabel(RG, rm.GetString("icfOpAct"));
                RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            }
            printDetails(new int[]{ 307,308,309,310,311,312,313});
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
            if (line406 > 0)
                Utility.UnderlineColumn(RG, 1, 1);
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            Utility.PrintSummary(RG, rm.GetString("icfProOp"), RG.GetPrintOrderCalc(RG.GetCalc("cfFrmOprAct")));
            Utility.UnderlinePage(RG, 1);
            Utility.mT.AddEndRow(Utility.nRow);


            //Print INVESTING ACTIVITIES
            Utility.mT.AddStartRow(Utility.nRow + 1);
            if (line407 > 0)
                Utility.PrintLabel(RG, rm.GetString("icfInvAct"));
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

            printDetails(new int[]{301,302,303,304,305,306});

            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            if (line407 > 0)
                Utility.UnderlineColumn(RG, 1, 1);
            Utility.PrintSummary(RG, rm.GetString("icfUseInv"), RG.GetPrintOrderCalc(RG.GetCalc("cfFrmInvestAct")));
            Utility.UnderlinePage(RG, 1);
            Utility.mT.AddEndRow(Utility.nRow);


            //print financial activities
            Utility.mT.AddStartRow(Utility.nRow + 1);
			if (line408 > 0)
                Utility.PrintLabel(RG, rm.GetString("icfFinAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			printDetails( new int[]{314,315,316,317,318,319});
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			///CPF 07/27/06 Log 1691:  This line408 check was previously checking agains the wrong section (line407).
			if (line408 > 0)
				Utility.UnderlineColumn(RG,1, 1);
            Utility.PrintSummary(RG, rm.GetString("icfProFin"), RG.GetPrintOrderCalc(RG.GetCalc("cfFrmFinAct")));
			Utility.mT.AddEndRow(Utility.nRow);


            Utility.mT.AddStartRow(Utility.nRow + 1);
            if (lineOther > 0)
                Utility.PrintLabel(RG, rm.GetString("icfOther"));
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintDetail(RG, RG.GetDetailCalcs("F_320"));
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
            Utility.UnderlineColumn(RG, 1, 1);
            Utility.PrintSummary(RG, rm.GetString("icfChgInCashEquiv"), RG.GetPrintOrderCalc(RG.GetCalc("cfChgInCashEquiv")));


            RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("icfBegPerCashEquiv"), RG.GetPrintOrderCalc(RG.GetCalc("begOfPerCashEquiv")));

            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("icfUnexAdjCash"), RG.GetPrintOrderCalc(RG.GetCalc("unExplAdjToCash")));

            RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
            Utility.UnderlineColumn(RG, 1, 1);
            Utility.PrintSummary(RG, rm.GetString("icfEndPerCashEquiv"), RG.GetPrintOrderCalc(RG.GetCalc("endOfPerCashEquiv")));
            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            ///CPF 02/01/06 Log 1603:  This warning is no longer necessary.
            ///ExchRateWarnMsg.printWarning(RG, Utility, rm);
            Utility.UnderlinePage(RG, 2);
            Utility.mT.AddEndRow(Utility.nRow);


            //End: Keep together for Full Report
            Utility.mT.AddEndRow(Utility.nRow);
            Utility.CloseReport(RG);
        }

        private void printDetails(int[] ids)
        {
            string label = "";

            for (int i = 0; i < ids.Length; i++)
            {
                label = "F_" + ids[i].ToString();
                Utility.PrintDetail(RG, RG.GetDetailCalcs(label));
            }

        }

    }
}
