using System.Collections;
using System.Threading;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;

namespace MMAS
{
	/// <summary>
	/// CASH FLOW SUMMARY Report for consultant.
	/// </summary>
	public class CASH_FLOW_SUMMARY: FinancialAnalyst.IReport
	{
		
		/**
		 * 
		 * We are not using STMTS_OVERLAP and assuming that the overlap never occurs.
		 * All the numbers in comments represent the corresponding line numbers in MFA
		 * 
		**/

		private ResourceManager rm       = null;
		private FORMATCOMMANDS FmtCmnd   = null;
		private ReportGenerator RG       = null;
		private PRINTCOMMANDS Utility    = null;

		private int pBaseID = 0; //statement ID
		private int period  = 0; //statement period

		private string sAdtMthVal  = ""; //Audit Method
		private string sDate       = null; //Statement Date
		private string auditMethod = ""; //audit method
		private int indCat         = 0; //Industry Category
		private double cfNumStmts  = 0; // Number of statements in the cash flow
		private int cashAfterOp    = 0; //cashAfterOperation flag
				
		/** Calculated in init() method. Straight Macro
		 * Calls.
		 **/
		private Calc cashAfterOperation = null; //580
		private Calc cashSGAExpense		= null; //1616
		private Calc cashSGAExpenseLag	= null;
		private Calc grossMarginCash	= null; //1609 
		private Calc grossMarginCashLag = null;
		private Calc netSalesByFlow		= null; //1600
		private Calc netSalesByFlowLag	= null;
		private Calc otherAssetGrowth	= null; //1715
		private Calc otherAssetGrowthLag= null;
		private Calc accrualsGrowth		= null; //1745
		private Calc accrualsGrowthLag	= null;
		private Calc othCurLiabsGrowth	= null; //1760
		private Calc othCurLiabsGrowthLag = null;
		private Calc totTradeActMgmt	= null; //1770
		private Calc cashAfterOperations = null; //580
		private Calc mgmtEffOnOpProfit	= null; //1642 Mgmt Effect on Operating Profit
		

		/** Calculated within the code. Calculations are
		 * derived from the results of other calculations. 
		 * **/
		private Calc othAssetsMgmt			= null; //1725
		private Calc accuralsMgmt			= null; //1755
		private Calc othCurLiabMgmt			= null; //1768
		private Calc totTradeActChange		= null; //1772
		private Calc netSalesGrByFlow		= null; //
		private Calc tradeActGrowth			= null; //1771
		private Calc cashAfterDebtAmort		= null; //710
		private Calc cashAfterDebtAmortLag	= null; //
		private Calc grEffOnOthCurAssets    = null; //1720 Growth Effect on Other Current Assets
		private Calc grEffOnAccruals        = null; //1750 Growth Effect on Accruals
		private Calc grEffOnOthCurLiab      = null; //1765 Growth Effect on Other Current Liabilities

		public CASH_FLOW_SUMMARY()
		{}

		public void Execute(ReportGenerator RGG)
		{
			RG = RGG;
            init();
			findStmtID();
			intro(); 
			overview();
			cashEffectMgmt();
			cashMarginMgmt();
			tradeAcctMgmt();
			salesGrowthImpact();
			Utility.PrintParagraph(RG, " ");
			Utility.PrintNotes(RG);
			//Utility.CloseReport(RG);
		}

		private void init ()
		{
			rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);
			FmtCmnd = new FORMATCOMMANDS();
			Utility = new PRINTCOMMANDS();
			FmtCmnd.LoadFormatDefaults(RG);
			
			Utility.CreatePageHeader(RG, true);
			//Utility.CreateTable(RG, 1);
						
			#region Common Macro Calls
			/** 
			 *  These values are used in varios places in the code 
			 **/

			//c580
			cashAfterOperation  = RG.MACRO(M.CASH_AFTER_OPERATIONS);
			//1616 
			cashSGAExpense = RG.MACRO(M.QC_OPERATING_EXPENSE_EXCL_DEPR);
			cashSGAExpenseLag = RG.MACRO(M.QC_OPERATING_EXPENSE_EXCL_DEPR, RG.LAG);
			//1609 
			grossMarginCash = RG.MACRO(M.QC_GROSS_MARGIN_CASH);
			grossMarginCashLag = RG.MACRO(M.QC_GROSS_MARGIN_CASH, RG.LAG);
			//1600
			netSalesByFlow = RG.MACRO(M.QC_NET_SALES_BY_FLOW);
			netSalesByFlowLag = RG.MACRO(M.QC_NET_SALES_BY_FLOW, RG.LAG);
			//1715 
			otherAssetGrowth = RG.MACRO(M.CFS_OTH_ASSETS_GROWTH);
			otherAssetGrowthLag = RG.MACRO(M.CFS_OTH_ASSETS_GROWTH, RG.LAG);
			//1745
			accrualsGrowth = RG.MACRO(M.CFS_ACCRUALS_GROWTH);
			accrualsGrowthLag = RG.MACRO(M.CFS_ACCRUALS_GROWTH, RG.LAG);
			//1760
			othCurLiabsGrowth = RG.MACRO(M.CFS_OTH_CURR_LIAB_GROWTH);
			othCurLiabsGrowthLag = RG.MACRO(M.CFS_OTH_CURR_LIAB_GROWTH, RG.LAG);
			//1770
			totTradeActMgmt = RG.MACRO(M.QC_AR_CASH_EFFECT) +
							  RG.MACRO(M.QC_MGMT_OF_AP) +
							  RG.MACRO(M.QC_MGMT_OF_INVENTORY);
			//580
			cashAfterOperations = RG.MACRO(M.CASH_AFTER_OPERATIONS);
			//1765
			netSalesGrByFlow = RG.MACRO(M.QC_NET_SALES_GROWTH_BY_FLOW);
			//710
			cashAfterDebtAmort = RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION);
			cashAfterDebtAmortLag = RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION, RG.LAG);
			//1642
			mgmtEffOnOpProfit = RG.MACRO(M.QC_OE_CASH_EFFECT);
			#endregion Macro Calls

		}

		
		public void findStmtID()
		{
			int BaseId = RG.BaseStatementID;
			//This variable will store the stmt index of the base comparison stmt
			pBaseID = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);
			//24 (Number of Statments in Cash Flow)
			//06/09/04: Modified the ACCUMUATE method to return actual number of statements
			//therefore need to subtract one for Cash Flow;
			cfNumStmts = RG.CALC_ACCUMULATE(new Calc(1, RG.Statements.Count), 3)[pBaseID] - 1;
		}

		public void intro ()
		{
			string header = "";
			int ind = 0;
				
			sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[pBaseID].ToString()).ToLower();
			period = (int)(RG.STMT_PERIODS()[pBaseID]);
			sDate = Convert.ToDateTime(RG.STMT_DATE()[pBaseID]).ToShortDateString();
			int month = (int)(RG.STMT_MONTH()[pBaseID]);
			int year = (int)(RG.STMT_YEAR()[pBaseID]);
		    int dbType = RG.DATABASE_TYPE();

			if (dbType == 3) indCat = dbType;

			ind = (RG.IND(94) > 0) ? 4 : 0;

			if (dbType != 4) //4 = No Peer Database Selected
			{
				if (RG.IND_Category == (int)ePeerCategory.Assets)
					indCat= 1;
				else if (RG.IND_Category == (int)ePeerCategory.Sales)
					indCat= 2;
				else if (RG.IND_Category == (int)ePeerCategory.Totals)
					indCat = 3;
				indCat = indCat + ind;
			}
			
			#region Audit Type Compare			
			if (rm.GetString("fsUnqUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsUnQalified").ToLower();
				auditMethod = "unqualified";
			}
			else if (rm.GetString("fsTxRetUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsTxRetUC").ToLower();
				auditMethod = "taxreturn";
			}
			else if (rm.GetString("fsRevUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsRevUC").ToLower();
				auditMethod = "reviewed";
			}
			
			else if (rm.GetString("fsQualUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsQualUC").ToLower();
				auditMethod = "qualified";
			}
			else if (rm.GetString("fsCompUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsCompUC").ToLower();
				auditMethod = "compiled";
			}
			else if (rm.GetString("fsCoPpdUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsCoPpd");
				auditMethod = "companyprepared";
			}
			else if (rm.GetString("fscivProj").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fscivProj");
				auditMethod = "projection";
			}
			else if (rm.GetString("fsDiscUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsDiscUC").ToLower();
				auditMethod = "disclaimer";
			}
			else if (rm.GetString("fsAdvUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsAdvUC").ToLower();
				auditMethod = "adverse";
			}
			#endregion Audit Type Compare

			#region Audit Desc
			if (period == 12)
			{
				if (auditMethod.Equals("taxreturn"))
					this.printReport("", rm.GetString("fsBsdTxRtFY") + " " + year, true);
				else if (auditMethod.Equals("disclaimer"))
					this.printReport("", rm.GetString("fsBsdDscFY") + " " + year, true);
				else if (auditMethod.Equals("adverse"))
					this.printReport("", rm.GetString("fsBsdAdvOp") + " " + year, true);
				else if (auditMethod != "")
					this.printReport("", string.Format(rm.GetString("fsbasedAnnual"), " " +sAdtMthVal+" ", year), true );
				else 
					this.printReport("", string.Format(rm.GetString("fsbasedAnnual"), " ", year), true );
					
			}
			else
			{
				if (auditMethod.Equals("taxreturn"))
					this.printReport("", string.Format(rm.GetString("fsbaseTaxInterim"), period, sDate), true);
				else if (auditMethod.Equals("disclaimer"))
					this.printReport("", string.Format(rm.GetString("fsbaseDisInterim"), period, sDate), true );
				else if (auditMethod.Equals("adverse"))
					this.printReport("", string.Format(rm.GetString("fsbasedAdvInterim"), period, sDate), true );
				else if (auditMethod != "") 
					this.printReport("", string.Format(rm.GetString("fsbasedInterim"), " " +sAdtMthVal +" ", period, sDate), true );
				else
					this.printReport("", string.Format(rm.GetString("fsbasedInterim"), " ", period, sDate), true );
			}
			#endregion Audit Desc

			#region Industry Category
			string s1 = "";
			switch (indCat)
			{
				case 0:
					s1 = rm.GetString("fsCompare3");
					break;
				case 1: 
					s1 = string.Format(rm.GetString("fsCompare1"), RG.IND_DESC);
					break;
				case 2: 
					goto case 1;
				case 3: 
					goto case 1;
				case 4:
					goto case 0;
				case 5:
					s1 =  string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpAssetsSize"), RG.IND_SIZE, RG.IND(7));
					break;
				case 6:
					s1 = string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpSalesSize"), RG.IND_SIZE, RG.IND(7));
					break;
				case 7:
					s1 = string.Format(rm.GetString("fsCompare4"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, RG.IND(7));
					break;
				default:
					break;
			}
			#endregion Industry Category

			
			//Currency 
			if (! RG.LANGCONSTANT(4)[pBaseID].ToString().Equals(""))
			{
				string targetCur = RG.TARGETCURRENCY(0)[0].ToString();
				s1 = string.Format(rm.GetString("qcFinInfoTarget"), targetCur) + " " + s1;
				this.printReport(header,  s1, true);
			}
			else
				this.printReport(header, s1, true );

			//interim statements comment
			if (period != 12)
				this.printReport(header, rm.GetString("fsInterimWarn"), true );
			
		}

		private void overview()
		{
			//printReport("OVERVIEW", "", true);
			printReport(rm.GetString("cfsOverview"), "", true);
			
			//Utility.indentLeft = 55;
															
			#region Calculation for Overview

			//1765
			grEffOnOthCurLiab = (othCurLiabsGrowthLag *  netSalesGrByFlow /100);
			//1768
			othCurLiabMgmt = othCurLiabsGrowth - grEffOnOthCurLiab - othCurLiabsGrowthLag;
			//1749
			Calc c1749 = (cashSGAExpense/RG.YEAR() - 
					      cashSGAExpenseLag/RG.YEAR(RG.LAG)) %
						 (cashSGAExpenseLag/(RG.YEAR(RG.LAG)));
			//1750
			grEffOnAccruals = accrualsGrowthLag * c1749/100;
			//1755
			accuralsMgmt = accrualsGrowth - grEffOnAccruals -	accrualsGrowthLag;
			//1720
			grEffOnOthCurAssets = (-1) * otherAssetGrowthLag * netSalesGrByFlow / 100;
			//1725
			othAssetsMgmt = otherAssetGrowthLag - grEffOnOthCurAssets - otherAssetGrowth;

			Calc growthDueToCOGS = null;
			//1705 Growth Effect On Inventory
			Calc growthEffOnInentory = null;
			if (RG.MACRO(M.QC_CASH_COGS)[pBaseID] == 0)
			{		
				//1728
				growthDueToCOGS = RG.MACRO(M.QC_AP_GROWTH_TO_SALES, RG.LAG) * netSalesGrByFlow/100;
				//1705
				growthEffOnInentory = (-1) * RG.MACRO(M.QC_INV_GWTH_DUE_TO_SALES, RG.LAG) * netSalesGrByFlow/100;
			}
			else
			{
				//1728
				growthDueToCOGS = RG.MACRO(M.QC_AP_GROWTH_TO_SALES, RG.LAG) * RG.MACRO(M.QC_COGS_GROWTH)/100;
				//1705
				growthEffOnInentory = (-1) * RG.MACRO(M.QC_INV_GWTH_DUE_TO_SALES, RG.LAG) * RG.MACRO(M.QC_COGS_GROWTH)/100;
			}
										
			
			//1771
			tradeActGrowth = RG.MACRO(M.QC_AR_GROWTH_TO_SALES) + growthEffOnInentory + growthDueToCOGS;
			//1772
			totTradeActChange = totTradeActMgmt + tradeActGrowth + othAssetsMgmt +
								accuralsMgmt + othCurLiabMgmt + grEffOnOthCurAssets + 
								grEffOnAccruals + grEffOnOthCurLiab;
			//1645
			Calc operatingProfit =  grossMarginCash - cashSGAExpense;
			
			#endregion Calculation for Overview
			
			#region 3899 CASH AFTER OPERATIONS

			if ((cashAfterOperations[pBaseID] > 0) && (operatingProfit[pBaseID] > 0) &&
				(operatingProfit[pBaseID] + totTradeActChange[pBaseID] > 0) &&
				(totTradeActChange[pBaseID] < 0))
			{
				//3281 = abs of totTradeActChange(1772)
				//582 = abs of cashAfterOperations(580)  
				this.printReport("", string.Format(rm.GetString("cfsCashAfterOp_a"), 
					                               FmtCmnd.RoundToReport(RG, Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
					                               FmtCmnd.RoundToReport(RG, Math.Abs(cashAfterOperations[pBaseID])).ToString("N0")),true);
				cashAfterOp= 67;
			}
			else if( (cashAfterOperations[pBaseID] > 0) && (operatingProfit[pBaseID] < 0) &&
				(operatingProfit[pBaseID] + totTradeActChange[pBaseID] > 0) &&
				(totTradeActChange[pBaseID] > 0))
			{
				this.printReport("", string.Format(rm.GetString("cfsCashAfterOp_b"), 
													FmtCmnd.RoundToReport(RG, Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
													FmtCmnd.RoundToReport(RG, Math.Abs(cashAfterOperations[pBaseID])).ToString("N0")),true);
				cashAfterOp= 33;
			}
			else if((cashAfterOperations[pBaseID] < 0) && (operatingProfit[pBaseID] > 0) &&
				(operatingProfit[pBaseID]+ totTradeActChange[pBaseID] < 0) &&
				(totTradeActChange[pBaseID] < 0))
			{
				this.printReport("", string.Format(rm.GetString("cfsCashAfterOp_c"), 
													FmtCmnd.RoundToReport(RG, Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
													FmtCmnd.RoundToReport(RG, cashAfterOperations[pBaseID]).ToString("N0")),true);
				cashAfterOp= 77;
			}
			else if((cashAfterOperations[pBaseID] < 0) && (operatingProfit[pBaseID] < 0) &&
				(operatingProfit[pBaseID] + totTradeActChange[pBaseID] < 0) &&
				(totTradeActChange[pBaseID] < 0))
			{
				
				this.printReport("",string.Format(rm.GetString("cfsCashAfterOp_d"), 
													FmtCmnd.RoundToReport(RG, Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
													FmtCmnd.RoundToReport(RG, Math.Abs(cashAfterOperations[pBaseID])).ToString("N0")),true);
                cashAfterOp= 80;
			}

			#endregion 3899

			#region 3920 NET CASH AFTER OPERATIONS

			//650
			Calc netCashAfterOp = RG.MACRO(M.NET_CASH_AFTER_OPERATIONS);
			//687
			Calc cashAfterFin = RG.MACRO(M.NET_CASH_INCOME);
			//682
			Calc cashPaidDivd = RG.MACRO(M.FS_CASH_PAID_DIVDENDS);

			string text = "";
			
			if (netCashAfterOp[pBaseID] == cashAfterDebtAmort[pBaseID])
			{
				if ((cashAfterDebtAmort[pBaseID] < 0) && (cashAfterFin[pBaseID] < 0) &&
					(netCashAfterOp[pBaseID] < 0) )
				{
					this.printReport("", rm.GetString("cfsNetCashAfterOp_f"), true);
				}
				else if ((cashAfterDebtAmort[pBaseID] > 0) && (netCashAfterOp[pBaseID] > 0) &&
					(cashAfterFin[pBaseID] > 0))
				{
					this.printReport("", rm.GetString("cfsNetCashAfterOp_b"), true);
				}
			}
			else
			{
				if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] > 0) &&
						 (cashAfterDebtAmort[pBaseID] > 0) && (cashPaidDivd[pBaseID] < 0))
				{
					//for the period  , dvidends,(40) 
					/*
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_a"), 
                                                                rm.GetString("cfsForThePeriod"),
						                                        rm.GetString("cfsDiv"))
									   , true);
					*/
					text = string.Format(rm.GetString("cfsNetCashAfterOp_a"), 
                                                                rm.GetString("cfsForThePeriod"),
						                                        rm.GetString("cfsDiv"));
				}
				else if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] > 0) &&
					(cashAfterDebtAmort[pBaseID] > 0))
				{
					//this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_a"), "", "")
					//				   , false);
					text = string.Format(rm.GetString("cfsNetCashAfterOp_a"), "", "");
					
				}
				else if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] > 0) &&
					(cashAfterDebtAmort[pBaseID] < 0) && (cashPaidDivd[pBaseID] < 0))
				{
					//space and dividends(49) L715 period 
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_c"),
						" " + rm.GetString("cfsAndDivid") + ".", 
						FmtCmnd.RoundToReport(RG, Math.Abs(cashAfterDebtAmort[pBaseID])).ToString("N0"))
						, true);

					printCashAfterOPBullets();
					this.printReport("", rm.GetString("cfsNetCashAfterOp_d"), true);
				}
				else if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] > 0) &&
					(cashAfterDebtAmort[pBaseID] < 0))
				{
					// . L715
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_c"),
															".", 
															FmtCmnd.RoundToReport(RG, Math.Abs(cashAfterDebtAmort[pBaseID])).ToString("N0"))
									   , true);
					printCashAfterOPBullets();
					this.printReport("", rm.GetString("cfsNetCashAfterOp_d"), true);
				}
				else if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] < 0) &&
					(cashAfterDebtAmort[pBaseID] < 0))
				{
					//however nothing
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_e"),
																rm.GetString("cfsHowever"),
																"")
									   , true);
					printCashAfterOPBullets();
					this.printReport("", rm.GetString("cfsNetCashAfterOp_d"), true);

				}
				else if ((netCashAfterOp[pBaseID] > 0) && (cashAfterFin[pBaseID] < 0) &&
					(cashAfterDebtAmort[pBaseID] < 0) && (cashAfterDebtAmort[pBaseID] > 0))
				{
					
					//but  , dvidends,
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_e"),
						                                        rm.GetString("cfsBut"),
						                                        rm.GetString("cfsDiv"))
						               , true);

					printCashAfterOPBullets();
					this.printReport("", rm.GetString("cfsNetCashAfterOp_d"), true);
				}
				else if ((netCashAfterOp[pBaseID] < 0) && (cashAfterFin[pBaseID] < 0) &&
					(cashAfterDebtAmort[pBaseID] < 0) && (cashPaidDivd[pBaseID] < 0))
				{
					//, its dividends, or
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_g"),
						rm.GetString("cfsDivdOr"))
						, true);
				}
				else if ((netCashAfterOp[pBaseID] < 0) && (cashAfterFin[pBaseID] < 0) &&
					(cashAfterDebtAmort[pBaseID] < 0))
				{
					//space and/or
					this.printReport("", string.Format(rm.GetString("cfsNetCashAfterOp_g"),
						                                        " " + rm.GetString("cfsAndOr"))
						                        , true);
									 
				}

			}
			#endregion 3920

			#region 3860 NET CASH AFTER OPERATIONS DESC 
									
			if ( cashAfterDebtAmort[pBaseID] > 0) 
			{
				//amit: 07/07/04 Multiplication by -1 is not returning the correct value in MFA. Multiplying by -1 again out here
				// to balance out the -1 multiplication in the Macro which will give similar result as MFA.
				//LINE(3855,LAST)
				double otherOperatingCF = (-1) * NaNCheck(RG.MACRO(M.FS_OTH_OPER_CASH_FLOW)[pBaseID]);
				
				if ( cashAfterDebtAmort[pBaseID] < otherOperatingCF)
				{
					
					text = text + string.Format(rm.GetString("cfscashAfterOpDesc"),
						                               FmtCmnd.RoundToReport(RG, otherOperatingCF).ToString("N0"));
					/*
					this.printReport("", string.Format(rm.GetString("cfscashAfterOpDesc"),
						                               FmtCmnd.RoundToReport(RG, otherOperatingCF).ToString("N0"))           
						               , true);
					*/
				}
			}

			if (text != "")
				this.printReport("", text, true);

			#endregion 3860

			#region 3980  CASH FLOW
			
			//d3967
			//double avgCashAfterDebtAmort = RG.CALC_ACCUMULATE(cashAfterDebtAmort, 2)[pBaseID];
			double avgCashAfterDebtAmort = RG.CALC_ACCUMULATE(cashAfterDebtAmort, 1)[pBaseID]/this.cfNumStmts;

						
			//WE are not using STMTS_OVERLAP and assuming that the overlap never occurs;
			
			int i3980 = 0;
			//number of Cash After Debt Amortization value greater than 0
			double d3928 = RG.CALC_ACCUMULATE(cashAfterDebtAmort, 4)[pBaseID];
			//number of netCashAfterOp that are > 0
			double d3943 = RG.CALC_ACCUMULATE(netCashAfterOp, 4)[pBaseID];
			//flag to display the mix Message
			bool isMixedMessage = true;
			
			if ((cfNumStmts > 2) &&  (d3943 == this.cfNumStmts))
			{
				if (d3928 == this.cfNumStmts)
				i3980++;

				
				if (avgCashAfterDebtAmort > 0)
				{
					//This block of for loop duplicates the DO_IF_ANY call 
					//in MFA
					
					for (int i=0; i < cashAfterDebtAmort.Count; i++)
					{
						if ((cashAfterDebtAmort[i] > 0) && (cashAfterDebtAmortLag[i] > 0))
						{
							i3980 = i3980 + 2;
							break;
						}

					}
				}
								
			}
			
			if (i3980 > 0)
			{
				//LINE(24,LAST) LINE(3967,LAST)    3980
				printReport("", string.Format(rm.GetString("cfsExmCashFlow"),
															this.cfNumStmts,
															FmtCmnd.RoundToReport(RG, avgCashAfterDebtAmort).ToString("N0"))
							, true);
				isMixedMessage = false;
			}

			#endregion 3980 

			//How many cashAfter Debt Amort < 0
			double d3932 = RG.CALC_ACCUMULATE(cashAfterDebtAmort, 5)[pBaseID];
							
			#region 3985 CASH FLOW

				if ( (cfNumStmts > 2) && (d3932 == cfNumStmts))
				{
					
					//LINE(24,LAST) LINE(3967,LAST)
					this.printReport("", string.Format(rm.GetString("cfsExmCFpoor"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG, avgCashAfterDebtAmort).ToString("N0"))
										, true);
					isMixedMessage = false;
				}
				#endregion 3985

			#region 3988 CASH FLOW
			
			if ((cfNumStmts > 2) && (avgCashAfterDebtAmort < 0) && (d3932 == 2))
			{
					//LINE(24,LAST) LINE(24,LAST) LINE(3967,LAST)
					printReport("", string.Format(rm.GetString("cfsExmCFweak"),
									this.cfNumStmts, this.cfNumStmts,
									FmtCmnd.RoundToReport(RG, avgCashAfterDebtAmort).ToString("N0"))
								  , true);
					isMixedMessage = false;
			}
			#endregion 3988
				
			
			#region 3990 CASH FLOW PERFORMANCE
			if ((cfNumStmts == 2) && (cashAfterDebtAmort[pBaseID] > 0) && 
				(cashAfterDebtAmortLag[pBaseID] < 0))
			{
				printReport("", rm.GetString("cfsCFPerfImp"), true);
				isMixedMessage = false;
			}
			#endregion 3990

			#region 3992 CASH FLOW PERFORMANCE DESC

			if ((cfNumStmts == 2) && (cashAfterDebtAmort[pBaseID] < 0) && 
				(cashAfterDebtAmortLag[pBaseID] > 0))
			{
					printReport("", rm.GetString("cfsCFPerfDec"), true);
					isMixedMessage = false;
			}
			#endregion 3992
				
			
			#region 3997 CASH FLOW TREND
			
			    if ((this.cfNumStmts > 2) && (isMixedMessage))
				{
					//LINE(3945,LAST) LINE(24,LAST)
					//3945 = (24 - 3932)    
					printReport("", string.Format(rm.GetString("cfsExmCFmix"), 
															(this.cfNumStmts - d3932).ToString("N0"),
															this.cfNumStmts)						
										  , true);
				}
			#endregion 3997
			
						
		}

		private void printCashAfterOPBullets()
		{
			this.printReport("", rm.GetString("cfsReasons_a"), true);
			this.printReport("", rm.GetString("cfsReasons_b"), true);
			this.printReport("", rm.GetString("cfsReasons_c"), true);
			this.printReport("", rm.GetString("cfsReasons_d"), true);
			this.printReport("", rm.GetString("cfsReasons_e"), true);
		}

		private void cashEffectMgmt()
		{
			//Utility.indentLeft = 45;
			//printReport("CASH EFFECT OF MANAGEMENT", "", true);
			printReport(rm.GetString("cfsCashEffMgmt"), "", true);
			//Utility.indentLeft = 55;
			
			#region 710 CASH EFFECT MGMT
			
			if (cashAfterDebtAmort[pBaseID] < 0)
				printReport("", rm.GetString("cfsCEMinable"), true);
			else
				printReport("", rm.GetString("cfsCEMable"), true);
			
			#endregion 710

		}

		private void cashMarginMgmt()
		{
						
			#region 1610 PROFITABILITY
			//1610
			Calc cashMargin =(grossMarginCash%netSalesByFlow);
			//1615
			//Calc cashMarginLag = (grossMarginCashLag%netSalesByFlowLag);
			double cashMarginLag = NaNCheck((grossMarginCashLag%netSalesByFlowLag)[pBaseID]);
			
			//DEBUG
			double d1610 = cashMargin[pBaseID];
			//double d1615 = cashMarginLag[pBaseID];
			//DEBUG END

			//1637
			//also use in region 4130
			Calc mgmtEffOnGrossProfit = RG.MACRO(M.QC_GM_CASH_EFFECT);
			//d3265 = Math.Abs(c1637[pBaseID]);
									        
			if (cashMargin[pBaseID] > cashMarginLag)
			{
				//'increased from' LINE(1615,LAST):2 LINE(1610,LAST):2 increased LINE(3265,LAST)
				printReport(rm.GetString("cfsCashMarginMgmt"), string.Format(rm.GetString("cfsGrossProfit"),
											  rm.GetString("cfsIncreaseFrom"),
											  cashMarginLag.ToString("N2"),
											  cashMargin[pBaseID].ToString("N2"),
											  rm.GetString("cfsIncreased"),
											  FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnGrossProfit[pBaseID])).ToString("N0")), true);
					                          
					                          
			}
			else if (cashMargin[pBaseID] < cashMarginLag)
			{
				//'declined from' LINE(1615,LAST):2 LINE(1610,LAST):2 reduced LINE(3265,LAST)
				printReport(rm.GetString("cfsCashMarginMgmt"), string.Format(rm.GetString("cfsGrossProfit"),
												rm.GetString("cfsDeclineFrom"),
												cashMarginLag.ToString("N2"),
												cashMargin[pBaseID].ToString("N2"),
												rm.GetString("cfsReduced"),
												FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnGrossProfit[pBaseID])).ToString("N0")), true);
			}
			else
			{
				//LINE(1610,LAST):2
			    printReport(rm.GetString("cfsCashMarginMgmt"), string.Format(rm.GetString("cfsGrossProfitsame"),
												cashMargin[pBaseID].ToString("N2"))
												, true);
			}
			
			#endregion 1610

			#region 4169 CUMULATIVE EFFECT ON CASH

			
			//c1638
			double cumMgmtEffOnGrossProfit = RG.CALC_ACCUMULATE(mgmtEffOnGrossProfit, 1)[pBaseID];
			//1639 
			//double avgMgmtEffOnGrossProfit = RG.CALC_ACCUMULATE(mgmtEffOnGrossProfit, 2)[pBaseID];
			double avgMgmtEffOnGrossProfit = RG.CALC_ACCUMULATE(mgmtEffOnGrossProfit, 1)[pBaseID]/this.cfNumStmts;

			//LINE(24,LAST) LINE(1638,LAST) LINE(1639,LAST)
			if ( this.cfNumStmts > 1)
			    printReport("", string.Format(rm.GetString("cfsCumEffectCash"), this.cfNumStmts,
													FmtCmnd.RoundToReport(RG,cumMgmtEffOnGrossProfit).ToString("N0"),
													FmtCmnd.RoundToReport(RG,avgMgmtEffOnGrossProfit).ToString("N0")), true);
													
			#endregion 4169

			//c1617 SG&A %
			//Calc SGApercent = cashSGAExpense%netSalesByFlow;
			double SGApercent = NaNCheck((cashSGAExpense%netSalesByFlow)[pBaseID]);
			//c1618 SG&A % Lag
			//Calc SGApercentLag = cashSGAExpenseLag % netSalesByFlowLag;
			double SGApercentLag = NaNCheck((cashSGAExpenseLag % netSalesByFlowLag)[pBaseID]);
			//SGApercentLag = (SGApercentLag);

			#region 4120 OPERATING EXPENSE

			
			if ( (SGApercent != 0) && (SGApercentLag == 0) && 
				 (SGApercent > SGApercentLag))
			{
				//LINE(1618,LAST):2 LINE(1617,LAST):2 LINE(3262,LAST)
				printReport("", string.Format(rm.GetString("cfsOPExpense"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);
			}
			else if ( (SGApercent == 0) && (SGApercentLag != 0) && 
				      (SGApercent > SGApercentLag))
			{
				printReport("", string.Format(rm.GetString("cfsOPExpense"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);
			}
			else if ( (SGApercent != 0) && (SGApercentLag != 0) && 
				      (SGApercent > SGApercentLag))
			{
				printReport("", string.Format(rm.GetString("cfsOPExpense"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);
			}
			else if ( (SGApercent != 0) && (SGApercentLag == 0) && 
				      (SGApercent < SGApercentLag))
			{
				printReport("", string.Format(rm.GetString("cfsOPExpDecr"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);
			}
			else if ( (SGApercent == 0) && (SGApercentLag != 0) && 
				      (SGApercent < SGApercentLag))
			{
				printReport("", string.Format(rm.GetString("cfsOPExpDecr"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);
			}
			else if ( (SGApercent != 0) && (SGApercentLag != 0) && 
				      (SGApercent < SGApercentLag))
			{
				printReport("", string.Format(rm.GetString("cfsOPExpDecr"),
														SGApercentLag.ToString("N2"),
														SGApercent.ToString("N2"),
														FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnOpProfit[pBaseID])).ToString("N0"))
										, true);	
			}
			else if ( (SGApercent != 0) && (SGApercentLag != 0) && 
				      (SGApercent == SGApercentLag))
			{
				//LINE(1617,LAST):2
				printReport("", string.Format(rm.GetString("cfsOPExpSame"),
														SGApercent.ToString("N2"))
										, true);
			}
			else if ( (SGApercent == 0) && (SGApercentLag == 0) && 
				      (SGApercent == SGApercentLag))
			{
				printReport("", rm.GetString("cfsOPExpZero"), true);
			}

			#endregion 4120 

			#region 4155 CHNG IN OPER EXPENSE

			//1643 cumulative mgmtEffOnOpProfit
			double cumMgmtEffOnOpProfit = RG.CALC_ACCUMULATE(mgmtEffOnOpProfit, 1)[pBaseID];
			//1644 average mgmtEffOnOpProfit
			//double avgMgmtEffOnOpProfit = RG.CALC_ACCUMULATE(mgmtEffOnOpProfit, 2)[pBaseID];
			double avgMgmtEffOnOpProfit = RG.CALC_ACCUMULATE(mgmtEffOnOpProfit, 1)[pBaseID] /this.cfNumStmts;
			if ((Math.Round(cumMgmtEffOnOpProfit, 4) != 0) && (this.cfNumStmts > 1))
			{
				//LINE(24,LAST) LINE(1643,LAST) LINE(1644,LAST)
				printReport("", string.Format(rm.GetString("cfsCumEffectOE"),
												this.cfNumStmts, 
												FmtCmnd.RoundToReport(RG, cumMgmtEffOnOpProfit).ToString("N0"),
												FmtCmnd.RoundToReport(RG, avgMgmtEffOnOpProfit).ToString("N0")), true);
			}
			else if ((Math.Round(cumMgmtEffOnOpProfit, 4) == 0) && (this.cfNumStmts > 1))
			{
				//LINE(24,LAST)
				printReport("", string.Format(rm.GetString("cfsCumEffectOEZero"), this.cfNumStmts), true);
			}
			#endregion 4155 

			#region 4130 CHNG IN GROSS PROFIT

			/** 3266 = 3268 = Math.abs(3266)
			double d3268 = Math.Abs((RG.MACRO(M.QC_GM_CASH_EFFECT)[pBaseID] + RG.MACRO(M.QC_OE_CASH_EFFECT)[pBaseID]));
			**/
			if ( ! ((SGApercent == 0) && (SGApercentLag == 0) && 
				    (SGApercent == SGApercentLag)))
			{
				//3266 Mgmt Effect on Gross Profit - Op Expense
				double mgmtEffOnGPOE = Math.Round((mgmtEffOnGrossProfit[pBaseID] + mgmtEffOnOpProfit[pBaseID]), 4);
				if (mgmtEffOnGPOE > 0)
				{
					//positive LINE(3268,LAST)
					printReport("", string.Format(rm.GetString("cfsChgGPOE"), 
															rm.GetString("qcPositive"),
															FmtCmnd.RoundToReport(RG, Math.Abs(mgmtEffOnGPOE)).ToString("N0")), true);
				}
				else if (mgmtEffOnGPOE < 0)
				{
					//negative LINE(3268,LAST)
					printReport("", string.Format(rm.GetString("cfsChgGPOE"), 
															rm.GetString("qcNegative"),
															FmtCmnd.RoundToReport(RG,Math.Abs(mgmtEffOnGPOE)).ToString("N0")), true);
				}
				else
				{
					printReport("", rm.GetString("cfsChgGPOEZero"), true);
				}
				
			}
			#endregion 4130 

		}

		private void tradeAcctMgmt()
		{		
			//printReport("TRADING ACCOUNT MANAGEMENT", "", true);
			printReport(rm.GetString("cfsTradAcctMgmt"), "", true);
			
			#region 3589 ACCOUNTS RECEIVABLE

			//970
			//Calc netRcvDaysOnHand = new Calc(0, RG.POStatements.Count);
			double netRcvDaysOnHand = 0;
			//971
			//Calc netRcvDaysOnHandLag = new Calc(0, RG.POStatements.Count);
			double netRcvDaysOnHandLag = 0;
			
			if (RG.MACRO(M.CFS_AR_BAD_DEBT)[pBaseID] > 0)
			{
				//970
				netRcvDaysOnHand = NaNCheck(RG.MACRO(M.CFS_NET_REC_DAYS_ON_HAND)[pBaseID]);
				
				//971
				netRcvDaysOnHandLag = NaNCheck(RG.MACRO(M.CFS_NET_REC_DAYS_ON_HAND, RG.LAG)[pBaseID]);
				
			}
			//CASH FLOW IMPACT OF A/R MANAGEMENT
			//1660
			double arCashEffect = NaNCheck(RG.MACRO(M.QC_AR_CASH_EFFECT)[pBaseID]);
			
			//2989 = ABSOLUTE VALUE OF CASH FLOW IMPACT OF A/R MANAGEMENT(1660)
				
			//1661 CUMULATIVE
			Calc cumARCashEffect = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_AR_CASH_EFFECT), 1);
			//1662 AVERAGE
			//double avgARCashEffect = RG.CALC_ACCUMULATE(arCashEffect, 2)[pBaseID];
			double avgARCashEffect = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_AR_CASH_EFFECT), 1)[pBaseID] / this.cfNumStmts;
			int i3589 = 0;
			if (netRcvDaysOnHand == 0)
				i3589++;
			if (netRcvDaysOnHandLag == 0)
				i3589++;
			if (netRcvDaysOnHand == netRcvDaysOnHandLag)
				i3589 = i3589 + 4;
			else if (netRcvDaysOnHand > netRcvDaysOnHandLag)
				i3589 = i3589 + 2;
			if (this.cfNumStmts > 1) i3589 = i3589 + 7;
			//Since we are not considering STMT_OVERLAPS some of the cases has been removed.
			switch(i3589)
			{
				case 0: case 1:
					//quickly LINE(971,LAST):2 LINE(970,LAST):2 increased, LINE(2989,LAST)
					this.printReport("", string.Format(rm.GetString("cfsSalesCash"),
																	rm.GetString("cfsQuickly"),
																	netRcvDaysOnHandLag.ToString("N2"),
																	netRcvDaysOnHand.ToString("N2"),
																	rm.GetString("cfsIncreased"),
																	FmtCmnd.RoundToReport(RG,Math.Abs(arCashEffect)).ToString("N0"))
													,true);
					break;
				case 2: case 3:
					//slowly LINE(971,LAST):2 LINE(970,LAST):2 decreased LINE(2989,LAST)
					this.printReport("", string.Format(rm.GetString("cfsSalesToCash"),
																	rm.GetString("cfsSlowly"),
																	netRcvDaysOnHandLag.ToString("N2"),
																	netRcvDaysOnHand.ToString("N2"),
																	rm.GetString("cfsDecreased"),
																	FmtCmnd.RoundToReport(RG, Math.Abs(arCashEffect)).ToString("N0"))
													,true);
					break;
				case 4: 
					//LINE(970,LAST):2
					this.printReport("", string.Format(rm.GetString("cfsARZero"),
																	netRcvDaysOnHand.ToString("N2")) , true);
					break;
				case 7: case 8:
					//quickly LINE(971,LAST):2 LINE(970,LAST):2 increased LINE(2989,LAST)
					this.printReport("", string.Format(rm.GetString("cfsSalesCash"),
																	rm.GetString("cfsQuickly"),
																	netRcvDaysOnHandLag.ToString("N2"),
																	netRcvDaysOnHand.ToString("N2"),
																	rm.GetString("cfsIncreased"),
																	FmtCmnd.RoundToReport(RG,Math.Abs(arCashEffect)).ToString("N0"))
									  ,true);

					//LINE(24,LAST) LINE(1661,LAST) LINE(1662,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumARCashEffect[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgARCashEffect).ToString("N0"))													
										, true);					
					break;
				case 9: case 10:
					//slowly LINE(971,LAST):2 LINE(970,LAST):2 decreased LINE(2989,LAST)
					this.printReport("", string.Format(rm.GetString("cfsSalesToCash"),
																	rm.GetString("cfsSlowly"),
																	netRcvDaysOnHandLag.ToString("N2"),
																	netRcvDaysOnHand.ToString("N2"),
																	rm.GetString("cfsDecreased"),
																	FmtCmnd.RoundToReport(RG,Math.Abs(arCashEffect)).ToString("N0"))
										, true);
					//LINE(24,LAST) LINE(1661,LAST) LINE(1662,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG, cumARCashEffect[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG, avgARCashEffect).ToString("N0"))													
										, true);

					break;
				case 11:
					//LINE(970,LAST):2
					this.printReport("", string.Format(rm.GetString("cfsARZero"),
																netRcvDaysOnHand.ToString("N2")) , true);
					//LINE(24,LAST) LINE(1661,LAST) LINE(1662,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumARCashEffect[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgARCashEffect).ToString("N0"))													
										, true);
					break;
				default:
					break;

			}
			#endregion 3589


			#region 3600 INVENTORY

			//1714 Management of Inventory
			double mgmtOfInventory = NaNCheck(RG.MACRO(M.QC_MGMT_OF_INVENTORY)[pBaseID]);
			//3130 ABSOLUTE VALUE OF (mgmtOfInventory)
						
			if ( (isServiceIndustry()) && (mgmtOfInventory == 0 ))
			{
				//CUST_NAME
				printReport("", string.Format(rm.GetString("cfsServiceInd"),
												RG.Customer.LongName), true);
			}
			else if ( (isServiceIndustry()) && (mgmtOfInventory != 0 ))
			{
				//cfsServiceIndMgmt LINE(3130,LAST) == abs value of mgmtOfInventory
				string s = string.Format(rm.GetString("cfsServiceInd"),	RG.Customer.LongName) + "  " +
						   string.Format(rm.GetString("cfsServiceIndMgmt"), FmtCmnd.RoundToReport(RG, Math.Abs(mgmtOfInventory)).ToString("N0"));
				
				printReport("", s, true);
			}
			#endregion 3600


			#region 3597 CHANGE IN INVENTORY

			//c1711 Cumulative mgmt of Inventory
			Calc cumMgmtOfInventory = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_MGMT_OF_INVENTORY), 1);
			//1712 average mgmt of Inventory
			//double avgMgmtOfInventory = RG.CALC_ACCUMULATE(mgmtOfInventory, 2)[pBaseID];
			double avgMgmtOfInventory = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_MGMT_OF_INVENTORY), 1)[pBaseID]/this.cfNumStmts;
			//117
			Calc cogsCash = RG.MACRO(M.CFS_COST_OF_SALES);
			Calc cogsCashLag = RG.MACRO(M.CFS_COST_OF_SALES, RG.LAG);
			//110
			Calc netSales = RG.MACRO(M.NET_SALES);
			Calc netSalesLag = RG.MACRO(M.NET_SALES, RG.LAG);
			Calc tradeInv = RG.MACRO(M.CFS_TRADE_INVENTORY);
			Calc tradeInvLag = RG.MACRO(M.CFS_TRADE_INVENTORY, RG.LAG);
			
            Calc c1100 = null;
			Calc c1101 = null;
			if (cogsCash[pBaseID] == 0)
			{
				c1100 = (
					      (tradeInv) /
					      (netSales[pBaseID]/RG.YEAR())
					     )*365;

				c1101 = (
						  (tradeInvLag) /
					      (netSalesLag[pBaseID]/RG.YEAR(RG.LAG))
					    )*365;
	
			}
			else
			{
				c1100 = (
					      (tradeInv) /
					      (cogsCash[pBaseID]/RG.YEAR())
					    )*365;

				c1101 = (
					      (tradeInvLag) /
					      (cogsCashLag[pBaseID]/RG.YEAR(RG.LAG))
					    )*365;
			}
			int i3597 = 0;
			/**
			if ( double.IsNaN(c1100[pBaseID]) || double.IsInfinity(c1100[pBaseID]))
				c1100[pBaseID] = 0;
			if ( double.IsNaN(c1101[pBaseID]) || double.IsInfinity(c1101[pBaseID]))
				c1101[pBaseID] = 0;
			**/
			
			if (NaNCheck(c1100[pBaseID]) == 0)
				i3597 = i3597 + 1;

			if (NaNCheck(c1101[pBaseID]) == 0)
				i3597 = i3597 + 1;

			if ( NaNCheck(c1100[pBaseID]) == NaNCheck(c1101[pBaseID])) 
				i3597 = i3597 + 4;

			else if ( NaNCheck(c1100[pBaseID]) > NaNCheck(c1101[pBaseID]))
				i3597 = i3597 + 2;
			if (this.cfNumStmts > 1) i3597 = i3597 + 7;

			//Since we are not considering STMT_OVERLAPS some of the cases has been removed.
			switch(i3597)
			{
				case 0: case 1:
					//decreased increased LINE(3130,LAST)
					this.printReport("", string.Format(rm.GetString("cfsInv"),
																rm.GetString("cfsDecreased"),
																rm.GetString("cfsIncreased"),
																FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfInventory)).ToString("N0"))
												, true);
					break;
				case 2:
					//increased decreased LINE(3130,LAST)
					this.printReport("", string.Format(rm.GetString("cfsInv"),
																rm.GetString("cfsIncreased"),
																rm.GetString("cfsDecreased"),
																FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfInventory)).ToString("N0"))
												, true);					
					break;
				case 3:
					//LINE(3130,LAST) cfsInvMgmt
					this.printReport("", string.Format(rm.GetString("cfsInvMgmt"), 
																FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfInventory)).ToString("N0")), true);
					break;
				case 4:
					//cfsInvZero
					this.printReport("", rm.GetString("cfsInvZero"), true);
					break;
				case 7: case 8:
					//decreased increased LINE(3130,LAST)
					this.printReport("", string.Format(rm.GetString("cfsInv"),
																	rm.GetString("cfsDecreased"),
																	rm.GetString("cfsIncreased"),
																	FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfInventory)).ToString("N0"))
													, true);
					//LINE(24,LAST) LINE(1711,LAST) LINE(1712,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumInvCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumMgmtOfInventory[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgMgmtOfInventory).ToString("N0"))													
										, true);
					break;
				case 9: case 10:
					//increased decreased LINE(3130,LAST)
					this.printReport("", string.Format(rm.GetString("cfsInv"),
																rm.GetString("cfsIncreased"),
																rm.GetString("cfsDecreased"),
																FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfInventory)).ToString("N0"))
												, true);	
					//LINE(24,LAST) LINE(1711,LAST) LINE(1712,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumInvCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumMgmtOfInventory[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgMgmtOfInventory).ToString("N0"))													
										, true);
					break;
				case 11:
					this.printReport("", rm.GetString("cfsInvZero"), true);
					//LINE(24,LAST) LINE(1711,LAST) LINE(1712,LAST)
					this.printReport("", string.Format(rm.GetString("cfsCumInvCF"),
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG, cumMgmtOfInventory[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG, avgMgmtOfInventory).ToString("N0"))													
										, true);
					break;
				default:
					break;

			}
			#endregion 3597


			
			//1735 GROWTH DUE TO MGMT
			//Calc mgmtOfAP =  RG.MACRO(M.QC_MGMT_OF_AP);
			double mgmtOfAP =  NaNCheck(RG.MACRO(M.QC_MGMT_OF_AP)[pBaseID]);
			
			#region 3619 ACCOUNTS PAYABLE
			
			//printReport("1735", mgmtOfAP[pBaseID].ToString(), true);
			if ( (isServiceIndustry()) && (mgmtOfAP == 0 ))
			{
				// CUST_NAME 
				printReport("" ,string.Format(rm.GetString("cfsAP"),
														RG.Customer.LongName), true);
			}
			else if ( (isServiceIndustry()) && (mgmtOfAP != 0 ))
			{
				// CUST_NAME  LINE(3260,LAST)
				string s = string.Format(rm.GetString("cfsAP"), RG.Customer.LongName) + " "+
					       string.Format(rm.GetString("cfsAPMgmt"), FmtCmnd.RoundToReport(RG,Math.Abs(mgmtOfAP)).ToString("N0"));
				printReport("", s, true);
			}
			#endregion 3619

			#region 3617 CHANGE ACCOUNTS PAYABLE

			//1741
			Calc cumMgmtOfAP = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_MGMT_OF_AP), 1);
			//AVERAGE of mgmt of Accounts Payable 
			//1742
			//double avgMgmtOfAP = RG.CALC_ACCUMULATE(mgmtOfAP, 2)[pBaseID];
			double avgMgmtOfAP = RG.CALC_ACCUMULATE(RG.MACRO(M.QC_MGMT_OF_AP), 1)[pBaseID]/this.cfNumStmts;

			if ( !(isServiceIndustry()))
			{
				if (this.cfNumStmts <= 1)
				{

					if (mgmtOfAP == 0 )
					{
						printReport("", rm.GetString("cfsAPZero"), true);
					}
					else if(mgmtOfAP > 0)
					{
						//increased LINE(1735,LAST)
						printReport("", string.Format(rm.GetString("cfsAPlevels"),
														rm.GetString("cfsIncreased"),
														FmtCmnd.RoundToReport(RG,mgmtOfAP).ToString("N0"))
										, true);
					}
					else if (mgmtOfAP < 0)
					{
						//decreased LINE(1735,LAST)
						printReport("", string.Format(rm.GetString("cfsAPlevels"),
														rm.GetString("cfsDecreased"),
														FmtCmnd.RoundToReport(RG,mgmtOfAP).ToString("N0"))
										, true);
					}
				}
				else
				{
					if(mgmtOfAP > 0)
					{
						//increased LINE(1735,LAST)
						printReport("", string.Format(rm.GetString("cfsAPlevels"),
														rm.GetString("cfsIncreased"),
														FmtCmnd.RoundToReport(RG,mgmtOfAP).ToString("N0"))
										, true);
						// LINE(24,LAST) LINE(1741,LAST) LINE(1742,LAST)
						printReport("", string.Format(rm.GetString("cfsCUMAplevels"), 
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumMgmtOfAP[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgMgmtOfAP).ToString("N0")), true);
	
					}
					else if (mgmtOfAP < 0)
					{
						// decreased LINE(1735,LAST)
						printReport("", string.Format(rm.GetString("cfsAPlevels"),
														rm.GetString("cfsDecreased"),
														FmtCmnd.RoundToReport(RG,mgmtOfAP).ToString("N0"))
										, true);
						//LINE(24,LAST) LINE(1741,LAST) LINE(1742,LAST)
						printReport("", string.Format(rm.GetString("cfsCUMAplevels"), 
														this.cfNumStmts,
														FmtCmnd.RoundToReport(RG,cumMgmtOfAP[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,avgMgmtOfAP).ToString("N0")), true);
					}


				}
			}

			#endregion

			#region 1715 3607 OTHER OPERATING ASSETS
						
			if (otherAssetGrowth[pBaseID] > otherAssetGrowthLag[pBaseID])
			{
				//an increase LINE(1716,LAST) LINE(1715,LAST) decreased LINE(1725,LAST)
				printReport("", string.Format(rm.GetString("cfsOOpAstsChg"),
													rm.GetString("cfsAn"),
													rm.GetString("cfsIncrease"),
													FmtCmnd.RoundToReport(RG,otherAssetGrowthLag[pBaseID]).ToString("N0"),
													FmtCmnd.RoundToReport(RG,otherAssetGrowth[pBaseID]).ToString("N0"),
													rm.GetString("cfsDecreased"),
													FmtCmnd.RoundToReport(RG,NaNCheck(othAssetsMgmt[pBaseID])).ToString("N0")), true);
			}
			else if (otherAssetGrowth[pBaseID] < otherAssetGrowthLag[pBaseID])
			{
				//a decrease LINE(1716,LAST) LINE(1715,LAST) increased LINE(1725,LAST)
				printReport("", string.Format(rm.GetString("cfsOOpAstsChg"),
													rm.GetString("cfsA"),
													rm.GetString("cfsDecrease"),
													FmtCmnd.RoundToReport(RG,otherAssetGrowthLag[pBaseID]).ToString("N0"),
													FmtCmnd.RoundToReport(RG,otherAssetGrowth[pBaseID]).ToString("N0"),
													rm.GetString("cfsIncreased"),
													FmtCmnd.RoundToReport(RG,NaNCheck(othAssetsMgmt[pBaseID])).ToString("N0")), true);
			}
			else 
			{
				if ((otherAssetGrowth[pBaseID] != 0) && (otherAssetGrowthLag[pBaseID] != 0))
				{
					//LINE(1715,LAST)
					printReport("", string.Format(rm.GetString("cfsOOpAstsZero"),
															FmtCmnd.RoundToReport(RG,otherAssetGrowth[pBaseID]).ToString("N0")), true);
				}
			}

			#endregion 1715 3607

			#region 1744 ACCRUED EXPENSES
			
			double opExpenseGrowth = NaNCheck(RG.MACRO(M.CFS_OE_GROWTH_ACCUR_DAYS)[pBaseID]);
			double opExpenseGrowthLag = NaNCheck(RG.MACRO(M.CFS_OE_GROWTH_ACCUR_DAYS, RG.LAG)[pBaseID]);

			if ((opExpenseGrowth - opExpenseGrowthLag) > 0)
			{
				//increased LINE(1755,LAST)
				printReport("", string.Format(rm.GetString("cfsACRExpChng"),
														rm.GetString("cfsIncreased"),
														FmtCmnd.RoundToReport(RG,NaNCheck(accuralsMgmt[pBaseID])).ToString("N0"))								
									  , true);
				
			}
			else if ((opExpenseGrowth - opExpenseGrowthLag) < 0)
			{
				//decreased LINE(1755,LAST)
				printReport("", string.Format(rm.GetString("cfsACRExpChng"),
														rm.GetString("cfsDecreased"),
														FmtCmnd.RoundToReport(RG,NaNCheck(accuralsMgmt[pBaseID])).ToString("N0"))								
										, true);
			}
			else
			{
				printReport("", rm.GetString("cfsACRExpZero"), true);
			}
			#endregion 1744

			#region 1760 3637 OTHER CURRENT LIABILITIES

			//1800 OTHER FACTORS MANAGEMENT
			//COMPUTE LINE(1725)+LINE(1755)+LINE(1768)
			Calc otherFactorsMgmt = othAssetsMgmt + accuralsMgmt + othCurLiabMgmt;

			//Calc c1801 = totTradeActMgmt + otherFactorsMgmt;
			double totTradeAndOthFactMgmt = totTradeActMgmt[pBaseID] + otherFactorsMgmt[pBaseID];

			if ( othCurLiabsGrowth[pBaseID] > othCurLiabsGrowthLag[pBaseID])
			{
				//an increase LINE(1762,LAST) LINE(1760,LAST) increased LINE(1768,LAST)
				printReport("", string.Format(rm.GetString("cfsOCurLiab"),
														rm.GetString("cfsAn"),
														rm.GetString("cfsIncrease"),
														FmtCmnd.RoundToReport(RG,othCurLiabsGrowthLag[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,othCurLiabsGrowth[pBaseID]).ToString("N0"),
														rm.GetString("cfsIncreased"),
														FmtCmnd.RoundToReport(RG,othCurLiabMgmt[pBaseID]).ToString("N0"))
										, true);
				
			}
			else if ( othCurLiabsGrowth[pBaseID] < othCurLiabsGrowthLag[pBaseID])
			{
				//a decrease LINE(1762,LAST) LINE(1760,LAST) reduced LINE(1768,LAST)
				printReport("", string.Format(rm.GetString("cfsOCurLiab"),
														rm.GetString("cfsA"),
														rm.GetString("cfsDecrease"),
														FmtCmnd.RoundToReport(RG,othCurLiabsGrowthLag[pBaseID]).ToString("N0"),
														FmtCmnd.RoundToReport(RG,othCurLiabsGrowth[pBaseID]).ToString("N0"),
														rm.GetString("cfsReduced"),
														FmtCmnd.RoundToReport(RG,othCurLiabMgmt[pBaseID]).ToString("N0"))
										, true);
			}
			else 
			{
				if ((othCurLiabsGrowth[pBaseID] != 0) && (othCurLiabsGrowthLag[pBaseID]!= 0))
				{
					//LINE(1760,LAST)
					printReport("", string.Format(rm.GetString("cfsOCurLiabZero"), 
														FmtCmnd.RoundToReport(RG,othCurLiabsGrowth[pBaseID]).ToString("N0"))
											,true);
					
				}
			}

			//LINE(1770,LAST) LINE(1800,LAST) LINE(1801, LAST)
			printReport("", string.Format(rm.GetString("cfsMgmtTradActs"),
											FmtCmnd.RoundToReport(RG,totTradeActMgmt[pBaseID]).ToString("N0"),
											FmtCmnd.RoundToReport(RG,otherFactorsMgmt[pBaseID]).ToString("N0"),
											FmtCmnd.RoundToReport(RG,totTradeAndOthFactMgmt).ToString("N0")), true);


			#endregion 1760 3637

			#region 3899 CASH AFTER OPERATIONS ANALYSIS

			//3281 = abs of 1772 (totTradeActChange)
			//582 = abs of 580 (cashAfterOperations)
			if (cashAfterOp == 67)
			{
				//LINE(3281,LAST) LINE(582,LAST)
				printReport("", rm.GetString("cfsCAOhdr"), true);
				//Utility.indentLeft = 62;
				printReport("", string.Format(rm.GetString("cfsCAODesc_a"), 
												FmtCmnd.RoundToReport(RG, Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
												FmtCmnd.RoundToReport(RG,Math.Abs(cashAfterOperations[pBaseID])).ToString("N0")), true);

			}
			else if (cashAfterOp== 33)
			{
				//LINE(3281,LAST) LINE(582,LAST)
				printReport("", rm.GetString("cfsCAOhdr"), true);
				//Utility.indentLeft = 62;
				
				printReport("", string.Format(rm.GetString("cfsCAODesc_b"), 
												FmtCmnd.RoundToReport(RG,Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
												FmtCmnd.RoundToReport(RG,Math.Abs(cashAfterOperations[pBaseID])).ToString("N0")), true);
			}
			else if (cashAfterOp== 77)
			{
				//LINE(3281,LAST) LINE(580,LAST)
				printReport("", rm.GetString("cfsCAOhdr"), true);
				//Utility.indentLeft = 62;
				
				printReport("", string.Format(rm.GetString("cfsCAODesc_c"), 
												FmtCmnd.RoundToReport(RG,Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
												FmtCmnd.RoundToReport(RG,cashAfterOperations[pBaseID]).ToString("N0")), true);
			}
			else if (cashAfterOp== 80)
			{
				//LINE(1772,LAST) LINE(580,LAST)
				printReport("", rm.GetString("cfsCAOhdr"), true);
				//Utility.indentLeft = 62;
				printReport("", string.Format(rm.GetString("cfsCAODesc_d"), 
												FmtCmnd.RoundToReport(RG,Math.Abs(totTradeActChange[pBaseID])).ToString("N0"),
												FmtCmnd.RoundToReport(RG,cashAfterOperations[pBaseID]).ToString("N0")), true);
			}
			
			#endregion 3899
		}

		private void salesGrowthImpact()
		{
			//Utility.indentLeft = 45;
			//printReport("CASH EFFECT OF SALES GROWTH", "", true);
			printReport(rm.GetString("cfsCashEffSalesGrw"), "", true);
			//Utility.indentLeft = 55;

			#region 4007 SALES GROWTH
			
			//975
			double netSalesGrowth = NaNCheck(RG.MACRO(M.NET_SALES_GROWTH)[pBaseID]);
			//2001  ABS VALUE OF SALES GROWTH (975)
			double absNetSalesGrowth = Math.Abs(netSalesGrowth);
			//c1803
			Calc othFactorsNet = grEffOnOthCurAssets + grEffOnAccruals + grEffOnOthCurLiab;
			//c1804 Combine Growth of Trading Accounts and Other Factors
			Calc grTradActOthFactors = tradeActGrowth + othFactorsNet;
			//c1773 Cumulative tradeActGrowth
			Calc cumTradeActGrowth = RG.CALC_ACCUMULATE(tradeActGrowth, 1);
			//d1775 Average tradeActGrowth
			//double avgTradeActGrowth = RG.CALC_ACCUMULATE(tradeActGrowth, 2)[pBaseID];
			double avgTradeActGrowth = RG.CALC_ACCUMULATE(tradeActGrowth, 1)[pBaseID] /this.cfNumStmts;
			//c1805 Cumulative combine Growth of Trading Accts and Other Factors
			Calc cumGrTradActOthFactors = RG.CALC_ACCUMULATE(grTradActOthFactors, 1);
            //d1806 COMPUTE LINE(1805)/LINE(24)
			//double avgGrTradActOthFactors = RG.CALC_ACCUMULATE(grTradActOthFactors, 2)[pBaseID];
			double avgGrTradActOthFactors = RG.CALC_ACCUMULATE(grTradActOthFactors, 1)[pBaseID]/this.cfNumStmts;
			if ((netSalesGrowth > 0) && (this.cfNumStmts <= 1))
			{
				//increased LINE(2001,LAST):2 'An' increase requires increase 
				//LINE(1771,LAST) LINE(1803,LAST) LINE(1804, LAST)
				printReport("", string.Format(rm.GetString("cfsSales"),
												rm.GetString("cfsIncreased"),
					                            absNetSalesGrowth.ToString("N2"),
												rm.GetString("cashFSAn"),
												rm.GetString("cfsIncrease"),
												rm.GetString("cfsRequires"),
												rm.GetString("cfsIncrease"),
												FmtCmnd.RoundToReport(RG,tradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,othFactorsNet[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,grTradActOthFactors[pBaseID]).ToString("N0"))				
										, true);
			}
			else if ((netSalesGrowth < 0)&& (this.cfNumStmts <= 1))
			{
				//decreased LINE(2001,LAST):2 A decrease  suggests  
				//decrease LINE(1771,LAST) LINE(1803,LAST) LINE(1804, LAST)
				printReport("", string.Format(rm.GetString("cfsSales"),
												rm.GetString("cfsDecreased"),
												absNetSalesGrowth.ToString("N2"),
												rm.GetString("cashFA"),
												rm.GetString("cfsDecrease"),
												rm.GetString("cfsSuggests"),
												rm.GetString("cfsDecrease"),
												FmtCmnd.RoundToReport(RG,tradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,othFactorsNet[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,grTradActOthFactors[pBaseID]).ToString("N0"))				
										, true);
			}
			else if ((netSalesGrowth == 0)&& (this.cfNumStmts <= 1))
			{
				//YR(LAST)
				printReport("", string.Format(rm.GetString("cfsSalesZero"),
														RG.STMT_YEAR()[pBaseID]), true);
			}
			else if ((netSalesGrowth > 0)&& (this.cfNumStmts > 1))
			{
				//increased LINE(2001,LAST):2 An increase requires increase 
				//LINE(1771,LAST) LINE(1803,LAST) LINE(1804, LAST)
				printReport("", string.Format(rm.GetString("cfsSales"),
												rm.GetString("cfsIncreased"),
					                            absNetSalesGrowth.ToString("N2"),
												rm.GetString("cashFSAn"),
												rm.GetString("cfsIncrease"),
												rm.GetString("cfsRequires"),
												rm.GetString("cfsIncrease"),
												FmtCmnd.RoundToReport(RG,tradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,othFactorsNet[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,grTradActOthFactors[pBaseID]).ToString("N0"))				
										, true);


				//LINE(24,LAST) LINE(1773,LAST) LINE(1775,LAST) LINE(1805,LAST) LINE(1806,LAST)
				printReport("", string.Format(rm.GetString("cfsCUMSales"),
												this.cfNumStmts ,
												FmtCmnd.RoundToReport(RG,cumTradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgTradeActGrowth).ToString("N0"),
												FmtCmnd.RoundToReport(RG,cumGrTradActOthFactors[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgGrTradActOthFactors).ToString("N0")), false);
				
			}
			else if ((netSalesGrowth < 0)&& (this.cfNumStmts > 1))
			{
				//decreased LINE(2001,LAST):2 A decrease  suggests  
				//decrease LINE(1771,LAST) LINE(1803,LAST) LINE(1804, LAST)
				printReport("", string.Format(rm.GetString("cfsSales"),
												rm.GetString("cfsDecreased"),
												absNetSalesGrowth.ToString("N2"),
												rm.GetString("cashFA"),
												rm.GetString("cfsDecrease"),
												rm.GetString("cfsSuggests"),
												rm.GetString("cfsDecrease"),
												FmtCmnd.RoundToReport(RG,tradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,othFactorsNet[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,grTradActOthFactors[pBaseID]).ToString("N0"))				
										, true);


				//LINE(24,LAST) LINE(1773,LAST) LINE(1775,LAST) LINE(1805,LAST) LINE(1806,LAST)
				printReport("", string.Format(rm.GetString("cfsCUMSales"),
												this.cfNumStmts ,
												FmtCmnd.RoundToReport(RG,cumTradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgTradeActGrowth).ToString("N0"),
												FmtCmnd.RoundToReport(RG,cumGrTradActOthFactors[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgGrTradActOthFactors).ToString("N0")), false);
			}
			else if ((netSalesGrowth == 0)&& (this.cfNumStmts > 1))
			{
				//YR(LAST)
				printReport("", string.Format(rm.GetString("cfsSalesZero"),
														RG.STMT_YEAR()[pBaseID]), true);
				//LINE(24,LAST) LINE(1773,LAST) LINE(1775,LAST) LINE(1805,LAST) LINE(1806,LAST)
				printReport("", string.Format(rm.GetString("cfsCUMSales"),
												this.cfNumStmts ,
												FmtCmnd.RoundToReport(RG,cumTradeActGrowth[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgTradeActGrowth).ToString("N0"),
												FmtCmnd.RoundToReport(RG,cumGrTradActOthFactors[pBaseID]).ToString("N0"),
												FmtCmnd.RoundToReport(RG,avgGrTradActOthFactors).ToString("N0")), false);
			
			}

			#endregion 4007 
			
						
		}


		public bool isServiceIndustry()
		{
			double[] ind1 = new double[13] {22, 48, 52, 53, 54, 55, 56, 61, 62, 71, 81, 92, 98};
			bool indFound = false;
						
			for(int x=0; x < ind1.Length -1; x++)
			{
				if (RG.IND(1) == ind1[x])
				{
					indFound = true;
					break;
				}
			}
			if (indFound) return indFound;
			if (this.indCat == 3) //Default Database 
			{
				string sic = RG.IND_DIVISON;	
				//REALSTA = H, SERVICE = I, TRANSPOR = E
				if (sic != null)
				{
					if ((sic.Equals("H")) || (sic.Equals("I"))||
						(sic.Equals("E")))
					{
						indFound = true;
					}
				}
			}
			return indFound;
		}

		private double NaNCheck(double d)
		{
			if ((double.IsNaN(d)) || (double.IsInfinity(d)))
				d = 0;
			/**
			if (double.IsInfinity(d))
				d = double.NaN;
			**/
			return d;
		}


		public void printReport(string header, string body, bool extraLine)
		{
			if ( !(header == null))
			{
				if(! header.Equals(""))
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
					Utility.PrintParagraph(RG, header);
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
						
				}
				if ( ! body.Equals(""))
				{
					Utility.PrintParagraph(RG, body);
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
					
				}
		
			}
			
		}
	}

	
}