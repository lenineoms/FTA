using System.Collections;
using System.IO;
using System.Text;

using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;

namespace MMAS
{
	public class SUM_BS_ACT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// ***CPF Load the Balance Sheet Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BSCalcs(RG);

			///***CPF 7/26/02 Call the base balance sheet code. 
			MMAS_Utility.SUMMARY_BALANCE_SHEET(RG, FORMATCOMMANDS.ACTUAL);

//			StreamWriter sw = new StreamWriter("C:\\Sum_BS_Act.txt");
//			sw.Write(RG.Writer.Commands);
//			sw.Close();
		}
	}
}
