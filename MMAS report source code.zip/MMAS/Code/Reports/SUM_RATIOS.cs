using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class SUM_RATIOS:FinancialAnalyst.IReport
	{
		//SPA - copied DET_RATIOS and commented out all items that don't belong in SUM_RATIOS
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();

			Calcs.BSCalcs(RG);
			Calcs.ISCalcs(RG);
			Calcs.RatioCalcs(RG);
			
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: start outer group (full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: start 1st group "Liquidity"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srLiquidity"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("srWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("WorkingCap")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("srQuickRatio"), RG.GetPrintOrderCalc(RG.GetCalc("QuickRatio")));
			Utility.PrintSummary(RG, rm.GetString("srCurrRatio"), RG.GetPrintOrderCalc(RG.GetCalc("CurrRatio")));
			Utility.PrintSummary(RG, rm.GetString("srNetSlsWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesWorkCap")));

			Utility.Skip(RG, 1);

			//amit: end of 1st group "liquidity"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 2nd group "Leverage"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srLeverage"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			Utility.PrintSummary(RG, rm.GetString("srNWA"), RG.GetPrintOrderCalc(RG.GetCalc("NetWorthAct")));
			Utility.PrintSummary(RG, rm.GetString("srTNWA"), RG.GetPrintOrderCalc(RG.GetCalc("TangNetWrthAct")));
			Utility.PrintSummary(RG, rm.GetString("srETNWA"), RG.GetPrintOrderCalc(RG.GetCalc("EffTangNW")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("srDtWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtWorth")));
			Utility.PrintSummary(RG, rm.GetString("srDtTgWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtTangWorth")));
			Utility.PrintSummary(RG, rm.GetString("srDtLsSubDtLbETW"), RG.GetPrintOrderCalc(RG.GetCalc("DebtLsSubDbtETW")));
			Utility.PrintSummary(RG, rm.GetString("srBrFndETW"), RG.GetPrintOrderCalc(RG.GetCalc("BorFndEffTgWth")));
			Utility.PrintSummary(RG, rm.GetString("srLTDtNFA"), RG.GetPrintOrderCalc(RG.GetCalc("LTDbtNFA")));
			Utility.PrintSummary(RG, rm.GetString("srTotLbTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("TotLiabTotAst")));

			Utility.Skip(RG, 1);

			//amit: end of 2nd group "Leverage"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 3rd group "Coverage"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srCoverage"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("srIntCov"), RG.GetPrintOrderCalc(RG.GetCalc("IntCover")));
			Utility.PrintSummary(RG, rm.GetString("srNetIncDpAmtCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("NetIncDepAmtCPLTD")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			//Utility.PrintSummary(RG, "Net Income+Depr+Amort/CPLTD pp", RG.GetPrintOrderCalc(RG.GetCalc("NetIncDepAmtCPLTDpp")));
			

			Utility.PrintSummary(RG, rm.GetString("srUCACFCov"), RG.GetPrintOrderCalc(RG.GetCalc("UCACashFlowCov")));
			Utility.PrintSummary(RG, rm.GetString("srUCACPLTDpp"), RG.GetPrintOrderCalc(RG.GetCalc("UCACashFlowCPLTDpp")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");

			Utility.PrintSummary(RG, rm.GetString("srEBITDAIntExpCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("EBITDAIntExpCPLTD")));
			//  KCZ Added Omit First and EBITDA/IntExp+CPLTDpp ratio Version V 6-16-03
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("drEBITDAIntExpCPLTDpp"), RG.GetPrintOrderCalc(RG.GetCalc("EBITDAIntExpCPLTDpp")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			// KCZ end of addition 6-16-03
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			Utility.PrintSummary(RG, rm.GetString("srEBITDA"), RG.GetPrintOrderCalc(RG.GetCalc("EBITDA")));
			Utility.PrintSummary(RG, rm.GetString("srEBIDA"), RG.GetPrintOrderCalc(RG.GetCalc("EBIDA")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			
			//Utility.PrintSummary(RG, "Fixed Charge Coverage", RG.GetPrintOrderCalc(RG.GetCalc("FixedChgCov")));

			Utility.Skip(RG, 1);

			//amit: end of 3rd group "Coverage"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 4th group "Profitability"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srProfitability"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("srROA"), RG.GetPrintOrderCalc(RG.GetCalc("ROA")));
			Utility.PrintSummary(RG, rm.GetString("srROE"), RG.GetPrintOrderCalc(RG.GetCalc("ROE")));
			Utility.PrintSummary(RG, rm.GetString("srGrsMgn"), RG.GetPrintOrderCalc(RG.GetCalc("GrossMargin")));
			//Utility.PrintSummary(RG, "Operating Profit Margin", RG.GetPrintOrderCalc(RG.GetCalc("OpPrftMgn")));
			Utility.PrintSummary(RG, rm.GetString("srNtMgn"), RG.GetPrintOrderCalc(RG.GetCalc("NetMargin")));
			//Utility.PrintSummary(RG, "Dividend Payout Rate", RG.GetPrintOrderCalc(RG.GetCalc("DivPayRate")));
			//Utility.PrintSummary(RG, "Effective Tax Rate", RG.GetPrintOrderCalc(RG.GetCalc("EffTaxRate")));

			Utility.Skip(RG, 1);

			//amit: end of 4th group "Profitability"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 5th group "Activity"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srActivity"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True"); //amit:06/07/04 uncommented this to make it consistent with MFA

			///Here we have to figure the logic around LINE(965) to figure out how to 
			///conditionally print labels 
			//amit: 06/07/04 blocked this check(only if line) to make it consistent with MFA
			//if (RG.TYPE(11).NonZero)
				//Utility.PrintSummary(RG, "Gross Accounts Receivable Days", RG.GetPrintOrderCalc(RG.GetCalc("GrsARDays")));

			Utility.PrintSummary(RG, rm.GetString("srNetARDays"), RG.GetPrintOrderCalc(RG.GetCalc("NetARDays")));

			/*
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "Days on Hand");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("RawMatDOH"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("WrkInPrgDOH"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("FinGdsDOH"));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");
            */
            
			//amit: 06/07/04 blocked this check to make it consistent with MFA
			/*if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(15)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(16)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(17)) > 1)
			*/
				Utility.PrintSummary(RG, rm.GetString("srInvDOH"), RG.GetPrintOrderCalc(RG.GetCalc("InvDOH")));

			Utility.PrintSummary(RG, rm.GetString("srAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("ActPayDOH")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("srNetSlsTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesTotAst")));
			Utility.PrintSummary(RG, rm.GetString("srNetSlsNetWth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesNetWrth")));
			Utility.PrintSummary(RG, rm.GetString("srNetSlsNFA"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesNetFxdAst")));
			Utility.PrintSummary(RG, rm.GetString("srPBTTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("PftB4TxsTotAst")));

			/// Here's where you would put the code to check for a page break.
			
			Utility.Skip(RG, 1);

			//amit: end of 5th group "Activity"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 6th group "Growth"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("srGrowth"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintSummary(RG, rm.GetString("srTotAstGwth"), RG.GetPrintOrderCalc(RG.GetCalc("TotAstGwth")));
			Utility.PrintSummary(RG, rm.GetString("srTotLiabGwth"), RG.GetPrintOrderCalc(RG.GetCalc("TotLiabGwth")));
			Utility.PrintSummary(RG, rm.GetString("srNetWthGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetWrthGwth")));
			Utility.PrintSummary(RG, rm.GetString("srNetSlsGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesGwth")));
			Utility.PrintSummary(RG, rm.GetString("srOpPftGwth"), RG.GetPrintOrderCalc(RG.GetCalc("OpProfitGwth")));
			Utility.PrintSummary(RG, rm.GetString("srNetPftGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfitGwth")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			//Utility.PrintSummary(RG, "Sustainable Growth", RG.GetPrintOrderCalc(RG.GetCalc("SusGrowth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Here we would enter the code to print the UDAs if the user had entered 
			/// any.  There is also page break logic to determine if the page should break
			/// prior to printing them.
			Utility.Skip(RG, 1);
			Utility.PrintUDAs(RG);
			
			Utility.UnderlinePage(RG, 2);

			//amit: end of 6th group "Growth"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: start of 6th group "Growth"
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
			
//			StreamWriter sw = new StreamWriter("C:\\Det_Ratios.txt");
//			sw.Write(RG.Writer.Commands);
//			sw.Close();
		}
	}
}
