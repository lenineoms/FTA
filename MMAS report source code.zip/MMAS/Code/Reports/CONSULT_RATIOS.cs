using System.Collections;
using System.Threading;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
	public class CONSULT_RATIOS:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("crProfitability"));
			

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			if (RG.GetCalc("PBTToSales") == null)
				RG.AddCalc("PBTToSales", RG.MACRO(M.CR_PROFIT_B4_TAX_TO_SALES));
			if (RG.GetCalc("PBTToTNW") == null)
				RG.AddCalc("PBTToTNW", RG.MACRO(M.CR_PROFIT_B4_TAX_TO_TNW));

			Utility.PrintSummary(RG, rm.GetString("crProfB4TaxSales"), RG.GetPrintOrderCalc(RG.GetCalc("PBTToSales")));
			Utility.PrintSummary(RG, rm.GetString("crProfB4TaxTNW"), RG.GetPrintOrderCalc(RG.GetCalc("PBTToTNW")));

			if (RG.GetCalc("OpExpToSales") == null)
				RG.AddCalc("OpExpToSales", RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT));
			if (RG.GetCalc("OpLever") == null)
				RG.AddCalc("OpLever", RG.MACRO(M.CR_OPERATING_LEVERAGE));

			Utility.PrintSummary(RG, rm.GetString("crOperExpenseSales"), RG.GetPrintOrderCalc(RG.GetCalc("OpExpToSales")));
			Utility.PrintSummary(RG, rm.GetString("crOperLeverage"), RG.GetPrintOrderCalc(RG.GetCalc("OpLever")));

			Utility.Skip(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("crBorrowCapSpending"));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetCalc("CRCapExp") == null)
				RG.AddCalc("CRCapExp", RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF));

			//amit: 11/29/05 using Master Statement List instead of POStatements
			Calc clcGwthPerCnt = new Calc(1, RG.Statements.Count);
			Calc clcStmts = RG.CALC_ACCUMULATE(clcGwthPerCnt, 1);
			Calc ChgNFA_CF = new Calc();
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			for (int i = 0; i <= RG.Statements.Count - 1; i++)
			{
				//Retrieve the stmt object for the passed stmt
				Statement s = (Statement)RG.Statements[i];
				//If ReconcileID = -1, then Reconcile = NONE and we should OMIT
				if ((RG.GetAuthorSetting(FORMATCOMMANDS.OMIT) == "First") && (s.GetReconcileID(RG.Context) == -1))
					ChgNFA_CF.Add(0);
				else
					ChgNFA_CF.Add(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[i]);
			}

			Calc cAvgCapx = -1 * (RG.CALC_ACCUMULATE(ChgNFA_CF,1) / (clcStmts - 1));

			if (RG.GetCalc("CRAvgCapExp") == null)
				RG.AddCalc("CRAvgCapExp", cAvgCapx);
			if (RG.GetCalc("CRExpCapExp") == null)
				RG.AddCalc("CRExpCapExp", RG.MACRO(M.EXP_CAP_EXPEND));

			Calc cAvgExpCapExp = RG.CALC_ACCUMULATE(RG.GetCalc("CRExpCapExp"),1) / (clcStmts - 1);
			if (RG.GetCalc("CRAvgExpCapExp") == null)
				RG.AddCalc("CRAvgExpCapExp", cAvgExpCapExp);
			if (RG.GetCalc("$ChgSTD") == null)
				RG.AddCalc("$ChgSTD", RG.MACRO(M.FS_ST_DEBT_CHG));
			if (RG.GetCalc("$ChgLTD") == null)
				RG.AddCalc("$ChgLTD", RG.MACRO(M.FS_CHG_LTD));

			Utility.PrintSummary(RG, rm.GetString("crCapExp"), RG.GetPrintOrderCalc(-1 * RG.GetCalc("CRCapExp")));
			Utility.PrintSummary(RG, rm.GetString("crAvgCapExp"), RG.GetPrintOrderCalc(RG.GetCalc("CRAvgCapExp")));
			Utility.PrintSummary(RG, rm.GetString("crExpCapExp"), RG.GetPrintOrderCalc(RG.GetCalc("CRExpCapExp")));
			Utility.PrintSummary(RG, rm.GetString("crAvgExpCapExp"), RG.GetPrintOrderCalc(RG.GetCalc("CRAvgExpCapExp")));
			Utility.PrintSummary(RG, rm.GetString("crChgSTD"), RG.GetPrintOrderCalc(RG.GetCalc("$ChgSTD")));
			Utility.PrintSummary(RG, rm.GetString("crChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("$ChgLTD")));

			Utility.Skip(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("crConsultAlerts"));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");

			if (RG.GetCalc("DefTaxPayToTaxExp") == null)
				RG.AddCalc("DefTaxPayToTaxExp", RG.MACRO(M.CR_DEF_TAX_PAY_TO_TAX_EXP));

			Utility.PrintSummary(RG, rm.GetString("crDefTaxPayTaxExp"), RG.GetPrintOrderCalc(RG.GetCalc("DefTaxPayToTaxExp")));
	
			Calc cAvgTaxRate = RG.CALC_ACCUMULATE(RG.MACRO(M.EFFECTIVE_TAX_RATE),1) / (clcStmts);

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("crAvgTaxRate"), RG.GetPrintOrderCalc(cAvgTaxRate));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");

			if (RG.GetCalc("OthCurAstToTotCurAst") == null)
				RG.AddCalc("OthCurAstToTotCurAst", RG.MACRO(M.CR_OTH_CUR_AST_TO_TOT_CUR_AST));
			if (RG.GetCalc("OthCurLiabToTotCurLiab") == null)
				RG.AddCalc("OthCurLiabToTotCurLiab", RG.MACRO(M.CR_OTH_CUR_LIAB_TO_TOT_CUR_LIAB));
			if (RG.GetCalc("OthNCAstToTotAst") == null)
				RG.AddCalc("OthNCAstToTotAst", RG.MACRO(M.CR_OTH_NON_CUR_AST_TO_TOT_AST));
			if (RG.GetCalc("AccDeprToGFA") == null)
				RG.AddCalc("AccDeprToGFA", RG.MACRO(M.CR_ACCUM_DEPR_TO_GROSS_FXD_AST));
			if (RG.GetCalc("OthIncToNetIncAT") == null)
				RG.AddCalc("OthIncToNetIncAT", RG.MACRO(M.CR_OTH_INC_TO_NET_INC_AFT_TAX));
			if (RG.GetCalc("InvestToTotAst") == null)
				RG.AddCalc("InvestToTotAst", RG.MACRO(M.CR_INVESTMENT_TO_TOT_AST));

			Utility.PrintSummary(RG, rm.GetString("crOthCurAstTotCurAst"), RG.GetPrintOrderCalc(RG.GetCalc("OthCurAstToTotCurAst")));
			Utility.PrintSummary(RG, rm.GetString("crOthCurLiabTotCurLiab"), RG.GetPrintOrderCalc(RG.GetCalc("OthCurLiabToTotCurLiab")));
			Utility.PrintSummary(RG, rm.GetString("crOthNonCurAstTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("OthNCAstToTotAst")));
			Utility.PrintSummary(RG, rm.GetString("crAccDeprGFA"), RG.GetPrintOrderCalc(RG.GetCalc("AccDeprToGFA")));
			Utility.PrintSummary(RG, rm.GetString("crOthIncNetIncAftTax"), RG.GetPrintOrderCalc(RG.GetCalc("OthIncToNetIncAT")));
			Utility.PrintSummary(RG, rm.GetString("crInvestTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("InvestToTotAst")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			if (RG.GetCalc("OthCashIncAdj") == null)
				RG.AddCalc("OthCashIncAdj", (-1) * RG.MACRO(M.FS_OTH_OPER_CASH_FLOW));

			Utility.PrintSummary(RG, rm.GetString("crOthCashIncAdj"), RG.GetPrintOrderCalc(RG.GetCalc("OthCashIncAdj")));

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			if (RG.GetCalc("GwthAccLiabs") == null)
				RG.AddCalc("GwthAccLiabs", RG.MACRO(M.CR_GROWTH_ACCRD_LIABS));
			if (RG.GetCalc("GwthPrefStck") == null)
				RG.AddCalc("GwthPrefStck", RG.MACRO(M.CR_GROWTH_PREF_STOCK));
			if (RG.GetCalc("GwthCommStck") == null)
				RG.AddCalc("GwthCommStck", RG.MACRO(M.CR_GROWTH_COMMON_STOCK));
			if (RG.GetCalc("GwthOthEqty") == null)
				RG.AddCalc("GwthOthEqty", RG.MACRO(M.CR_GROWTH_OTHER_EQUITY));

			Utility.PrintSummary(RG, rm.GetString("crGwthAcrdLiab"), RG.GetPrintOrderCalc(RG.GetCalc("GwthAccLiabs")));
			Utility.PrintSummary(RG, rm.GetString("crGwthPrefStock"), RG.GetPrintOrderCalc(RG.GetCalc("GwthPrefStck")));
			Utility.PrintSummary(RG, rm.GetString("crGwthComStk"), RG.GetPrintOrderCalc(RG.GetCalc("GwthCommStck")));
			Utility.PrintSummary(RG, rm.GetString("crGwthOthEqty"), RG.GetPrintOrderCalc(RG.GetCalc("GwthOthEqty")));

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Calc cInv = RG.MACRO(M.CFS_TRADE_INVENTORY) / RG.CONV_RATE();

			if (RG.GetDetailCalcs("DTType15") == null)
				RG.AddCalc("DTType15", RG.DETAILTYPE(15));
			if (RG.GetDetailCalcs("DTType16") == null)
				RG.AddCalc("DTType16", RG.DETAILTYPE(16));
			if (RG.GetDetailCalcs("DTType17") == null)
				RG.AddCalc("DTType17", RG.DETAILTYPE(17));

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTType15")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTType16")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTType17")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintLabel(RG, rm.GetString("crInventory"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("crTrdInvSuffix"));

				Utility.PrintDetail(RG, (RG.GetDetailCalcs("DTType15") % cInv));
				Utility.PrintDetail(RG, (RG.GetDetailCalcs("DTType16") % cInv));
				Utility.PrintDetail(RG, (RG.GetDetailCalcs("DTType17") % cInv));

				RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");
			}

			Utility.UnderlinePage(RG, 1);

			Utility.CloseReport(RG);

		}
	}
}
