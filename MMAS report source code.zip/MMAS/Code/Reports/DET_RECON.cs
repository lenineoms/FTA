using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class DET_RECON:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);
			Calcs.DetReconCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("drecRecRE"));
			Utility.UnderlinePage(RG, 1);

			if (RG.GetCalc("LINE(209)").NonZero)
			{
				// KCZ 8-19-03 Turned suppress off, then on again, to fix part of bug 227, when
				// Retained Earnings are zero with a constant exchange rate
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				Utility.PrintLabel(RG, rm.GetString("drecBegRE"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("drecAsPrevRept"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(204)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			if (FormatCommands.DetailCount(RG, RG.GetPrintOrderDetailCalcs(RG.DETAILAND(103, RG.ANDFLOW, 30, RG.ANDCLASS))) + FormatCommands.DetailCount(RG, RG.GetPrintOrderDetailCalcs(RG.DETAILAND(103, RG.ANDFLOW, 32, RG.ANDCLASS))) > 0)
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(217)"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(219)"));
			}

			if (RG.GetCalc("LINE(202)").NonZero)
				Utility.PrintSummary(RG, rm.GetString("drecAdjChgExgRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(206)")));

			if (RG.GetCalc("LINE(209)").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				// KCZ 8-19-03 As a part of fixing 227, also make RE print if zero if there is 
				// an adjustment (so set suppress to false, then true again)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				Utility.PrintSummary(RG, rm.GetString("drecBegRERst"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(208)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			if (RG.GetCalc("LINE(204)").NonZero == false)
			{ 
				//amit: 06/07/04 removed indent for this line
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("drecRE"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(210)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			Utility.PrintSummary(RG, rm.GetString("drecNetPft"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfit")));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(216)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(218)"));
			Utility.PrintSummary(RG, rm.GetString("drecUnexAdjRE"), -1 * RG.GetPrintOrderCalc(RG.GetCalc("LINE(220)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("drecEndRE"), RG.GetPrintOrderCalc(RG.GetCalc("EndRetEarn")));
			Utility.UnderlinePage(RG, 2);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("drecRecNW"));
			Utility.UnderlinePage(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("drecBegNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(225)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("drecNetPft"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfit")));
			Utility.PrintSummary(RG, rm.GetString("drecDivWithCash"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(216)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("drecDivStk"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(218)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("drecAdjsRE"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(230)")));

			if(RG.GetCalc("LINE(235)").NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("drecIncDecr"));
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(341)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(240)"));
			Utility.PrintSummary(RG, rm.GetString("drecOthGyArEq"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(243)")));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(244)"));           
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(241)"));           
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(242)"));
			Utility.PrintSummary(RG, rm.GetString("drecOCIReclsAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(212)")));
			Utility.PrintSummary(RG, rm.GetString("drecOCIAdjChgExRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(214)")));

			///COMPARE LINE(250) TO LINE(265)
			///IF NOT = DO_IF_ANY THEN PRINT 'Ending Net Worth(As Calc Above)' LINE(250)
			for (int i = 0; i < RG.GetCalc("LINE(250)").Count; i++) 
				///if (RG.GetCalc("LINE(250)")[i] != double.NaN && RG.GetCalc("LINE(250)")[i] != RG.GetCalc("LINE(265)")[i])
				if (double.IsNaN(RG.GetCalc("LINE(250)")[i]) == false && RG.GetCalc("LINE(250)")[i] != RG.GetCalc("LINE(265)")[i])
				{
					Utility.PrintSummary(RG, rm.GetString("drecEndNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(250)")));
					break;
				}
			
			Utility.PrintSummary(RG, rm.GetString("drecUnexAdjNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(260)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("drecActEndNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(265)")));
			Utility.PrintSummary(RG, rm.GetString("drecIncDecNW"), RG.GetPrintOrderCalc(RG.GetCalc("IncDecNetWrth")));
			Utility.UnderlinePage(RG, 2);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("drecRecWorkCap"));
			Utility.UnderlinePage(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("drecBegWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(300)")));
			Utility.PrintLabel(RG, rm.GetString("drecDecIncNonCurAst"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("drecTotFixAstNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(370)")));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(375)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(380)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(382)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(385)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(390)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(395)"));

			Utility.PrintSummary(RG, rm.GetString("drecIntangNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(398)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintLabel(RG, rm.GetString("drecIncDecNonCurLiab"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("drecLTD"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(330)")));			
			Utility.PrintSummary(RG, rm.GetString("drecCapLseObl"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(335)")));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(340)"));
			Utility.PrintSummary(RG, rm.GetString("drecOthNonCurLiab"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(345)")));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(350)"));
			Utility.PrintSummary(RG, rm.GetString("drecOthLiab"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(360)")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("drecIncDecNWlc"), RG.GetPrintOrderCalc(RG.GetCalc("IncDecNetWrth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("drecUnexAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(320)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("drecEndWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("EndWorkCap")));
			///ST_CROSS_FOOT_ON
			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
