﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]

[assembly: Guid("4992980c-35bb-424a-89a4-6307bd6446c3")]
