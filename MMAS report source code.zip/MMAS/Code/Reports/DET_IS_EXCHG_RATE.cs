using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class DET_IS_EXCHG_RATE:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// Load the Balance Sheet Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);				

			/// Call the base balance sheet code. 
			
			MMAS_Utility.DETAILED_INCOME_STATEMENT(RG, FORMATCOMMANDS.ACT_EXCHANGE, Calcs);
		}
	}
}
