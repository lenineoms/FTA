using System.Collections;
using System.Threading;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
	public class PEER_COMP_IND_VALUES:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();

			Calcs.Peer_Comp_Ind_Val(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
            //amit: 04/17/07 set zeros_string as ""
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG,true);

			PeerStatement ps = null;
			int BaseId=-1;
			int PeerId=-1;
			int VarId=-1;
			int PBaseId;
			int PPeerId;
			int PVarId;
			VarianceStatement vs = null;
			
			foreach (Statement s in RG.Statements)
			{
				if (s.Peer == true)
				{
					PeerId = s.Id;
					ps = (PeerStatement)s;
					BaseId = ps.BaseStatementID;
				}
				else if (s.Variance == true)
				{
					VarId = s.Id;
					vs = (VarianceStatement)s;
				}

			}

			PPeerId = (ps == null) ? -1:RG.Statements.IndexOf(ps);
			PVarId = (vs == null) ? -1:RG.Statements.IndexOf(vs);
            PBaseId = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);
            if (PBaseId < 0)
            {
                string[] err = { rm.GetString("pcinInvalidStatement")};
                Utility.PrintRCErrors(RG,  err);
                return;
            }

            string sPeriod = RG.STMT_PERIODS()[PBaseId].ToString();
            string sYear = RG.STMT_YEAR()[PBaseId].ToString();
            string sDate = Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString();

            string s1 = "";
			///UNQUALIFIED			
			if (RG.GetCalc("LINE(46)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdUnqFY") + sYear + ".";
			else if (RG.GetCalc("LINE(46)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdUnq") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
			

			///QUALIFIED			
			if (RG.GetCalc("LINE(43)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdQlFY") + sYear + ".";
			else if (RG.GetCalc("LINE(43)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdQl") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///REVIEWED			
			if (RG.GetCalc("LINE(59)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdRvFY") + sYear + ".";
			else if (RG.GetCalc("LINE(59)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdRv") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
			

			///DISCLAIMER			
			if (RG.GetCalc("LINE(49)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdDscFY") + sYear + ".";
			else if (RG.GetCalc("LINE(49)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdDsc") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///COMPILED			
			if (RG.GetCalc("LINE(53)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdCmpFY") + sYear + ".";
			else if (RG.GetCalc("LINE(53)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdCmp") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///COMPANY PREPARED			
			if (RG.GetCalc("LINE(57)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdCmpPdFY") + sYear + ".";
			else if (RG.GetCalc("LINE(57)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdCmpPd") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///ADVERSE OPINION			
			if (RG.GetCalc("LINE(68)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdAdvOp") + sYear + ".";
			else if (RG.GetCalc("LINE(68)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdAdvOpThe") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///TAX RETURNS			
			if (RG.GetCalc("LINE(71)")[PBaseId] == 3)
				s1 = rm.GetString("civBsdTxRtFY") + sYear + ".";
			else if (RG.GetCalc("LINE(71)")[PBaseId] == 2)
				s1 = rm.GetString("civBsdTxRt") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

			///ANYTHING ELSE			
			if (RG.GetCalc("LINE(69)")[PBaseId] == 1)
				s1 = rm.GetString("civBsdOn") + RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString() + rm.GetString("civFinDatFY") + sYear + ".";
			else if (RG.GetCalc("LINE(69)")[PBaseId] == 0)
				s1 = rm.GetString("civBsdOn") + RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString() + rm.GetString("civFinDat") + sPeriod + rm.GetString("civMthPerEnd") + sDate + ".";
				

            
			///Print the first line.
			Utility.PrintParagraph(RG, s1);

			string s2="";
			///ANYTHING ELSE			
			if (RG.GetCalc("LINE(4164)")[PBaseId] == 5)
				s2 = rm.GetString("civCmpPurp") + Convert.ToString(RG.IND(94)) + rm.GetString("civDatIndCd") + RG.PEER_CODE + ", " + RG.IND_DESC + rm.GetString("civSrtAstSz") + 
					RG.IND_SIZE + rm.GetString("civPrGrpCsts") + Convert.ToString(RG.IND(7)) + rm.GetString("civCmps");
			else if (RG.GetCalc("LINE(4164)")[PBaseId] == 6)
				s2 = rm.GetString("civAlyCmp") + Convert.ToString(RG.IND(94)) + rm.GetString("civDatAllCmp") + RG.PEER_CODE + ", " + RG.IND_DESC + rm.GetString("civFrCmpPurp") + 
					rm.GetString("civGrpCsts") + Convert.ToString(RG.IND(7)) + rm.GetString("civCmps");
			else if (RG.GetCalc("LINE(4164)")[PBaseId] == 7)
				s2 = rm.GetString("civCmpPurp") + Convert.ToString(RG.IND(94)) + rm.GetString("civDatIndCd") + RG.PEER_CODE + ", " + RG.IND_DESC + rm.GetString("civSrtSlsSz") +
					RG.IND_SIZE + rm.GetString("civPrGrpCsts") + Convert.ToString(RG.IND(7)) + rm.GetString("civCmps");
			else if (RG.GetCalc("LINE(4164)")[PBaseId] == 0)
				s2 = rm.GetString("civAlyNoCmpInd");
			else if ((RG.GetCalc("LINE(4164)")[PBaseId] == 3) || (RG.GetCalc("LINE(4164)")[PBaseId] == 2) || (RG.GetCalc("LINE(4164)")[PBaseId] == 1))
				s2 = rm.GetString("civCmpPurp") + RG.IND_DESC + ".";
			else if (RG.GetCalc("LINE(4164)")[PBaseId] == 4)
				s2 = rm.GetString("civAlyNoCmpInd");
			
				

			///Print the first line.
			Utility.PrintParagraph(RG, s2);
			///Skip a line.
			//Utility.PrintParagraph(RG, "/n");
			            
			//By default there will be 2 columns to print (+ label) which would be 
			//Cust Value and Peer Value.  If there is a Variance column in the report collection,
			//then we need to add a column for printing of variance as well.
			int isvar = 3;
			if (PVarId != -1)
				isvar = 4;

			Utility.CreateTable(RG, isvar);

			string[] Labels = new string[isvar];
			Labels[0] = rm.GetString("civBSData");
			Labels[1] = rm.GetString("civCustVal");
			Labels[2] = rm.GetString("civPeerVal");
			if (isvar == 4)
				Labels[3] = rm.GetString("civVariance");
			
			Utility.PrintColumnLabels(RG, Labels);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");

			//amit: Start Report Group
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PageBreak(RG);
			//amit: Start 1st group
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintSummary(RG, rm.GetString("civCashEq"), RG.GetCalc("PRCashEq"));
			if (RG.IND(33) == 100)
				Utility.PrintSummary(RG, rm.GetString("civARProgBil"), RG.GetCalc("PRTrdRcv"));
			else
				Utility.PrintSummary(RG, rm.GetString("civTrdRcvNet"), RG.GetCalc("PRTrdRcv"));
			if (RG.IND(33) == 100)
				Utility.PrintSummary(RG, rm.GetString("civARCurRet"), RG.GetCalc("PRARCurRet"));
			Utility.PrintSummary(RG, rm.GetString("civInventory"), RG.GetCalc("PRInv"));
			if (RG.IND(33) == 100)
				Utility.PrintSummary(RG, rm.GetString("civCstExcBil"), RG.GetCalc("PRCstExcBil"));
			Utility.PrintSummary(RG, rm.GetString("civAllOthCurAst"), RG.GetCalc("PRAllOthCurAst"));
			Utility.PrintSummary(RG, rm.GetString("civTotCurAst"), RG.GetCalc("PRTotCurAst"));

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);

			//amit: End 1st group
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start 2nd group
			Utility.mT.AddStartRow(Utility.nRow + 1);
            
			Utility.PrintSummary(RG, rm.GetString("civFxdAstNet"), RG.GetCalc("PRFxdAstNt"));
			if (RG.IND(33) == 100)
				Utility.PrintSummary(RG, rm.GetString("civJVInvst"), RG.GetCalc("PRJVInt"));
			Utility.PrintSummary(RG, rm.GetString("civIntang"), RG.GetCalc("PRIntang"));
			Utility.PrintSummary(RG, rm.GetString("civAllOthNonCurAst"), RG.GetCalc("PRAllOthNCAst"));
			Utility.PrintSummary(RG, rm.GetString("civTotNonCurAst"), RG.GetCalc("PRTotNCAst"));

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);

			//amit: End 2nd group
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//amit: Start 3rd group
			//Utility.PageBreak(RG);
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintSummary(RG, rm.GetString("civNtPayST"), RG.GetCalc("PRNotPayST"));
			Utility.PrintSummary(RG, rm.GetString("civCurMatLTD"), RG.GetCalc("PRCurMatLTD"));
			Utility.PrintSummary(RG, rm.GetString("civTrdPay"), RG.GetCalc("PRTrdPay"));
			if (RG.IND(33) == 100)
			{
				Utility.PrintSummary(RG, rm.GetString("civAPRetent"), RG.GetCalc("PRAPRetent"));
				Utility.PrintSummary(RG, rm.GetString("civBilExcCst"), RG.GetCalc("PRBillExcCst"));
			}
			Utility.PrintSummary(RG, rm.GetString("civIncTxPay"), RG.GetCalc("PRIncTaxPay"));
			Utility.PrintSummary(RG, rm.GetString("civAllOthCurLiab"), RG.GetCalc("PRAllOthCurLb"));
			Utility.PrintSummary(RG, rm.GetString("civTotCurLiab"), RG.GetCalc("PRTotCurLiab"));

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);

			//amit: End 3rd group
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//amit: Start 4th group
			//Utility.PageBreak(RG);
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintSummary(RG, rm.GetString("civLTD"), RG.GetCalc("PRLTD"));
			Utility.PrintSummary(RG, rm.GetString("civDefTax"), RG.GetCalc("PRDefTax"));
			Utility.PrintSummary(RG, rm.GetString("civAllOthNonCurLiab"), RG.GetCalc("PRAllOthNCLiab"));
			Utility.PrintSummary(RG, rm.GetString("civTotNonCurLiab"), RG.GetCalc("PRTotNCLiab"));
			Utility.PrintSummary(RG, rm.GetString("civNetWorth"), RG.GetCalc("PRNetWrth"));

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civIncData"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, rm.GetString("civGrsPft"), RG.GetCalc("PRGrsPft"));
			Utility.PrintSummary(RG, rm.GetString("civOpExp"), RG.GetCalc("PROpExp"));
			Utility.PrintSummary(RG, rm.GetString("civOpPft"), RG.GetCalc("PROpPft"));
			Utility.PrintSummary(RG, rm.GetString("civAllOthExp"), RG.GetCalc("PRAllOthExp"));
			Utility.PrintSummary(RG, rm.GetString("civPftB4Tx"), RG.GetCalc("PRPftB4Tx"));

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);

			//amit: End 4th group
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start 5th group
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Labels[0] = rm.GetString("civRatios");
			Labels[1] = rm.GetString("civCustVal");
			Labels[2] = rm.GetString("civPeerVal");
			if (isvar == 4)
				Labels[3] = rm.GetString("civVariance");

            //amit: 04/17/07 set zeros_string as ""
            RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintColumnLabels(RG, Labels);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civCurRat"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppCR"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedCR"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowCR"));

			//amit: End 5th group
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);

			if (RG.IND(33) != 100)
			{
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);

				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civQckRat"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppQR"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedQR"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowQR"));

				//amit: End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);
			}

			if (RG.IND(33) == 100)
			{
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);

				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civRecPay"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppRecPay"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedRecPay"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowRecPay"));

				//amit: End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);
			}

			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civARDaysTO"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppARDaysTO"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedARDaysTO"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowARDaysTO"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);

			if (RG.IND(33) != 100)
			{
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);

				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civInvDays"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppInvDays"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedInvDays"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowInvDays"));
				//amit:End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);

			}

			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civAPDaysTO"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppAPDaysTO"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedAPDaysTO"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowAPDaysTO"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civSlsWorkCap"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppSlsWrkCap"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedSlsWrkCap"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowSlsWrkCap"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civIntCov"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppIntCov"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedIntCov"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowIntCov"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count," ***************** ");

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civNIDepAmtDivCPLTD"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppNIDpAmDvCPLTD"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedNIDpAmDvCPLTD"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowNIDpAmDvCPLTD"));
			
			//Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, " ***************** ");
			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civNFATNW"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppNFATNW"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedNFATNW"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowNFATNW"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civDbtTNW"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppDbtTNW"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedDbtTNW"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowDbtTNW"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
            //Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civPftB4TaxTNW"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppPftB4TxTNW"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedPftB4TxTNW"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowPftB4TxTNW"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civPftB4TaxTA"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppPftB4TxTA"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedPftB4TxTA"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowPftB4TxTA"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);

			if (RG.IND(33) != 100)
			{
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);

				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civSlsNFA"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppSlsNFA"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedSlsNFA"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowSlsNFA"));

				//amit:End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);
			
				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civSlsTotAst"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppSlsTA"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedSlsTA"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowSlsTA"));

				//amit:End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);
				//amit: Start
				Utility.mT.AddStartRow(Utility.nRow + 1);

				Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
				Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civDepAmtSls"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
				Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppDepAmtSls"));
				Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedDepAmtSls"));
				Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowDepAmtSls"));

				//amit:End
				Utility.mT.AddEndRow(Utility.nRow - 1);
				//Utility.PageBreak(RG);
			}

			//amit: Start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civOffCompSls"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppOffCompSls"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedOffCompSls"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowOffCompSls"));

			//amit:End
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
            //amit: Start
            Utility.mT.AddStartRow(Utility.nRow + 1);

            Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
            Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civDbtEBITDA"));
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
            Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppDbtEBITDA"));
            Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedDbtEBITDA"));
            Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowDbtEBITDA"));

            Utility.Skip(RG, RG.GetCalc("PRTotCurAst").Count, 1);

            //amit:End
            Utility.mT.AddEndRow(Utility.nRow - 1);
            //Utility.PageBreak(RG);
			//amit: Report End
			Utility.mT.AddEndRow(Utility.nRow - 1);

			Utility.CloseTable(RG);

			// paragraph of text giving RiskCalc version, sample size
			//basically, we have added a call to a field in the RMA database that has not been created (123).  This
			//field will hopefully be used to store the RC Version in the future.  So here we check to see if the call
			//to RG.IND(123) returns anything other than 0.  If not, sub in 1.50.
			string s3 = "";
			string sVersion = (RG.IND(123) == 0) ? "1.50" : RG.IND(123).ToString();
			s3 = string.Format(rm.GetString("civRC1"), sVersion) + Convert.ToString(RG.IND(113)) + rm.GetString("civRC2");
			Utility.PrintParagraph(RG, s3);

			Utility.CreateTable(RG,3);

			string[] RCLabels = new string[3];
			RCLabels[0] = rm.GetString("civRCLabel");
			RCLabels[1] = "";
			RCLabels[2] = rm.GetString("civPeerVal");
			
			// KCZ Added for RiskCalc 6-18-03 //
			Utility.Skip(RG, 2, 1);
//			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
//			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
//			Utility.PrintLabel(RG, RG.GetCalc("PRTotCurAst").Count, rm.GetString("civRCLabel"));
//			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
//			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintColumnLabels(RG, RCLabels);

			//start: Report Group
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//start: 1st Group
			Utility.mT.AddStartRow(Utility.nRow + 1);

			// 1 Year PD (no customer value, just peer values)
			Utility.Skip(RG, 2, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, 2, rm.GetString("civ1Yr"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppRC1Yr"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedRC1Yr"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowRC1Yr"));

			// 5 Year PD (no customer value, just peer values)
			Utility.Skip(RG, 2, 1);

			//amit: end 
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//Utility.PageBreak(RG);
			//amit: start
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "3");
			Utility.PrintLabel(RG, 2, rm.GetString("civ5Yr"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "7");
			Utility.PrintSummary(RG, rm.GetString("civUpp"), RG.GetCalc("PRUppRC5Yr"));
			Utility.PrintSummary(RG, rm.GetString("civMed"), RG.GetCalc("PRMedRC5Yr"));
			Utility.PrintSummary(RG, rm.GetString("civLow"), RG.GetCalc("PRLowRC5Yr"));

			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			//amit: end 
			Utility.mT.AddEndRow(Utility.nRow - 1);
			//amit: End Report
			Utility.mT.AddEndRow(Utility.nRow - 1);

			Utility.CloseReport(RG);

		}
	}
}
