using System.Collections;
using FinancialAnalyst;
using MFAReportAuthoring;
using System.IO;
using System.Text;

namespace MMAS
{
	public class DATA_TEST:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BSCalcs(RG);
			Calcs.ISCalcs(RG);
			Calcs.RatioCalcs(RG);
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			Calcs.CF_MGMT_Calcs(RG);
			Calcs.Data_Test_Calcs(RG);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.25");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG, "Data Test Report");

			//grab the list of report names and ids
			ArrayList arrExcludeConst = new ArrayList();

			/// List the statment constants you DO NOT want to print.
			arrExcludeConst.Add(1);
			arrExcludeConst.Add(2);
			arrExcludeConst.Add(3);

			/// Copy the arraylist items into a int array
			int[] ExcludeConst = new int[arrExcludeConst.Count];
			arrExcludeConst.CopyTo(ExcludeConst);

			Utility.ExcludeConstID = ExcludeConst;

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Balance Sheet");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, "LIFO Reserve", RG.GetPrintOrderCalc(RG.GetCalc("LIFOReserve")));
			Utility.PrintSummary(RG, "Current Portion LTD", RG.GetPrintOrderCalc(RG.GetCalc("CurrentPortionLTD")));
			Utility.PrintSummary(RG, "Total Net Worth", RG.GetPrintOrderCalc(RG.GetCalc("TotNetWrth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, "Chg in ST Debt", RG.GetPrintOrderCalc(RG.GetCalc("ChgInSTDebt")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Utility.PrintSummary(RG, "% Chg in Common Stock", RG.GetPrintOrderCalc(RG.GetCalc("%ChgComStk")));
			Utility.PrintSummary(RG, "% Chg in Preferred Stock", RG.GetPrintOrderCalc(RG.GetCalc("%ChgPrefStk")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, "Adjustments to R/E", RG.GetPrintOrderCalc(RG.GetCalc("AdjToRE")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Income Statement");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, "Net Sales", RG.GetPrintOrderCalc(RG.GetCalc("NetSalesRev")));
			Utility.PrintSummary(RG, "Net Operating Profit", RG.GetPrintOrderCalc(RG.GetCalc("NetOpProfit")));
			Utility.PrintSummary(RG, "Interest Expense", RG.GetPrintOrderCalc(RG.GetCalc("TotIntExp")));
			Utility.PrintSummary(RG, "Non-Operating Inc(Exp)", RG.GetPrintOrderCalc(RG.GetCalc("NonOpIncExp")));
			Utility.PrintSummary(RG, "Profit Before Extraordinary", RG.GetPrintOrderCalc(RG.GetCalc("ProfB4ExtrItem")));
			Utility.PrintSummary(RG, "Extraordinary Items", RG.GetPrintOrderCalc(RG.GetCalc("ExtraItems")));

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Liquidity");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Utility.PrintSummary(RG, "Current Ratio", RG.GetPrintOrderCalc(RG.GetCalc("CurrRatio")));
			Utility.PrintSummary(RG, "Quick Ratio", RG.GetPrintOrderCalc(RG.GetCalc("QuickRatio")));

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Leverage/Coverage");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, "Debt/Tang Worth", RG.GetPrintOrderCalc(RG.GetCalc("DebtTangWorth")));
			Utility.PrintSummary(RG, "Adjusted Leverage", RG.GetPrintOrderCalc(RG.GetCalc("DebtLsSubDbtETW")));
			Utility.PrintSummary(RG, "Net Fixed Assets/TNW", RG.GetPrintOrderCalc(RG.GetCalc("NFATNW")));
			Utility.PrintSummary(RG, "Off Balance Sheet Leverage", RG.GetPrintOrderCalc(RG.GetCalc("OffBSLever")));
			
			//I think this DECIMAL_PRCSN_1 = 1 is for calc precision, but it should be 0 for print.
			//RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintSummary(RG, "Cash After Operations", RG.GetPrintOrderCalc(RG.GetCalc("CashAfterOps")));
			Utility.PrintSummary(RG, "Net Cash After Operations", RG.GetPrintOrderCalc(RG.GetCalc("NetCashAfterOps")));
			Utility.PrintSummary(RG, "Chg in Long Term Debt", RG.GetPrintOrderCalc(RG.GetCalc("ChgLTD")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Utility.PrintSummary(RG, "Interest Coverage", RG.GetPrintOrderCalc(RG.GetCalc("IntCover")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, "EBITDA", RG.GetPrintOrderCalc(RG.GetCalc("EBITDA")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Utility.PrintSummary(RG, "Net Income+Depr+Amort/CPLTD", RG.GetPrintOrderCalc(RG.GetCalc("NetIncDepAmtCPLTD")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintSummary(RG, "Cash Coverage", RG.GetPrintOrderCalc(RG.GetCalc("CashCover")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");

			///WE NEED TO CHECK FOR LINES LEFT ON PAGE HERE.

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Profitability (%)");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, "Gross Margin", RG.GetPrintOrderCalc(RG.GetCalc("GrossMargin")));
			Utility.PrintSummary(RG, "Operating Expense/Sales", RG.GetPrintOrderCalc(RG.GetCalc("OpExpSales")));
			Utility.PrintSummary(RG, "Operating Profit Margin", RG.GetPrintOrderCalc(RG.GetCalc("OpPrftMgn")));
			Utility.PrintSummary(RG, "Profit Before Taxes/Sales", RG.GetPrintOrderCalc(RG.GetCalc("PBTSales")));
			Utility.PrintSummary(RG, "Profit Margin", RG.GetPrintOrderCalc(RG.GetCalc("NetMargin")));
			Utility.PrintSummary(RG, "Retention Rate", RG.GetPrintOrderCalc(RG.GetCalc("RetentRate")));

			///Check for LINES_LEFT_ON_PAGE
			
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Activity");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintSummary(RG, "Net Accounts Receivable Days", RG.GetPrintOrderCalc(RG.GetCalc("NetARDays")));
			Utility.PrintSummary(RG, "Inventory Days on Hand", RG.GetPrintOrderCalc(RG.GetCalc("InvDOH")));
			Utility.PrintSummary(RG, "Accounts Payable Days", RG.GetPrintOrderCalc(RG.GetCalc("ActPayDOH")));
			Utility.PrintSummary(RG, "Total Assets/Sales", RG.GetPrintOrderCalc(RG.GetCalc("TotAstSales")));
			Utility.PrintSummary(RG, "Other Assets/Total Assets", RG.GetPrintOrderCalc(RG.GetCalc("OthAstTotAst")));
			Utility.PrintSummary(RG, "ST Debt/Total Assets", RG.GetPrintOrderCalc(RG.GetCalc("STDebtTotAst")));
			Utility.PrintSummary(RG, "Net Sales/Net Fixed Assets", RG.GetPrintOrderCalc(RG.GetCalc("NetSalesNetFxdAst")));

			///Check for LINES LEFT ON PAGE
			
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Cash Flow Management");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintSummary(RG, "Gross Profit", RG.GetPrintOrderCalc(RG.GetCalc("LINE(983)")));
			Utility.PrintSummary(RG, "Operating Expense", RG.GetPrintOrderCalc(RG.GetCalc("LINE(986)")));
			Utility.PrintSummary(RG, "Accounts Receivable", RG.GetPrintOrderCalc(RG.GetCalc("LINE(995)")));
			Utility.PrintSummary(RG, "Inventory", RG.GetPrintOrderCalc(RG.GetCalc("LINE(1713)")));
			Utility.PrintSummary(RG, "Accounts Payable", RG.GetPrintOrderCalc(RG.GetCalc("LINE(1737)")));
			Utility.PrintSummary(RG, "Other Operating Assets", RG.GetPrintOrderCalc(RG.GetCalc("LINE(1725)")));
			Utility.PrintSummary(RG, "Accruals & Other Current Liabs", RG.GetPrintOrderCalc(RG.GetCalc("AccOthCurLiabs")));
			Utility.PrintSummary(RG, "Sales Growth Impact on Trading Accts", RG.GetPrintOrderCalc(RG.GetCalc("LINE(1771)")));

			/// Check for LINES LEFT ON PAGE.
			
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, "Other");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			Utility.PrintSummary(RG, "Sales Growth", RG.GetPrintOrderCalc(RG.GetCalc("NetSalesGwth")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, "Capital Expenditures", RG.GetPrintOrderCalc(-1 * RG.GetCalc("ChgNetFxdAsts")));
			Utility.PrintSummary(RG, "Expected Capital Expenditures", RG.GetPrintOrderCalc(RG.GetCalc("ExpCapExpend")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, "Depreciation Rate", RG.GetPrintOrderCalc(RG.GetCalc("DepreciationRate")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			Utility.UnderlinePage(RG, 2);

			Utility.CloseReport(RG);

		}
	}
}
