using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class DET_FAS_CF_DIR:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			Calcs.FAS_CF_Dir_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("fasCshFlwOpAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCashSales"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSalesAdjCF"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTBadDbtRes"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgRcvbls"));
			///CPF 01/12/06 Log 898:  Adding "Due from Rel Co - CP"
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueFmRelCoCP"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgBadDbtRes"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefRev"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			///CPF 6/15/04:  Log 773:  Switch NonZero check to use RG.GetCalc("CashRecFrmCust") instead of RG.GetCalc("CashCollFromSales")
			if (RG.GetCalc("CashRecFrmCust").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("fasCshRcdFrCust"), RG.GetPrintOrderCalc(RG.GetCalc("CashRecFrmCust")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCostOfSalesCF"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgInventory"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSupplies"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgPurchases"));
			///CPF 01/12/06 Log 898:  Adding "Due to Rel Co - CP"
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueToRelCoCP"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOthPurch"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSellExp"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpExp"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgPrePds"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCostExcBill"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOvrdrfts"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgBillExcCost"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOp"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOpAst"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgLTOpAst"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOpLiab"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOpNonCurLiab"));

			if (RG.GetCalc("CashPdSuppEmp").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintLabel(RG, rm.GetString("fasCshPdToSup"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("fasAndEmp"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdSuppEmp")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInterestExp"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapInterestUCA"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIntPay"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("InterestPaid").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("fasIntPd"), RG.GetPrintOrderCalc(RG.GetCalc("InterestPaid")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncomeTaxes"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncomeTaxCred"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIncTaxRcv"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefIncTaxRec"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIncTaxPay"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefFedIncTax"));

			if (RG.GetCalc("IncTaxPaid").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("fasIncTxPd"), RG.GetPrintOrderCalc(RG.GetCalc("IncTaxPaid")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIntIncome"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncFrmSubsid"));

			if (RG.GetCalc("IntDivRcvd").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("fasIntDivRcvd"), RG.GetPrintOrderCalc(RG.GetCalc("IntDivRcvd")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthIncAccts"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthIncAccts2"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTExtrIncAftTxInc"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpInc"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthExpAct"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTxIncome"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSTInvRelCo"));

			if (RG.GetCalc("MiscCashRcvPd").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("fasMiscCshRcvPd"), RG.GetPrintOrderCalc(RG.GetCalc("MiscCashRcvPd")));
			Utility.Skip(RG, 1);
			
			Utility.PrintLabel(RG, rm.GetString("fasNetCshProv"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("fasByOper"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvOp")));

			Utility.UnderlinePage(RG, 1);

			//amit: 05/24/04 Removing hard page break. Cannot implement hard pagebreak with report
			//grouping (Keep togther)
			//Utility.PageBreak(RG);

			//RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			//Utility.PrintLabel(RG, rm.GetString("fasNetCshProv"));
			//RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			//Utility.PrintSummary(RG, rm.GetString("fasByOper"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvOp")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintLabel(RG, rm.GetString("fasCshFlwInvAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			if (RG.GetCalc("Flows96,97,98").NonZero)
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTProcFrmAstSale"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapExpend"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapInterestStat"));
			}

			for (int i = 0; i < RG.GetCalc("Flows96,97,98").Count; i++) 
			{
				if (RG.GetCalc("Flows96,97,98")[i] == 0)
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFChgFxdAsts"));                   
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFChgAccDepr"));
					RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFDepreciation"));
                    RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
                    Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgReserves"));
                    RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFGnLsAstSale"));
					break;
				}
			}

			if (RG.GetCalc("FASChgNetFxdAsts").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("fasChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgNetFxdAsts")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.Skip(RG, 1);
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgMarkSec"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSTInvest"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgInvest"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCompInc"));
			Utility.PrintSummary(RG, rm.GetString("fasOCIRclsAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(212)")));
			Utility.PrintSummary(RG, rm.GetString("fasOCIAdjDueChgExcRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(214)")));

			if (RG.GetCalc("FASChgInvest").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("fasChgInvest"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgInvest")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.Skip(RG, 1);
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIntang"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgAccAmrt"));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAmortization"));

			if (RG.GetCalc("ChgNetIntang").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("fasChgNetIntang"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetIntang")));
			}

            Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAsstRvltn"));

			if (RG.GetCalc("NetCashUsedInvst").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("fasNetCshUsdInv"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashUsedInvst")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("fasCshFlwFinAct"));

			if (RG.GetCalc("ProcLessPymts").NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTProcFrBorr"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTPrinPytDbt"));
			}
		
			for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++) 
			{
				if (RG.GetCalc("ProcLessPymts")[i] == 0)
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
					RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTFASChgSTBorr"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTFASChgCPLTD"));
					Utility.PrintSummary(RG, rm.GetString("fasChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgLTD")));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTFASChgDefDebt"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTFASChgSubordDef"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTFASChgSubordDbtLiab"));
					break;
				}
			}
	

			if (RG.GetCalc("NetChgBorrow").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("fasNetChgBorr"), RG.GetPrintOrderCalc(RG.GetCalc("NetChgBorrow")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefIntExp"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgNonOpCurLiabs"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueRelCo"));			
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOthLiabGA"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthDeduct"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDividends"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDivPay"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintSummary(RG, rm.GetString("fasUnexAdjNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(260)")));
			Utility.PrintSummary(RG, rm.GetString("fasUnexAdRE"), -1 * RG.GetPrintOrderCalc(RG.GetCalc("LINE(220)")));

			if (RG.GetDetailCalcs("LINE(217)") != null & RG.GetDetailCalcs("LINE(219)") != null)
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(217)"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(219)"));
			}

			Utility.PrintSummary(RG, rm.GetString("fasAdjChgExgRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(206)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCapItems"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgTreasStk"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubDebtEq"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubDefer"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonCashIncome"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonCashExpense"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTxNnCashIncExp"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDivStock"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDivOth"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMinInt"));

			if (RG.GetCalc("NetCashProvFin").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("fasNetCshProvFin"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvFin")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(244)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("ChgInCashEquiv").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("fasChgCshEqv"), RG.GetPrintOrderCalc(RG.GetCalc("ChgInCashEquiv")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (RG.GetCalc("ChgInCashEquiv").NonZero)
				Utility.Skip(RG, 1);

			if (RG.GetCalc("FASAdjstItems").NonZero)
				Utility.PrintLabel(RG, rm.GetString("ucaAdd"));

			///HERE WE WOULD SHUT OFF ST_CROSS_FOOT FOR STP.
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");
			
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCashCF"));
			Utility.PrintSummary(RG, rm.GetString("fasCshAdj"), RG.GetPrintOrderCalc(RG.GetCalc("FASCashAdjustment")));
			Utility.UnderlineColumn(RG, 1, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("fasCshEqvEOP"), RG.GetPrintOrderCalc(RG.GetCalc("CashEquivEOP")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
