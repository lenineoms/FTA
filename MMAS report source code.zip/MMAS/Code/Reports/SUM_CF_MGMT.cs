using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	
	public class SUM_CF_MGMT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			//SPA - see if all of these are necessary - streamline to possible remove BSCalcs
			Calcs.ISCalcs(RG);
			Calcs.BSCalcs(RG);
			Calcs.RatioCalcs(RG);
			Calcs.CF_MGMT_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: start outer group (full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: start 1st group "UCA Cash After"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintLabel(RG,rm.GetString("scfmUCACshAftOps"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("scfmNetSales"), RG.GetPrintOrderCalc(RG.GetCalc("CFNetSales")));
			Utility.PrintSummary(RG, rm.GetString("scfmChgActNtsRecTrd"), RG.GetPrintOrderCalc(RG.GetCalc("CFChgARNet")));
			///CPF 04/11/06 Log 898:  Added print of Chg Due from Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueFmRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("scfmChgBllCsts"), RG.GetPrintOrderCalc(RG.GetCalc("ChgBillVsCosts")));
			Utility.PrintSummary(RG, rm.GetString("scfmChgDefRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDefRev").GetTotals(RG)));

			if (RG.GetCalc("CashCollFromSales").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("scfmCshCollFmSls"), RG.GetPrintOrderCalc(RG.GetCalc("CashCollFromSales")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("scfmCstSlsRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTCostOfSalesCF").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("scfmChgInv"), RG.GetPrintOrderCalc(RG.GetCalc("ChgTotInventory")));
			///CPF 04/11/06 Log 1667: Removed Chg Due to Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("scfmChgAPTrd"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgPurchases").GetTotals(RG)));
			///CPF 04/11/06 Log 898:  Added print of Chg Due to Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueToRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueToRelCoCP").GetTotals(RG)));

			if (RG.GetCalc("CashPaidToSupp").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("scfmCshPdSupp"), RG.GetPrintOrderCalc(RG.GetCalc("CashPaidToSupp")));
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("scfmCshFmTrdAct"), RG.GetPrintOrderCalc(RG.GetCalc("CashFromTradAct")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintSummary(RG, rm.GetString("scfmSGAExp"), RG.GetPrintOrderCalc(RG.GetCalc("CFSGAExp")));
			Utility.PrintSummary(RG, rm.GetString("scfmChgPpdDfd"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgPrePds").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("scfmChgOvrdfts"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgOvrdrfts").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("scfmChgAccrOthPay"), RG.GetPrintOrderCalc(RG.GetCalc("ChgAccrlsOthPay")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("CashPdOpCost").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("scfmCshPdOpCsts"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdOpCost")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("scfmCshAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("CashAfterOps")));
			Utility.UnderlinePage(RG,2);

			// SPA - put these calcs in Calculations.cs for CF_MGMT
			if (RG.GetCalc("CFGrossMargin") == null)
				RG.AddCalc("CFGrossMargin", RG.GetCalc("LINE(978)") % RG.GetCalc("NetSalesRev"));
			if (RG.GetCalc("CFOpExpPct") == null)
				RG.AddCalc("CFOpExpPct", RG.GetCalc("LINE(979)") % RG.GetCalc("NetSalesRev"));

			//amit: end 1st group "UCA cash after"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start 2nd group "Cash impact"
			Utility.mT.AddStartRow(Utility.nRow + 1);
			
			Utility.PrintLabel(RG,rm.GetString("scfmCshImpAnyl"));
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmNetSlsGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesGwth")));
		
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			Utility.PrintSummary(RG, rm.GetString("scfmTotCshImpGwth"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1771)")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmGrsMgnDpr"), RG.GetPrintOrderCalc(RG.GetCalc("CFGrossMargin")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpGrsMgnMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(983)")));
			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmOpExpDpr"), RG.GetPrintOrderCalc(RG.GetCalc("CFOpExpPct")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpOpExpMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(986)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmARDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(984)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpARDaysMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(995)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmInvDOHDpr"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1701)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpInvDaysMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1713)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmAPDaysDpr"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1728)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpAPDaysMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1737)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("scfmOthOpAsts"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1729)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpOthOpAstMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1725)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("scfmAccrExpDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1741)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpAccrMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1755)")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("scfmOthCurLiabs"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1731)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("scfmCshImpOthCurLbMt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1768)")));

			Utility.UnderlinePage(RG,2);
            
			//amit: end of 2nd group "cash impact"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: end of outer group(full report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
