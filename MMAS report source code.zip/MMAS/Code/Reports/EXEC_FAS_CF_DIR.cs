using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class EXEC_FAS_CF_DIR:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			Calcs.FAS_CF_Dir_Calcs(RG);
			Calcs.FAS_CF_Ind_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);
			
			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start outer group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 1st group "Cash Flows"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("efasCFFmOpAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			
			Utility.PrintSummary(RG, rm.GetString("efasCshRcvFmCust"), RG.GetPrintOrderCalc(RG.GetCalc("CashRecFrmCust")));
			Utility.PrintSummary(RG, rm.GetString("efasCshPdSupEmp"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdSuppEmp")));
			Utility.PrintSummary(RG, rm.GetString("efasIntPd"), RG.GetPrintOrderCalc(RG.GetCalc("InterestPaid")));
			Utility.PrintSummary(RG, rm.GetString("efasIntTxPd"), RG.GetPrintOrderCalc(RG.GetCalc("IncTaxPaid")));
			Utility.PrintSummary(RG, rm.GetString("efasIntDivRcd"), RG.GetPrintOrderCalc(RG.GetCalc("IntDivRcvd")));
			Utility.PrintSummary(RG, rm.GetString("efasMiscCashRcvd"), RG.GetPrintOrderCalc(RG.GetCalc("MiscCashRcvPd")));
			Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("efasNtCshPrvByOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvOp")));

			Utility.Skip(RG, 1);

			//amit: End 1st group "Cash Flows"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start of 2nd group "Cash Flows From Investing"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("efasCFFmInvAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("efasChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgNetFxdAsts")));
			Utility.PrintSummary(RG, rm.GetString("efasChgInvest"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgInvest")));
			Utility.PrintSummary(RG, rm.GetString("efasChgIntangNet"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetIntang")));
            //add to GainLossAssRev
            Utility.PrintSummary(RG, rm.GetString("sucaGainLossAssRev"), RG.GetPrintOrderCalc(RG.GetCalc("GainLossAssRev")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("efasNetCshUsdInvst"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashUsedInvst")));
			Utility.Skip(RG, 1);

			//amit: End 2nd group "Cash Flows From Investing"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start of 3rd group "Cash Flows From Financing"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("efasCFFmFinAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
			{
				if (RG.GetCalc("ProcLessPymts")[i] != 0)
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTProcFrBorr"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTPrinPytDbt"));
					break;
				}
			}

			for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
			{
				if (RG.GetCalc("ProcLessPymts")[i] == 0)
				{
					Utility.PrintSummary(RG, rm.GetString("efasChgSTLiabs"), RG.GetPrintOrderCalc(RG.GetCalc("FASEChgSTLiabs")));
					Utility.PrintSummary(RG, rm.GetString("efasChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("FASSumChgLTD")));
					Utility.PrintSummary(RG, rm.GetString("efasChgSubDbtAct"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgSubDbt")));
					break;
				}
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			if (RG.GetCalc("NetChgBorrow").NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.UnderlineColumn(RG, 1, 1);
				Utility.PrintSummary(RG, rm.GetString("efasNetChgBorr"), RG.GetPrintOrderCalc(RG.GetCalc("NetChgBorrow")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			//Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefIntExp"));
			Utility.PrintSummary(RG, rm.GetString("efasDefIntExp"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG)));
			//RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			
			Utility.PrintSummary(RG, rm.GetString("efasChgOthSTLTLiabs"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgOthSTLTLiabs")));
			Utility.PrintSummary(RG, rm.GetString("efasCashDivPd"), RG.GetPrintOrderCalc(RG.GetCalc("CFDivsPIC")));			
			Utility.PrintSummary(RG, rm.GetString("efasChgCapLsNonCsh"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(2450)")));			

			if (RG.GetCalc("NetCashProvFin").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("efasNetCshProvFin"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvFin")));

			//amit: 09/10/05 removed the hard coded string
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn")); //("Chg in ");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(244)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("ChgInCashEquiv").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("efasChgCashEq"), RG.GetPrintOrderCalc(RG.GetCalc("ChgInCashEquiv")));
			Utility.Skip(RG, 1);

			///HERE WE WOULD SHUT OFF ST_CROSS_FOOT FOR STP.
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");
			
			Utility.PrintSummary(RG, rm.GetString("efasAddCshEqBOP"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTCashCF").GetTotals(RG)));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintSummary(RG, rm.GetString("efasCshAdj"), RG.GetPrintOrderCalc(RG.GetCalc("FASCashAdjustment")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.UnderlineColumn(RG, 1, 1);
			
			Utility.PrintSummary(RG, rm.GetString("efasCshEqEOP"), RG.GetPrintOrderCalc(RG.GetCalc("CashEquivEOP")));

			Utility.UnderlinePage(RG, 2);

			//amit: End 3rd group "Cash Flows from financing"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End outer group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
