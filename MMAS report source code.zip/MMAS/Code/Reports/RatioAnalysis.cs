using System;
using FinancialAnalyst;
using System.Threading;
using System.Collections;
using System.IO;
using System.Resources;
using System.Reflection;

using MKMV.DocumentGenerator;
using MKMV.DocumentGenerator.PDF;
using MKMV.DocumentGenerator.HTML;

namespace MMAS
{
	public class RatioAnalysis
	{
		/// The purpose of the ColumnHeader class is to allow the model author to print a dynamic
		/// listing of lines in the column header.  For this purpose, I am describing the column header
		/// as the line typically starting with "Statement Date" and ending typically with the 
		/// underline page that seperates the header from the actual report data.
		/// 
		/// Basically, we have a ColumnHeader object that accepts 4 parms.  
		///		string Label			This is the text label that you see left justified in the first cell
		///		object Column1_Values	This is any object that you want to use to supply values for the first column
		///								Typical items here would be RG.STMT_DATE, STMT_CONSTANTS, string arrays
		///		object Column2_Values	This is any object that you want to use to supply values for the second column
		///								This is something you might want in a % column of a Act & % report for example.  If
		///								you wanted blanks, simply pass a string array the size of the stmt collection full of "" values.
		///		object Column3_Values	This is any object that you want to use to supply values for the third column
		///								This is something you might want in a % column of a Act & % report for example.  If
		///								you wanted blanks, simply pass a string array the size of the stmt collection full of "" values.
		///								
		/// You will have 1 ColumnHeader object for EACH row in the ColumnHeader.  Basically, in the report
		/// side, we will create an arraylist of ColumnHeader objects.
		
		protected eGrowthType GType;
		protected eGrowthSignificance GSig;
		protected eGrowthTrend GTrnd;

		public enum eGrowthType
		{
			NoGrowth = 1,
			Positive = 2,
			Negative = 3,
		}

		public enum eGrowthSignificance
		{
			Little = 1,
			Moderate = 2,
			Significant = 3,
			VerySignificant = 4,			
		}

		public enum eGrowthTrend
		{
			NoGrowthLastYear = 1,
			CloseToLastYear = 2,
			GreaterThanLastYear = 3,
			LessThanLastYear = 4,			
		}

		public  RatioAnalysis(ReportGenerator RG, double RatioValue, double RatioValueLag, int ModerateParmID, int SignificantParmID, bool LessTwoGwthPeriods)
		{
			///First check to see if the nature of the growth.
			if (RatioValue > 0)
				GType = eGrowthType.Positive;
			else if (RatioValue < 0)
				GType = eGrowthType.Negative;
			else
				GType = eGrowthType.NoGrowth;

			///Next check the Growth Signigicance
			///CHECK TO SEE IF ATLEAST MODERATE
			if (Math.Abs(RatioValue) > RG.PARM(ModerateParmID))
			{
				///CHECK TO SEE IF ATLEAST SIGNIFICANT
				if (Math.Abs(RatioValue) > RG.PARM(SignificantParmID))
				{
					///CHECK TO SEE IF VERY SIGNIFICANT (> 2 X SIGNIFICANT)
					if (Math.Abs(RatioValue) > (RG.PARM(SignificantParmID) * 2))
						GSig = eGrowthSignificance.VerySignificant;
					else
						GSig = eGrowthSignificance.Significant;
				}
				else
					GSig = eGrowthSignificance.Moderate;
			}
			else
				GSig = eGrowthSignificance.Little;


			///Finally, check to see the trend in growth
			if (LessTwoGwthPeriods == true)
				GTrnd = eGrowthTrend.NoGrowthLastYear;
			else 
			{
				if (Math.Abs(RatioValue - RatioValueLag) > (RG.PARM(SignificantParmID) * 0.1))
				{
					if ((RatioValue - RatioValueLag) > 0)
						GTrnd = eGrowthTrend.GreaterThanLastYear;
					else 
						GTrnd = eGrowthTrend.LessThanLastYear;
				}
				else
					GTrnd = eGrowthTrend.CloseToLastYear;
			}


		}

		public RatioAnalysis(ReportGenerator RG, double RatioValue, double RatioValueLag, int ModerateParmID, int SignificantParmID)
		{
			///First check to see if the nature of the growth.
			if (RatioValue > RatioValueLag)
				GType = eGrowthType.Positive;
			else if (RatioValue < RatioValueLag)
				GType = eGrowthType.Negative;
			else
				GType = eGrowthType.NoGrowth;

			///Next check the Growth Signigicance
			///CHECK TO SEE IF ATLEAST MODERATE
			if (Math.Abs(RatioValue - RatioValueLag) > RG.PARM(ModerateParmID))
			{
				///CHECK TO SEE IF ATLEAST SIGNIFICANT
				if (Math.Abs(RatioValue - RatioValueLag) > RG.PARM(SignificantParmID))
				{
					///CHECK TO SEE IF VERY SIGNIFICANT (> 2 X SIGNIFICANT)
					if (Math.Abs(RatioValue - RatioValueLag) > (RG.PARM(SignificantParmID) * 2))
						GSig = eGrowthSignificance.VerySignificant;
					else
						GSig = eGrowthSignificance.Significant;
				}
				else
					GSig = eGrowthSignificance.Moderate;
			}
			else
				GSig = eGrowthSignificance.Little;


//			///Finally, check to see the trend in growth
//			if (LessTwoGwthPeriods == true)
//				GTrnd = eGrowthTrend.NoGrowthLastYear;
//			else 
//			{
//				if (Math.Abs(RatioValue - RatioValueLag) > (RG.PARM(SignificantParmID) * 0.1))
//				{
//					if ((RatioValue - RatioValueLag) > 0)
//						GTrnd = eGrowthTrend.GreaterThanLastYear;
//					else 
//						GTrnd = eGrowthTrend.LessThanLastYear;
//				}
//				else
//					GTrnd = eGrowthTrend.CloseToLastYear;
//			}


		}
		public eGrowthType GrowthType
		{
			get{ return GType; }
			set{ GType = value; }
		}

		public eGrowthSignificance GrowthSignificance
		{
			get{ return GSig; }
			set{ GSig = value; }
		}

		public eGrowthTrend GrowthTrend
		{
			get{ return GTrnd; }
			set{ GTrnd = value; }
		}
	}
}
