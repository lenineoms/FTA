using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class DET_IS_ACT_PERCENT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// ***CPF Load the Income Statement Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);
			
			///***CPF 7/26/02 Call the base income statement code. 
			MMAS_Utility.DETAILED_INCOME_STATEMENT(RG, FORMATCOMMANDS.ACT_PERCENT, Calcs);

			//			StreamWriter sw = new StreamWriter("C:\\Det_IS_Act.txt");
			//			sw.Write(RG.Writer.Commands);
			//			sw.Close();
		}
	}
}
