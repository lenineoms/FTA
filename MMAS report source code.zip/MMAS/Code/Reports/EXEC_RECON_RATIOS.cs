using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class EXEC_RECON_RATIOS:FinancialAnalyst.IReport
	{
		//SPA - copied DET_RATIOS and commented out all items that don't belong in SUM_RATIOS
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();

			Calcs.BSCalcs(RG);
			Calcs.ISCalcs(RG);
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			Calcs.RatioCalcs(RG);
			
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows

			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//SPA - Recon WC section
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");
			
			//amit: Start outer group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 1st group "Begining W capital"
			Utility.mT.AddStartRow(Utility.nRow + 1);
            
			Utility.PrintCenter(RG, rm.GetString("errReconWC"));
			Utility.UnderlinePage(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			// KCZ Fix for suppress #336
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintSummary(RG, rm.GetString("errBegWC"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(300)")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("errChgTotFxdAstNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(370)")));
			Utility.PrintSummary(RG, rm.GetString("errChgLTRecInv"), RG.GetPrintOrderCalc(RG.GetCalc("EReconChgLTRecInv")));
			Utility.PrintSummary(RG, rm.GetString("errChgOthLTAst"), RG.GetPrintOrderCalc(RG.GetCalc("EReconChgOthLTAsts")));
			Utility.PrintSummary(RG, rm.GetString("errChgIntangNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(398)")));

			Utility.PrintSummary(RG, rm.GetString("errChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("EReconChgLTD")));			
			Utility.PrintSummary(RG, rm.GetString("errChgOthNonCurLiab"), RG.GetPrintOrderCalc(RG.GetCalc("SumReconOthNonCurLiabs")));
			
			Utility.PrintSummary(RG, rm.GetString("errChgNW"), RG.GetPrintOrderCalc(RG.GetCalc("IncDecNetWrth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintSummary(RG, "Unexplained Adjustment", RG.GetPrintOrderCalc(RG.GetCalc("LINE(320)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("errEndWC"), RG.GetPrintOrderCalc(RG.GetCalc("EndWorkCap")));

			///ST_CROSS_FOOT_ON
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");

			Utility.UnderlinePage(RG, 2);

			//amit: End 1st group "Begining W capital"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start of 2nd group "UCA Cash Flow"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//SPA - UCA Cash Flow section
			Utility.PrintCenter(RG,rm.GetString("errUCACF"));
			Utility.UnderlinePage(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("errCshCollFmSls"), RG.GetPrintOrderCalc(RG.GetCalc("CashCollFromSales")));
			Utility.PrintSummary(RG, rm.GetString("errCshPdSupp"), RG.GetPrintOrderCalc(RG.GetCalc("CashPaidToSupp")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("errCashFmTrdAct"), RG.GetPrintOrderCalc(RG.GetCalc("CashFromTradAct")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("errCshPdOpCst"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdOpCost")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("errCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("CashAfterOps")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("errOthCashExp"), RG.GetPrintOrderCalc(RG.GetCalc("ECFOthCashExp")));
			Utility.PrintSummary(RG, rm.GetString("errTxPdCash"), RG.GetPrintOrderCalc(RG.GetCalc("CFTaxesPIC")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("errNetCshAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashAfterOps")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("errIntPdInCsh"), RG.GetPrintOrderCalc(RG.GetCalc("ECFIntPIC")));
			Utility.PrintSummary(RG, rm.GetString("errDivPdInCsh"), RG.GetPrintOrderCalc(RG.GetCalc("CFDivsPIC")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("errNetCshInc"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashInc")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("errCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("CurPtnLTD")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("errCashAftDbtAmt"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftDebtAmrt")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			
			Utility.PrintSummary(RG, rm.GetString("errChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetFxdAsts")));
			Utility.PrintSummary(RG, rm.GetString("errChgInvstIntng"), RG.GetPrintOrderCalc(RG.GetCalc("ECFChgInvestIntang")));
            //add to GainLossAssRev
            Utility.PrintSummary(RG, rm.GetString("sucaGainLossAssRev"), RG.GetPrintOrderCalc(RG.GetCalc("GainLossAssRev")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("errExtraNonCshItm"), RG.GetPrintOrderCalc(RG.GetCalc("ExtraordNonCashItems")));

			Utility.PrintSummary(RG, rm.GetString("errFinSrplsRqmt"), RG.GetPrintOrderCalc(RG.GetCalc("FinancingSurplus")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("errTotExtFin"), RG.GetPrintOrderCalc(RG.GetCalc("TotExtFinanc")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			
			Utility.PrintSummary(RG, rm.GetString("errCashAftFin"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftFinanc")));

			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");

			Utility.PrintSummary(RG, rm.GetString("errAddBegCshEq"), RG.GetPrintOrderCalc(RG.GetCalc("CFBegCashEquiv")));

			//SPA - my suppress is True and I do this IF, but Cash Adjustment still prints if zero
			// must investigate and resolve later
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			if (RG.GetCalc("CashAdjustment").NonZero)
				Utility.PrintSummary(RG, rm.GetString("errCashAdj"), RG.GetPrintOrderCalc(RG.GetCalc("CashAdjustment")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("errEndCshEqv"), RG.GetPrintOrderCalc(RG.GetCalc("EndCashEquiv")));

			Utility.UnderlinePage(RG, 2);

			//amit: End 2nd group "UCA Cash Flow"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start of 3rd group "Ratios"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//SPA - Ratios section
			Utility.PrintCenter(RG,rm.GetString("errRatios"));
			Utility.UnderlinePage(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, rm.GetString("errWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("WorkingCap")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("errQckRatio"), RG.GetPrintOrderCalc(RG.GetCalc("QuickRatio")));
			Utility.PrintSummary(RG, rm.GetString("errCurrRatio"), RG.GetPrintOrderCalc(RG.GetCalc("CurrRatio")));
			Utility.PrintSummary(RG, rm.GetString("errDbtWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtWorth")));
			Utility.PrintSummary(RG, rm.GetString("errDbtTngWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtTangWorth")));
			Utility.PrintSummary(RG, rm.GetString("errNetIncDprAmtCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("NetIncDepAmtCPLTD")));

			Utility.PrintSummary(RG, rm.GetString("errROA"), RG.GetPrintOrderCalc(RG.GetCalc("ROA")));
			Utility.PrintSummary(RG, rm.GetString("errROE"), RG.GetPrintOrderCalc(RG.GetCalc("ROE")));
			Utility.PrintSummary(RG, rm.GetString("errNetARDays"), RG.GetPrintOrderCalc(RG.GetCalc("NetARDays")));
			if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(15)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(16)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(17)) > 0) //amit: 06/07/04 changed to > 0 from > 1
				Utility.PrintSummary(RG, rm.GetString("errInvDOH"), RG.GetPrintOrderCalc(RG.GetCalc("InvDOH")));

			Utility.PrintSummary(RG, rm.GetString("errAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("ActPayDOH")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintSummary(RG, rm.GetString("errTAGwth"), RG.GetPrintOrderCalc(RG.GetCalc("TotAstGwth")));
			Utility.PrintSummary(RG, rm.GetString("errTLGwth"), RG.GetPrintOrderCalc(RG.GetCalc("TotLiabGwth")));
			Utility.PrintSummary(RG, rm.GetString("errNWGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetWrthGwth")));
			Utility.PrintSummary(RG, rm.GetString("errNSGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesGwth")));
			Utility.PrintSummary(RG, rm.GetString("errNPGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfitGwth")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.UnderlinePage(RG, 2);

			//amit: End 3rd group "Ratios"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End outer group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
			
		}
	}
}
