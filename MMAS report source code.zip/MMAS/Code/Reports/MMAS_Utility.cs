using System.Collections;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.Collections.Generic;
using System.Linq;

namespace MMAS
{
	public static class MMAS_Utility
	{
		static public void DETAILED_BALANCE_SHEET(ReportGenerator RG, int ReportType)
		{
			int[] ColumnFormula = new int[1];
			int[] DetColumnFormula = new int[1];
			bool[] ColRound = new bool[1];
			int RptTypeVal;

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;			
			ColRound[0] = false;

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();
			//ColumnHeader ColHead = new ColumnHeader();

			/// This switch statement sets up a variable that tells
			/// some of the formatting commands how many columns there are.
			int NumCols;
			switch(ReportType)
			{
				case FORMATCOMMANDS.ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.PERCENT:
					NumCols = 1;break;
                // KCZ Added for Version V 6-16-03
				case FORMATCOMMANDS.ACT_EXCHANGE:
					NumCols = 2;
					ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
					DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
					ColRound[0] = true;
					break;
				case FORMATCOMMANDS.ACT_TREND:
					NumCols = 2;
					ColumnFormula[0] = M.COLUMN_2_TREND;
					DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
					break;
                 // End of 6-16-03 Addition
				case FORMATCOMMANDS.ACT_PERCENT:
					NumCols = 2;break;
				default: 
					NumCols = 1;break;
			}

			FormatCommands.LoadFormatDefaults(RG);
			
			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			}
                 // KCZ New report types
			else if ( (ReportType == FORMATCOMMANDS.ACT_EXCHANGE))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "ON");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				//KCZ  make the second column wider to accommodate actual numbers
				RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_2, "1.0");
			}
			else if ((ReportType == FORMATCOMMANDS.ACT_TREND))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "ON");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
				// KCZ Added to make column 2 have 1 decimal for trend reports 6-17-03
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}

			//CPF 11/21/03 This section modifies what prints in the stmt constant section
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				//Add the currency line
				ColumnHeader cCurr = new ColumnHeader(rm.GetString("bsCurrency"), rm.GetString("bsTarget"), rm.GetString("bsSource"), "");
				Utility.arrColHead.Add(cCurr);
			}
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				//Remove the last two stmt constants added in the default.
				Utility.arrColHead.RemoveRange(5,2);
				//Re-Add the last two stmt constants with the extra "Trend % Chg" labels in column 2.
				StatementConstant sc1 = (StatementConstant)RG.Customer.Model.StatementConstants[3];
				StatementConstant sc2 = (StatementConstant)RG.Customer.Model.StatementConstants[4];
				ColumnHeader ch1 = new ColumnHeader(sc1.Label, sc1, rm.GetString("bsTrend"), "");
				ColumnHeader ch2 = new ColumnHeader(sc2.Label, sc2, rm.GetString("bs%Chg"), "");
				Utility.arrColHead.Add(ch1);
				Utility.arrColHead.Add(ch2);
			}
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, NumCols);

			///***CPF 3/12/02 ONCE GLOBAL CONSTS ARE DETERMINED, WE NEED TO CHECK
			///SOURCE AND TARGET CURRENCY HERE, AND PRINT IF THERE ARE FILLED.
			Utility.PrintSourceTargetCurr(RG);
		
			///***CPF 3/2/04 This is the outer most keep together for the entire report
			Utility.mT.AddStartRow(Utility.nRow+1);
			///***CPF 3/2/04 This is the keep together to start the Total Assets Section
			Utility.mT.AddStartRow(Utility.nRow+1);
			///***CPF 3/2/04 This is the keep together to start the Current Assets section
			Utility.mT.AddStartRow(Utility.nRow+1);

			

			int iCurColEx = ColumnFormula[0];
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "5");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
				///CPF 6/24/03  This is so that we don't round these items.
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
				ColumnFormula[0] = M.COLUMN_2_EMPTY;	
				Utility.PrintSummary(RG, rm.GetString("bsExchgRt"), RG.CONV_RATE(), ReportType, ColumnFormula, ColRound);
				ColumnFormula[0] = iCurColEx;	
				///CPF 6/24/04 Log 797:  Added skip before Current Asset header
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			///Check to see if there are any items in Class(5) to print.
			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(5)) > 0)
				/// Print the "CURRENT ASSETS" header
				Utility.PrintLabel(RG, rm.GetString("bsCurAstHdr"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCashActs"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMarkSecActs"), ReportType, DetColumnFormula, ColRound);

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTARActs")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTBadDebtRes")) > 1)
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTARActs"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTBadDebtRes"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTARActs")) + FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTBadDebtRes")) > 1)
			{
				/// Underline the columns you just printed
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("bsTotActsRecNet"), RG.GetCalc("TotActsRcvNet"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTActsNotRcvRelCo"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTActsNotRcvOth"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncTaxRcv"), ReportType, DetColumnFormula, ColRound);

			int DetInv;
			DetInv = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTInvRawMat")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTInvWrkProc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTInvFinGds")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTInvOther"));

			if (DetInv > 1)
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInvRawMat"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInvWrkProc"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInvFinGds"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInvOther"), ReportType, DetColumnFormula, ColRound);

			if (DetInv > 1)
				/// Underline the columns you just printed
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (DetInv > 1)
				Utility.PrintSummary(RG, rm.GetString("bsTotInv"), RG.GetCalc("TotalInv"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCostExcBill"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpCurAst"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonOpCurAst"), ReportType, DetColumnFormula, ColRound);

			/// Set up the fomula for the second column
			//6-19 ColumnFormula[0] = M.COLUMN_2_EMPTY;
			DetColumnFormula[0]=M.COLUMN_2_EMPTY;

			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}
            // KCZ 6-17-03 Added to support Exchange Rate report memos
			else if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				//ColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
			}

			// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}


			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCA"), ReportType, DetColumnFormula, ColRound);
			


			// KCZ 6-17-03 Added to support Exchange Rate report memos (back to using exch rate)
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				//ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLifoRes"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurAst"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			// KCZ 6-17-03 Added to support Exchange Rate report memos
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				//ColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				DetColumnFormula[0]=M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCA"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			
			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
			// KCZ 6-23-03 Added to support Trend report memos
			if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
			}
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(5)) > 0)
				/// Underline the columns you just printed
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsTotCurAsts"), RG.GetCalc("TotCurAst"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if ((FormatCommands.DetailCount(RG, RG.DETAILCLASS(5)) > 0) && (FormatCommands.DetailCount(RG, RG.DETAILCLASS(10)) > 0))
				///  Double underline the page
				Utility.UnderlinePage(RG, 1);

			///***CPF 3/2/04  This is where we close the Current Assets keep together
			Utility.mT.AddEndRow(Utility.nRow);
			///***CPF 3/2/04  This is where start the keep together for Non-Current Assets
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(10)) > 0)
				/// Print the "NON-CURRENT ASSETS" header
				Utility.PrintLabel(RG, rm.GetString("bsNonCurAstHdr"));

			int NetFxdAst;
			NetFxdAst = (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTLand"))) + 
				(FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTConstInPrg"))) +
				(FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOthFxdAsts")));

			if (NetFxdAst < 1)
			{NetFxdAst = 0;}
			else if (NetFxdAst == 1)
			{NetFxdAst=1;}
			else
			{NetFxdAst=2;}
			
		
			int AccDepr;
			AccDepr = (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAccumDepr")));		

			if (AccDepr == 0)
			{AccDepr = 3;}
			else
			{AccDepr = 6;}
			
			if ((NetFxdAst + AccDepr == 2) || (NetFxdAst + AccDepr >= 5))
			{RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLand"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTConstInPrg"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthFxdAsts"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if ((NetFxdAst + AccDepr == 2) || (NetFxdAst + AccDepr == 5))
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("bsTotFxdAstNet"), RG.GetCalc("NetFxdAsts"), ReportType, ColumnFormula, ColRound);
			}

			if (NetFxdAst + AccDepr == 8) 
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("bsGrsFxdAst"), RG.GetCalc("GrsFxdAsts"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (NetFxdAst + AccDepr >= 6)
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAccumDepr"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			
			if ((NetFxdAst + AccDepr == 7) || (NetFxdAst + AccDepr == 8))
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("bsTotFxdAstNet"), RG.GetCalc("NetFxdAsts"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLTReceiv"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInvestments"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLTPrepaids"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpNonCurAst"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncTaxRcvble"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonOpNonCurAst"), ReportType, DetColumnFormula, ColRound);

			int Intang;
			Intang = FormatCommands.DetailCount(RG, RG.DETAILTYPE(70));

			if (Intang < 1)
			{Intang = 0;}
			else if (Intang == 1)
			{Intang = 1;}
			else
			{Intang = 2;}

			int AccAmrt;
			AccAmrt = FormatCommands.DetailCount(RG, RG.DETAILTYPE(71));

			if (AccAmrt == 0)
			{AccAmrt = 3;}
			else
			{AccAmrt = 6;}

			if ((Intang + AccAmrt == 2) || (Intang + AccAmrt >= 5))
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIntangibles"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if ((Intang + AccAmrt == 2) || (Intang + AccAmrt == 5))
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("bsTotIntangNet"), RG.GetCalc("IntangNet"), ReportType, ColumnFormula, ColRound);				
			}

			if (Intang + AccAmrt == 8) 
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("bsGrsIntang"), RG.GetCalc("GrossIntang"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (Intang + AccAmrt >= 6)
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAccAmort"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if ((Intang + AccAmrt == 7) || (Intang + AccAmrt == 8))
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("bsTotIntangNet"), RG.GetCalc("IntangNet"), ReportType, ColumnFormula, ColRound);				
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			/// Set up the fomula for the second column
			DetColumnFormula[0] = M.COLUMN_2_EMPTY;
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}
            // KCZ 6-17-03 Added for support of Exchange Rate report
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				//ColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				DetColumnFormula[0]=M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
			}
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCA"), ReportType, DetColumnFormula, ColRound);

			// KCZ 6-17-03 Added for support of Exchange Rate report
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				//ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurAst"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			// KCZ 6-17-03 Added for support of Exchange Rate report
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				//ColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				DetColumnFormula[0]=M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCA"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			// KCZ 6-17-03 Added for support of Exchange Rate report
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
				// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(10)) > 0)
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurAsts"), RG.GetCalc("TotNonCurAst"), ReportType, ColumnFormula, ColRound);

			Utility.PrintSummary(RG, rm.GetString("bsTotAsts"), RG.GetCalc("TotalAssets"), ReportType, ColumnFormula, ColRound);

			Utility.UnderlinePage(RG,1);

			///***CPF 3/2/04  This is where we close the Non-Current Assets keep together
			Utility.mT.AddEndRow(Utility.nRow);
			///***CPF 3/2/04  This is where we close the Total Assets keep together
			Utility.mT.AddEndRow(Utility.nRow);

			///***CPF 3/2/04  This is where start the keep together for Total Liabs
			Utility.mT.AddStartRow(Utility.nRow + 1);
			///***CPF 3/2/04  This is where start the keep together for Current Liabs
			Utility.mT.AddStartRow(Utility.nRow +1);

			///Utility.PageBreak(RG);

			/// HERE IS WHERE THE TOTAL LIABS AND EQUITY SECTION BEGINS

			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(15)) > 0)
				/// Print the "CURRENT LIABILITIES" header
				Utility.PrintLabel(RG, rm.GetString("bsCurLiabHdr"));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOvrDrftBook"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOvrDrftIB"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSTPayables"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCPLTD"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCPCapLeaseOb"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTActPayTrd"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTActPayRelCo"), ReportType, DetColumnFormula, ColRound);

			int DetAccdLiabPay;
			DetAccdLiabPay = FormatCommands.DetailCount(RG, RG.DETAILTYPE(90)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(91)) + 
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(92));

			if (DetAccdLiabPay > 1)
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIntPay"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDivPay"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAccrdLiabs"), ReportType, DetColumnFormula, ColRound);

			if (DetAccdLiabPay > 1)
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (DetAccdLiabPay > 1)
				Utility.PrintSummary(RG, rm.GetString("bsTotAcrdLiab"), RG.GetCalc("TotAccrdLiab"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTBillExcCost"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTTaxPayable"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpCurLiabs"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonOpCurLiabs"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			/// Set up the fomula for the second column
			DetColumnFormula[0] = M.COLUMN_2_EMPTY;
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}
            // KCZ Added in support of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
			}
			// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCL"), ReportType, DetColumnFormula, ColRound);
			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurLiabs"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

            // KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCL"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			
			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			// KCZ Added in suppport of Exchange Rate report 6-17-03 - set back to non-memos
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
			}
				// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			int CurLiab = 0;
			if (FormatCommands.DetailCount(RG, RG.DETAILCLASS(15)) > 0)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				CurLiab = 1;
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsTotCurLiabs"), RG.GetCalc("TotCurLiabs"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			int DetNonCurLiab;
			int NonCurLiab = 0;

			DetNonCurLiab = FormatCommands.DetailCount(RG, RG.DETAILTYPE(110)) + 
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(112)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(125)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(127)) + 
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(126)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(115)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(120)) +
                FormatCommands.DetailCount(RG, RG.DETAILTYPE(122)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(123));
 
			if (DetNonCurLiab > 0)
				NonCurLiab = 1;

			if (CurLiab + NonCurLiab == 2) 
				Utility.UnderlinePage(RG,1);

			///***CPF 3/2/04  This is where we close the Current Liabs keep together
			Utility.mT.AddEndRow(Utility.nRow);

			///***CPF 3/2/04  This is where start the keep together for Non-Current Liabs
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (DetNonCurLiab > 0)
				/// Print the "NON-CURRENT LIABILITIES" header
				Utility.PrintLabel(RG, rm.GetString("bsNonCurLiabHdr"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLTD"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapLeaseOb"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonOpNonCurLiab"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDueToRelCo"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpNonCurLiab"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefFedIncTax"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSubordDebtLiab"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTGrayAreaLiab"), ReportType, DetColumnFormula, ColRound);
            Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOtherLiabGrayArea"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			/// Set up the fomula for the second column
			DetColumnFormula[0] = M.COLUMN_2_EMPTY;
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
			}
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL"), ReportType, DetColumnFormula, ColRound);
			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurLiab"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL2"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL2"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			
			

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			// KCZ Added in suppport of Exchange Rate report 6-17-03- reset to non-memo status
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
				DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
			}
				// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (DetNonCurLiab > 0)
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurLiabs"), RG.GetCalc("TotNonCurLiabs"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("bsTotLiabs"), RG.GetCalc("TotLiabs"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (CurLiab + NonCurLiab >= 1) 
				Utility.UnderlinePage(RG, 1);

			///***CPF 3/2/04  This is where we close the Non-Current Liabs keep together
			Utility.mT.AddEndRow(Utility.nRow);
			///***CPF 3/2/04  This is where we close the Total Liabs keep together
			Utility.mT.AddEndRow(Utility.nRow);

			///***CPF 3/2/04  This is where start the keep together for Total Equity
			Utility.mT.AddStartRow(Utility.nRow + 1);

			int EquityDetail;

			EquityDetail  = FormatCommands.DetailCount(RG, RG.DETAILTYPE(134)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(135)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(130)) + 
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(131)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(140)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(132)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(133)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(129)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(141));
 
			if (EquityDetail > 0)
				/// Print the "NET WORTH" header
				Utility.PrintLabel(RG, rm.GetString("bsNetWrthHdr"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSubDebtEq"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTGrayAreaEq"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTPrefStk"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTComStk"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthEq"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCurTran"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTRetEarn"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAccumOCI"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTTreasStk"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			/// Set up the fomula for the second column
			DetColumnFormula[0] = M.COLUMN_2_EMPTY;
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}


			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
			}
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecEQ"), ReportType, DetColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			// KCZ Added in suppport of Exchange Rate report 6-17-03
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				DetColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecEQ"), ReportType, DetColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Set up the fomula for the second column // KCZ 6-17-03 added else
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			// KCZ Added in suppport of Exchange Rate report 6-17-03- reset to non-memo status
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "0");
			}
				// KCZ 6-23-03 Added to support Trend report memos
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_TREND;
				DetColumnFormula[0] = M.COLUMN_2_TREND_DC;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
			}

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (EquityDetail > 0)
				Utility.UnderlineColumn(RG, NumCols, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsTotNetWrth"), RG.GetCalc("TotNetWrth"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("bsTotLiabNetWrth"), RG.GetCalc("TotLiabsNetWorth"), ReportType, ColumnFormula, ColRound);

			Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("bsWorkCap"), RG.GetCalc("WorkingCap"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("bsTangNetWrth"), RG.GetCalc("TangNetWrthAct"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			///CPF 8/28/03  We modifed what we pass here as we did not want to pass converted values for
			///TA & TL/NW.  This way things should balance and the conversion rate cannot cause a rounding
			///issue.
			if (FormatCommands.Compare(RG.GetPrintOrderCalc(RG.GetCalc("TotalAssetsNoConvRate")), RG.GetPrintOrderCalc(RG.GetCalc("TotLiabsNetWorthNoConvRate"))) == "NotEqual")
				Utility.PrintLabel(RG, rm.GetString("bsImbalance"));

			Utility.UnderlinePage(RG, 2);

			///***CPF 3/2/04  This is where we close the Total Equity keep together
			Utility.mT.AddEndRow(Utility.nRow);
			///***CPF 3/2/04  This is where we close the keep together for the entire report.
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
		static public void SUMMARY_BALANCE_SHEET(ReportGenerator RG, int ReportType)
		{
			int[] ColumnFormula = new int[1];
			int[] DetColumnFormula = new int[1];
			bool[] ColRound = new bool[1];
			int RptTypeVal;

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS_DC;
			ColRound[0] = false;

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			/// This switch statement sets up a variable that tells
			/// some of the formatting commands how many columns there are.
			int NumCols;
			switch(ReportType)
			{
				case FORMATCOMMANDS.ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.ACT_PERCENT:
					NumCols = 2;break;
				default: 
					NumCols = 1;break;
			}

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			}

			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, NumCols);

			///***CPF 3/12/02 ONCE GLOBAL CONSTS ARE DETERMINED, WE NEED TO CHECK
			///SOURCE AND TARGET CURRENCY HERE, AND PRINT IF THERE ARE FILLED.
			Utility.PrintSourceTargetCurr(RG);

			///Utility.Skip(RG, 1);
		

            //amit: Start of the outer group (full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start of 1st group "Assets"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			/// Print the "ASSETS" header
			Utility.PrintLabel(RG, rm.GetString("sbsAssets"));
			/// RG.Writer.Execute("<TR><TD ALIGN=L>ASSETS</TD></TR>");

			/// Print the Current Assets section. 
			Utility.PrintSummary(RG, rm.GetString("sbsCashEq"), RG.GetDetailCalcs("DTCashActs").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsMarkSec"), RG.GetDetailCalcs("DTMarkSecActs").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			//if (ReportType != FORMATCOMMANDS.PERCENT)
			Utility.PrintSummary(RG, rm.GetString("sbsActNtRcTd"), RG.GetCalc("TotActsRcvNet"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsActNtRcRel"), RG.GetCalc("ActNotRecRel"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsIncTaxRcv"), RG.GetDetailCalcs("DTIncTaxRcv").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsTrdInv"), RG.GetCalc("TradeInv"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOthInv"), RG.GetDetailCalcs("DTInvOther").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsCstExBl"), RG.GetDetailCalcs("DTCostExcBill").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOpCurAst"), RG.GetDetailCalcs("DTOpCurAst").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsNonOpCurAst"), RG.GetDetailCalcs("DTNonOpCurAst").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			/// Add the memo suffix to the memo items
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLifoRes"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurAst"), ReportType, ColumnFormula, ColRound);

			/// Change the decimal setting to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCA"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Change the decimal setting back to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			/// Turn off the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			/// Underline the columns you just printed
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotCurAsts"), RG.GetCalc("TotCurAst"), ReportType, ColumnFormula, ColRound);

			/// Skip a line before Non Current Assets
			Utility.Skip(RG, 1);

			//amit: End of 1st group "Assets"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 2nd group "Net fixed assets"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			/// Print Non-Current Assets and Total Assets
			Utility.PrintSummary(RG, rm.GetString("sbsNetFxdAsts"), RG.GetCalc("NetFxdAsts"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsActNtRcvLT"), RG.GetDetailCalcs("DTLTReceiv").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsInvest"), RG.GetDetailCalcs("DTInvestments").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOpNonCurAst"), RG.GetCalc("OpNonCurAst"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsDefIncTxRecLTP"), RG.GetDetailCalcs("DTIncTaxRcvble").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsNonOpNonCurAst"), RG.GetDetailCalcs("DTNonOpNonCurAst").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsIntangNet"), RG.GetCalc("IntangNet"), ReportType, ColumnFormula, ColRound);

			/// Turn on the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurAst"), ReportType, ColumnFormula, ColRound);

			/// Set precision to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCA"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Set precision to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			/// Turn the suffix off
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			/// Underline the columns of what you just printed.
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurAsts"), RG.GetCalc("TotNonCurAst"), ReportType, ColumnFormula, ColRound);
			///  Underline the Columns above
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("bsTotAsts"), RG.GetCalc("TotalAssets"), ReportType, ColumnFormula, ColRound);

			///  Underline the page
			Utility.UnderlinePage(RG, 1);

			///CPF 8/19/03 REMOVED HARDCODED PAGE BREAKS
//			/// Close the page
//			Utility.PageBreak(RG);

			//amit: End of 2nd group "Net Fixed Assets"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 3rd group "Liablilities/net"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			///Print the "Liabilities/Net Worth" header
			Utility.PrintLabel(RG, rm.GetString("sbsLiabNW"));

			/// Print the Current Liabs
			Utility.PrintSummary(RG, rm.GetString("sbsOvrDrftBk"), RG.GetDetailCalcs("DTOvrDrftBook").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOvrDrftIB"), RG.GetDetailCalcs("DTOvrDrftIB").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsSTLnPay"), RG.GetDetailCalcs("DTSTPayables").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCPLTD"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCPCapLeaseOb"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsActPayTrd"), RG.GetDetailCalcs("DTActPayTrd").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsActPayOth"), RG.GetDetailCalcs("DTActPayRelCo").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsIntDivPay"), RG.GetCalc("IntDivPay"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOthAccr"), RG.GetDetailCalcs("DTAccrdLiabs").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsBlExCst"), RG.GetDetailCalcs("DTBillExcCost").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsTaxPay"), RG.GetDetailCalcs("DTTaxPayable").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOpCurLiab"), RG.GetDetailCalcs("DTOpCurLiabs").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsNonOpCurLiab"), RG.GetDetailCalcs("DTNonOpCurLiabs").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			///  Turn the memo suffix on.
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCL"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurLiabs"), ReportType, ColumnFormula, ColRound);

			///  Set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCL"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  Set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			///  Release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			///  Undeline the memo columns
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotCurLiabs"), RG.GetCalc("TotCurLiabs"), ReportType, ColumnFormula, ColRound);

			/// Skip a line.
			Utility.Skip(RG, 1);

			//amit: End of 3rd group "Liablilities/net"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 4th group "Long Term"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			/// Print Non-Current Liabs
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLTD"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapLeaseOb"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsDueRelCoOth"), RG.GetDetailCalcs("DTDueToRelCo").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOthNonCurLiab"), RG.GetCalc("OthNonCurLiab"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsDefFedIncTxLTP"), RG.GetDetailCalcs("DTDefFedIncTax").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			///  Add the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}
			
			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL"), ReportType, ColumnFormula, ColRound);

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurLiab"), ReportType, ColumnFormula, ColRound);

			///  set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			/// Print the memos
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL2"), ReportType, ColumnFormula, ColRound);

			/// Print the memos
			///  Set the decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL2"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set the decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			///  Release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			///  Underline the columns
			Utility.UnderlineColumn(RG, NumCols, 1);

			/// Print the Total Liabs section
			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurLiabs"), RG.GetCalc("TotNonCurLiabs"), ReportType, ColumnFormula, ColRound);
			///  Underline the columns above
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("bsTotLiabs"), RG.GetCalc("TotLiabs"), ReportType, ColumnFormula, ColRound);

			///  Skip a line
			Utility.Skip(RG, 1);

			//amit: End of 4th group "Long Term"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 3rd group "Stock"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			/// Print the Equity Section.
			Utility.PrintSummary(RG, rm.GetString("sbsStock"), RG.GetCalc("Stock"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsOthEq"), RG.GetCalc("OthEqty"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTRetEarn"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAccumOCI"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsTreasStk"), RG.GetDetailCalcs("DTTreasStk").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			///  Turn of the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecEQ"), ReportType, ColumnFormula, ColRound);

			///  set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecEQ"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			///  release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			///  underline the columns above
			Utility.UnderlineColumn(RG, NumCols, 1);

			/// Print the Equity totals.
			Utility.PrintSummary(RG, rm.GetString("bsTotNetWrth"), RG.GetCalc("TotNetWrth"), ReportType, ColumnFormula, ColRound);
			///  Underline the columns
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotLiabNetWrth"), RG.GetCalc("TotLiabsNetWorth"), ReportType, ColumnFormula, ColRound);

			///  Double underline the page
			Utility.UnderlinePage(RG, 2);
			//amit: End of 5th group "Stock"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of outer group (full report)
			Utility.mT.AddEndRow(Utility.nRow);
			
			Utility.CloseReport(RG);
		}

		/// <summary>
		/// Print the details for the given label, to ensure the account order is right
		/// </summary>
		static public void PrintDetailsFor(this PRINTCOMMANDS Utility, ReportGenerator RG, int reportType,
			int[] columnFormula, bool[] colRound, CALCULATIONS calcs, params string[] labels)
		{
			foreach (var label in labels.Where(l => !calcs.AccountCalculations.Any(ac => ac.Label == l)))
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs(label), reportType, columnFormula, colRound);
			}
			foreach (var accountCalc in calcs.AccountCalculations.Where(ac => labels.Contains(ac.Label)))
			{
				Utility.PrintDetail(RG, accountCalc.Calc, reportType, columnFormula, colRound);
			}
		}

		/// <summary>
		/// Get all the detail calculations for a label, even though it is accounts or types
		/// </summary>
		/// <param name="RG"></param>
		/// <param name="calcs"></param>
		/// <param name="label"></param>
		/// <returns></returns>
		static public DetailCalcs GetDetailCalcsFor(this ReportGenerator RG, CALCULATIONS calcs, string label) {
			DetailCalcs result = new DetailCalcs();
			foreach (var accountCalc in calcs.AccountCalculations.Where(ac => ac.Label == label))
			{
				result.AddRange(accountCalc.Calc);
			}
			return result.Count > 0 ? result : RG.GetDetailCalcs("DTSales");
		}

		static public void DETAILED_INCOME_STATEMENT(ReportGenerator RG, int ReportType, CALCULATIONS calcs)
		{
			int[] ColumnFormula = new int[1];
			int[] DetColumnFormula = new int[1];
			bool[] ColRound = new bool[1];
			int RptTypeVal;

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_NET_SALES;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_NET_SALES_DC;
			ColRound[0] = false;

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			/// This switch statement sets up a variable that tells
			/// some of the formatting commands how many columns there are.
			int NumCols;
			switch(ReportType)
			{
				case FORMATCOMMANDS.ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.ACT_PERCENT:
					NumCols = 2;break;
				case FORMATCOMMANDS.COMP_ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.COMP_PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.COMP_ACT_PERCENT:
					NumCols = 2;break;
                // KCZ Added for Version V 6-16-03
				case FORMATCOMMANDS.ACT_EXCHANGE:
					NumCols = 2;
					ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE;
					DetColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
					ColRound[0] = true;
					break;
				case FORMATCOMMANDS.ACT_TREND:
					NumCols = 2;
					ColumnFormula[0] = M.COLUMN_2_IS_TREND;
					DetColumnFormula[0] = M.COLUMN_2_IS_TREND_DC;
					break;
                // KCZ End of 6-16-03 addition
				default: 
					NumCols = 1;break;
			}

			FormatCommands.LoadFormatDefaults(RG);
	
			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT || ReportType == FORMATCOMMANDS.COMP_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			}
            // KCZ new report types 6-16-03
			else if ((ReportType == FORMATCOMMANDS.ACT_TREND) )
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "ON");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			}
			// KCZ new report types 6-16-03
			else if ( (ReportType == FORMATCOMMANDS.ACT_EXCHANGE))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "ON");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				//KCZ  make the second column wider to accommodate actual numbers
				RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_2, "1.0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			}
			else  // Actual report
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows

			//CPF 11/21/03 This section modifies what prints in the stmt constant section
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				//Add the currency line
				ColumnHeader cCurr = new ColumnHeader(rm.GetString("bsCurrency"), rm.GetString("bsTarget"), rm.GetString("bsSource"), "");
				Utility.arrColHead.Add(cCurr);
			}
			else if (ReportType == FORMATCOMMANDS.ACT_TREND)
			{
				//Remove the last two stmt constants added in the default.
				Utility.arrColHead.RemoveRange(5,2);
				//Re-Add the last two stmt constants with the extra "Trend % Chg" labels in column 2.
				StatementConstant sc1 = (StatementConstant)RG.Customer.Model.StatementConstants[3];
				StatementConstant sc2 = (StatementConstant)RG.Customer.Model.StatementConstants[4];
				ColumnHeader ch1 = new ColumnHeader(sc1.Label, sc1, rm.GetString("bsTrend"), "");
				ColumnHeader ch2 = new ColumnHeader(sc2.Label, sc2, rm.GetString("bs%Chg"), "");
				Utility.arrColHead.Add(ch1);
				Utility.arrColHead.Add(ch2);
			}

			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, NumCols);

			///***CPF 3/12/02 ONCE GLOBAL CONSTS ARE DETERMINED, WE NEED TO CHECK
			///SOURCE AND TARGET CURRENCY HERE, AND PRINT IF THERE ARE FILLED.
			Utility.PrintSourceTargetCurr(RG);

			int iCurColEx = ColumnFormula[0];
			if (ReportType == FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "5");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
				///CPF 6/24/03  This is so that we don't round these items.
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");	
				ColumnFormula[0] = M.COLUMN_2_EMPTY;	
				Utility.PrintSummary(RG, rm.GetString("bsExchgRt"), RG.CONV_RATE(), ReportType, ColumnFormula, ColRound);
				ColumnFormula[0] = iCurColEx;
				///CPF 6/24/04 Log 797:  Added skip before Sales 
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");	
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			//amit: Start of the OuterMost Grouping "Whole Report"
			Utility.mT.SetTableBorderWidth(2);
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 1");

			//amit: Start of the 1st Group 2nd level "Sales/Revenue"
			//Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 2");


			//amit: Start of the 1st Group 3nd level "Sales/Revenue"
			//Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 3");


			//amit: Start of First Innermost Group "Sales/Revenue"
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 4");

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs, 
				"DTSales",
				"DTSalesAdj"
			);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTSales")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTSalesAdj")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isNetSalesRev"), RG.GetCalc("NetSalesRev"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTCostOfSales", 
				"DTCostOfSalesAdj"
			);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTCostOfSales")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTCostOfSalesAdj")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotCstSalesRev"), RG.GetCalc("TotCostOfSalesRev"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOperInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTSGAExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOffComp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTLeaseExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTDeprec")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAmort")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOperExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTESOPDiv")) >= 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isGrsPrft"), RG.GetCalc("GrossProf"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//amit: End of 1st Innermost Group "Gross Profit"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 1");

			
			//amit: Start of 2nd Innermost Group "Other Operating Income(+)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 5");



			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs, "DTOperInc");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOperInc")) == 1)
				Utility.Skip(RG, 1);
			else if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOperInc")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotOthOpInc"), RG.GetCalc("TotOthOpInc"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTSGAExp",
				"DTOffComp",
				"DTLeaseExp",
				"DTDeprec",
				"DTAmort",
				"DTOperExp",
				"DTESOPDiv"
			);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTSGAExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOffComp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTLeaseExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTDeprec")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAmort")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOperExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTESOPDiv")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotOpExp"), RG.GetCalc("TotOpExp"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			int TotOthIncExp;
			TotOthIncExp = FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncFromSubs")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTNonCashInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOthInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTOthExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTGLAssets")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTNonCashExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTCapInterest"));

			if (TotOthIncExp >= 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isNetOpPrft"), RG.GetCalc("NetOpProfit"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//amit: End of 2nd Innermost group "NET Operating Profit"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 2");

			//amit: End of 1st Group 3rd level "Net Operating Profit"
			//Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 3");

			            
			//amit: Start of 2nd group 3rd level "Interest Expense (-)"
			//Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 6");


			//amit: Start of 3rd Innermost group "Interest Expense (-)"
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 7");


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			int IntExpCapInt;
			int IntExpCapIntCount=0;
			IntExpCapInt = (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntExp")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTCapInterest")));

			if (IntExpCapInt < 1)
				IntExpCapIntCount = 0;
			else if (IntExpCapInt == 1)
				IntExpCapIntCount = 1;
			else if (IntExpCapInt > 1)
				IntExpCapIntCount = 2;

			int IntIncCount=0;
			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntInc")) < 1)
				IntIncCount = 0;
			else if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntInc")) == 1)
				IntIncCount = 3;
			else if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntInc")) > 1)
				IntIncCount = 6;

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTIntExp",
				"DTCapInterest"
			);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (IntExpCapInt > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotIntExp"), RG.GetCalc("TotIntExp"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			if (IntExpCapIntCount + IntIncCount == 5 || IntExpCapIntCount + IntIncCount == 7 || IntExpCapIntCount + IntIncCount == 8)
				Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs, "DTIntInc");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIntInc")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotIntInc"), RG.GetCalc("TotIntInc"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			if (IntExpCapIntCount + IntIncCount == 4 || IntExpCapIntCount + IntIncCount == 5 
				|| IntExpCapIntCount + IntIncCount == 7 || IntExpCapIntCount + IntIncCount == 8)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotIntIncExp"), RG.GetCalc("TotIntIncExp"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTIncFromSubs",
				"DTNonCashInc",
				"DTNonCashExp",
				"DTOthInc",
				"DTOthExp",
				"DTGLAssets"
			);
				                        
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			IntExpCapIntCount = 0;
			if (IntExpCapInt == 1)
				IntExpCapIntCount = 1;
			else if (IntExpCapInt > 1)
				IntExpCapIntCount = 2;

			int TotOthIncExpCount = 0;
			if (TotOthIncExp - IntExpCapInt == 1)
				TotOthIncExpCount = 3;
			else if (TotOthIncExp - IntExpCapInt > 1)
				TotOthIncExpCount = 4;

			if (IntExpCapIntCount + TotOthIncExpCount > 2)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotOthIncExp"), RG.GetCalc("TotOthIncExp"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			int IncTax=0;
			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTax")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTaxCred")) >= 1)
				IncTax = 1;
			else if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTax")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTaxCred")) > 1)
				IncTax = 4;

			/// COMMENTED THIS OUT UNTIL WE USE IT.
			//			int MinInt;
			//			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTMinorityInt")) > 0)
			//				MinInt = 1;
			//
			//			int AftTaxItems;
			//			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxInc")) + 
			//				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxExp")) +
			//				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxNonCash")) > 4)
			//				AftTaxItems = 4;

			/// 5/14/02 - HERE IS WHERE WE WOULD HAVE PUT THE #DEFINE STUFF FOR LEGACY
			/// SYSTEMS AND OTHER APPLICATIONS.  THIS WAS INTENTIONALLY LEFT OUT BECUASE
			/// WE DON'T KNOW HOW WE ARE GOING TO INTEGRATE WITH THESE SYSTEMS.

			///HERE WE WILL NEED TO INSERT LOGIC FOR LINES_LEFT_ON_PAGE WHEN WE
			///FIGURE OUT HOW IN THE WORLD WE ARE GOING TO DO IT.  FOR NOW, WE WILL
			///JUST KEEP ON PRINTING, W/O BREAKING THE PAGE.
			int NewPage=0;

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (IncTax + NewPage == 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isProfB4Tax"), RG.GetCalc("ProfB4Tax"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
			}

			//amit: End of 3rd Innermost Group "Profit Before Taxes"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 4");

			
			//amit: Start of 4th Innermost Group "Current Income Tax"
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 8");


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTIncTax",
				"DTIncTaxCred"
			);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTax")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTIncTaxCred")) > 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("isTotIncTaxExp"), RG.GetCalc("TotIncTaxExp"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTMinorityInt")) > 0)
				Utility.Skip(RG, 1);

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs, "DTMinorityInt");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxInc")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcsFor(calcs, "DTAftTaxNonCash")) >= 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("isProfB4"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("isExtraItems"), RG.GetCalc("ProfB4ExtrItem"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs,
				"DTAftTaxInc",
				"DTAftTaxExp",
				"DTAftTaxNonCash"
			);

			Utility.UnderlineColumn(RG, NumCols, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("isNetProf"), RG.GetCalc("NetProfit"), ReportType, ColumnFormula, ColRound);

			Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("isEBIT"), RG.GetCalc("EBIT"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("isEBITDA"), RG.GetCalc("EBITDA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("isEBIDA"), RG.GetCalc("EBIDA"), ReportType, ColumnFormula, ColRound);
            
			//amit: End of the 4th Innermost group "EBIDA"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 5");

			//amit: End of the 2nd Group 3rd level "EBIDA"
			//Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 6");
			
			//amit: End of the first group 2nd level "EBIDA"
			//Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 7");

            //amit: Start of the 2nd group 2nd level
			//Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 9");

			if (ReportType == FORMATCOMMANDS.COMP_ACTUAL || ReportType == FORMATCOMMANDS.COMP_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				//amit: start of the 5th (comprehensive) innermost group "Unreal Gain(Loss)"
				Utility.mT.AddStartRow(Utility.nRow + 1);
				//Utility.PrintLabel(RG, "Start 10");

				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintDetailsFor(RG, ReportType, DetColumnFormula, ColRound, calcs, "DTOthCompInc");

				if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(201)) > 0)
					Utility.UnderlineColumn(RG, NumCols, 1);
			
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("isCompInc"), RG.GetCalc("CompInc"), ReportType, ColumnFormula, ColRound);
				//amit: End of 4th Innermost Group "Comprehensive Income"
				Utility.mT.AddEndRow(Utility.nRow);
				//Utility.PrintLabel(RG, "End 8");
			}

			//amit: start of last group 3rd level "Dividends"
			//Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 11");


			//amit: start of the 5th (comprehensive)group innermost Level "Dividends - common"
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//Utility.PrintLabel(RG, "Start 12");


			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}
            // KCZ added Report types for Exchange Rate, Trend 6-16-03
			else if (ReportType==FORMATCOMMANDS.ACT_EXCHANGE)
    		{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				ColumnFormula[0] = M.COLUMN_2_NO_EXCHANGE_DC;
			}
			else if (ReportType==FORMATCOMMANDS.ACT_TREND)
			{
				ColumnFormula[0] = M.COLUMN_2_IS_TREND_DC;
			}
			// KCZ end of addition 6-16-03

			///If this is a percent only report, do NOT print the following.
			if (ReportType != FORMATCOMMANDS.PERCENT && ReportType != FORMATCOMMANDS.COMP_PERCENT)
			{
				Utility.PrintDetailsFor(RG, ReportType, ColumnFormula, ColRound, calcs,
					"DTComDiv",
					"DTPrefDiv",
					"DTStockDiv",
					"DTAdjToRE");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT || ReportType == FORMATCOMMANDS.COMP_PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}
			// KCZ Added so that column 2 of Exchange rate report = column 1 for memo items
			if (ReportType==FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "");
				ColumnFormula[0] = M.COLUMN_2_EQUALS_COL_1_DC;
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			Utility.PrintDetailsFor(RG, ReportType, ColumnFormula, ColRound, calcs,
				"DTMemo0DecIS");

			
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			// KCZ Added make 2 decimals in column 2 on Exchange Rate report 6-17-03
			if (ReportType==FORMATCOMMANDS.ACT_EXCHANGE)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "2");
			}
			
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
			Utility.PrintDetailsFor(RG, ReportType, ColumnFormula, ColRound, calcs,
				"DTMemo2DecIS");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.COMP_ACTUAL || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
				Utility.UnderlinePage(RG, 1);
			else
				Utility.UnderlinePage(RG, 2);

			//amit: End of the 5th group Innermost level "Memo -2"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 9");

			
			if (ReportType == FORMATCOMMANDS.COMP_ACTUAL || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				//amit: Start of the last group Innermost level "Reconconciliation of Acc"
				Utility.mT.AddStartRow(Utility.nRow + 1);
				//Utility.PrintLabel(RG, "Start 13");


				/// This is the section to add the OCI Reconciliation section.  Everything
				/// before this is an exact copy of DET_IS_ACT, except Report Name.
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintCenter(RG, rm.GetString("isReconAccOCI"));
					Utility.UnderlinePage(RG, 1);
				}

				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintLabel(RG, rm.GetString("isBegAccumOCI"));
					Utility.PrintSummary(RG, rm.GetString("isAsPrevRptd"), RG.GetCalc("LINE(213)"), ReportType, ColumnFormula, ColRound);
				}

				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

				Utility.PrintDetailsFor(RG, ReportType, ColumnFormula, ColRound, calcs,
					"DTReconCompInc");

				if (RG.GetCalc("LINE(202)").NonZero)
					Utility.PrintSummary(RG, rm.GetString("isOCIAdjCnvRt"), RG.GetCalc("LINE(214)"), ReportType, ColumnFormula, ColRound);

				Utility.PrintSummary(RG, rm.GetString("isOCIReclasAdj"), RG.GetCalc("LINE(212)"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintSummary(RG, rm.GetString("isEndAccOCI"), RG.GetCalc("EndAccumOCI"), ReportType, ColumnFormula, ColRound);
					Utility.UnderlinePage(RG, 2);
				}
				//amit: End of the last group Innermost Level "Ending Accumulated OCI"
				Utility.mT.AddEndRow(Utility.nRow);
				//Utility.PrintLabel(RG, "End 10");
               
			}

			//amit: End of the last Group 3rd level "Ending Accumulated OCI"
			//Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 11");



			//amit: End of the last group 2nd level "Ending Accumulated OCI"
			//Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 12");


			//amit: End of the Outermost Group "Whole Report"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PrintLabel(RG, "End 13");
			


			Utility.CloseReport(RG);
		}
		static public void SUMMARY_INCOME_STATEMENT(ReportGenerator RG, int ReportType)
		{
			int[] ColumnFormula = new int[1];
			int[] DetColumnFormula = new int[1];
			bool[] ColRound = new bool[1];
			int RptTypeVal;

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_NET_SALES;
			DetColumnFormula[0] = M.COLUMN_2_PERCENT_NET_SALES_DC;
			ColRound[0] = false;
			
			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			/// This switch statement sets up a variable that tells
			/// some of the formatting commands how many columns there are.
			int NumCols;
			switch(ReportType)
			{
				case FORMATCOMMANDS.ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.ACT_PERCENT:
					NumCols = 2;break;
				case FORMATCOMMANDS.COMP_ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.COMP_PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.COMP_ACT_PERCENT:
					NumCols = 2;break;
				default: 
					NumCols = 1;break;
			}

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
		
			if (ReportType == FORMATCOMMANDS.ACT_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT || ReportType == FORMATCOMMANDS.COMP_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			}
			else  // Actual report
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows

			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, NumCols);

			///***CPF 3/12/02 ONCE GLOBAL CONSTS ARE DETERMINED, WE NEED TO CHECK
			///SOURCE AND TARGET CURRENCY HERE, AND PRINT IF THERE ARE FILLED.
			Utility.PrintSourceTargetCurr(RG);

			///Utility.Skip(RG, 1);
			///

			//amit: start of the outer group (full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: start of 1st group "Sales/Rev"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sisSalesRev"), RG.GetDetailCalcs("DTSales").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisRetAllDisc"), RG.GetDetailCalcs("DTSalesAdj").GetTotals(RG), ReportType, ColumnFormula, ColRound);
 
			if (FormatCommands.Compare(RG.TYPE(145), (RG.TYPE(145) + RG.TYPE(147))) == "NotEqual")
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("sisNetSalesRev"), RG.GetCalc("SumNetSales"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("sisCostSalesRev"), RG.GetDetailCalcs("DTCostOfSales").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisCostSalesDepr"), RG.GetDetailCalcs("DTCostOfSalesAdj").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.Compare(RG.TYPE(150), (RG.TYPE(150) + RG.TYPE(152))) == "NotEqual")
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				Utility.PrintSummary(RG, rm.GetString("isTotCstSalesRev"), RG.GetCalc("TotCostOfSalesRev"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}



			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOperInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTSGAExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOffComp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTLeaseExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTDeprec")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAmort")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOperExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTESOPDiv")) >= 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isGrsPrft"), RG.GetCalc("GrossProf"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//amit: end of 1st group "Sales/Rev"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 2nd group "Other Operating Income"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintSummary(RG, rm.GetString("sisOthOpInc"), RG.GetDetailCalcs("DTOperInc").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisSGAExp"), RG.GetDetailCalcs("DTSGAExp").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisOpExp"), RG.GetDetailCalcs("DTOperExp").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisOffComp"), RG.GetDetailCalcs("DTOffComp").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisLeaseRentExp"), RG.GetDetailCalcs("DTLeaseExp").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisDepr"), RG.GetDetailCalcs("DTDeprec").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisAmrt"), RG.GetDetailCalcs("DTAmort").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisDivESOPTrst"), RG.GetDetailCalcs("DTESOPDiv").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTSGAExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOffComp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTLeaseExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTDeprec")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAmort")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOperExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTESOPDiv")) > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				Utility.PrintSummary(RG, rm.GetString("sisTotOpExpInc"), RG.GetCalc("TotOpExpInc"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			int TotOthIncExp;
			TotOthIncExp = FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIntInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIntExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIncFromSubs")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTNonCashInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOthInc")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTOthExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTGLAssets")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTNonCashExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTCapInterest"));

			if (TotOthIncExp >= 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isNetOpPrft"), RG.GetCalc("NetOpProfit"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//amit: end of 2nd group "Other Operating Income"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 3rd group "Income from Subs"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintSummary(RG, rm.GetString("sisIntIncExp"), RG.GetCalc("TotIntIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisIncSubsJtVt"), RG.GetDetailCalcs("DTIncFromSubs").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisNonCashIncExp"), RG.GetCalc("NonCashIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisOthIncExp"), RG.GetCalc("OthIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisGnLsSlAsts"), RG.GetDetailCalcs("DTGLAssets").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			if (TotOthIncExp > 1)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isTotOthIncExp"), RG.GetCalc("TotOthIncExp"), ReportType, ColumnFormula, ColRound);
			}

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIncTax")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIncTaxCred")) >= 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				Utility.PrintSummary(RG, rm.GetString("isProfB4Tax"), RG.GetCalc("ProfB4Tax"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
			}

			//amit: end of 3rd group "Income from Subs"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 4th group "Income Taxes"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintSummary(RG, rm.GetString("sisIncTax"), RG.GetDetailCalcs("DTIncTax").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisIncTaxCred"), RG.GetDetailCalcs("DTIncTaxCred").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIncTax")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTIncTaxCred")) > 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("isTotIncTaxExp"), RG.GetCalc("TotIncTaxExp"), ReportType, ColumnFormula, ColRound);
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
		
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTMinorityInt")) > 0)
				Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("sisMinInt"), RG.GetDetailCalcs("DTMinorityInt").GetTotals(RG), ReportType, ColumnFormula, ColRound);

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxInc")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxNonCash")) >= 1)
			{
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("isProfB4"));
				
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("isExtraItems"), RG.GetCalc("ProfB4ExtrItem"), ReportType, ColumnFormula, ColRound);
				Utility.Skip(RG, 1);
			}

			//amit: end of 4th group "Income Taxes"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 5th group "Extraordinary Gain"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTaxInc"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTaxExp"), ReportType, DetColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTaxNonCash"), ReportType, DetColumnFormula, ColRound);

			if (FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxInc")) + 
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxExp")) +
				FormatCommands.DetailCount(RG, RG.GetDetailCalcs("DTAftTaxNonCash")) >= 1)
				Utility.UnderlineColumn(RG, NumCols, 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("isNetProf"), RG.GetCalc("NetProfit"), ReportType, ColumnFormula, ColRound);

			Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("isEBIT"), RG.GetCalc("EBIT"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("isEBITDA"), RG.GetCalc("EBITDA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("isEBIDA"), RG.GetCalc("EBIDA"), ReportType, ColumnFormula, ColRound);

			//amit: end of 5th group "Extraordinary Gain"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 6th group "Other Comp Income"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (ReportType == FORMATCOMMANDS.COMP_ACTUAL || ReportType == FORMATCOMMANDS.COMP_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("sisOthCompInc"), RG.GetDetailCalcs("DTOthCompInc").GetTotals(RG), ReportType, ColumnFormula, ColRound);
				Utility.UnderlineColumn(RG, NumCols, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("isCompInc"), RG.GetCalc("CompInc"), ReportType, ColumnFormula, ColRound);
			}

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If this is a percent only report, do NOT print the following.
			if (ReportType != FORMATCOMMANDS.PERCENT && ReportType != FORMATCOMMANDS.COMP_PERCENT)
			{
				Utility.PrintSummary(RG, rm.GetString("sisCashDivWith"), (RG.GetDetailCalcs("DTComDiv").GetTotals(RG) + RG.GetDetailCalcs("DTPrefDiv").GetTotals(RG)), ReportType, ColumnFormula, ColRound);
				Utility.PrintSummary(RG, rm.GetString("sisDivStk"), RG.GetDetailCalcs("DTStockDiv").GetTotals(RG), ReportType, ColumnFormula, ColRound);
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAdjToRE"), ReportType, ColumnFormula, ColRound);
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT || ReportType == FORMATCOMMANDS.COMP_PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecIS"), ReportType, ColumnFormula, ColRound);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecIS"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			Utility.UnderlinePage(RG, 2);

			//amit: end of 6th group "Other Comp Income"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 7th group "Reconciliation of Acc OCI"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.COMP_ACTUAL || ReportType == FORMATCOMMANDS.COMP_ACT_PERCENT)
			{
				/// This is the section to add the OCI Reconciliation section.  Everything
				/// before this is an exact copy of DET_IS_ACT, except Report Name.
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintCenter(RG, rm.GetString("isReconAccOCI"));
					Utility.UnderlinePage(RG, 1);
				}

				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintLabel(RG, rm.GetString("isBegAccumOCI"));
					Utility.PrintSummary(RG, rm.GetString("isAsPrevRptd"), RG.GetCalc("LINE(213)"), ReportType, ColumnFormula, ColRound);
				}

				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTReconCompInc"), ReportType, ColumnFormula, ColRound);

				if (RG.GetCalc("LINE(202)").NonZero)
					Utility.PrintSummary(RG, rm.GetString("isOCIAdjCnvRt"), RG.GetCalc("LINE(214)"), ReportType, ColumnFormula, ColRound);

				Utility.PrintSummary(RG, rm.GetString("isOCIReclasAdj"), RG.GetCalc("LINE(212)"), ReportType, ColumnFormula, ColRound);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
				{
					Utility.PrintSummary(RG, rm.GetString("isEndAccOCI"), RG.GetCalc("EndAccumOCI"), ReportType, ColumnFormula, ColRound);
					Utility.UnderlinePage(RG, 2);
				}
			}

			//amit: end of 7th group "Other Comp Income"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: end of outer group (full report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}

		static public void EXECUTIVE_BALANCE_SHEET(ReportGenerator RG, int ReportType)
		{
			int[] ColumnFormula = new int[1];
			int[] DetColumnFormula = new int[1];
			bool[] ColRound = new bool[1];
			int RptTypeVal;

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			/// Set up the fomula for the second column
			ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;	
			ColRound[0] = false;

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			/// This switch statement sets up a variable that tells
			/// some of the formatting commands how many columns there are.
			int NumCols;
			switch(ReportType)
			{
				case FORMATCOMMANDS.ACTUAL:
					NumCols = 1;break;
				case FORMATCOMMANDS.PERCENT:
					NumCols = 1;break;
				case FORMATCOMMANDS.ACT_PERCENT:
					NumCols = 2;break;
				default: 
					NumCols = 1;break;
			}
            // KCZ sets reports back to "default" settings for column width, etc.
			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");

			//SPA - trying to set width column 2 - it is currently too big
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_2, "0.5");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_2, "True");

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_2, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_2, "-");
				RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_2, "()");
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			}
			else if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			}
			else // Actual report
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows

			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, NumCols);

			///***CPF 3/12/02 ONCE GLOBAL CONSTS ARE DETERMINED, WE NEED TO CHECK
			///SOURCE AND TARGET CURRENCY HERE, AND PRINT IF THERE ARE FILLED.
			Utility.PrintSourceTargetCurr(RG);

			///Utility.Skip(RG, 1);

			// Turn off crosfoot for balance sheet items
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");	

			//amit: Start outer group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 1st group "Assets"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			/// Print the "ASSETS" header
			Utility.PrintLabel(RG, rm.GetString("sbsAssets"));
			/// RG.Writer.Execute("<TR><TD ALIGN=L>ASSETS</TD></TR>");

			/// Print the Current Assets section. 
			Utility.PrintSummary(RG, rm.GetString("efsCashNearCash"), RG.GetCalc("CashNearCash"), ReportType, ColumnFormula, ColRound);
			//if (ReportType != FORMATCOMMANDS.PERCENT)
			Utility.PrintSummary(RG, rm.GetString("efsActNtsRecNet"), RG.GetCalc("TotActsRcvNet"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsIncTaxRcv"), RG.GetDetailCalcs("DTIncTaxRcv").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsInventory"), RG.GetCalc("TotalInv"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsOthCurAst"), RG.GetCalc("OthCurAssets"), ReportType, ColumnFormula, ColRound);

			/// Add the memo suffix to the memo items
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}
			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTLifoRes"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurAst"), ReportType, ColumnFormula, ColRound);

			/// Change the decimal setting to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCA"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Change the decimal setting back to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			/// Turn off the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			/// Underline the columns you just printed
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotCurAsts"), RG.GetCalc("TotCurAst"), ReportType, ColumnFormula, ColRound);

			/// Skip a line before Non Current Assets
			Utility.Skip(RG, 1);

			/// Print Non-Current Assets and Total Assets
			Utility.PrintSummary(RG, rm.GetString("sbsNetFxdAsts"), RG.GetCalc("NetFxdAsts"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsLTRcvInvst"), RG.GetCalc("LTRecAndInv"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsOthNonCurAst"), RG.GetCalc("OthNonCurAsts"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsIntangNet"), RG.GetCalc("IntangNet"), ReportType, ColumnFormula, ColRound);

			/// Turn on the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCA"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurAst"), ReportType, ColumnFormula, ColRound);

			/// Set precision to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCA"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			/// Set precision to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			/// Turn the suffix off
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			/// Underline the columns of what you just printed.
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurAsts"), RG.GetCalc("TotNonCurAst"), ReportType, ColumnFormula, ColRound);
			///  Underline the Columns above
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("bsTotAsts"), RG.GetCalc("TotalAssets"), ReportType, ColumnFormula, ColRound);

			///  Underline the page
			Utility.UnderlinePage(RG, 1);

			//amit: End 1st group "Assets"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 2nd group "Liabilities/net"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			///Print the "Liabilities/Net Worth" header
			Utility.PrintLabel(RG, rm.GetString("sbsLiabNW"));

			/// Print the Current Liabs
			Utility.PrintSummary(RG, rm.GetString("sbsSTLnPay"), RG.GetCalc("OdraftsSTPay"), ReportType, ColumnFormula, ColRound);
		    Utility.PrintSummary(RG, rm.GetString("efsCurPtnLTD"), RG.GetCalc("CPLTDAll"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsActsPay"), RG.GetCalc("AcctsPayTot"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsAccrLiabs"), RG.GetCalc("TotAccrdLiab"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sbsTaxPay"), RG.GetDetailCalcs("DTTaxPayable").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsOthCurLiab"), RG.GetCalc("OthCurLiabs"), ReportType, ColumnFormula, ColRound);
			
			///  Turn the memo suffix on.
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecCL"), ReportType, ColumnFormula, ColRound);
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSCurLiabs"), ReportType, ColumnFormula, ColRound);

			///  Set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecCL"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  Set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			///  Release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			///  Undeline the memo columns
			Utility.UnderlineColumn(RG, NumCols, 1);

			Utility.PrintSummary(RG, rm.GetString("efsTotCurLiab"), RG.GetCalc("TotCurLiabs"), ReportType, ColumnFormula, ColRound);

			/// Skip a line.
			Utility.Skip(RG, 1);

			/// Print Non-Current Liabs
			Utility.PrintSummary(RG, rm.GetString("efsLongTermDebt"), RG.GetCalc("LTDAndCapLse"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsOthNonCurLiab"), RG.GetCalc("ExecOthNonCurLiab"), ReportType, ColumnFormula, ColRound);

			///  Add the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}
			
			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL"), ReportType, ColumnFormula, ColRound);

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOffBSNonCurLiab"), ReportType, ColumnFormula, ColRound);

			///  set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			/// Print the memos
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecNCL2"), ReportType, ColumnFormula, ColRound);

			/// Print the memos
			///  Set the decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecNCL2"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set the decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			///  Release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			///  Underline the columns
			Utility.UnderlineColumn(RG, NumCols, 1);

			/// Print the Total Liabs section
			Utility.PrintSummary(RG, rm.GetString("bsTotNonCurLiabs"), RG.GetCalc("TotNonCurLiabs"), ReportType, ColumnFormula, ColRound);
			///  Underline the columns above
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("bsTotLiabs"), RG.GetCalc("TotLiabs"), ReportType, ColumnFormula, ColRound);

			///  Skip a line
			Utility.Skip(RG, 1);

			/// Print the Equity totals.
			Utility.PrintSummary(RG, rm.GetString("bsTotNetWrth"), RG.GetCalc("TotNetWrth"), ReportType, ColumnFormula, ColRound);

			///  Turn of the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));
			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecEQ"), ReportType, ColumnFormula, ColRound);

			///  set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecEQ"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///  set decimals to 0
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			///  release the suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");
			
			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "1");
			}

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "N/A");
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_PERCENT_TOTAL_ASSETS;
			}

			Utility.PrintSummary(RG, rm.GetString("bsTotLiabNetWrth"), RG.GetCalc("TotLiabsNetWorth"), ReportType, ColumnFormula, ColRound);

			///  Double underline the page
			Utility.UnderlinePage(RG, 2);

			///CPF 8/19/03 REMOVED HARDCODED PAGE BREAKS
//			Utility.PageBreak(RG);

			/// Set up the fomula for the second column
			/// SPA - change column 2 formula for the I/S items
			ColumnFormula[0] = M.COLUMN_2_PERCENT_NET_SALES;

			//amit: End 2nd group "Liabilities/net"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 2nd group "Income Statement"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			///CPF 11/02/04 - Log 901 - Added the "if" check.  If the report type is Pecent,
			///the ST_CROSS_FOOT column is not setup at the beginning.  Without this check, ST_CROSS_FOOT
			///was always being turned on at the beginning of the IS section.  But since the table was not
			///set up for the extra column, it crashed. 
			if ((ReportType == FORMATCOMMANDS.ACT_PERCENT) || (ReportType == FORMATCOMMANDS.ACTUAL))
				// Turn on crosfoot for income stmt items
				RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");	

			///Print the "INCOME STATEMENT" header
			Utility.PrintLabel(RG, rm.GetString("efsIncStmt"));
			Utility.PrintSummary(RG, rm.GetString("efsNetSalesRev"), RG.GetCalc("NetSalesRev"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisCostSalesRev"), RG.GetDetailCalcs("DTCostOfSales").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisCostSalesDepr"), RG.GetDetailCalcs("DTCostOfSalesAdj").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("isGrsPrft"), RG.GetCalc("GrossProf"), ReportType, ColumnFormula, ColRound);
			
			Utility.PrintSummary(RG, rm.GetString("efsNetOpExps"), RG.GetCalc("ExecNetOpExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("efsDeprAmrt"), RG.GetCalc("ExecDepAmort"), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("isNetOpPrft"), RG.GetCalc("NetOpProfit"), ReportType, ColumnFormula, ColRound);

			Utility.PrintSummary(RG, rm.GetString("sisIntIncExp"), RG.GetCalc("TotIntIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisNonCashIncExp"), RG.GetCalc("NonCashIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisOthIncExp"), RG.GetCalc("ExecOthIncExp"), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("isProfB4Tax"), RG.GetCalc("ProfB4Tax"), ReportType, ColumnFormula, ColRound);

	        Utility.PrintSummary(RG, rm.GetString("sisIncTax"), RG.GetCalc("TotIncTaxExp"), ReportType, ColumnFormula, ColRound);
			Utility.PrintSummary(RG, rm.GetString("sisMinInt"), RG.GetDetailCalcs("DTMinorityInt").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("efsPrfB4ExtraItems"), RG.GetCalc("ProfB4ExtrItem"), ReportType, ColumnFormula, ColRound);

			Utility.PrintSummary(RG, rm.GetString("efsAftTaxIncExp"), RG.GetCalc("ExtraItems"), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("isNetProf"), RG.GetCalc("NetProfit"), ReportType, ColumnFormula, ColRound);
			
			Utility.PrintSummary(RG, rm.GetString("sisOthCompInc"), RG.GetDetailCalcs("DTOthCompInc").GetTotals(RG), ReportType, ColumnFormula, ColRound);
			Utility.UnderlineColumn(RG, NumCols, 1);
			Utility.PrintSummary(RG, rm.GetString("isCompInc"), RG.GetCalc("CompInc"), ReportType, ColumnFormula, ColRound);
            
			Utility.Skip(RG, 1);

			if (ReportType == FORMATCOMMANDS.ACT_PERCENT)
			{
				/// Set up the fomula for the second column
				ColumnFormula[0] = M.COLUMN_2_EMPTY;
				DetColumnFormula[0] = M.COLUMN_2_EMPTY;
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_2, "");
			}

			///If this is a percent only report, do NOT print the following.
			if (ReportType != FORMATCOMMANDS.PERCENT)
			{
				Utility.PrintSummary(RG, rm.GetString("sisCashDivWith"), RG.GetCalc("CashDivAndWDs"), ReportType, ColumnFormula, ColRound);
				Utility.PrintSummary(RG, rm.GetString("sisDivStk"), RG.GetDetailCalcs("DTStockDiv").GetTotals(RG), ReportType, ColumnFormula, ColRound);
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAdjToRE"), ReportType, DetColumnFormula, ColRound);
			}

			///If the report type is Percent, we don't want the memo items to show as a decimal, but
			///rather the actual value.  So we change the report type flag to print memos, then switch it back
			RptTypeVal = ReportType;
			if (ReportType == FORMATCOMMANDS.PERCENT)
			{
				ReportType = FORMATCOMMANDS.ACTUAL;
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			}

			///  Turn oN the memo suffix
			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("Memo"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo0DecIS"), ReportType, ColumnFormula, ColRound);

			///  set decimals to 2
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMemo2DecIS"), ReportType, ColumnFormula, ColRound);
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			///So we change the report type flag to print memos, then switch it back
			ReportType = RptTypeVal;

			Utility.UnderlinePage(RG, 2);

			//amit: End 3rdgroup "Income Statement"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End outer group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}

	}
}
