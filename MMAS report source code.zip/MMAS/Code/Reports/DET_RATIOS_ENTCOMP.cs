using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class DET_RATIOS_ENTCOMP:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();

			Calcs.BSCalcs(RG);
			Calcs.RatioCalcs(RG);
			Calcs.ISCalcs(RG);
			// KCZ Added CF Management since now several ratios require CFM calculations
			Calcs.CF_MGMT_Calcs(RG);
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			if (! RG.CustComp)
				Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drLiquidity"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("drWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("WorkingCap")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("drQuickRatio"), RG.GetPrintOrderCalc(RG.GetCalc("QuickRatio")));
			Utility.PrintSummary(RG, rm.GetString("drCurrRatio"), RG.GetPrintOrderCalc(RG.GetCalc("CurrRatio")));
			Utility.PrintSummary(RG, rm.GetString("drNetSlsWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesWorkCap")));

			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drLeverage"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, rm.GetString("drNWA"), RG.GetPrintOrderCalc(RG.GetCalc("NetWorthAct")));
			Utility.PrintSummary(RG, rm.GetString("drTNWA"), RG.GetPrintOrderCalc(RG.GetCalc("TangNetWrthAct")));
			Utility.PrintSummary(RG, rm.GetString("drETNWA"), RG.GetPrintOrderCalc(RG.GetCalc("EffTangNW")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("drDtWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtWorth")));
			Utility.PrintSummary(RG, rm.GetString("drDtTgWth"), RG.GetPrintOrderCalc(RG.GetCalc("DebtTangWorth")));
			Utility.PrintSummary(RG, rm.GetString("drDtLsSubDtLbETW"), RG.GetPrintOrderCalc(RG.GetCalc("DebtLsSubDbtETW")));
			Utility.PrintSummary(RG, rm.GetString("drBrFndETW"), RG.GetPrintOrderCalc(RG.GetCalc("BorFndEffTgWth")));
			Utility.PrintSummary(RG, rm.GetString("drLTDtNFA"), RG.GetPrintOrderCalc(RG.GetCalc("LTDbtNFA")));
			Utility.PrintSummary(RG, rm.GetString("drTotLbTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("TotLiabTotAst")));
            Utility.PrintSummary(RG, rm.GetString("drDbToBC"), RG.GetPrintOrderCalc(RG.GetCalc("DebtToBookCapital")));

			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drCoverage"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("drIntCov"), RG.GetPrintOrderCalc(RG.GetCalc("IntCover")));
			Utility.PrintSummary(RG, rm.GetString("drNetIncDpAmtCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("NetIncDepAmtCPLTD")));
            Utility.PrintSummary(RG, rm.GetString("drIcfCov"), RG.GetPrintOrderCalc(RG.GetCalc("InputCashFlowCov")));
			Utility.PrintSummary(RG, rm.GetString("drEBITDAIntExpCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("EBITDAIntExpCPLTD")));
			// KCZ end of addition
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			Utility.PrintSummary(RG, rm.GetString("drEBITDA"), RG.GetPrintOrderCalc(RG.GetCalc("EBITDA")));
			Utility.PrintSummary(RG, rm.GetString("drEBIDA"), RG.GetPrintOrderCalc(RG.GetCalc("EBIDA")));

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("drFxdChgCov"), RG.GetPrintOrderCalc(RG.GetCalc("FixedChgCov")));
            Utility.PrintSummary(RG, rm.GetString("drFFOInterestExpense"), RG.GetPrintOrderCalc(RG.GetCalc("FFOInterestExpense")));
            Utility.PrintSummary(RG, rm.GetString("drDebtCoverageRatio"), RG.GetPrintOrderCalc(RG.GetCalc("DebtCoverageRatio")));
            Utility.PrintSummary(RG, rm.GetString("drBrFndEBITDA"), RG.GetPrintOrderCalc(RG.GetCalc("BorFndToEBITDA")));

			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drProfitability"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("drROA"), RG.GetPrintOrderCalc(RG.GetCalc("ROA")));
			Utility.PrintSummary(RG, rm.GetString("drROE"), RG.GetPrintOrderCalc(RG.GetCalc("ROE")));
			Utility.PrintSummary(RG, rm.GetString("drGrsMgn"), RG.GetPrintOrderCalc(RG.GetCalc("GrossMargin")));
			// KCZ Added GM (plus Depr) ratio Version V 6-11-03
			Utility.PrintSummary(RG, rm.GetString("cfmGMDpr%"), RG.GetPrintOrderCalc(RG.GetCalc("GrsMgnPlsDepr")));
			// KCZ Added Op Exp % KCZ Version V 6-11-03
            Utility.PrintSummary(RG, rm.GetString("drOperExpPercent"), RG.GetPrintOrderCalc(RG.GetCalc("OperExpensePercent")));
			// KCZ Added Op Exp (excl Depr)% Version V 6-11-03
			Utility.PrintSummary(RG, rm.GetString("cfmOEDpr%"), RG.GetPrintOrderCalc(RG.GetCalc("OpExpExclDepr")));
			Utility.PrintSummary(RG, rm.GetString("drOpPftMgn"), RG.GetPrintOrderCalc(RG.GetCalc("OpPrftMgn")));
			// KCZ new ratio Version V 6-11-03 
			Utility.PrintSummary(RG, rm.GetString("drOperProfMarginPlusDepr"),RG.GetPrintOrderCalc(RG.GetCalc("OpPrftMgnPlsDepr")));
			Utility.PrintSummary(RG, rm.GetString("drNtMgn"), RG.GetPrintOrderCalc(RG.GetCalc("NetMargin")));
			Utility.PrintSummary(RG, rm.GetString("drDivPORt"), RG.GetPrintOrderCalc(RG.GetCalc("DivPayRate")));
			Utility.PrintSummary(RG, rm.GetString("drEffTxRt"), RG.GetPrintOrderCalc(RG.GetCalc("EffTaxRate")));
            Utility.PrintSummary(RG, rm.GetString("drEBITAMargin"), RG.GetPrintOrderCalc(RG.GetCalc("EBITAMargin")));
            //Utility.PrintSummary(RG, rm.GetString("drEBITAAvgAssets"), RG.GetPrintOrderCalc(RG.GetCalc("EBITAAvgAssets")));

			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drActivity"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True"); //amit: 06/07/04 uncommented this line

			///Here we have to figure the logic around LINE(965) to figure out how to 
			///conditionally print labels 
			
			if (RG.TYPE(11).NonZero)
				Utility.PrintSummary(RG, rm.GetString("drGrsARDays"), RG.GetPrintOrderCalc(RG.GetCalc("GrsARDays")));

			Utility.PrintSummary(RG, rm.GetString("drNetARDays"), RG.GetPrintOrderCalc(RG.GetCalc("NetARDays")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, rm.GetString("drDOH"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("RawMatDOH"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("WrkInPrgDOH"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("FinGdsDOH"));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUFFIX, "");

			if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(15)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(16)) +
				FormatCommands.DetailCount(RG, RG.DETAILTYPE(17)) > 1)
				Utility.PrintSummary(RG, rm.GetString("drInvDOH"), RG.GetPrintOrderCalc(RG.GetCalc("InvDOH")));
            // KCZ Added Inventory Days (excl Depr) Version V 6-11-03 
			Utility.PrintSummary(RG, rm.GetString("cfmInvDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1701)")));
			Utility.PrintSummary(RG, rm.GetString("drAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("ActPayDOH")));
			// KCZ Added Accounts Payable Days (excl Depr) Version V 6-11-03 
            Utility.PrintSummary(RG, rm.GetString("cfmAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1728)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("drNetSlsTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesTotAst")));
			Utility.PrintSummary(RG, rm.GetString("drNetSlsNetWth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesNetWrth")));
			Utility.PrintSummary(RG, rm.GetString("drNetSlsNFA"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesNetFxdAst")));
			Utility.PrintSummary(RG, rm.GetString("drPBTTotAst"), RG.GetPrintOrderCalc(RG.GetCalc("PftB4TxsTotAst")));
            Utility.PrintSummary(RG, rm.GetString("drCAPEXDepExp"), RG.GetPrintOrderCalc(RG.GetCalc("CAPEXDepExp")));
            //Utility.PrintSummary(RG, rm.GetString("drRevenueVolatility"), RG.GetPrintOrderCalc(RG.GetCalc("RevenueVolatility")));
            Utility.PrintSummary(RG, rm.GetString("drCashToNetSales"), RG.GetPrintOrderCalc(RG.GetCalc("CashToNetSales")));
            Utility.PrintSummary(RG, rm.GetString("drLog10NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("Log10NetSales")));

			/// Here's where you would put the code to check for a page break.
			
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintLabel(RG, rm.GetString("drGrowth"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("drSustGwth"), RG.GetPrintOrderCalc(RG.GetCalc("SusGrowth")));

            Utility.Skip(RG, 1);

            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
            Utility.PrintLabel(RG, rm.GetString("icfCashFlow"));
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            Utility.PrintSummary(RG, rm.GetString("icfFfoToAdjDebt"), RG.GetPrintOrderCalc(RG.GetCalc("FfoToAdjustedDebt")));
            Utility.PrintSummary(RG, rm.GetString("icfFfoToNetAdjDebt"), RG.GetPrintOrderCalc(RG.GetCalc("FfoToNetAdjustedDebt")));
            Utility.PrintSummary(RG, rm.GetString("icfCAPEXToCfo"), RG.GetPrintOrderCalc(RG.GetCalc("CAPEXToCfo")));
            Utility.PrintSummary(RG, rm.GetString("icfCFOToProBefExtra"), RG.GetPrintOrderCalc(RG.GetCalc("CFOToProfitBefExtra")));


			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			/// Here we would enter the code to print the UDAs if the user had entered 
			/// any.  There is also page break logic to determine if the page should break
			/// prior to printing them.
			
			Utility.Skip(RG, 1);
			Utility.PrintUDAs(RG);
			
			Utility.UnderlinePage(RG, 2);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
			
//			StreamWriter sw = new StreamWriter("C:\\Det_Ratios.txt");
//			sw.Write(RG.Writer.Commands);
//			sw.Close();
		}
	}
}
