using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class CREDIT_COMPL:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.CredCompCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);
			
			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,3);

			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.25");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			RG.AddCalc("LiquidActs", RG.ACCOUNT(8000) + RG.ACCOUNT(8050) + RG.ACCOUNT(8100));
			
			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start of the 1st group "LIQUIDITY"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (RG.GetCalc("LiquidActs").NonZero) 
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccLiquidity"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
//			RG.AddCalc(FormatCommands.ZEROS_STRING_1, 0);

			if (RG.ACCOUNT(8000).NonZero)
			{
				Utility.PrintLabel(RG, rm.GetString("ccWorkCap"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("WCAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("WCStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("WCVar")));
			
				Calc WCDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("WCVar").Count; i++) 
					if (RG.GetCalc("WCVar")[i] < 0)
						WCDefChk.Add(double.NaN);
					else
						WCDefChk.Add(0);

				Calc WCDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8000).Count; i++) 
					if (RG.ACCOUNT(8000)[i] != 0)
						WCDef.Add(WCDefChk[i]);
					else
						WCDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (WCDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(WCDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");			
		
			if (RG.ACCOUNT(8100).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccQkRatio"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("QRAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("QRStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("QRVar")));
			
				Calc QRDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("QRVar").Count; i++) 
					if (RG.GetCalc("QRVar")[i] < 0)
						QRDefChk.Add(double.NaN);
					else
						QRDefChk.Add(0);

				Calc QRDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8100).Count; i++) 
					if (RG.ACCOUNT(8100)[i] != 0)
						QRDef.Add(QRDefChk[i]);
					else
						QRDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (QRDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(QRDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2"); 
				Utility.Skip(RG, 1);
			}
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8050).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccCurRatio"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("CRAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("CRStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("CRVar")));
			
				Calc CRDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("CRVar").Count; i++) 
					if (RG.GetCalc("CRVar")[i] < 0)
						CRDefChk.Add(double.NaN);
					else
						CRDefChk.Add(0);

				Calc CRDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8050).Count; i++) 
					if (RG.ACCOUNT(8050)[i] != 0)
						CRDef.Add(CRDefChk[i]);
					else
						CRDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (CRDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(CRDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			//amit: End of the 1st group "LIQUIDITY"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 2nd group "LEVERAGE/COVERAGE"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.AddCalc("LeverCover", RG.ACCOUNT(8150) + RG.ACCOUNT(8170) + RG.ACCOUNT(8200) + RG.ACCOUNT(8250));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("LeverCover").NonZero) 
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccLeverCover"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}
			
			if (RG.ACCOUNT(8150).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				Utility.PrintLabel(RG, rm.GetString("ccDbtTangWrth"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("DTWAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("DTWStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("DTWVar")));
			
				Calc DTWDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("DTWVar").Count; i++) 
					if (RG.GetCalc("DTWVar")[i] < 0)
						DTWDefChk.Add(double.NaN);
					else
						DTWDefChk.Add(0);

				Calc DTWDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8150).Count; i++) 
					if (RG.ACCOUNT(8150)[i] != 0)
						DTWDef.Add(DTWDefChk[i]);
					else
						DTWDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (DTWDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(DTWDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8170).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccIntCover"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("ICAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("ICStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("ICVar")));
			
				Calc ICDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("ICVar").Count; i++) 
					if (RG.GetCalc("ICVar")[i] < 0)
						ICDefChk.Add(double.NaN);
					else
						ICDefChk.Add(0);

				Calc ICDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8170).Count; i++) 
					if (RG.ACCOUNT(8170)[i] != 0)
						ICDef.Add(ICDefChk[i]);
					else
						ICDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (ICDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(ICDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8200).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccNetIncDprAmtCPLTD"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("NIDAAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("NIDAStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("NIDAVar")));
			
				Calc NIDADefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("NIDAVar").Count; i++) 
					if (RG.GetCalc("NIDAVar")[i] < 0)
						NIDADefChk.Add(double.NaN);
					else
						NIDADefChk.Add(0);

				Calc NIDADef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8200).Count; i++) 
					if (RG.ACCOUNT(8200)[i] != 0)
						NIDADef.Add(NIDADefChk[i]);
					else
						NIDADef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (NIDADef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(NIDADef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			///CPF 6/24/03  Round this item if report rounding is different.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if ((RG.ACCOUNT(8250).NonZero)&& (RG.IsBudgetToActual == false))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccCapExpend"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("CEAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("CEStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("CEVar")));
			
				Calc CEDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("CEVar").Count; i++) 
					if (RG.GetCalc("CEVar")[i] < 0)
						CEDefChk.Add(double.NaN);
					else
						CEDefChk.Add(0);

				Calc CEDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8250).Count; i++) 
					if (RG.ACCOUNT(8250)[i] != 0)
						CEDef.Add(CEDefChk[i]);
					else
						CEDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (CEDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(CEDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);

				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			//amit: End of the 2nd group "LIQUIDITY"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 3rd group "PROFITABILITY"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.AddCalc("Profitability", RG.ACCOUNT(8300) + RG.ACCOUNT(8350) + RG.ACCOUNT(8400));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("Profitability").NonZero) 
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccProfitability"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			if (RG.ACCOUNT(8300).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccNetMgn"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("NMAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("NMStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("NMVar")));
			
				Calc NMDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("NMVar").Count; i++) 
					if (RG.GetCalc("NMVar")[i] < 0)
						NMDefChk.Add(double.NaN);
					else
						NMDefChk.Add(0);

				Calc NMDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8300).Count; i++) 
					if (RG.ACCOUNT(8300)[i] != 0)
						NMDef.Add(NMDefChk[i]);
					else
						NMDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (NMDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(NMDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8350).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccRetEqty"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("ROEAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("ROEStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("ROEVar")));
			
				Calc ROEDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("ROEVar").Count; i++) 
					if (RG.GetCalc("ROEVar")[i] < 0)
						ROEDefChk.Add(double.NaN);
					else
						ROEDefChk.Add(0);

				Calc ROEDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8350).Count; i++) 
					if (RG.ACCOUNT(8350)[i] != 0)
						ROEDef.Add(ROEDefChk[i]);
					else
						ROEDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (ROEDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(ROEDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8400).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccRetAsts"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("ROAAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("ROAStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("ROAVar")));
			
				Calc ROADefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("ROAVar").Count; i++) 
					if (RG.GetCalc("ROAVar")[i] < 0)
						ROADefChk.Add(double.NaN);
					else
						ROADefChk.Add(0);

				Calc ROADef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8400).Count; i++) 
					if (RG.ACCOUNT(8400)[i] != 0)
						ROADef.Add(ROADefChk[i]);
					else
						ROADef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (ROADef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(ROADef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			//amit: End of the 3rd group "PROFITABILITY"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 4th group "ACITIVITY"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.AddCalc("Activity", RG.ACCOUNT(8450) + RG.ACCOUNT(8500) + RG.ACCOUNT(8550));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("Activity").NonZero) 
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccActivity"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8450).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccNetActRecDays"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("NARDAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("NARDStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("NARDVar")));
			
				Calc NARDDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("NARDVar").Count; i++) 
					if (RG.GetCalc("NARDVar")[i] < 0)
						NARDDefChk.Add(double.NaN);
					else
						NARDDefChk.Add(0);

				Calc NARDDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8450).Count; i++) 
					if (RG.ACCOUNT(8450)[i] != 0)
						NARDDef.Add(NARDDefChk[i]);
					else
						NARDDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (NARDDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(NARDDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8500).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccInvDays"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("IDAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("IDStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("IDVar")));
			
				Calc IDDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("IDVar").Count; i++) 
					if (RG.GetCalc("IDVar")[i] < 0)
						IDDefChk.Add(double.NaN);
					else
						IDDefChk.Add(0);

				Calc IDDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8500).Count; i++) 
					if (RG.ACCOUNT(8500)[i] != 0)
						IDDef.Add(IDDefChk[i]);
					else
						IDDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (IDDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(IDDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8550).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccActPayDays"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("APDAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("APDStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("APDVar")));
			
				Calc APDDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("APDVar").Count; i++) 
					if (RG.GetCalc("APDVar")[i] < 0)
						APDDefChk.Add(double.NaN);
					else
						APDDefChk.Add(0);

				Calc APDDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8550).Count; i++) 
					if (RG.ACCOUNT(8550)[i] != 0)
						APDDef.Add(APDDefChk[i]);
					else
						APDDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (APDDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(APDDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			//amit: End of the 4th group "ACTIVITY"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 5th group "EXPENSE"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.AddCalc("Expense", RG.ACCOUNT(8600) + RG.ACCOUNT(8650) + RG.ACCOUNT(8700));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("Expense").NonZero) 
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccExpense"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			///CPF 6/24/03  Round these items if Report rounding differs
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.ACCOUNT(8600).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccOffComp"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("OCAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("OCStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("OCVar")));
			
				Calc OCDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("OCVar").Count; i++) 
					if (RG.GetCalc("OCVar")[i] < 0)
						OCDefChk.Add(double.NaN);
					else
						OCDefChk.Add(0);

				Calc OCDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8600).Count; i++) 
					if (RG.ACCOUNT(8600)[i] != 0)
						OCDef.Add(OCDefChk[i]);
					else
						OCDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (OCDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(OCDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8650).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccLseRentExp"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("LREAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("LREStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("LREVar")));
			
				Calc LREDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("LREVar").Count; i++) 
					if (RG.GetCalc("LREVar")[i] < 0)
						LREDefChk.Add(double.NaN);
					else
						LREDefChk.Add(0);

				Calc LREDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8650).Count; i++) 
					if (RG.ACCOUNT(8650)[i] != 0)
						LREDef.Add(LREDefChk[i]);
					else
						LREDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (LREDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(LREDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			if (RG.ACCOUNT(8700).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccCashDivWith"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("CDWAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("CDWStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("CDWVar")));
			
				Calc CDWDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("CDWVar").Count; i++) 
					if (RG.GetCalc("CDWVar")[i] < 0)
						CDWDefChk.Add(double.NaN);
					else
						CDWDefChk.Add(0);

				Calc CDWDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8700).Count; i++) 
					if (RG.ACCOUNT(8700)[i] != 0)
						CDWDef.Add(CDWDefChk[i]);
					else
						CDWDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (CDWDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(CDWDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************
			
			//amit: End of the 5th group "EXPENSE"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 6th group "OTHER RELATION"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.AddCalc("OthRltnshp", RG.ACCOUNT(8750) + RG.ACCOUNT(8800) + RG.ACCOUNT(8850) + RG.ACCOUNT(8880) + RG.ACCOUNT(8900));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("Expense").NonZero) 
			{
				//amit: 03/23/04 
				//Utility.Skip(RG, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("ccOthRltnshps"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}


			if ((RG.ACCOUNT(8750).NonZero) && (RG.IsBudgetToActual == false))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccSubDbtRepay"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("SDRAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("SDRStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("SDRVar")));
			
				Calc SDRDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("SDRVar").Count; i++) 
					if (RG.GetCalc("SDRVar")[i] < 0)
						SDRDefChk.Add(double.NaN);
					else
						SDRDefChk.Add(0);

				Calc SDRDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8750).Count; i++) 
					if (RG.ACCOUNT(8750)[i] != 0)
						SDRDef.Add(SDRDefChk[i]);
					else
						SDRDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (SDRDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(SDRDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            if ((RG.ACCOUNT(8800).NonZero) && (RG.IsBudgetToActual == false))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccNewDebt"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("NDAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("NDStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("NDVar")));
			
				Calc NDDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("NDVar").Count; i++) 
					if (RG.GetCalc("NDVar")[i] < 0)
						NDDefChk.Add(double.NaN);
					else
						NDDefChk.Add(0);

				Calc NDDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8800).Count; i++) 
					if (RG.ACCOUNT(8800)[i] != 0)
						NDDef.Add(NDDefChk[i]);
					else
						NDDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (NDDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(NDDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			if (RG.ACCOUNT(8850).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccTNW"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("TNWAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("TNWStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("TNWVar")));
			
				Calc TNWDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("TNWVar").Count; i++) 
					if (RG.GetCalc("TNWVar")[i] < 0)
						TNWDefChk.Add(double.NaN);
					else
						TNWDefChk.Add(0);

				Calc TNWDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8850).Count; i++) 
					if (RG.ACCOUNT(8850)[i] != 0)
						TNWDef.Add(TNWDefChk[i]);
					else
						TNWDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (TNWDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(TNWDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			
			if (RG.ACCOUNT(8880).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccCashBal"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("CBAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMin"), RG.GetPrintOrderCalc(RG.GetCalc("CBStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("CBVar")));
			
				Calc CBDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("CBVar").Count; i++) 
					if (RG.GetCalc("CBVar")[i] < 0)
						CBDefChk.Add(double.NaN);
					else
						CBDefChk.Add(0);

				Calc CBDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8880).Count; i++) 
					if (RG.ACCOUNT(8880)[i] != 0)
						CBDef.Add(CBDefChk[i]);
					else
						CBDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (CBDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(CBDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			/// ********************************************************
			/// CHECK FOR LINES LEFT ON PAGE WHENEVER WE FIGURE OUT HOW.
			/// ********************************************************

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");

            if ((RG.ACCOUNT(8900).NonZero) && (RG.IsBudgetToActual == false))
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintLabel(RG, rm.GetString("ccSalesGwth"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.PrintSummary(RG, rm.GetString("ccActual"), RG.GetPrintOrderCalc(RG.GetCalc("SGAct")));
				Utility.PrintSummary(RG, rm.GetString("ccStndMax"), RG.GetPrintOrderCalc(RG.GetCalc("SGStnd")));
				Utility.PrintSummary(RG, rm.GetString("ccVariance"), RG.GetPrintOrderCalc(RG.GetCalc("SGVar")));
			
				Calc SGDefChk = new Calc();
				for (int i = 0; i < RG.GetCalc("SGVar").Count; i++) 
					if (RG.GetCalc("SGVar")[i] < 0)
						SGDefChk.Add(double.NaN);
					else
						SGDefChk.Add(0);

				Calc SGDef = new Calc();
				for (int i = 0; i < RG.ACCOUNT(8900).Count; i++) 
					if (RG.ACCOUNT(8900)[i] != 0)
						SGDef.Add(SGDefChk[i]);
					else
						SGDef.Add(0);

				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, rm.GetString("ccDefault"));
				if (SGDef.Contains(double.NaN))
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
				else
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
				Utility.PrintSummary(RG, rm.GetString("ccResult"), RG.GetPrintOrderCalc(SGDef));
				RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "0");
				RG.SetAuthorSetting(FORMATCOMMANDS.ERR_STRING_1, "N/A");

				RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				Utility.Skip(RG, 1);
			}

			Utility.PrintUDACompliance(RG);

			Utility.UnderlinePage(RG, 2);

			//amit: End of the 6th group "OTHER RELATION"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the outer group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);

//			StreamWriter sw = new StreamWriter("C:\\Credit_Compliance.txt");
//			sw.Write(RG.Writer.Commands);
//			sw.Close();
		}
	}
}
