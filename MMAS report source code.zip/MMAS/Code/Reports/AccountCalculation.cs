﻿/**********************************************************************************************************************
 * Copyright Moody's Analytics. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Moody's Analytics. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered
 * into with Moody's Analytics.
 *********************************************************************************************************************/

using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.Reflection;
using System.Resources;
using System.Linq;
using System.Collections.Generic;

namespace MMAS
{
    /// <summary>
    /// This class is used to hold calculations and reorder them
    /// </summary>
    public class AccountCalculation
    {
        public string Label { get; set; }
        public int? AccountId => Account?.Id;
        public Account Account { get; set; }
        public int TypeId { get; set; }
        public DetailCalcs Calc { get; set; }

        public AccountCalculation(string label, Account account, int typeId, DetailCalcs calc)
        {
            this.Label = label;
            this.Account = account;
            this.TypeId = typeId;
            this.Calc = calc;
        }
    }
}
