using System.Collections;
using System.Threading;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
	public class FOCUS_QUESTIONS:FinancialAnalyst.IReport
	{
		private ArrayList m_arrSalesGrowth = new ArrayList();
		private ArrayList m_arrSGCashFlow = new ArrayList();
		private ArrayList m_arrSGAcquire = new ArrayList();
		private ArrayList m_arrGrossMargin = new ArrayList();
		private ArrayList m_arrOpExpenses =  new ArrayList();
		private ArrayList m_arrOpPftMgn = new ArrayList();
		private ArrayList m_arrNetPftMgn = new ArrayList();
		private ArrayList m_arrARDays = new ArrayList();
		private ArrayList m_arrBadDebtRes = new ArrayList();
		private ArrayList m_arrInvDays = new ArrayList();
		private ArrayList m_arrAPDays = new ArrayList();
		private ArrayList m_arrTrdAccts =  new ArrayList();
		private ArrayList m_arrCapExpend = new ArrayList();
		private ArrayList m_arrCurRatio = new ArrayList();
		private ArrayList m_arrLeverage = new ArrayList();
		private ArrayList m_arrMisc = new ArrayList();
		private int indCat         = 0; //Industry Category
		private FORMATCOMMANDS FC = new FORMATCOMMANDS();
		CONSULTANT_CALCS Calcs = new CONSULTANT_CALCS();
		

		public void Execute(ReportGenerator RG)
		{
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			Calcs.FOCUS_QUESTIONS(RG);
			

			FormatCommands.LoadFormatDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			///Utility.CreateSystemPageHeader(RG,false);
			Utility.CreatePageHeader(RG, true);
			
			//CALCULATIONS Calcs = new CALCULATIONS();

			FormatCommands.LoadFormatDefaults(RG);

			int PBaseId;
			int BaseId = RG.BaseStatementID;

			///This variable will store the stmt index of the base comparison stmt
			PBaseId = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);

			///CPF 7/7/04 Added this logic to check for service industry
			int dbType = RG.DATABASE_TYPE();

			if (dbType == 3) indCat = dbType;

			int ind = (RG.IND(94) > 0) ? 4 : 0;

			if (dbType != 4) //4 = No Peer Database Selected
			{
				if (RG.IND_Category == (int)ePeerCategory.Assets)
					indCat= 1;
				else if (RG.IND_Category == (int)ePeerCategory.Sales)
					indCat= 2;
				else if (RG.IND_Category == (int)ePeerCategory.Totals)
					indCat = 3;
				indCat = indCat + ind;
			}

			string sCategory = "";

			///This if statement is used to store the selected IND_CATEGORY in a string variable
			if (RG.IND_Category == (int)ePeerCategory.Assets)
				sCategory= rm.GetString("sfpAssetsSize"); //ePeerCategory.Assets.ToString();
			else if (RG.IND_Category == (int)ePeerCategory.Sales)
				sCategory=rm.GetString("sfpSalesSize"); //ePeerCategory.Sales.ToString();
			else
				sCategory=ePeerCategory.Totals.ToString(); //not changing this one becasue its not used anywhere.
			
			///Utility.CreateTable(RG,(RG.POStatements.Count + 1));

			string s1="";
			///Cast a statement-constant object so that we can retrieve the name of it and store in the
			///string variable to follow.
			StatementConstant sc = (StatementConstant)RG.Customer.Model.StatementConstants[SCON.AuditMthd - 1];
			string sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToUpper();

			///If the audit method is Unqualified, Qualified, Reviewed, Compiled, or Company Prepared
			if ((sAdtMthVal == rm.GetString("civUnqUC")) || (sAdtMthVal == rm.GetString("civQualUC")) || (sAdtMthVal == rm.GetString("civRevUC")) || (sAdtMthVal == rm.GetString("civCompUC")) || (sAdtMthVal == rm.GetString("civCoPpdUC")))
			{
				///If the base stmt is annual, then describe the comparison stmt as such.
				if (RG.STMT_PERIODS()[PBaseId] == 12)
					s1 = string.Format(rm.GetString("qcAnylAnnual"), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
				else
					s1 = string.Format(rm.GetString("qcAnylInterim"), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), RG.STMT_PERIODS()[PBaseId].ToString(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
			}
			else
			{
				///This section is for if the audit method is anything other than those 
				///listed above...like Tax Return, Adverse Opinion, etc.  You still need to
				///check if the stmt is annual or not.
				if (RG.STMT_PERIODS()[PBaseId] == 12)
					s1 = string.Format(rm.GetString("qcAnylOthAnnual"), (sc.Label).ToLower(), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
				else
					s1 = string.Format(rm.GetString("qcAnylOthInterim"), (sc.Label).ToLower(), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), RG.STMT_PERIODS()[PBaseId].ToString(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
			}

			if (s1 != "")
			{
				///Print the first line.
				Utility.PrintParagraph(RG, s1);

				///This is the equivalent of skip when you don't have a table yet.
				Utility.PrintParagraph(RG, " ");
			}

			s1="";
			///If TargetCurrency is set, formulate the print line
			
			if (RG.TARGETCURRENCY(0) != null && RG.TARGETCURRENCY(0)[PBaseId] != null && RG.TARGETCURRENCY(0)[PBaseId].ToString().Trim() != "")
				s1 = string.Format(rm.GetString("qcFinInfoTarget"), RG.TARGETCURRENCY(0)[PBaseId].ToString());

			if (s1 != "")
			{
				///Print the first line.
				Utility.PrintParagraph(RG, s1);

				///This is the equivalent of skip when you don't have a table yet.
				Utility.PrintParagraph(RG, " ");
			}

			if (RG.STMT_PERIODS()[PBaseId] != 12)
			{
				Utility.PrintParagraph(RG, " ");
				Utility.PrintParagraph(RG, rm.GetString("qcInterimDisclmr"));
				Utility.PrintParagraph(RG, " ");
			}

			bool bLessTwoGwthPer = false;
			//amit: 11/29/05 Using Master Statement List instead of POStatements
			Calc clcGwthPerCnt = new Calc(1, RG.Statements.Count);
			Calc clcGP = RG.CALC_ACCUMULATE(clcGwthPerCnt,1);

			//amit: 11/29/05
			foreach(Statement s in RG.Statements)
			{
				if (s.Id == PBaseId)
				{
					if (s.GetReconcileID(RG.Context) == -1)
						bLessTwoGwthPer = true;
					break;
				}
			}

			//if ((RG.GetPrintOrderCalc(clcGP)[PBaseId]-1) == 1)
				//bLessTwoGwthPer = true;

			//Sales Growth
			RatioAnalysis SG = new RatioAnalysis(RG,RG.MACRO(M.NET_SALES_GROWTH)[PBaseId],RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],1,2,bLessTwoGwthPer);
			//Gross Margin
			RatioAnalysis GM = new RatioAnalysis(RG,RG.MACRO(M.GROSS_MARGIN)[PBaseId],RG.MACRO(M.GROSS_MARGIN, RG.LAG)[PBaseId],3,4);
			//Operating Expense
			RatioAnalysis OE = new RatioAnalysis(RG,RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES)[PBaseId],RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES, RG.LAG)[PBaseId],5,6);
			//Operating Profit Margin
			RatioAnalysis OPM = new RatioAnalysis(RG,RG.MACRO(M.OPERATING_PROFIT_MARGIN)[PBaseId],RG.MACRO(M.OPERATING_PROFIT_MARGIN, RG.LAG)[PBaseId],40,42);
			//Net Profit
			//CPF 6/15/04 Log 782:  Removed the boolean so that it can compare against pp instead of 0.
			RatioAnalysis NP = new RatioAnalysis(RG,RG.MACRO(M.PROFIT_MARGIN)[PBaseId],RG.MACRO(M.PROFIT_MARGIN, RG.LAG)[PBaseId],13,14); /*,bLessTwoGwthPer)*/
			//AR Days
			RatioAnalysis ARD = new RatioAnalysis(RG,RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId],RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[PBaseId],7,8);
			//Inventory Days
			RatioAnalysis ID = new RatioAnalysis(RG,RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId],RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[PBaseId],9,10);
			//Accounts Payable Days
			RatioAnalysis APD = new RatioAnalysis(RG,RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId],RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[PBaseId],11,12);
			//Debt/TNW
			RatioAnalysis DTNW = new RatioAnalysis(RG,RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId],RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId],19,20);

			SalesGrowth(RG, rm, PBaseId, SG);
			
			for (int i = 0; i < m_arrSalesGrowth.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrSalesGrowth[i].ToString());

				if (i + 1 == m_arrSalesGrowth.Count)
					Utility.PrintParagraph(RG, " ");
			}

			SalesGrowthCashFlow(RG, rm, PBaseId, SG);

			for (int i = 0; i < m_arrSGCashFlow.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrSGCashFlow[i].ToString());

				if (i + 1 == m_arrSGCashFlow.Count)
					Utility.PrintParagraph(RG, " ");
			}

			SalesGrowthAcquisition(RG, rm, PBaseId, SG);

			for (int i = 0; i < m_arrSGAcquire.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrSGAcquire[i].ToString());

				if (i + 1 == m_arrSGAcquire.Count)
					Utility.PrintParagraph(RG, " ");
			}

			GrossMargin(RG, rm, PBaseId, GM);

			for (int i = 0; i < m_arrGrossMargin.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrGrossMargin[i].ToString());

				if (i + 1 == m_arrGrossMargin.Count)
					Utility.PrintParagraph(RG, " ");
			}

			OperatingExpenses(RG, rm, PBaseId, OE);
			
			for (int i = 0; i < m_arrOpExpenses.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrOpExpenses[i].ToString());

				if (i + 1 == m_arrOpExpenses.Count)
					Utility.PrintParagraph(RG, " ");
			}

			OperatingProfitMargin(RG, rm, PBaseId, OPM);
			
			for (int i = 0; i < m_arrOpPftMgn.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrOpPftMgn[i].ToString());

				if (i + 1 == m_arrOpPftMgn.Count)
					Utility.PrintParagraph(RG, " ");
			}
			
			NetProfitMargin(RG, rm, PBaseId, NP);
			
			for (int i = 0; i < m_arrNetPftMgn.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrNetPftMgn[i].ToString());

				if (i + 1 == m_arrNetPftMgn.Count)
					Utility.PrintParagraph(RG, " ");
			}

			ARDays(RG, rm, PBaseId, ARD);

			for (int i = 0; i < m_arrARDays.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrARDays[i].ToString());

				if (i + 1 == m_arrARDays.Count)
					Utility.PrintParagraph(RG, " ");
			}

			BadDebtReserve(RG, rm, PBaseId);
			for (int i = 0; i < m_arrBadDebtRes.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrBadDebtRes[i].ToString());

				if (i + 1 == m_arrBadDebtRes.Count)
					Utility.PrintParagraph(RG, " ");
			}

			///CPF 7/7/04 Log 819:  Aded logic to not print Inv or AP days if Service industry.
			if (isServiceIndustry(RG) == false)
			{
				InventoryDays(RG, rm, PBaseId, ID);
				for (int i = 0; i < m_arrInvDays.Count; i++)
				{
					Utility.PrintParagraph(RG, m_arrInvDays[i].ToString());

					if (i + 1 == m_arrInvDays.Count)
						Utility.PrintParagraph(RG, " ");
				}

				AccountsPayableDays(RG, rm, PBaseId, APD);
				for (int i = 0; i < m_arrAPDays.Count; i++)
				{
					Utility.PrintParagraph(RG, m_arrAPDays[i].ToString());

					if (i + 1 == m_arrAPDays.Count)
						Utility.PrintParagraph(RG, " ");
				}
			}

			TradeAccounts(RG, rm, PBaseId, ID, APD, ARD);
			for (int i = 0; i < m_arrTrdAccts.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrTrdAccts[i].ToString());

				if (i + 1 == m_arrTrdAccts.Count)
					Utility.PrintParagraph(RG, " ");
			}
	
			CapExpend(RG, rm, PBaseId);
			for (int i = 0; i < m_arrCapExpend.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrCapExpend[i].ToString());

				if (i + 1 == m_arrCapExpend.Count)
					Utility.PrintParagraph(RG, " ");
			}

			CurrentRatio(RG, rm, PBaseId);
			for (int i = 0; i < m_arrCurRatio.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrCurRatio[i].ToString());

				if (i + 1 == m_arrCurRatio.Count)
					Utility.PrintParagraph(RG, " ");
			}

			Leverage(RG, rm, PBaseId, DTNW);
			for (int i = 0; i < m_arrLeverage.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrLeverage[i].ToString());

				if (i + 1 == m_arrLeverage.Count)
					Utility.PrintParagraph(RG, " ");
			}

			Miscellaneous(RG, rm, PBaseId);
			for (int i = 0; i < m_arrMisc.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrMisc[i].ToString());

				if (i + 1 == m_arrMisc.Count)
					Utility.PrintParagraph(RG, " ");
			}

			//Utility.CloseReport(RG);
	
			Utility.PrintParagraph(RG, " ");
			Utility.PrintNotes(RG);

		}
		private bool isServiceIndustry(ReportGenerator RG)
		{
			double[] ind1 = new double[13] {22, 48, 52, 53, 54, 55, 56, 61, 62, 71, 81, 92, 98};
			bool indFound = false;
						
			for(int x=0; x < ind1.Length -1; x++)
			{
				if (RG.IND(1) == ind1[x])
				{
					indFound = true;
					break;
				}
			}
			if (indFound) return indFound;
			if (this.indCat == 3) //Default Database 
			{
				string sic = RG.IND_DIVISON;	
				//REALSTA = H, SERVICE = I, TRANSPOR = E
				if (sic != null)
				{
					if ((sic.Equals("H")) || (sic.Equals("I"))||
						(sic.Equals("E")))
					{
						indFound = true;
					}
				}
			}
			return indFound;
		}
		private string SignifString (RatioAnalysis RA, ResourceManager rm)
		{
			string s;
			if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little)
				s =rm.GetString("fqModest");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)
				s =rm.GetString("fqModerate");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant)
				s =rm.GetString("fqHigh");
			else 
				s =rm.GetString("fqVeryHigh");

			return s;
		}
		private string SignifStringAdverb (RatioAnalysis RA, ResourceManager rm)
		{
			string s;
			if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little)
				s =rm.GetString("fqModestly");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)
				s =rm.GetString("fqModerately");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant)
				s =rm.GetString("fqSignificantly");
			else 
				s =rm.GetString("fqSignificantly");

			return s;
		}
		private void SalesGrowth(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis SG)
		{			

			string sYear = RG.STMT_YEAR()[PBaseId].ToString(); 
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			double dSG = Math.Round(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId], 2);
			double dSGLag = Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId], 2);
			string indent = "   ";

			if (SG.GrowthType == RatioAnalysis.eGrowthType.NoGrowth)
			{
				///Line 8000:  0, 9, 18    Line 8005:  0 
				m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSUnchgd"), sYear));//"NET SALES were unchanged in {0}.  Does management anticipate any changes in sales level in the near future?  If so, will it be due to:");
				m_arrSalesGrowth.Add(indent + rm.GetString("fqChgSalesMgmt"));//*"   Change in sales targets set by management?");
				m_arrSalesGrowth.Add(indent + rm.GetString("fqChgDirMktGls"));//*"   Change in strategic direction with regard to marketing goals?");
				m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix or pricing policy?");
				m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdCap"));//"   Change in production capacity?");
				m_arrSalesGrowth.Add(indent + rm.GetString("fqAntChgBuyPref"));//"   Anticipated changes in buyer preferences?");
			}
			else if (SG.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))
				{
					///LINE 8000:  1,3
					if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSIncrModClose"), SignifString(SG,rm), dSG, sYear, dSGLag));//"SALES GROWTH was {0} at {1}% in {2} compared to {3}% in the prior period.  Will the current growth be maintained?  If not, will the change be due to:");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgSalesMgmt"));//*"   Change in sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgDirMktGls"));//"   Change in strategic direction with regard to marketing goals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix or pricing policy?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdCap"));//"   Change in production capacity?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqAntChgBuyPref"));//"   Anticipated changes in buyer preferences?");
					}
						///LINE 8000:  10, 12
					else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.GreaterThanLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSIncrModGThanPP"), SignifString(SG, rm), dSG, sYear, dSGLag));//"SALES GROWTH was {0} at {1}% in {2}, higher than {3}% in the prior year.  Was this rising rate caused by:");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIncSalesTarMgmt"));//"   Increased sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgDirMktGls"));//"   Changes in strategic direction regaring marketing goals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMix"));//"   Introduction of new products or change in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDeclCompForce"));//"   Decline in competitive forces?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in market demand or buyer preferences?");
						m_arrSalesGrowth.Add(rm.GetString("fqWillGwthBeMaintained"));//"Will this growth level be maintained or does management anticipate changes in the near future?");
					}
						///LINE 8000:  19, 21  
					else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.LessThanLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSIncrModLThanPP"), SignifString(SG, rm), dSG, sYear, dSGLag));//"SALES GROWTH was {0} at {1}% in {2} although lower than {3}% in the prior year.  Was this slowing rate caused by:");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgSalesMgmt"));//*"   Change in sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgDirMktGls"));//"   Change in strategic direction with regard to marketing goals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix or pricing policy?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqCapLimit"));//"   Capacity limitations?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIncCompMajMkt"));//"   Increased competition in the company's major markets?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqFinDeterMajBuy"));//"   Financial deterioration of major buyers?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgGenMktDmd"));//"   Changes in general market demand?");
						m_arrSalesGrowth.Add(rm.GetString("fqWillGwthDecline"));//"Will the growth rate continue to decline or will it stabilize in the near future?");
					}
						///LINE 8005:  1,3
					else 
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSIncrModNoPP"), SignifString(SG, rm), dSG, sYear));//"SALES GROWTH was {0} at {1}% in {2}.  Was this increase caused by:");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIncSalesTarMgmt"));//"   Increased sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgDirMktGls"));//"   Changes in strategic direction regaring marketing goals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMix"));//"   Introduction of new products or change in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDeclCompForce"));//"   Decline in competitive forces?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in market demand or buyer preferences?");
						m_arrSalesGrowth.Add(rm.GetString("fqWillGwthBeMaintained"));//"Will this growth level be maintained or does management anticipate changes in the near future?");
					}
				}
				else
					///THIS IS THE SECTION FOR SIGNIFICANT OR VERY SIGNIFICANT
				{
					///LINE 8000:  5,7
					if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqNSHighClose"), sYear));//"What caused the continued high SALES GROWTH in {0}?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqHighSlsTgt"));//"   High sales targets set and pursued by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewRefocusMgmt"));//"   New or refocused sales management and direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgOverallStratDir"));//"   Changes in overall strategic direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMkt"));//"   Introduction of new products or new markets?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewMktgAdApp"));//"   New marketing and/or advertising approaches?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDecCompPresRiv"));//"   Decline of competitive pressures or strong rivals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in buyer preferences or general market demand?");
						m_arrSalesGrowth.Add(rm.GetString("fqCanMgmtMaintainHiSales"));//"Can management maintain the high sales growth level or will it decline before stabilizing?");
					}
						///LINE 8000:  14,16
					else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.GreaterThanLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGHighIncr"), SignifString(SG, rm), sYear));//What caused the {0} and increasing SALES GROWTH in {1}?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqHighSlsTgt"));//"   High sales targets set and pursued by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewRefocusMgmt"));//"   New or refocused sales management and direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgOverallStratDir"));//"   Changes in overall strategic direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMkt"));//"   Introduction of new products or new markets?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewMktgAdApp"));//"   New marketing and/or advertising approaches?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDecCompPresRiv"));//"   Decline of competitive pressures or strong rivals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in buyer preferences or general market demand?");
						m_arrSalesGrowth.Add(rm.GetString("fqCanMgmtMaintainHiSales"));//"Can management maintain the high sales growth level or will it decline before stabilizing?");
					}
						///LINE 8000:  23,25  
					else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.LessThanLastYear)
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGHighDecr"), SignifString(SG, rm), sYear, sYearLag));//"SALES GROWTH was {0} in {1} although not greater than in {2}.  Has this high growth been caused by:");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqHighSlsTgt"));//"   High sales targets set and pursued by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewRefocusMgmt"));//"   New or refocused sales management and direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgOverallStratDir"));//"   Changes in overall strategic direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMkt"));//"   Introduction of new products or new markets?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewMktgAdApp"));//"   New marketing and/or advertising approaches?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDecCompPresRiv"));//"   Decline of competitive pressures or strong rivals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in buyer preferences or general market demand?");
						m_arrSalesGrowth.Add(rm.GetString("fqCanMgmtMaintainHiSales"));//"Can management maintain the high sales growth level or will it decline before stabilizing?");
					}
						///LINE 8005:  5,7
					else
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGHigh"), SignifString(SG, rm), sYear));//"What caused the {0} SALES GROWTH in {1}?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqHighSlsTgt"));//"   High sales targets set and pursued by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewRefocusMgmt"));//"   New or refocused sales management and direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgOverallStratDir"));//"   Changes in overall strategic direction?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIntroNewProdMkt"));//"   Introduction of new products or new markets?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgProdMix"));//"   Changes in product mix?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqNewMktgAdApp"));//"   New marketing and/or advertising approaches?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqDecCompPresRiv"));//"   Decline of competitive pressures or strong rivals?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in buyer preferences or general market demand?");
						m_arrSalesGrowth.Add(rm.GetString("fqCanMgmtMaintainHiSales"));//"Can management maintain the high sales growth level or will it decline before stabilizing?");
					}
				}
			}
				///THIS IS THE NEGATIVE GROWTH SECTION
			else
			{
				if ((SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))
				{
					///LINE 8005:  2,4
					if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.NoGrowthLastYear) 
					{   
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGDecrNoPP"), SignifStringAdverb(SG, rm), sYear, dSG));//"SALES GROWTH declined {0} in {1} to {2}%.  What has caused this decline?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgSalesMgmt"));//*"   Change in sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqMgmtDecDown"));//"   Conscious management decision to downsize?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqStratChgMktPrice"));//"   Strategic changes regarding markets or pricing policy?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqInadProdFac"));//"   Inadequate production facilities?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqProdSvcInad"));//"   Product service inadequacies?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqObsolStyleCons"));//"   Obsolescence or style considerations?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in general market or buyer preferences?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIncrComp"));//"   Increased competition?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqFinDeterMajBuy"));//"   Financial deterioration of major consumers?");
						m_arrSalesGrowth.Add(rm.GetString("fqWillSGContNeg"));//"Will this sales level continue or does management have plans to control or reverse this negative growth?");
					}
						///LINE 8000:  2,4,11,13,20,22 
					else
					{
						m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGNeg"), SignifStringAdverb(SG, rm), sYear, dSG));//"SALES GROWTH was {0} negative in {1} at {2}%.  What has caused this decline?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgSalesMgmt"));//"   Change in sales targets set by management?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqMgmtDecDown"));//"   Conscious management decision to downsize?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqStratChgMktPrice"));//"   Strategic changes regarding markets or pricing policy?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqInadProdFac"));//"   Inadequate production facilities?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqProdSvcInad"));//"   Product service inadequacies?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqObsolStyleCons"));//"   Obsolescence or style considerations?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in general market or buyer preferences?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqIncrComp"));//"   Increased competition?");
						m_arrSalesGrowth.Add(indent + rm.GetString("fqFinDeterMajBuy"));//"   Financial deterioration of major consumers?");
						m_arrSalesGrowth.Add(rm.GetString("fqWillSGContNeg"));//Will this sales level continue or does management have plans to control or reverse this negative growth?");
					}
				}
				else
					///THIS IS THE SECTION FOR SIGNIFICANT OR VERY SIGNIFICANT
				{
					///LINE 8000:  6,8,15,17,24,26
					///LINE 8005:  6,8
					m_arrSalesGrowth.Add(string.Format(rm.GetString("fqSGNeg"), SignifStringAdverb(SG, rm), sYear, dSG));//"SALES GROWTH was {0} negative in {1} at {2}%.  What has caused this decline?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqMgmtDecDown"));//"   Conscious management decision to downsize?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqStratChgMktPrice"));//"   Strategic changes regarding markets or pricing policy?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqInadProdFac"));//"   Inadequate production facilities?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqProdSvcInad"));//"   Product service inadequacies?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqObsolStyleCons"));//"   Obsolescence or style considerations?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqChgMktDmdPref"));//"   Changes in general market or buyer preferences?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqIncrComp"));//"   Increased competition?");
					m_arrSalesGrowth.Add(indent + rm.GetString("fqFinDeterMajBuy"));//"   Financial deterioration of major consumers?");
					m_arrSalesGrowth.Add(rm.GetString("fqWillSGContNeg"));//"Will this sales level continue or does management have plans to control or reverse this negative growth?");
				}
			}	
		}
		private void SalesGrowthCashFlow(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis SG)
		{

			string sYear = RG.STMT_YEAR()[PBaseId].ToString(); 
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			double dSG = Math.Round(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId], 2);
			double dSGLag = Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId], 2);
			string indent = "   ";
			double dNCI = RG.MACRO(M.NET_CASH_INCOME)[PBaseId];
			double dCADA = RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION)[PBaseId];
			double dFinSpls = RG.MACRO(M.FIN_SURPLUS)[PBaseId];
			double dIntPayCPLTD = RG.GetCalc("fqIntPayCPLTD")[PBaseId];

			if (SG.GrowthType == RatioAnalysis.eGrowthType.NoGrowth)
			{
				if ((dNCI < 0) && (dCADA < 0) && (dFinSpls < 0))
				{
					if (dIntPayCPLTD > 0)
					{
						///Line 8305:  27
						m_arrSGCashFlow.Add(rm.GetString("fqUnchgInsuffCash"));//*The business, even at this unchanged sales level, is not generating sufficient cash to service its debt.
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
					}
					else
					{
						///Line 8305:  9
						m_arrSGCashFlow.Add(rm.GetString("fqUnchgNoPosCF"));//The business, even at this unchanged sales level, is not generating positive cash flow from operations.
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
					}
				}
			}
			else if (SG.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))
				{
					if ((dNCI < 0) && (dCADA < 0) && (dFinSpls < 0))
					{
						if (dIntPayCPLTD > 0)
						{
							///LINE 8305   28, 30
							m_arrSGCashFlow.Add(rm.GetString("fqIncrInsuffCash"));//The business, even at this modest growth rate, is not generating sufficient cash to service its debt.
							m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
							m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
							m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
						}
						else
						{
							///LINE 8305   10, 12
							m_arrSGCashFlow.Add(rm.GetString("fqIncrNoPosCF"));//The business, even at this modest growth rate, is not generating positive cash flow from operations.
							m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
							m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
							m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
						}
					}
				}
			}
			else
			{
				if ((dNCI < 0) && (dCADA < 0) && (dFinSpls < 0))
				{
					if (dIntPayCPLTD > 0)
					{
						///LINE 8305:  29, 31, 33, 35
						m_arrSGCashFlow.Add(rm.GetString("fqDeclInsuffCash"));//Although sales are declining, normally an indication of cash inflows, the business is not generating sufficent cash to service its debt.
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
					}
					else 
					{
						///LINE 8305:  11, 13, 15, 17
						m_arrSGCashFlow.Add(rm.GetString("fqDeclNoPosCF"));//Although sales are declining, normally an indication of cash inflows, the business is failing to generate positive cash flow from operations.
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtCostControl"));//Is management considering cost controls or reductions?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqHighSalary"));//Are wages and salaries unusually high?
						m_arrSGCashFlow.Add(indent + rm.GetString("fqMgmtTightCFDriver"));//Can management tighten control of balance sheet cash flow drivers?
					}
				}
			}
		}
		private void SalesGrowthAcquisition(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis SG)
		{
			double dSG = Math.Round(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId], 2);
			double dSGLag = Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId], 2);
			string indent = "   ";
			double dNFA = RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId];
			double dNFALag = RG.MACRO(M.NET_FIXED_ASSETS, RG.LAG)[PBaseId];

			///check to see if sales growth >= 15%
			if (dSG >= 0.15)
			{		
				if ((SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if (dNFA > (dNFALag * (1 + dSG/100)))
					{
						///Line 8083:  3
						m_arrSGAcquire.Add(rm.GetString("fqHasCmpyAcqrd"));//Has the company acquired or opened another operating entity?  The sharp increase in sales growth and the relative increase in fixed assets suggest such a change.
						m_arrSGAcquire.Add(indent + rm.GetString("fqAchvStratGoals"));//Does this represent achievement of strategic goals?
						m_arrSGAcquire.Add(indent + rm.GetString("fqChgOccurMgmt"));//What changes have occurred or might occur in management?
						m_arrSGAcquire.Add(indent + rm.GetString("fqChgMarkStrat"));//What changes might occur in corporate or marketing strategy?
					}
				}
			}
		}

		private void GrossMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis GM)
		{
			double dGM = Math.Round(RG.MACRO(M.GROSS_MARGIN_EXCL_DEPRECIATION)[PBaseId], 2);
			double dGMLag = Math.Round(RG.MACRO(M.GROSS_MARGIN_EXCL_DEPRECIATION, RG.LAG)[PBaseId], 2);
			string indent = "   ";

			///check to see if sales growth >= 15%
			if ((dGM < 100) && (dGM > 0))
			{		
				if (GM.GrowthType == RatioAnalysis.eGrowthType.Positive)
				{
					if ((GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate) || (GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
					{
						///Line 8340:  3,5,7
						m_arrGrossMargin.Add(string.Format(rm.GetString("fqGMImprove"), dGM));//What has caused GROSS MARGIN (excl. Cost of Sales-Depreciation) to improve to {0}%?
						m_arrGrossMargin.Add(indent + rm.GetString("fqMgmtInitPrcInc"));//Management-initiated price increases?
						m_arrGrossMargin.Add(indent + rm.GetString("fqRedInvCost"));//Reduction in inventory costs?
						m_arrGrossMargin.Add(indent + rm.GetString("fqProdDistEff"));//Production or distribution efficiencies?
						m_arrGrossMargin.Add(indent + rm.GetString("fqRealStratGoals"));//Realization of strategic goals previously implemented?
						m_arrGrossMargin.Add(indent + rm.GetString("fqMktAdvProdInov"));//Market advantage due to product innovation or uniqueness?
						m_arrGrossMargin.Add(indent + rm.GetString("fqMktAdvPromAdv"));//Market advantage due to effective promotion or advertising?
						m_arrGrossMargin.Add(indent + rm.GetString("fqMktAdvEnvGeoIss"));//Market advantage due to environmental or geographic issues?
						m_arrGrossMargin.Add(indent + rm.GetString("fqDecrComp"));//Decreased competition?
						m_arrGrossMargin.Add(rm.GetString("fqCanMgmtMainHiMgn"));//Can management maintain this higher margin?  Does management believe that market or cost pressures in the near futute will reduce the margin?
					}
				}
				else
				{
					if ((GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate) || (GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (GM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
					{
						///Line 8340:  4,6,8
						m_arrGrossMargin.Add(string.Format(rm.GetString("fqGMDecine"), dGM));//What has caused the decline of GROSS MARGIN (excl. Cost of Sales-Depreciation) to {0}%?
						m_arrGrossMargin.Add(indent + rm.GetString("fqMgmtInitPrcRed"));//Management-initiated price reductions to gain market share?
						m_arrGrossMargin.Add(indent + rm.GetString("fqProdDistIneff"));//Production or distribution inefficiencies?
						m_arrGrossMargin.Add(indent + rm.GetString("fqIncInvCost"));//Increased inventory costs?
						m_arrGrossMargin.Add(indent + rm.GetString("fqStratMistake"));//Strategic mistakes?
						m_arrGrossMargin.Add(indent + rm.GetString("fqPrcPressProdIssue"));//Price pressure from key buyers due to product/service issues?
						m_arrGrossMargin.Add(indent + rm.GetString("fqLossMSObsolesc"));//Loss of market share due to obsolescence or style factors?
						m_arrGrossMargin.Add(indent + rm.GetString("fqIncCompMajRiv"));//Increased competition from major rivals?
						m_arrGrossMargin.Add(indent + rm.GetString("fqIncCstPressLab"));//Increased cost pressures from labor or suppliers?
						m_arrGrossMargin.Add(rm.GetString("fqCanMgmtRevDcln"));//Can management reverse or halt this decline?  If not, are strategic plans being developed to address the fundamental issues?
					}
				}
			}
			else if (dGM < 0)
			{
				///Line 8340:  0
				m_arrGrossMargin.Add(rm.GetString("fqGMNegative"));//What is the cause for the negative GROSS MARGIN (excl. Cost of Sales-Depreciation)?
				m_arrGrossMargin.Add(indent + rm.GetString("fqMgmtInitPrcRed"));//Management-initiated price reductions to gain market share?
				m_arrGrossMargin.Add(indent + rm.GetString("fqProdDistIneff"));//Production or distribution inefficiencies?
				m_arrGrossMargin.Add(indent + rm.GetString("fqIncInvCost"));//Increased inventory costs?
				m_arrGrossMargin.Add(indent + rm.GetString("fqStratMistake"));//Strategic mistakes?
				m_arrGrossMargin.Add(indent + rm.GetString("fqPrcPressProdIssue"));//Price pressure from key buyers due to product/service issues?
				m_arrGrossMargin.Add(indent + rm.GetString("fqLossMSObsolesc"));//Loss of market share due to obsolescence or style factors?
				m_arrGrossMargin.Add(indent + rm.GetString("fqIncCompMajRiv"));//Increased competition from major rivals?
				m_arrGrossMargin.Add(indent + rm.GetString("fqIncCstPressLab"));//Increased cost pressures from labor or suppliers?
				m_arrGrossMargin.Add(rm.GetString("fqCanMgmtRevDcln"));//Can management reverse or halt this decline?  If not, are strategic plans being developed to address the fundamental issues?
			}
		}
		private void OperatingExpenses(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis OE)
		{
			double dOE = Math.Round(RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES)[PBaseId], 2);
			double dOELag = Math.Round(RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES, RG.LAG)[PBaseId], 2);
			//double dOE$ = RG.MACRO(M.
			double dSG = Math.Round(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId], 2);
			double dTOE = RG.MACRO(M.TOTAL_OPERATING_EXP)[PBaseId] - RG.MACRO(M.DEPR_PLUS_AMORT)[PBaseId];
			double dTOELag = RG.MACRO(M.TOTAL_OPERATING_EXP, RG.LAG)[PBaseId]- RG.MACRO(M.DEPR_PLUS_AMORT,RG.LAG)[PBaseId];
			string indent = "   ";
			RatioAnalysis SG = new RatioAnalysis(RG,RG.MACRO(M.NET_SALES_GROWTH)[PBaseId],RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],1,2,true);
	
			if (OE.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate) || (OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if ((SG.GrowthType == RatioAnalysis.eGrowthType.Positive) || (SG.GrowthType == RatioAnalysis.eGrowthType.NoGrowth))/*(dSG >= 0)*/
					{
						///LINE 8347:  3,5,7,12,14,16,21,23,25,30,32,34,57,59,61,66,68,70,93,95,97,102,104,106,129,131,133,138,140,142
						m_arrOpExpenses.Add(rm.GetString("fqOEIncrSGIncre"));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase as a percent of sales?
						m_arrOpExpenses.Add(indent + rm.GetString("fqIncrAdminOvhd"));//Increased administrative or overhead costs?
						m_arrOpExpenses.Add(indent + rm.GetString("fqIncrMktAdv"));//Increased marketing or advertising costs?
						m_arrOpExpenses.Add(indent + rm.GetString("fqHighCostSalPress"));//Higher selling or technical costs due to salary pressures?
						m_arrOpExpenses.Add(indent + rm.GetString("fqHighPropFxdCst"));//High proportion of fixed costs in operating expense?
						m_arrOpExpenses.Add(indent + rm.GetString("fqReorgCost"));//Expansion or reorganization costs?
						m_arrOpExpenses.Add(indent + rm.GetString("fqUnusNessExp"));//Unusual necessary expenses?
					}
					else
					{
						if (dTOE > dTOELag)
						{
							///LINE 8347:  48,50,52,84,86,88,120,122,124,156,158,160
							m_arrOpExpenses.Add(string.Format(rm.GetString("fqOEIncrSalesChg"), FC.RoundToReport(RG, dTOE).ToString("N0"), dSG.ToString("N2")));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase to {0} as sales have changed by {1}%.
							m_arrOpExpenses.Add(indent + rm.GetString("fqIncrAdminOvhd"));//Increased administrative or overhead costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqIncrMktAdv"));//Increased marketing or advertising costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqHighCostSalPress"));//Higher selling or technical costs due to salary pressures?
							m_arrOpExpenses.Add(indent + rm.GetString("fqHighPropFxdCst"));//High proportion of fixed costs in operating expense?
							m_arrOpExpenses.Add(indent + rm.GetString("fqReorgCost"));//Expansion or reorganization costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqUnusNessExp"));//Unusual necessary expenses?
							m_arrOpExpenses.Add(rm.GetString("fqAreFxdCostInflex"));//Are the company's fixed costs inflexible or subject to long contract terms?
						}
						else if (dTOE <= dTOELag)
						{
							///LINE 8347:  39,41,43,75,77,79,111,113,115,147,149,151
							m_arrOpExpenses.Add(string.Format(rm.GetString("fqOEDcrSalesDcr"), FC.RoundToReport(RG, dTOE).ToString("N0"), dOE.ToString("N2")));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase as a percent of sales?
							m_arrOpExpenses.Add(indent + rm.GetString("fqIncrAdminOvhd"));//Increased administrative or overhead costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqIncrMktAdv"));//Increased marketing or advertising costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqHighCostSalPress"));//Higher selling or technical costs due to salary pressures?
							m_arrOpExpenses.Add(indent + rm.GetString("fqHighPropFxdCst"));//High proportion of fixed costs in operating expense?
							///CPF 6/9/04 Log 766:  Commented out extra line copied from case above.
							///m_arrOpExpenses.Add(indent + rm.GetString("fqReorgCost"));//Expansion or reorganization costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqUnusNessExp"));//Unusual necessary expenses?
							m_arrOpExpenses.Add(indent + rm.GetString("fqCanMgmtRedExp"));//Can management continue to reduce expenses if sales remain at the current level or lower?
						}
					}
				}
			}
			else if (OE.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if ((OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate) || (OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if ((SG.GrowthType == RatioAnalysis.eGrowthType.Negative) || (SG.GrowthType == RatioAnalysis.eGrowthType.NoGrowth))/*(dSG <= 0)*/
					{
						///LINE 8347:  4,6,8,13,15,17,40,42,44,49,51,53,76,78,80,85,87,89,112,114,116,121,123,125,148,150,152,157,159,161
						m_arrOpExpenses.Add(rm.GetString("fqOEDcrPctSls"));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase as a percent of sales?
						m_arrOpExpenses.Add(indent + rm.GetString("fqStabOvrHdCst"));//Increased administrative or overhead costs?
						m_arrOpExpenses.Add(indent + rm.GetString("fqStabMktSellTech"));//Increased marketing or advertising costs?
						m_arrOpExpenses.Add(indent + rm.GetString("fqLowFxdCstToOE"));//Higher selling or technical costs due to salary pressures?
						m_arrOpExpenses.Add(indent + rm.GetString("fqSavOrgConsol"));//High proportion of fixed costs in operating expense?
						m_arrOpExpenses.Add(indent + rm.GetString("fqCanMgmtContLowExpRt"));//Expansion or reorganization costs?
					}
					else
					{
						if (dTOE > dTOELag)
						{
							///LINE 8347:  31,33,35,67,69,71,103,105,107,139,141,143
							m_arrOpExpenses.Add(string.Format(rm.GetString("fqOEIncrRtDcrSlsInc"), FC.RoundToReport(RG, dTOE).ToString("N0"), dOE.ToString("N2")));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase to {0} as sales have changed by {1}%.
							m_arrOpExpenses.Add(indent + rm.GetString("fqStabOvrHdCst"));//Increased administrative or overhead costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqStabMktSellTech"));//Increased marketing or advertising costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqLowStbFxdCstOE"));//Higher selling or technical costs due to salary pressures?
							m_arrOpExpenses.Add(indent + rm.GetString("fqSavOrgConsol"));//High proportion of fixed costs in operating expense?
							m_arrOpExpenses.Add(indent + rm.GetString("fqCanMgmtContExpGwth"));//Expansion or reorganization costs?
						}
						else if (dTOE <= dTOELag)
						{
							///LINE 8347:  22,24,26,58,60,62,94,96,98,130,132,134
							m_arrOpExpenses.Add(string.Format(rm.GetString("fqOERtDcrSlsIncr"), dOE.ToString("N2")));//What has caused the OPERATING EXPENSE (excl. depreciation) to increase as a percent of sales?
							m_arrOpExpenses.Add(indent + rm.GetString("fqStabOvrHdCst"));//Increased administrative or overhead costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqStabMktSellTech"));//Increased marketing or advertising costs?
							m_arrOpExpenses.Add(indent + rm.GetString("fqLowFxdCstToOE"));//Higher selling or technical costs due to salary pressures?
							m_arrOpExpenses.Add(indent + rm.GetString("fqSavOrgConsol"));//High proportion of fixed costs in operating expense?
						}
					}
				}
			}
			if (SG.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (SG.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant)) 
				{
					if ((OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (OE.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
					{
						//if there are items currently in the array, then add a skip
						if (m_arrOpExpenses.Count != 0)
							m_arrOpExpenses.Add(" ");
						//LINE 8347 = 95, 96, 97, 98, 104, 105, 106, 107, 131, 132, 133, 134, 140, 141, 142, 143
						m_arrOpExpenses.Add(rm.GetString("fqDoesMgmtAntUnusExp"));
					}
				}
			}

			if (dTOE == 0)
			{
				//if there are items currently in the array, then add a skip
				if (m_arrOpExpenses.Count != 0)
					m_arrOpExpenses.Add(" ");
				//LINE 1616 = 0
				m_arrOpExpenses.Add(rm.GetString("fqWhyOEZero"));
			}
			else if (dTOE < 0)
			{
				//if there are items currently in the array, then add a skip
				if (m_arrOpExpenses.Count != 0)
					m_arrOpExpenses.Add(" ");
				//LINE 1616 < 0
				m_arrOpExpenses.Add(rm.GetString("fqWhyOENeg"));
			}

			
		}
		private void OperatingProfitMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis OPM)
		{
			double dOP = Math.Round(RG.MACRO(M.NET_OPERATING_PROFIT)[PBaseId], 2);
			double dOPLag = Math.Round(RG.MACRO(M.NET_OPERATING_PROFIT, RG.LAG)[PBaseId], 2);
			double dOPM = Math.Round(RG.MACRO(M.OPERATING_PROFIT_MARGIN)[PBaseId], 2);
			double dOPMLag = Math.Round(RG.MACRO(M.OPERATING_PROFIT_MARGIN, RG.LAG)[PBaseId],2);
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
	
			if (dOP < 0)
				m_arrOpPftMgn.Add(string.Format(rm.GetString("fqOPDoesMgmtRestOP"), FC.RoundToReport(RG,dOP).ToString("N0"), sYear));

			if (dOP > 0 && dOPLag < 0)
				m_arrOpPftMgn.Add(string.Format(rm.GetString("fqOPTurnPos"), sYear));
			

			if (dOPM > 0)
			{
				if (dOPMLag > 0)
				{
					if ((OPM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (OPM.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
					{
						if (OPM.GrowthType == RatioAnalysis.eGrowthType.Positive)
							m_arrOpPftMgn.Add(string.Format(rm.GetString("fqOPMIncr"), dOPM, sYear));
						else if (OPM.GrowthType == RatioAnalysis.eGrowthType.Negative)
							m_arrOpPftMgn.Add(string.Format(rm.GetString("fqOPMDecr"), dOPM, sYear));
					}
				}
			}	
		}
		private void ARDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis ARD)
		{
			double dARD = Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId], 2);
			double dARDLag = Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[PBaseId], 2);
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string indent = "   ";

			if ((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
			{
				if (ARD.GrowthType == RatioAnalysis.eGrowthType.Positive)
				{
					m_arrARDays.Add(string.Format(rm.GetString("fqCauseARDInc"), dARD.ToString("N2")));
					m_arrARDays.Add(indent + rm.GetString("fqInadCollMgmt"));
					m_arrARDays.Add(indent + rm.GetString("fqLongTermPromSls"));
					m_arrARDays.Add(indent + rm.GetString("fqFinDeterMjCust"));
					m_arrARDays.Add(indent + rm.GetString("fqEconPressRegInd"));
					m_arrARDays.Add(rm.GetString("fqStepsMgmtRedARD"));

				}
				else if (ARD.GrowthType == RatioAnalysis.eGrowthType.Negative)
				{
					m_arrARDays.Add(string.Format(rm.GetString("fqARDShort"), dARD.ToString("N2"), sYear));
					m_arrARDays.Add(indent + rm.GetString("fqClosMonMgmt"));
					m_arrARDays.Add(indent + rm.GetString("fqTightCredApp"));
					m_arrARDays.Add(indent + rm.GetString("fqLargeDiscRapPay"));
					m_arrARDays.Add(indent + rm.GetString("fqImpFinCondMajBuy"));
					m_arrARDays.Add(indent + rm.GetString("fqIncrWriteOff"));
					m_arrARDays.Add(rm.GetString("fqCanMgmtLevOrLengt"));
				}
			}

			if (dARD > RG.PARM(223))
			{
				if (m_arrARDays.Count != 0)
					m_arrARDays.Add(" ");
				
				m_arrARDays.Add(rm.GetString("fqWhyARDSoHigh"));
				m_arrARDays.Add(indent + rm.GetString("fqNormBusInd"));
				m_arrARDays.Add(indent + rm.GetString("fqIfNtHowSpdAR"));
			}	
		}
		private void BadDebtReserve(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			double dBDR = Math.Round(RG.MACRO(M.QC_BAD_DEBT_RESERVE_TO_AR)[PBaseId], 2);
			double dBDRLag = Math.Round(RG.MACRO(M.QC_BAD_DEBT_RESERVE_TO_AR, RG.LAG)[PBaseId], 2);

			if (dBDR > RG.PARM(220)) 
			{
				if (dBDR > dBDRLag)
					m_arrBadDebtRes.Add(rm.GetString("fqWhyBDRHiIncr"));
				else 
					m_arrBadDebtRes.Add(rm.GetString("fqWhyBDRHi"));
			}
		}
		private void InventoryDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis ID)
		{
			double dINVD = Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId], 2);
			double dINVDLag = Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[PBaseId], 2);
			Calc cInv = RG.MACRO(M.TOTAL_INVENTORY) - (RG.TYPE(20) * RG.CONV_RATE());
			double dINV = cInv[PBaseId];
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";

			if (dINV > 0)
			{
				if ((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if (ID.GrowthType == RatioAnalysis.eGrowthType.Positive)
					{
						m_arrInvDays.Add(string.Format(rm.GetString("fqINVDIncrWhy"), dINVD.ToString("N2"), sYear, dINVDLag.ToString("N2"), sYearLag));
						m_arrInvDays.Add(indent + rm.GetString("fqConsMgmtDecFutDemd"));
						m_arrInvDays.Add(indent + rm.GetString("fqInadInvControl"));
						m_arrInvDays.Add(indent + rm.GetString("fqBulkPurchDisc"));
						m_arrInvDays.Add(indent + rm.GetString("fqReqHiLevProdMix"));
						m_arrInvDays.Add(indent + rm.GetString("fqObsoleteStock"));
						m_arrInvDays.Add(indent + rm.GetString("fqLowSalesRedDemd"));
						m_arrInvDays.Add(indent + rm.GetString("fqLowSalesProbClt"));
						m_arrInvDays.Add(indent + rm.GetString("fqSuppPresIncPurch"));
					}
					else
					{
						m_arrInvDays.Add(string.Format(rm.GetString("fqINVDDecrWhy"), dINVD.ToString("N2"), sYear, dINVDLag.ToString("N2"), sYearLag));
						m_arrInvDays.Add(indent + rm.GetString("fqClosMonInvMgmt"));
						m_arrInvDays.Add(indent + rm.GetString("fqWriteDownObsol"));
						m_arrInvDays.Add(indent + rm.GetString("fqHighExpSales"));
						m_arrInvDays.Add(indent + rm.GetString("fqInvDeplSuppUnShip"));
						m_arrInvDays.Add(indent + rm.GetString("fqSuppUnwillFinCon"));
						m_arrInvDays.Add(indent + rm.GetString("fqUnusInvExtraEvt"));
					}
				}
			}

			if (dINV >= (RG.MACRO(M.NET_SALES)[PBaseId] * 0.25))
			{
				if (m_arrInvDays.Count != 0)
					m_arrInvDays.Add(" ");

				m_arrInvDays.Add(rm.GetString("fqOnlyOneSuppl"));
			}
			
		}
		private void AccountsPayableDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis APD)
		{
			double dAPD = Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId], 2);
			double dAPDLag = Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[PBaseId], 2);
			//double dINVDLag = Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[PBaseId], 2);
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";
			
			///CPF 7/7/04 Log 817:  Only execute functions if APD > 0, else print nothing.
			if (dAPD > 0)
			{
				if (APD.GrowthType == RatioAnalysis.eGrowthType.Negative)
				{
					if ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
					{
						if (dAPD > RG.PARM(225))
						{
							///LINE 8379:  206, 208
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDDclStillHigh"), sYear, dAPD.ToString("N2")));
							m_arrAPDays.Add(indent + rm.GetString("fqCashSqueeze"));
							m_arrAPDays.Add(indent + rm.GetString("fqTightMgmtCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqSpecTermMajSupp"));
							m_arrAPDays.Add(indent + rm.GetString("fqExtTermCompSupp"));
							m_arrAPDays.Add(rm.GetString("fqHiLevIndMgmtProb"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
							m_arrAPDays.Add(rm.GetString("fqDelCrdDlyd"));
							m_arrAPDays.Add(rm.GetString("fqCertCredPrefTrtmt"));
						}
						else if (dAPD < RG.PARM(224))
						{
							///LINE 8379:  106, 108
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDDeclLow"), dAPD.ToString("N2"), sYear, dAPDLag.ToString("N2"), sYearLag));
							m_arrAPDays.Add(indent + rm.GetString("fqInadMgmtAttCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqPrmprPayCredRat"));
							m_arrAPDays.Add(indent + rm.GetString("fqSubsDiscEarPymt"));
							m_arrAPDays.Add(indent + rm.GetString("fqSuppPressEarPymt"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
							m_arrAPDays.Add(rm.GetString("fqDelCrdDlyd"));
						}
						else
						{
							///LINE 8379:  6, 8
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDDecWhyPySuppEarl"), dAPD.ToString("N2"), sYear, dAPDLag.ToString("N2"), sYearLag));
							m_arrAPDays.Add(indent + rm.GetString("fqInadMgmtAttCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqPrmprPayCredRat"));
							m_arrAPDays.Add(indent + rm.GetString("fqSubsDiscEarPymt"));
							m_arrAPDays.Add(indent + rm.GetString("fqSuppPressEarPymt"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
							m_arrAPDays.Add(rm.GetString("fqDelCrdDlyd"));
							m_arrAPDays.Add(rm.GetString("fqCertCredPrefTrtmt"));
						}
					}
					else
					{
						if (dAPD > RG.PARM(225))
						{
							///LINE 8379:  202, 204
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDDecHiLev"), sYear, dAPD.ToString("N2")));
							m_arrAPDays.Add(indent + rm.GetString("fqCashSqueeze"));
							m_arrAPDays.Add(indent + rm.GetString("fqTightMgmtCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqSpecTermMajSupp"));
							m_arrAPDays.Add(indent + rm.GetString("fqExtTermCompSupp"));
							m_arrAPDays.Add(rm.GetString("fqHiLevIndMgmtProb"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
						}
						else if (dAPD < RG.PARM(224))
						{
							///LINE 8379:  102, 104
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDWhyDeclLowLev"), dAPD.ToString("N2")));
							m_arrAPDays.Add(indent + rm.GetString("fqInadMgmtAttCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqPrmprPayCredRat"));
							m_arrAPDays.Add(indent + rm.GetString("fqSubsDiscEarPymt"));
							m_arrAPDays.Add(indent + rm.GetString("fqSuppPressEarPymt"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
						}
					}
				}
				else
				{
					if (dAPD > RG.PARM(225))
					{
						if ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
						{
							///LINE 8379:  205, 207
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDWhySlowPymtAPD"), dAPD.ToString("N2"), sYear, dAPDLag.ToString("N2"), sYearLag));
							m_arrAPDays.Add(indent + rm.GetString("fqCashSqueeze"));
							m_arrAPDays.Add(indent + rm.GetString("fqTightMgmtCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqSpecTermMajSupp"));
							m_arrAPDays.Add(indent + rm.GetString("fqExtTermCompSupp"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
						}
						else
						{
							///LINE 8379:  200, 201, 203
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDVeryHighLevel"), dAPD.ToString("N2")));
							m_arrAPDays.Add(indent + rm.GetString("fqCashSqueeze"));
							m_arrAPDays.Add(indent + rm.GetString("fqTightMgmtCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqSpecTermMajSupp"));
							m_arrAPDays.Add(indent + rm.GetString("fqExtTermCompSupp"));
							///CPF 6/17/04 Log 787:  This line was missing.  Added item to resouce file and added this line here to add string to the array.
							m_arrAPDays.Add(rm.GetString("fqAPDLevIndPmtMgmtPrb"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
						}
					}
					else if (dAPD < RG.PARM(224))
					{
						///LINE 8379:  100,101,103,105,107
						m_arrAPDays.Add(string.Format(rm.GetString("fqAPDLowLevShtTurn"), dAPD.ToString("N2"), sYear));
						m_arrAPDays.Add(indent + rm.GetString("fqInadMgmtAttCash"));
						m_arrAPDays.Add(indent + rm.GetString("fqPrmprPayCredRat"));
						m_arrAPDays.Add(indent + rm.GetString("fqSubsDiscEarPymt"));
						m_arrAPDays.Add(indent + rm.GetString("fqSuppPressEarPymt"));
						m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
					}
					else
					{
						if ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
						{
							///LINE 8379:  5, 7
							m_arrAPDays.Add(string.Format(rm.GetString("fqAPDWhySlowPymt"), dAPD.ToString("N2"), sYear, dAPDLag.ToString("N2"), sYearLag));
							m_arrAPDays.Add(indent + rm.GetString("fqCashSqueeze"));
							m_arrAPDays.Add(indent + rm.GetString("fqTightMgmtCash"));
							m_arrAPDays.Add(indent + rm.GetString("fqSpecTermMajSupp"));
							m_arrAPDays.Add(indent + rm.GetString("fqExtTermCompSupp"));
							m_arrAPDays.Add(rm.GetString("fqAPDRemHiPolPlc"));
						}
					}
				}
			}

		}
		private void CapExpend(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{

			double d3003 = (double.IsNaN(Math.Round(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId], 2);
			double d3006 = -1 * d3003;
			double d9003 = (double.IsNaN(Math.Round(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF, RG.LAG)[PBaseId], 2);
			double d9005 = Math.Abs(d3003);
			double d9006 = Math.Abs(d9003);
			double d9012 = RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId]/RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId];
			double d9007;
			double d9008;
			double d9011;
			double d9013;
			double d9031;
			double d9032;
			double d9033;
			double d9034;
			double d9035;
			double d9036;
			double d9037;
			
			//amit: 11/29/05  using Master Statement List Instead of POStatements
			Calc clcGwthPerCnt = new Calc(1, RG.Statements.Count);
			Calc clcStmts = RG.CALC_ACCUMULATE(clcGwthPerCnt, 1);

			Calc ChgNFA_CF = new Calc();

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			for (int i = 0; i <= RG.Statements.Count - 1; i++)
			{
				//Retrieve the stmt object for the passed stmt
				Statement s = (Statement)RG.Statements[i];
				//If ReconcileID = -1, then Reconcile = NONE and we should OMIT
				if ((RG.GetAuthorSetting(FORMATCOMMANDS.OMIT) == "First") && (s.GetReconcileID(RG.Context) == -1))
					ChgNFA_CF.Add(0);
				else
					ChgNFA_CF.Add(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[i]);
			}

			//Calc cAvgCapx = RG.CALC_ACCUMULATE(-1 * RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF),1) / (clcStmts - 1);
			Calc cAvgCapx = RG.CALC_ACCUMULATE((-1 * ChgNFA_CF),1) / (clcStmts[PBaseId] - 1);
			double dAvgCapx = cAvgCapx[PBaseId]; /*RG.CALC_ACCUMULATE(-1 * RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF),1)[PBaseId] / (clcStmts[PBaseId] - 1);*/

			//if (d9005 < (RG.MACRO(M.NET_SALES)[PBaseId]/RG.STMT_PERIODS()[PBaseId] * 0.05)) d9007 = 1; else d9007 = 2;
			if (d9005 < (RG.MACRO(M.NET_SALES)[PBaseId]/ RG.YEAR()[PBaseId] * 0.05)) d9007 = 1; else d9007 = 2;
			//d9008 = if ABS(CapX pp) >= Net Sales pp / Months pp * .05 then 1 else 0
			//if (d9006 >= (RG.MACRO(M.NET_SALES, RG.LAG)[PBaseId] / RG.STMT_PERIODS(RG.LAG)[PBaseId] * 0.05)) d9008 = 1; else d9008 = 0;
			if (d9006 >= (RG.MACRO(M.NET_SALES, RG.LAG)[PBaseId] / RG.YEAR(RG.LAG)[PBaseId] * 0.05)) d9008 = 1; else d9008 = 0;
			//d9011 = if CapX pp < 0 d9007 + d9008 else 0
			if (d9003 < 0) d9011 = d9007 + d9008; else d9011 = 0;
			if (RG.IND(59) > 0) d9013 = 3; else d9013 = 0;
			if (RG.IND(59) <= d9012) d9031 = 3; else d9031 = 0;
			if (RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId] > 0) d9032 = 3; else d9032 = 0;
			if (RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] > 0) d9033 = 2; else d9033 = 0;
			///CPF 6/9/04 Log 767:  Removed the LAG from NET_SALES.
			if (RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] < (RG.MACRO(M.NET_SALES)[PBaseId] / RG.YEAR(RG.LAG)[PBaseId] * 0.1)) d9034 = 2; else d9034 = 0;

			double d9021 = dAvgCapx * -1 * (1 + RG.PARM(1)/100);
			double d9022 = dAvgCapx * -1 * (1 - RG.PARM(2)/100);

			double d9023;
			double d9024;
			double d9014;
			double d9015;
			double d9016;
			double d9017;
			double d9018;
			double d9019;
			double d9010;
			double d9030;
			double d9009;
			double d9020;

			if (d3003 > d9021) d9023 = 1; else d9023 = 0;
			if (d3003 < d9022) d9024 = 1; else d9024 = 0;

			if (dAvgCapx > 0) d9020 = 1; else d9020 = -9999;
			if (RG.MACRO(M.CASH_PAID_PLANT_INVEST)[PBaseId] > 0) d9018 = 1; else d9018 = 2;
			if (d9003 >= 0) d9016 = 1;else d9016 = 2;

			if (d3003 < 0) d9009 = 1; else d9009 = 0;
			if (d3003 > 0) d9014 = 2; else d9014 = 0;
			d9015 = d9009 + d9014;

			if (d9015 == 0) d9017 = d9016; else d9017 = 0;
			if (d9015 == 1) d9010 = d9007; else d9010 = 0;
			if (d9015 == 2) d9019 = d9018; else d9019 = 0;

			if (d9007 == 2) d9030 = d9020 + d9023; else d9030 = 0;

			if (d9007 == 1) d9035 = d9020 + d9024; else d9035 = 0;
			if (d9007 == 1) d9036 = d9013 + d9031 + d9032; else d9036 = 0;
			if (d9007 == 1) d9037 = d9033 + d9034; else d9037 = 0;

			double d9038;
			double d9039;
			double d9040;

			if (d9035 == 2) d9038 = 1; else d9038 = 0;
			if (d9036 == 9) d9039 = 2; else d9039 = 0;
			if (d9037 == 4) d9040 = 4; else d9040 = 0;

			double d9041 = d9038 + d9039 + d9040;
			
			double d9480;
			double d9481;

			if (RG.TYPE(39)[PBaseId] > (RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] * 0.5)) d9480 = 2; else d9480 = 0;
			if (RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] > (RG.MACRO(M.TOTAL_ASSETS)[PBaseId] * 0.4)) d9481 = 2; else d9481 = 0;

			double d9482 = d9480 + d9481 + d9033;

			double d9483;
			double d9484;
			double d9485;

			if (RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] > (RG.MACRO(M.NET_FIXED_ASSETS, RG.LAG)[PBaseId] * (1 + (RG.PARM(2)/100)))) d9483 = 1; else d9483 = 0;
			if (RG.MACRO(M.CHG_IN_INTANGIBLES)[PBaseId] < 0) d9484 = 1;else d9484 = 0;
			if (RG.MACRO(M.INTANG_NET)[PBaseId] > (RG.MACRO(M.INTANG_NET, RG.LAG)[PBaseId] * (1 + (RG.PARM(2)/100)))) d9485 = 1; else d9485 = 0;

			double d9486 = d9009 + d9483 + d9484 + d9485;

			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";
	
			if (d9041 == 1)
			{
				m_arrCapExpend.Add(rm.GetString("fqCEHowLongCurRt"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 2)
			{
				m_arrCapExpend.Add(rm.GetString("fqCECpyPfmPos"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 3)
			{
				m_arrCapExpend.Add(rm.GetString("fqCEHowLongCurRt"));
				m_arrCapExpend.Add(rm.GetString("fqCECpyPfmPos"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 4)
			{
				m_arrCapExpend.Add(rm.GetString("fqCECpyPftmPosNFALow"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 5)
			{
				m_arrCapExpend.Add(rm.GetString("fqCEHowLongCurRt"));
				m_arrCapExpend.Add(rm.GetString("fqCECpyPftmPosNFALow"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 6)
			{
				m_arrCapExpend.Add(rm.GetString("fqCECpyPfmPos"));
				m_arrCapExpend.Add(rm.GetString("fqCECpyPftmPosNFALow"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}
			else if (d9041 == 7)
			{
				m_arrCapExpend.Add(rm.GetString("fqCEHowLongCurRt"));
				m_arrCapExpend.Add(rm.GetString("fqCECpyPfmPos"));
				m_arrCapExpend.Add(rm.GetString("fqCECpyPftmPosNFALow"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEPlnIncSpdRt"));
			}

			if (d9017 == 1)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(string.Format(rm.GetString("fqCECpyReqCE"), sYear));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCEMgmtPlnsFutCP"));
			}
			else if (d9017 == 2)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(string.Format(rm.GetString("fqCECpyReqCE"), sYear));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEAreLandBldAdq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEPltGdOrd"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(rm.GetString("fqCERecExpMtNeed"));

			}

			if (d9019 == 1)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(rm.GetString("fqCEHowLongB4Acq"));
				m_arrCapExpend.Add(indent + string.Format(rm.GetString("fqCESaleCapAstInv"), FC.RoundToReport(RG, RG.MACRO(M.CASH_PAID_PLANT_INVEST)[PBaseId]), sYear));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoExstLndOK"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoFxdAstExcReq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEFurthCapSlsAnt"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));

			}
			else if (d9019 == 2)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(rm.GetString("fqCEHowLongB4Acq"));
				m_arrCapExpend.Add(indent + string.Format(rm.GetString("fqCESaleFxdAst"), FC.RoundToReport(RG,d3003), sYear));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoExstLndOK"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoFxdAstExcReq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEFurthCapSlsAnt"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELsdPrmEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));

			}

			if (d9011 == 2)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(rm.GetString("fqCEDoesCpyHiCE"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEEvSoLseEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoesMgmtHiSpend"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEIfSoFurtInv"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEIfNotSlsLev"));
			}
			
			if (d9030 == 2)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(string.Format(rm.GetString("fqCECpyHiCapEx"), sYear));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEEvSoLseEq"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCELseCancel"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEDoesMgmtHiSpend"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEIfSoFurtInv"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCEIfNotSlsLev"));

			}

			if (d9482 == 6)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(rm.GetString("fqCELandInvest"));
			}
			
			if (d9486 == 4)
			{
				if (m_arrCapExpend.Count != 0)
					m_arrCapExpend.Add(" ");

				m_arrCapExpend.Add(rm.GetString("fqCEBSNewOpAst"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCENewBusAbs"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCESomeAstResld"));
				m_arrCapExpend.Add(indent + rm.GetString("fqCECanSavProdMkt"));
			}
		}
		private void CurrentRatio(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			double dCR = (double.IsNaN(Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2);
			dCR = (double.IsPositiveInfinity(Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2);
			///double dCR = Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId],2);
			double dCRLag = (double.IsNaN(Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2);
			dCRLag = (double.IsPositiveInfinity(Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2);
			///double dCRLag = Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId],2);
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";
	
			///CPF 6/9/04 Log 765: Changed last compare from dCR < 0 to dCR < 1 to match MFA
			if (((dCR - dCRLag) < 0) && (dCR < 1) && (dCRLag >= 1))
			{
				///LINE 8072:  5
				m_arrCurRatio.Add(string.Format(rm.GetString("fqCRDecl"), dCR));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRSTFndLTAst"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRCurAstBlowDebtLev"));
			}

			///CPF 6/9/04 Log 765: Changed both compares from  < 0 to < 1 to match MFA
			if ((dCR < 1) && (dCRLag < 1))
			{
				///LINE 8072:  9,10,11
				m_arrCurRatio.Add(rm.GetString("fqCRBel1For2Per"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRNormCond"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRIfNotWhatCause"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRSTLbFndLTAst"));
			}

			///CPF 6/9/04 Log 765: Changed last compare from dCRLag < 0 to dCRLag < 1 to match MFA
			if (((dCR - dCRLag) > 0) && (dCR >= 1) && (dCRLag < 1))
			{
				///LINE 8072:  7
				m_arrCurRatio.Add(rm.GetString("fqCRAbv1"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRWhtCseIncr"));
				m_arrCurRatio.Add(indent + rm.GetString("fqCRLiqBeMtnd"));
			}

		}
		private void Miscellaneous(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			double dDebt = RG.MACRO(M.FQ_DEBT)[PBaseId];
			double dCFIE = RG.MACRO(M.FQ_CASH_FLOW_INT_EXP)[PBaseId];
			double dIE = RG.MACRO(M.TOT_INT_EXP)[PBaseId];
			double dCPLTD = RG.MACRO(M.CPLTD_FROM_UCA_CASH_FLOW)[PBaseId];
			double dNetIntang = RG.MACRO(M.INTANG_NET)[PBaseId];
			double dNetIntangLag = RG.MACRO(M.INTANG_NET, RG.LAG)[PBaseId];
			double dCS = RG.MACRO(M.FQ_COMMON_STOCK)[PBaseId];
			double dCSLag = RG.MACRO(M.FQ_COMMON_STOCK, RG.LAG)[PBaseId];
			double dSD = RG.MACRO(M.FQ_SUB_DEBT)[PBaseId];
			///CPF 6/22/04 Log 791, added RG.LAG to calc
			double dSDLag = RG.MACRO(M.FQ_SUB_DEBT, RG.LAG)[PBaseId];
			double dUARE = RG.MACRO(M.UNEXPL_ADJ_RE)[PBaseId];
			double dSR = RG.MACRO(M.FQ_SENIOR_LIABS)[PBaseId];

			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";
	
			if ((dDebt > 0) && (dCFIE >= 0) && (dIE == 0))
			{
				///LINE 8454:  5
				m_arrMisc.Add(rm.GetString("fqMSDbtNoInt"));
			}

			if ((dCPLTD < 0) && (dCFIE >= 0))
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				///LINE 8456:  2
				m_arrMisc.Add(rm.GetString("fqMSPymtNoInt"));
			}

			if ((dNetIntang < dNetIntangLag) && (RG.TYPE(162)[PBaseId] == 0))
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				///LINE 8459:  2
				m_arrMisc.Add(rm.GetString("fqMSAmtNotItem"));
			}

			if ((RG.MACRO(M.NET_FIXED_ASSETS)[PBaseId] != RG.MACRO(M.NET_FIXED_ASSETS, RG.LAG)[PBaseId]) && (RG.MACRO(M.FQ_DEPR_EXPENSE)[PBaseId] == 0))
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				///LINE 8463:  2
				m_arrMisc.Add(string.Format(rm.GetString("fqMSFxdAstNoDepr"), sYear));
			}

			///CPF 5/19/04  SOME NOTES ON THIS SECTION.  THE RESULTS YOU GET FOR MFA
			///AND EMFA WILL VARY AS THERE IS A BUG IN MFA.  KRISTIN HAS LOGGED THE DIFFERENCE IN
			///THE MFA PROJECT.  BASICALLY, BEGINNING RETAINED EARNINGS RESTATED DOES NOT INCLUDE
			///ADJ TO RETAINED EARNINGS.  AND SINCE THIS NUMBER WILL AFFECT UARE, THESE VALUES ARE
			///DIFFERING FOR EMFA, BUT IT IS CORRECT.
			if ((dCS > 0) && (dCS > dCSLag) && (dUARE == 0) && (dSD > (dSDLag * .6)) && (dCS <= (dCSLag * 1.2)))
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				//LINE 8478:  5
				m_arrMisc.Add(rm.GetString("fqMSCapStkIncr"));
				m_arrMisc.Add(indent + rm.GetString("fqMSMgmtPlnRsEq"));
				m_arrMisc.Add(indent + rm.GetString("fqMSConvSubDbt"));
				m_arrMisc.Add(indent + rm.GetString("fqMSKeyAchvStratGl"));
				m_arrMisc.Add(indent + rm.GetString("fqMSNotChgMgmt"));
				m_arrMisc.Add(indent + rm.GetString("fqMSMgmtAuthChg"));
			}

			if ((dSD > (dSR * .1)) && (dSD > (dSDLag * 1.5)) && (dCS < (dCSLag * .6))) 
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				///LINE 8484:  3
				m_arrMisc.Add(rm.GetString("fqMSCorpRestruct"));
				m_arrMisc.Add(indent + rm.GetString("fqMSRepAchvGls"));
				m_arrMisc.Add(indent + rm.GetString("fqMSChgOccMgmt"));
				m_arrMisc.Add(indent + rm.GetString("fqMSChgMarkStrat"));
			}

			///CPF 5/19/04  SOME NOTES ON THIS SECTION.  THE RESULTS YOU GET FOR MFA
			///AND EMFA WILL VARY AS THERE IS A BUG IN MFA.  KRISTIN HAS LOGGED THE DIFFERENCE IN
			///THE MFA PROJECT.  BASICALLY, BEGINNING RETAINED EARNINGS RESTATED DOES NOT INCLUDE
			///ADJ TO RETAINED EARNINGS.  AND SINCE THIS NUMBER WILL AFFECT UARE, THESE VALUES ARE
			///DIFFERING FOR EMFA, BUT IT IS CORRECT.
			if (Math.Abs(dUARE) > 5)
			{
				if (m_arrMisc.Count != 0)
					m_arrMisc.Add(" ");

				///LINE 8485:  5
				m_arrMisc.Add(string.Format(rm.GetString("fqMSAdjRE"), FC.RoundToReport(RG,dUARE).ToString("N0")));
				m_arrMisc.Add(indent + rm.GetString("fqMSStmtNtsRead"));
				m_arrMisc.Add(indent + rm.GetString("fqMSMgmtPrvDetail"));
			}

		}
		private void Leverage(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis DTNW)
		{
			double dDTNW = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId],2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId],2);
			double dDTNWLag = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId],2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId],2);
			double dTNW = RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId];
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			string indent = "   ";
		
			double d2183 = (dDTNW <= 0) ? -54 : 0;   /*SEE IF DTNW IS < 0*/
			double d2546 = (dDTNW >= RG.IND(61)) ? 9 : 0;
			double d2547 = (dDTNW >= RG.IND(62)) ? 9 : 0;
			double d2548 = (dDTNW >= RG.IND(63)) ? 9 : 0;
			double d2551 = (RG.IND(63) > 900) ? 27 : 0;
			double d2550 = d2546 + d2548 + d2547 + d2183 + d2551;
			double d999 = (RG.PEER_TYPE() == ePeerType.RMA) ? 1 : 0;
			double d998 = (RG.PEER_TYPE() == ePeerType.Default) ? 1 : 0;

			double d8430 = (d2550 == 0) ? (1 * (d999 + d998)) : 0;
			double d8433 = (d2550 == 9) ? (2 * (d999 + d998)) : 0;
			double d8434 = (d2550 == 18) ? (3 * (d999 + d998)) : 0;
			double d8431 = (d2550 == 27) ? (4 * (d999 + d998)) : 0;
			double d8435 = (d2550 == 28) ? (5 * (d999 + d998)) : 0;

			double d8075 = (dDTNW < RG.PARM(221)) ? 9 : 0;
			double d8076 = (dDTNW > RG.PARM(222)) ? 108 : 0;

			double d8432 = d2183 + d8430 + d8433 + d8434 + d8431 + d8435 + d8075 + d8076;

			///PART 1 of 3
			if (dDTNW - dDTNWLag > 0)
			{
				if ((DTNW.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (DTNW.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if ((dDTNW > 0) && (dDTNWLag > 0))
						///LINE 2199:  5,7
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERCauseIncr"), sYear));
					else if ((dDTNW > 0) && (dDTNWLag <= 0))
						///LINE 2199:  23,25
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERCauseIncrNegPP"), sYear));
				}
			}

			if (dDTNW - dDTNWLag < 0)
			{
				if ((DTNW.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (DTNW.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))
				{
					if ((dDTNW > 0) && (dDTNWLag > 0))
						///LINE 2199:  6,8
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERCauseDecl"), sYear));					
				}
			}

			///PART 2 of 3
			if ((d8432 == 112) || (d8432 == 113))
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERHiUnfav"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtAwareHi"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtConcHiLev"));
			}
			else if (d8432 == 111)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERHiWorAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtAwareHi"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtConcHiLev"));
			}
			else if ((d8432 == 109) || (d8432 == 110))
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERHiLowAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtAwareHi"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtConcHiLev"));
			}
			else if (d8432 == 108)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERHigh"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERTypInd"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtAwareHi"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtConcHiLev"));
			}
			else if ((d8432 == 4) || (d8432 == 5))
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERSigHighAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtRsEqLev"));
			}
			else if (d8432 == 10)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERLowSigLowAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtIncDTNW"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERCpySupCstHiLev"));
			}
			else if (d8432 == 11)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERLowLowAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtIncDTNW"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERCpySupCstHiLev"));
			}
			else if ((d8432 == 12) || (d8432 == 13) || (d8432 == 14))
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERLowHiAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtIncDTNW"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERCpySupCstHiLev"));

			}
			else if (d8432 == 9)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERLow"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERTypInd"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtIncDTNW"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERCpySupCstHiLev"));
			}
			else if (d8432 == 1)
			{
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVERLowIndAvg"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtIncDTNW"));
				m_arrLeverage.Add(indent + rm.GetString("fqLEVERCpySupCstHiLev"));
			}

			///PART 3 of 3
			//If DTNW < Parm 221 and DTNW >0 and DTNW pp > 0 and Profit Before Extraordinary Items > 0 and Profit Before Extraordinary Items pp > 0
			if ((dDTNW < RG.PARM(221)) && (dDTNW > 0) && (dDTNWLag > 0) && (RG.MACRO(M.PROFIT_BEFORE_EXTRAORDINARY_ITEMS)[PBaseId] > 0) && (RG.MACRO(M.PROFIT_BEFORE_EXTRAORDINARY_ITEMS, RG.LAG)[PBaseId] > 0))
			{
				//LINE 8438:  11
				if (m_arrLeverage.Count != 0)
					m_arrLeverage.Add(" ");

				m_arrLeverage.Add(rm.GetString("fqLEVEROppMoreDebt"));
			}

			if (dDTNW <= 0)
			{
				if (dDTNWLag > 0)
				{
					if (RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId] <= 0)
					{
						if (m_arrLeverage.Count != 0)
							m_arrLeverage.Add(" ");

						///LINE 8439:  -54
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERNotDefTNWNeg"), sYear));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERIntgRealVal"));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERMgmtPlnRestVal"));
					}
					else if (RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId] > 0)
					{
						if (m_arrLeverage.Count != 0)
							m_arrLeverage.Add(" ");

						///LINE 8439:  -53
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERZeroNoLiab"), sYear));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERCorrect"));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERSvcDbtAnothPty"));
					}
				}
				else if (dDTNWLag <= 0)
				{
					if (RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId] <= 0)
					{
						if (m_arrLeverage.Count != 0)
							m_arrLeverage.Add(" ");

						///LINE 8439:  -36
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERNotDef2Yr"), sYear, sYearLag, sYear));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERIntgRealVal"));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERCanBusContToOp"));
					}
					else if (RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId] > 0)
					{
						if (m_arrLeverage.Count != 0)
							m_arrLeverage.Add(" ");

						///LINE 8439:  -35
						m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERZeroNoLiab"), sYear));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERCorrect"));
						m_arrLeverage.Add(indent + rm.GetString("fqLEVERSvcDbtAnothPty"));
					}
				}
			}
			else if (dDTNW > 0)
			{
				///CPF 6/21/04 Log 789:  Added the extra portion (dTNW <=0) as it was missing from the case
				///and design.
				if ((dDTNWLag <= 0) && (dTNW <= 0))
				{
					if (m_arrLeverage.Count != 0)
						m_arrLeverage.Add(" ");

					///LINE 8439:  18
					m_arrLeverage.Add(string.Format(rm.GetString("fqLEVERImprvPP"), dDTNW));
				}
			}
			

		}
		private void TradeAccounts(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis ID, RatioAnalysis APD, RatioAnalysis ARD)
		{
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string sYearLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			double dID = (double.IsNaN(Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId], 2);
			double dARD = (double.IsNaN(Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId], 2);
			double dAPD = (double.IsNaN(Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId], 2);
			string indent = "   ";

			if (((ID.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((ARD.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((APD.GrowthType == RatioAnalysis.eGrowthType.Negative)&& ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant)))) 
			{
				//LINE 8411:  42
				m_arrTrdAccts.Add(string.Format(rm.GetString("fqARAPINVAllAbsorb"), sYear));
				m_arrTrdAccts.Add(indent + rm.GetString("fqCanCashPosSuppChg"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqAreMontSysInPlc"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqIfNotArePlans"));
			}
			else if (((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)) && 
				((ARD.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((APD.GrowthType == RatioAnalysis.eGrowthType.Negative)&& ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant)))) 
			{
				//LINE 8411:  41
				m_arrTrdAccts.Add(rm.GetString("fqARAPAbsorb"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqCanCashPosSuppChg"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqAreMontSysInPlc"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqIfNotArePlans"));
			}
			else if (((ID.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((ARD.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))) 
			{
				//LINE 8411:  26
				m_arrTrdAccts.Add(rm.GetString("fqINVARAbsorb"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqCanCashPosSuppChg"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqAreMontSysInPlc"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqIfNotArePlans"));
			}
			else if (((ID.GrowthType == RatioAnalysis.eGrowthType.Positive)&& ((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))) && 
				((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)) && 
				((APD.GrowthType == RatioAnalysis.eGrowthType.Negative)&& ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.VerySignificant))))
			{
				//LINE 8411:  38
				m_arrTrdAccts.Add(rm.GetString("fqINVAPAbsorb"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqCanCashPosSuppChg"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqAreMontSysInPlc"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqIfNotArePlans"));
			}
			else if (((dID > 0) && ((ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (ID.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))) && 
				((dARD > 0) && ((ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (ARD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate))) && 
				((dAPD > 0) && ((APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little) || (APD.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)))) 
			{
				//LINE 8411:  21
				m_arrTrdAccts.Add(rm.GetString("fqARAPINVConsist"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqExpCont"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqIfNoWhatContFact"));
				m_arrTrdAccts.Add(indent + rm.GetString("fqPlansOffset"));
			}
		}
		private void NetProfitMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis NPM)
		{
			double dNP = Math.Round(RG.MACRO(M.NET_PROFIT)[PBaseId], 2);
			double dNPLag = Math.Round(RG.MACRO(M.NET_PROFIT, RG.LAG)[PBaseId], 2);
			double dNPM = Math.Round(RG.MACRO(M.PROFIT_MARGIN)[PBaseId], 2);
			double dNPMLag = Math.Round(RG.MACRO(M.PROFIT_MARGIN, RG.LAG)[PBaseId],2);
			double dNPMLag2 = Math.Round(RG.MACRO(M.PROFIT_MARGIN, RG.LAG,2)[PBaseId],2);
			string sYear = RG.STMT_YEAR()[PBaseId].ToString();
			string indent = "   ";
	
			if (dNP > 0)
			{
				if (dNPLag > 0)
				{
					if (NPM.GrowthType == RatioAnalysis.eGrowthType.Negative)
					{
						m_arrNetPftMgn.Add(string.Format(rm.GetString("fqKeyFactDclnNPM"), sYear));
						m_arrNetPftMgn.Add(indent + rm.GetString("fqIncrNonOpCst"));
						m_arrNetPftMgn.Add(indent + rm.GetString("fqLossRelBusInv"));
						m_arrNetPftMgn.Add(rm.GetString("fqPlnsMgmtHaltDcln"));
					}
				}
				else
					m_arrNetPftMgn.Add(string.Format(rm.GetString("fqNPMTurnPos"), sYear));
			}
			///CPF 6/16/04 Log 784:  Made check <= zero instead of < zero.
			else if (dNP <= 0)
				m_arrNetPftMgn.Add(string.Format(rm.GetString("fqNPMNeg"), FC.RoundToReport(RG,dNP).ToString("N0")));


			if (dNPMLag2 > 0)
			{
				if (dNPM > dNPMLag)
				{
					if (dNPMLag > dNPMLag2)
						m_arrNetPftMgn.Add(rm.GetString("fqNPMImp2yr"));
				}
			}
		}
	}
}



