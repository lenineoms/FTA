using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class NOTES_FIN_STMTS:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.NotesFSCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the Outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//amit: Start of the 1st inner grouping "Exchage Rate"
			Utility.mT.AddStartRow(Utility.nRow + 1);

            Utility.PrintCenter(RG, rm.GetString("nfsStats"));
			Utility.UnderlinePage(RG, 1);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ProjStat"));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("HistStat"));

			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "False");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("SICCode"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("PerCashSales"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("AdjToIntang"));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "5");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsExchgRt"), RG.GetPrintOrderCalc(RG.CONV_RATE_BS()));
			//Utility.PrintDetail(RG, RG.GetDetailCalcs("ConvRate"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "");

			//amit: End of the 1st group "Moody's Rating"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 2nd group "ASSET FOOTNOTES"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.UnderlinePage(RG, 1);
			Utility.PrintCenter(RG, rm.GetString("nfsFoots"));
			Utility.UnderlinePage(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");



			Utility.PrintLabel(RG, rm.GetString("nfsAstFtnts"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("AstFootNotes1"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("AstFootNotes2"));

			Utility.Skip(RG, 1);

			//amit: End of the 2nd group "Footnote - Non-Cur"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);

			//amit: Start of the 3rd group "LIABILITY AND"
			Utility.mT.AddStartRow(Utility.nRow + 1);
           
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, rm.GetString("nfsLiabEqFtnts"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("LIABEQNotes1"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LIABEQNotes2"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LIABEQNotes3"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LIABEQNotes4"));

			Utility.Skip(RG, 1);

			//amit: End of the 3rd group "Moody's Ratine"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);

			//amit: Start of the 4th group "ASSET FOOTNOTES"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, rm.GetString("nfsISFtnts"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ISFootNotes"));

			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintLabel(RG, rm.GetString("nfsStatFtnts"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("StatFootNotes"));

			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");

			Utility.UnderlinePage(RG, 2);

			float[] fFooterWidths  = new float[]{2.5f, 1.5f};
			Utility.OpenTableFooter(RG, 2, fFooterWidths);
			
			///Print "Accouting for Revenue"
			Utility.PrintModelConst(RG, 6, true);

			///Print "Inventory Accounting Method"
			Utility.PrintGlobConst(RG, 7, true);

			///Print "Depreciation Method"
			Utility.PrintGlobConst(RG, 8, true);

			///Print "Industry Type"
			//Utility.PrintModelConst(RG, 9, true);
			var indType = RG.Customer?.Entity?.IndClassification;
			Utility.printFooters(RG, rm.GetString("industryType"), indType, true);

			///Print "Entity Type"
			///AMP Change according to Tracker #544 03/10/04
			///from Utility.PrintGlobConst
			//Utility.PrintModelConst(RG, 10, true);
			var entityType = RG.Customer?.Entity?.EntityType;
			Utility.printFooters(RG, rm.GetString("entityType"), entityType, true);
			
			///Print "Segment Type"
			///AMP Change according to Tracker #544 03/10/04
			///from Utility.PrintGlobConst
			Utility.PrintModelConst(RG, 11, true);

			///Print "Responsible Office"
			Utility.PrintGlobConst(RG, 12, true);

			///Print "Responsible Officer"
			Utility.PrintGlobConst(RG, 13, true);

			///Print "Tax Id"
			//Utility.PrintGlobConst(RG, 14, true);
			var taxId = RG.Customer?.Entity?.TaxId;
			Utility.printFooters(RG, rm.GetString("taxId"), taxId, true);

			///Print "LAS ID #"
			Utility.PrintGlobConst(RG, 16, true);

			///Print "D & B #"
			Utility.PrintGlobConst(RG, 17, true);

			///Print "Other ID"
			Utility.PrintGlobConst(RG, 18, true);

			///Print "Relationship Type"
			Utility.PrintGlobConst(RG, 19, true);

			///Print "Moody's Rating"
			Utility.PrintGlobConst(RG, 20, true);
//			Constant c = CustomerManager.ModelManager.GlobalConstants["1"] as Constant;
//			string label = (c != null) ? c.Label : "";
//			ValueData vd = RG.Context.GlobalConstants["1"] as ValueData;
//			string data = (vd != null) ? vd.Value : "0";

			//amit: End of the 4th group "Moody's Ratine"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow -1);

			Utility.CloseReport(RG);
		}
	}
}
