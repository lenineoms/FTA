using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class BS_ASSUMPTIONS:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BS_Assumption_Calcs(RG);

			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,3);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start of the 1st group "Current Assets"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (RG.CLASS(5).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("bsaCurAsts"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1050)"));

			if (RG.GetDetailCalcs("ACCT(1050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 1st group "Current Assets"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 2nd group "Time Deposits"
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1100)"));

			if (RG.GetDetailCalcs("ACCT(1100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");	
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 2nd group "Time Depostits"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 3rd group "Marketable S"
			Utility.mT.AddStartRow(Utility.nRow + 1);
						
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1150)"));

			if (RG.GetDetailCalcs("ACCT(1150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);
			
			//amit: End of 3rd group "Marketable S"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 4th group "Accts/Notes"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1200)"));

			if (RG.GetDetailCalcs("ACCT(1200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1200)")));
			Utility.PrintSummary(RG, rm.GetString("bsaDOHGrsRCV"), RG.GetPrintOrderCalc(RG.GetCalc("DOHGrsRec(1200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	


			if (RG.GetDetailCalcs("ACCT(1200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			
			//amit: End of 4th group "Accts/Notes"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 5th group "Loans to"
			Utility.mT.AddStartRow(Utility.nRow + 1); 


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1230)"));

			if (RG.GetDetailCalcs("ACCT(1230)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	


			if (RG.GetDetailCalcs("ACCT(1230)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);


			//amit: End of 5th group "Loans to"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 6th group "Due from"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//amit: 12/06/05 tracker log# 1497

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1240)"));

			if (RG.GetDetailCalcs("ACCT(1240)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1240)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1240)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1240)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			
			if (RG.GetDetailCalcs("ACCT(1240)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			Utility.mT.AddEndRow(Utility.nRow);
			Utility.mT.AddStartRow(Utility.nRow + 1);
			

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1250)"));

			if (RG.GetDetailCalcs("ACCT(1250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	


			if (RG.GetDetailCalcs("ACCT(1250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 6 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 7 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1300)"));

			if (RG.GetDetailCalcs("ACCT(1300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	



			if (RG.GetDetailCalcs("ACCT(1300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 7 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of 8 the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1670)"));

			if (RG.GetDetailCalcs("ACCT(1670)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	


			if (RG.GetDetailCalcs("ACCT(1670)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);


			//amit: End of  8 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 9 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1680)"));

			if (RG.GetDetailCalcs("ACCT(1680)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1680)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 9 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 10 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1400)"));

			if (RG.GetDetailCalcs("ACCT(1400)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1400)")));
			//amit: 09/10/05 removed hard coded string Days on Hand
			Utility.PrintSummary(RG, rm.GetString("bsaDaysOnHand"), RG.GetPrintOrderCalc(RG.GetCalc("DayOnHand(1400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1400)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 10  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 11 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1450)"));

			if (RG.GetDetailCalcs("ACCT(1450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1450)")));
			//amit:09/10/05 Removed hard coded string Days On Hand
			Utility.PrintSummary(RG, rm.GetString("bsaDaysOnHand"), RG.GetPrintOrderCalc(RG.GetCalc("DayOnHand(1450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 11 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 12 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1500)"));

			if (RG.GetDetailCalcs("ACCT(1500)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1500)")));
			Utility.PrintSummary(RG, rm.GetString("bsaDaysOnHand"), RG.GetPrintOrderCalc(RG.GetCalc("DayOnHand(1500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1500)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 12 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 13 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1550)"));

			if (RG.GetDetailCalcs("ACCT(1550)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1550)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 13 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 14 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1600)"));

			if (RG.GetDetailCalcs("ACCT(1600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 14 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 15 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1650)"));

			if (RG.GetDetailCalcs("ACCT(1650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 15 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 16 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1350)"));

			if (RG.GetDetailCalcs("ACCT(1350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 16 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 17 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1700)"));

			if (RG.GetDetailCalcs("ACCT(1700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 17 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 18 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1750)"));

			if (RG.GetDetailCalcs("ACCT(1750)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1750)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 18 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 19 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

// KCZ Added Code for account 1790 to update model to Version V 6-11-03
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1790)"));

			if (RG.GetDetailCalcs("ACCT(1790)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1790)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1790)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of 19 group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the 20 group 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
// KCZ End of added code



			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1800)"));

			if (RG.GetDetailCalcs("ACCT(1800)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(1800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(1800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(1800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(1800)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);



			if (RG.CLASS(5).NonZero)
			{
				Utility.UnderlinePage(RG, 1);
				Utility.Skip(RG, 1);
				///added until we can break correctly
				///amit: blocked 03/23/04
				//Utility.PageBreak(RG);
			}
			
    		Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			
			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (RG.CLASS(10).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("bsaNonCurAsts"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}
			
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2050)"));

			if (RG.GetDetailCalcs("ACCT(2050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2070)"));

			if (RG.GetDetailCalcs("ACCT(2070)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2070)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2100)"));

			if (RG.GetDetailCalcs("ACCT(2100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2150)"));

			if (RG.GetDetailCalcs("ACCT(2150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2200)"));

			if (RG.GetDetailCalcs("ACCT(2200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2250)"));

			if (RG.GetDetailCalcs("ACCT(2250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2300)"));

			if (RG.GetDetailCalcs("ACCT(2300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2350)"));

			if (RG.GetDetailCalcs("ACCT(2350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			//amit: changed to 1 from 2,blocked don't need it here 
			//RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "1");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
            //amit: Start of the  group 
            Utility.mT.AddStartRow(Utility.nRow + 1);

            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

            Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2360)"));

            if (RG.GetDetailCalcs("ACCT(2360)").GetTotals(RG).NonZero)
                RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            //amit: changed to 1 from 2,blocked don't need it here 
            //RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "1");
            Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
            ///CPF 6/24/03  This is so that we don't round these items.
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
            Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            if (RG.GetDetailCalcs("ACCT(2360)").GetTotals(RG).NonZero)
                Utility.Skip(RG, 1);

            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (RG.TYPE(40).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(38)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(39)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(40)) > 1)
			{
				Utility.PrintSummary(RG, rm.GetString("bsaGrsFxdAstExclLnd"), RG.GetPrintOrderCalc(RG.GetCalc("TYPE(40)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(40)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				///CPF 6/24/03  This is so that we don't round these items.
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
				Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(40)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			}

			if (RG.TYPE(40).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("LINE(3000)").NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("bsaBegAccDepr"), RG.GetPrintOrderCalc(RG.GetCalc("BegAccumDepr")));
			Utility.PrintSummary(RG, rm.GetString("bsaPlsDeprExp"), RG.GetPrintOrderCalc(RG.GetCalc("PlusDeprExp")));
			Utility.PrintSummary(RG, rm.GetString("bsaPurchSaleAsts"), RG.GetPrintOrderCalc(RG.GetCalc("PurchSaleAst")));

			if (RG.GetCalc("LINE(3000)").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("bsaEndAccDepr"), RG.GetPrintOrderCalc(RG.GetCalc("EndAccumDepr")));

			if (RG.GetCalc("LINE(3000)").NonZero)
				Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(45)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(45)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(45)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%GrsFxdAstExclLnd"), RG.GetPrintOrderCalc(RG.GetCalc("%GrsFxdAsts(45)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetCalc("LINE(3000)").NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2450)"));

			if (RG.GetDetailCalcs("ACCT(2450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2500)"));

			if (RG.GetDetailCalcs("ACCT(2500)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2500)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2530)"));

			if (RG.GetDetailCalcs("ACCT(2530)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2530)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2530)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2550)"));

			if (RG.GetDetailCalcs("ACCT(2550)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2550)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2600)"));

			if (RG.GetDetailCalcs("ACCT(2600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2650)"));

			if (RG.GetDetailCalcs("ACCT(2650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2800)"));

			if (RG.GetDetailCalcs("ACCT(2800)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2800)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2700)"));

			if (RG.GetDetailCalcs("ACCT(2700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            
			// KCZ Added for Account 2740 Version V 6-11-03
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2740)"));

			if (RG.GetDetailCalcs("ACCT(2740)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2740)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			if (RG.GetDetailCalcs("ACCT(2740)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			// KCZ End of Addition


			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2750)"));

			if (RG.GetDetailCalcs("ACCT(2750)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(2750)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);
				
			//amit: End of  group 
			//Utility.Skip(RG, 1);
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//Utility.PrintLabel(RG, "**** 6 ***");
			//Printing Intangibles-Goodwill

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2850)"));

			if (RG.GetDetailCalcs("ACCT(2850)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");
			
			if (RG.GetDetailCalcs("ACCT(2850)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);
				
			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2900)"));

			if (RG.GetDetailCalcs("ACCT(2900)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(2900)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if( FormatCommands.DetailCount(RG, RG.DETAILTYPE(70)) > 1)
			{
				Utility.PrintSummary(RG, rm.GetString("bsaGrsIntang"),  RG.GetPrintOrderCalc(RG.GetDetailCalcs("TYPE(70)").GetTotals(RG)));

				if (RG.GetDetailCalcs("TYPE(70)").GetTotals(RG).NonZero)
					RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(70)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
				///CPF 6/24/03  This is so that we don't round these items.
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
				Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(70)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
				Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(70)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

				if (RG.GetDetailCalcs("TYPE(70)").GetTotals(RG).NonZero)
					Utility.Skip(RG, 1);
			}

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(2820)"));

			if (RG.GetDetailCalcs("ACCT(2820)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(2820)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(2820)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(2820)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%GrsIntang"), RG.GetPrintOrderCalc(RG.GetCalc("%GrsIntang(2820)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(2820)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);


			if (RG.CLASS(10).NonZero)
			{
				Utility.UnderlinePage(RG, 1);
				Utility.Skip(RG, 1);
				///added until we can break correctly
				///amit: blocked 03/23/04
				//Utility.PageBreak(RG);
			}
			
			Utility.Skip(RG, 1);

			//amit: End of  group  999
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);



			///HERE WE START THE LIABILITY ASSUMPTIONS
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.CLASS(15).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("bsaCurLiab"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3050)"));

			if (RG.GetDetailCalcs("ACCT(3050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3070)"));

			if (RG.GetDetailCalcs("ACCT(3070)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3070)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3070)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3100)"));

			if (RG.GetDetailCalcs("ACCT(3100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3150)"));

			if (RG.GetDetailCalcs("ACCT(3150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3200)"));

			if (RG.GetDetailCalcs("ACCT(3200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3200)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%LTDAccts"), RG.GetPrintOrderCalc(RG.GetCalc("%LTDAccts(3200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3250)"));

			if (RG.GetDetailCalcs("ACCT(3250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3250)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%LTDAccts"), RG.GetPrintOrderCalc(RG.GetCalc("%LTDAccts(3250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3300)"));

			if (RG.GetDetailCalcs("ACCT(3300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3300)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%LTDAccts"), RG.GetPrintOrderCalc(RG.GetCalc("%LTDAccts(3300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3350)"));

			if (RG.GetDetailCalcs("ACCT(3350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3350)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%CapLseOb"), RG.GetPrintOrderCalc(RG.GetCalc("%CapLseOb(3350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
            //amit: Start of the  group 
            Utility.mT.AddStartRow(Utility.nRow + 1);


            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

            Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3360)"));

            if (RG.GetDetailCalcs("ACCT(3360)").GetTotals(RG).NonZero)
                RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
            ///CPF 6/24/03  This is so that we don't round these items.
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
            Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3360)")));
            Utility.PrintSummary(RG, rm.GetString("bsa%CapLseOb"), RG.GetPrintOrderCalc(RG.GetCalc("%CapLseOb(3360)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            if (RG.GetDetailCalcs("ACCT(3360)").GetTotals(RG).NonZero)
                Utility.Skip(RG, 1);

            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3370)"));

			if (RG.GetDetailCalcs("ACCT(3370)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3370)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3370)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3370)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3370)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3400)"));

			if (RG.GetDetailCalcs("ACCT(3400)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3400)")));
			Utility.PrintSummary(RG, rm.GetString("bsaDaysOnHand"), RG.GetPrintOrderCalc(RG.GetCalc("%DaysOnHand(3400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3400)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3450)"));

			if (RG.GetDetailCalcs("ACCT(3450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3500)"));

			if (RG.GetDetailCalcs("ACCT(3500)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3500)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3500)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3600)"));

			if (RG.GetDetailCalcs("ACCT(3600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3650)"));

			if (RG.GetDetailCalcs("ACCT(3650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3550)"));

			if (RG.GetDetailCalcs("ACCT(3550)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3550)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3550)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3700)"));

			if (RG.GetDetailCalcs("ACCT(3700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3750)"));

			if (RG.GetDetailCalcs("ACCT(3750)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3750)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3800)"));

			if (RG.GetDetailCalcs("ACCT(3800)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3800)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3920)"));

			if (RG.GetDetailCalcs("ACCT(3920)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3920)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3920)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3920)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3920)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3850)"));

			if (RG.GetDetailCalcs("ACCT(3850)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3850)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3900)"));

			if (RG.GetDetailCalcs("ACCT(3900)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3900)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%ProfB4Tax(3900)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3900)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3910)"));

			if (RG.GetDetailCalcs("ACCT(3910)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3910)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3910)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3910)")));
			Utility.PrintSummary(RG, rm.GetString("bsa%PBT"), RG.GetPrintOrderCalc(RG.GetCalc("%ProfB4Tax(3910)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3910)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3960)"));

			if (RG.GetDetailCalcs("ACCT(3960)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3960)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3960)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3960)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3960)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3970)"));

			if (RG.GetDetailCalcs("ACCT(3970)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3970)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3970)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3970)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3970)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
            
			// KCZ Added account 3940 for Version V 6-11-03
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3940)"));

			if (RG.GetDetailCalcs("ACCT(3940)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3940)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3940)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3940)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3940)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			// KCZ End of addition
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(3950)"));

			if (RG.GetDetailCalcs("ACCT(3950)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(3950)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(3950)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(3950)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(3950)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			if (RG.CLASS(15).NonZero)
			{
				Utility.UnderlinePage(RG, 1);
				Utility.Skip(RG, 1);
			}

			Utility.Skip(RG, 1);

			//amit: End of  group  999
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//amit: blocked 02/23/04
			//Utility.PageBreak(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.CLASS(20).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("bsaNonCurLiabs"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4050)"));

			if (RG.GetDetailCalcs("ACCT(4050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4100)"));

			if (RG.GetDetailCalcs("ACCT(4100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4150)"));

			if (RG.GetDetailCalcs("ACCT(4150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4220)"));

			if (RG.GetDetailCalcs("ACCT(4220)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4220)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4220)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4220)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4220)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4230)"));

			if (RG.GetDetailCalcs("ACCT(4230)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4230)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4230)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4200)"));

			if (RG.GetDetailCalcs("ACCT(4200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);
            
            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
            //Utility.PageBreak(RG);
            //amit: Start of the  group 
            Utility.mT.AddStartRow(Utility.nRow + 1);

            RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

            Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4210)"));

            if (RG.GetDetailCalcs("ACCT(4210)").GetTotals(RG).NonZero)
                RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4210)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
            ///CPF 6/24/03  This is so that we don't round these items.
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
            Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4210)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
            Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4210)")));
            RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

            if (RG.GetDetailCalcs("ACCT(4210)").GetTotals(RG).NonZero)
                Utility.Skip(RG, 1);

            //amit: End of  group 
            Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			// KCZ Added 4390 Versio V 6-11-03 
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4390)"));

			if (RG.GetDetailCalcs("ACCT(4390)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4390)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4390)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4390)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4390)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			// KCZ end of addition

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4400)"));

			if (RG.GetDetailCalcs("ACCT(4400)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4400)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4400)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4250)"));

			if (RG.GetDetailCalcs("ACCT(4250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4300)"));

			if (RG.GetDetailCalcs("ACCT(4300)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4300)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4300)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4330)"));

			if (RG.GetDetailCalcs("ACCT(4330)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4330)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4330)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4330)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4330)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4340)"));

			if (RG.GetDetailCalcs("ACCT(4340)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4340)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4340)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4340)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4340)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4350)"));

			if (RG.GetDetailCalcs("ACCT(4350)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4350)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4350)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4450)"));

			if (RG.GetDetailCalcs("ACCT(4450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4600)"));

			if (RG.GetDetailCalcs("ACCT(4600)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4600)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4600)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4660)"));

			if (RG.GetDetailCalcs("ACCT(4660)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4660)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4660)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4660)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4660)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4680)"));

			if (RG.GetDetailCalcs("ACCT(4680)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4680)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4680)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4700)"));

			if (RG.GetDetailCalcs("ACCT(4700)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4700)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4700)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4800)"));

			if (RG.GetDetailCalcs("ACCT(4800)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4800)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4800)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);



			if (RG.CLASS(20).NonZero)
			{
				Utility.UnderlinePage(RG, 1);
				Utility.Skip(RG, 1);
			}

			Utility.Skip(RG, 1);

			//amit: End of  group  999
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);
            //amit:03/23/04 blocked
			//Utility.PageBreak(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.CLASS(25).NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintLabel(RG, rm.GetString("bsaEquity"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			}


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4650)"));

			if (RG.GetDetailCalcs("ACCT(4650)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4650)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4650)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4670)"));

			if (RG.GetDetailCalcs("ACCT(4670)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4670)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4670)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4690)"));

			if (RG.GetDetailCalcs("ACCT(4690)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4690)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4690)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4690)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4690)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4750)"));

			if (RG.GetDetailCalcs("ACCT(4750)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4750)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4750)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4850)"));

			if (RG.GetDetailCalcs("ACCT(4850)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(4850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(4850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(4850)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(4850)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5050)"));

			if (RG.GetDetailCalcs("ACCT(5050)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5050)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5050)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5100)"));

			if (RG.GetDetailCalcs("ACCT(5100)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5100)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5100)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5150)"));

			if (RG.GetDetailCalcs("ACCT(5150)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5150)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5150)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5200)"));

			if (RG.GetDetailCalcs("ACCT(5200)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5200)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5200)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5250)"));

			if (RG.GetDetailCalcs("ACCT(5250)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5250)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5250)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5420)"));

			if (RG.GetDetailCalcs("ACCT(5420)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5420)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5420)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5410)"));

			if (RG.GetDetailCalcs("ACCT(5410)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5410)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5410)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5410)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5410)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: Start of the  group 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5450)"));

			if (RG.GetDetailCalcs("ACCT(5450)").GetTotals(RG).NonZero)
				RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("bsaActIncrDcrOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("ActIDOvPer(5450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintSummary(RG, rm.GetString("bsa%IncDecOvPP"), RG.GetPrintOrderCalc(RG.GetCalc("%IDOvPP(5450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("bsa%NetSales"), RG.GetPrintOrderCalc(RG.GetCalc("%NetSales(5450)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");

			if (RG.GetDetailCalcs("ACCT(5450)").GetTotals(RG).NonZero)
				Utility.Skip(RG, 1);

			Utility.UnderlinePage(RG, 2);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);
			
			Utility.CloseReport(RG);



		}
	}
}
