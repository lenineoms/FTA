using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class SUM_COMP_IS_PERCENT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.ISCalcs(RG);

			MMAS_Utility.SUMMARY_INCOME_STATEMENT(RG, FORMATCOMMANDS.COMP_PERCENT);
		}
	}
}
