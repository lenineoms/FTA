using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class SUM_FAS_CF_DIR:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);
			Calcs.FAS_CF_Dir_Calcs(RG);
			Calcs.FAS_CF_Ind_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: start outer group (full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: start 1st group "Cash Flows From"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("sfasCFFmOpAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sfasNetSales"), RG.GetPrintOrderCalc(RG.GetCalc("CFNetSales")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgNetRcv"), RG.GetPrintOrderCalc(RG.GetCalc("CFChgARNet")));
			///CPF 05/31/06 Log 1699:  Added Chg Due From Rel Co 
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueFmRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasChgDefRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDefRev").GetTotals(RG)));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			if (RG.GetCalc("CashCollFromSales").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sfasCshRcvFmCust"), RG.GetPrintOrderCalc(RG.GetCalc("CashRecFrmCust")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sfasCstSlesRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTCostOfSalesCF").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasChgInv"), RG.GetPrintOrderCalc(RG.GetCalc("ChgTotInventory")));
			Utility.PrintSummary(RG, rm.GetString("scfmChgAPTrd"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgAPTrdOth")));
			///CPF 05/31/06 Log 1699:  Added Chg Due To Rel Co 
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueToRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueToRelCoCP").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasOpExp"), RG.GetPrintOrderCalc(RG.GetCalc("CFSGAExp")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgPpdDfd"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgPrePdsCostEB")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgOvdfts"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgOvrdrfts").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasChgAccrls"), RG.GetPrintOrderCalc(RG.GetCalc("FASDChgAccruals")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgOpAstLbs"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgOpItems")));

			if (RG.GetCalc("CashPdSuppEmp").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintLabel(RG, rm.GetString("sfasCshPdSupp"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("sfasAndEmpl"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdSuppEmp")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("sfasIntPd"), RG.GetPrintOrderCalc(RG.GetCalc("InterestPaid")));
			Utility.PrintSummary(RG, rm.GetString("sfasIncTxPd"), RG.GetPrintOrderCalc(RG.GetCalc("IncTaxPaid")));
			Utility.PrintSummary(RG, rm.GetString("sfasIntDivRcvd"), RG.GetPrintOrderCalc(RG.GetCalc("IntDivRcvd")));
			Utility.PrintSummary(RG, rm.GetString("sfasMiscCshRcvdPd"), RG.GetPrintOrderCalc(RG.GetCalc("MiscCashRcvPd")));
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("sfasNetCshPrvOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvOp")));

			Utility.Skip(RG, 1);

			//amit: end 1st group "Cash flows from"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start 2nd group "Cash Flows From investing"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("sfasCFFmInvAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintSummary(RG, rm.GetString("sfasChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("FASChgNetFxdAsts")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgSTInv"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgSTInv")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgLTInv"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgLTInv")));
			Utility.PrintSummary(RG, rm.GetString("sfasChgNetIntang"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetIntang")));
            //add to GainLossAssRev
            Utility.PrintSummary(RG, rm.GetString("sucaGainLossAssRev"), RG.GetPrintOrderCalc(RG.GetCalc("GainLossAssRev")));


			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			if (RG.GetCalc("NetCashUsedInvst").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sfasNetCshUsdInvst"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashUsedInvst")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: end 2nd group "Cash flows from investing"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start 3rd group "Cash Flows From financing"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("sfasCFFmFinAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++) 
			{
				if (RG.GetCalc("ProcLessPymts")[i] != 0)
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTProcFrBorr"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTPrinPytDbt"));
					break;
				}
			}

			for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++) 
			{
				if (RG.GetCalc("ProcLessPymts")[i] == 0)
				{
					Utility.PrintSummary(RG, rm.GetString("sfasChgSTLoans"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTFASChgSTBorr").GetTotals(RG)));
					Utility.PrintSummary(RG, rm.GetString("sfasChgCPLTD"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTFASChgCPLTD").GetTotals(RG)));
					Utility.PrintSummary(RG, rm.GetString("sfasChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("FASSumChgLTD")));
					Utility.PrintSummary(RG, rm.GetString("sfasChgSubDbtAct"), RG.GetPrintOrderCalc(RG.GetCalc("FASIChgSubDbt")));
					break;
				}
			}

			if (RG.GetCalc("NetChgBorrow").NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.UnderlineColumn(RG, 1, 1);
				Utility.PrintSummary(RG, rm.GetString("sfasNetChgBorr"), RG.GetPrintOrderCalc(RG.GetCalc("NetChgBorrow")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefIntExp"));
			
			Utility.PrintSummary(RG, rm.GetString("sfasChgOthPay"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasChgOthLTLiabs"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG)));			
			Utility.PrintSummary(RG, rm.GetString("sfasChgOthGALiabs"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG)));			
			Utility.PrintSummary(RG, rm.GetString("sfasCashDivPd"), RG.GetPrintOrderCalc(RG.GetCalc("CFDivsPIC")));			
			Utility.PrintSummary(RG, rm.GetString("sfasChgCap"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(2450)")));			

			if (RG.GetCalc("NetCashProvFin").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("sfasNetCashPrvFin"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashProvFin")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "Chg in ");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(244)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("ChgInCashEquiv").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sfasChgCashEq"), RG.GetPrintOrderCalc(RG.GetCalc("ChgInCashEquiv")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			///HERE WE WOULD SHUT OFF ST_CROSS_FOOT FOR STP.
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");

			Utility.PrintSummary(RG, rm.GetString("sfasAddCshEqBOP"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTCashCF").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sfasCashAdj"), RG.GetPrintOrderCalc(RG.GetCalc("FASCashAdjustment")));
			Utility.UnderlineColumn(RG, 1, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("sfasCashEqEOP"), RG.GetPrintOrderCalc(RG.GetCalc("CashEquivEOP")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: end 3rd group "Cash flows from financing"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: end of outer group (full report)
			Utility.mT.AddEndRow(Utility.nRow);


			Utility.CloseReport(RG);
		}
	}
}
