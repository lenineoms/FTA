using System;
using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class CONSULTANT_CALCS
	{
		CALCULATIONS Calcs = new CALCULATIONS();
	
		public void FOCUS_QUESTIONS(ReportGenerator RG)
		{
			Calcs.UCACFCalcs(RG);
			if (RG.GetCalc("fqIntPayCPLTD") == null)
				RG.AddCalc("fqIntPayCPLTD", (-1 * (RG.GetDetailCalcs("DTInterestExp").GetTotals(RG) + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG))) - RG.GetCalc("CurPtnLTD"));





		}
	}
}
