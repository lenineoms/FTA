using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class DET_BS_TREND:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// Load the Balance Sheet Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BSCalcs(RG);				

			/// Call the base balance sheet code. 
			MMAS_Utility.DETAILED_BALANCE_SHEET(RG, FORMATCOMMANDS.ACT_TREND);
		}
	}
}
