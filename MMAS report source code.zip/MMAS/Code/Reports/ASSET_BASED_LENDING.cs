using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class ASSET_BASED_LENDING:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ABLCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			Utility.Skip(RG, 1);

			//amit: Start of the Outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start of the 1st Group "ACCOUNTS RECEIVABLE"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("ablAcctsRec"));

			Utility.PrintSummary(RG, rm.GetString("ablTotActsRecAR"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5500)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(5501)"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			for (int i = 0; i < RG.GetCalc("LINE(5754)").Count; i++) 
				if (RG.GetCalc("LINE(5754)")[i] == 1)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					Utility.PrintSummary(RG, rm.GetString("ablEligActsRec"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5503)")));
					break;
				}
		
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(1020)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			for (int i = 0; i < RG.GetCalc("LINE(5763)").Count; i++) 
				/// if 5763 = 2 for any period then we have both an AR subtotal and AR adjust.
				if (RG.GetCalc("LINE(5763)")[i] == 2)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					break;
				}

			Utility.PrintSummary(RG, rm.GetString("ablARBsB4CapSrLns"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5504)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(254)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(256)"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			for (int i = 0; i < RG.GetCalc("LINE(5758)").Count; i++) 
				/// if 5758 = 2 for any period then we have both AR Base before Cap & Leins and Cap/Leins.
				if (RG.GetCalc("LINE(5758)")[i] == 2)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					break;
				}

			Utility.PrintSummary(RG, rm.GetString("ablNetARBorrBase"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5507)")));

			Utility.Skip(RG, 1);

			//amit: End of the 1st Group "ACCOUNTS RECEIVABLE"
			Utility.mT.AddEndRow(Utility.nRow -1);
			//Utility.PageBreak(RG);
			//amit: Start of the 2nd Group "INVENTORY"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("ablInventory"));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintSummary(RG, rm.GetString("ablRawMat"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5511)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4950)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, rm.GetString("ablWIP"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5512)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(4980)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, rm.GetString("ablFinGds"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5513)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5010)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
	
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			for (int i = 0; i < RG.GetCalc("LINE(5720)").Count; i++) 
				if (RG.GetCalc("LINE(5720)")[i] > 0)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					Utility.PrintSummary(RG, rm.GetString("ablInvBsB4CapSrLns"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5514)")));
					break;
				}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(264)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(266)"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("ablNetInvBorrBase"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5517)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End of the 2nd Group "INVENTORY"
			Utility.mT.AddEndRow(Utility.nRow -1);
			//Utility.PageBreak(RG);
			//amit: Start of the 3rd Group "ORDERS"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("ablOrders"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(268)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(270)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			for (int i = 0; i < RG.GetCalc("LINE(5854)").Count; i++) 
				if (RG.GetCalc("LINE(5854)")[i] == 2)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					Utility.PrintSummary(RG, rm.GetString("ablElgOrdHnd"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5522)")));
					break;
				}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("ACCT(5640)"));
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			for (int i = 0; i < RG.GetCalc("LINE(5863)").Count; i++) 
				/// if 5863 = 2 for any period then we have both order b4 cap and cap entered
				if (RG.GetCalc("LINE(5863)")[i] == 2)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					break;
				}

			Utility.PrintSummary(RG, rm.GetString("ablOrdBaseB4Cap"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5523)")));
 
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(272)"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			for (int i = 0; i < RG.GetCalc("LINE(5868)").Count; i++) 
				if (RG.GetCalc("LINE(5868)")[i] == 2)
				{
					Utility.UnderlineColumn(RG, 1, 1);
					break;
				}

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("ablNetOrdBorrBase"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5525)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End of the 3rd Group "ORDERS"
			Utility.mT.AddEndRow(Utility.nRow -1);
			//Utility.PageBreak(RG);
			//amit: Start of the 4th Group "BORROWING BASE"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintLabel(RG, rm.GetString("ablBorrBaseSumm"));

			Utility.PrintSummary(RG, rm.GetString("ablTotAstBorrBase"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5529)")));
			Utility.PrintSummary(RG, rm.GetString("ablTotExcl"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5530)")));
			Utility.PrintSummary(RG, rm.GetString("ablEligAsts"), RG.GetPrintOrderCalc(RG.GetCalc("EligAssets")));
			Utility.PrintSummary(RG, rm.GetString("ablTotBsB4CapLns"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5531)")));
			Utility.PrintSummary(RG, rm.GetString("ablExclDueCaps"), RG.GetPrintOrderCalc(RG.GetCalc("ExclDueToCaps")));
			Utility.PrintSummary(RG, rm.GetString("ablTotSenLnDed"), RG.GetPrintOrderCalc(RG.GetCalc("TotSenLeinDed")));

			if (RG.GetCalc("LINE(5529)").NonZero || RG.GetCalc("LINE(5530)").NonZero || RG.GetCalc("EligAssets").NonZero || RG.GetCalc("LINE(5531)").NonZero || RG.GetCalc("ExclDueToCaps").NonZero || RG.GetCalc("TotSenLeinDed").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("ablTotBorrBase"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5542)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);



			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(274)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(276)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(278)"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("TYPE(280)"));

			if (RG.GetDetailCalcs("TYPE(274)").GetTotals(RG).NonZero || RG.GetDetailCalcs("TYPE(276)").GetTotals(RG).NonZero || RG.GetDetailCalcs("TYPE(278)").GetTotals(RG).NonZero || RG.GetDetailCalcs("TYPE(280)").GetTotals(RG).NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("ablAmtAvail"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(5543)")));

            Utility.UnderlinePage(RG, 2);
			//amit: End of the 4th Group "BORROWING BASE"
			Utility.mT.AddEndRow(Utility.nRow -1);
			//Utility.PageBreak(RG);
			//amit: End of the outer Group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow -1);
			
			Utility.CloseReport(RG);
		}
	}
}
