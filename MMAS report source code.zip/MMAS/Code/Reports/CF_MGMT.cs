using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class CF_MGMT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);
			Calcs.RatioCalcs(RG);
			Calcs.CF_MGMT_Calcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant & Analyst stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,3);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.25");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			///CPF 6/3/04 Log 713 Make zeros print - instead of 0.
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("cfmCFDrvrs"));
			Utility.UnderlinePage(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");

			Utility.PrintLabel(RG, rm.GetString("cfmCFDrvrs"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("cfmNtSlsGwth"), RG.GetPrintOrderCalc(RG.GetCalc("NetSalesGwth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");

			Utility.PrintSummary(RG, rm.GetString("cfmGMDpr%"), RG.GetPrintOrderCalc(RG.GetCalc("GrsMgnPlsDepr")));
			Utility.PrintSummary(RG, rm.GetString("cfmOEDpr%"), RG.GetPrintOrderCalc(RG.GetCalc("OpExpExclDepr")));

			Utility.PrintSummary(RG, rm.GetString("cfmARDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(984)")));
			Utility.PrintSummary(RG, rm.GetString("cfmInvDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1701)")));
			Utility.PrintSummary(RG, rm.GetString("cfmAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1728)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintLabel(RG, rm.GetString("cfmOthFact"));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	

			Utility.PrintSummary(RG, rm.GetString("cfmOthOpAsts"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1729)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			///CPF 6/24/03  This is so that we don't round these items.
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");	

			Utility.PrintSummary(RG, rm.GetString("cfmAccExpDays"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1741)")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");	
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");

			Utility.PrintSummary(RG, rm.GetString("cfmOthCurLiabs"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1731)")));

			Utility.UnderlinePage(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("cfmCashMargMgtSum"));
			Utility.UnderlinePage(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintLabel(RG, rm.GetString("cfmGrsMgn"));
 
			Utility.PrintSummary(RG, rm.GetString("cfmBegGrsMgn"), RG.GetPrintOrderCalc(RG.GetCalc("BegGrsPrft")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmGrsPftMgmt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(983)")));
			Utility.PrintSummary(RG, rm.GetString("cfmGrsPftGwth"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(982)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("cfmEndGrsPftDrp"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(978)")));

			Utility.Skip(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("cfmOpExp"));
			Utility.PrintSummary(RG, rm.GetString("cfmBegOpExp"), RG.GetPrintOrderCalc(RG.GetCalc("BegOpExp")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmOpExpMgmt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(986)")));
			Utility.PrintSummary(RG, rm.GetString("cfmOpExpGwth"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(985)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("cfmEndOpExpDr"), RG.GetPrintOrderCalc(-1 * RG.GetCalc("LINE(979)")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("cfmCashOpPft"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(987)")));

			Utility.UnderlinePage(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("cfmTrdActMgmtSum"));
			Utility.UnderlinePage(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("cfmCashImpMgmt"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmAR"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(995)")));
			Utility.PrintSummary(RG, rm.GetString("cfmInv"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1713)")));
			Utility.PrintSummary(RG, rm.GetString("cfmAP"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1737)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintSummary(RG, rm.GetString("cfmTotMgmtTrdAct"), RG.GetPrintOrderCalc(RG.GetCalc("TotMgmtTA")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmOthOpAst"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1725)")));
			Utility.PrintSummary(RG, rm.GetString("cfmAccrls"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1755)")));
			Utility.PrintSummary(RG, rm.GetString("cfmOthCurLiab"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1768)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintSummary(RG, rm.GetString("cfmTotMgmtOthFact"), RG.GetPrintOrderCalc(RG.GetCalc("TotMgmtOF")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintSummary(RG, rm.GetString("cfmTotCashImpMgmt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1770)")));

			Utility.Skip(RG, 1);
			Utility.PrintLabel(RG, rm.GetString("cfmCashImpGwth"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmAR"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(990)")));
			Utility.PrintSummary(RG, rm.GetString("cfmInv"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1705)")));
			Utility.PrintSummary(RG, rm.GetString("cfmAP"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1735)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintSummary(RG, rm.GetString("cfmTotGwthTrAct"), RG.GetPrintOrderCalc(RG.GetCalc("TotGwthTA")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("cfmOthOpAst"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1720)")));
			Utility.PrintSummary(RG, rm.GetString("cfmAccrls"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1750)")));
			Utility.PrintSummary(RG, rm.GetString("cfmOthCurLiabs"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1765)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
			Utility.PrintSummary(RG, rm.GetString("cfmTotGwthOthFact"), RG.GetPrintOrderCalc(RG.GetCalc("TotGwthOF")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.PrintLabel(RG, rm.GetString("cfmTotCashImp"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("cfmOfSalesGwth"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1771)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.Skip(RG, 1);

			Utility.PrintLabel(RG, rm.GetString("cfmTotTrdAct"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("cfmOthFactChg"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(1772)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			Utility.Skip(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("cfmCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("CashOps")));

			Utility.UnderlinePage(RG, 2);

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);


		}
	}
}
