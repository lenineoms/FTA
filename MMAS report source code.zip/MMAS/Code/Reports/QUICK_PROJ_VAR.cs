using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class QUICK_PROJ_VAR:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.QuickProjCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);
			
			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,3);

			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_COLUMN_1, "1");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "False");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start outer group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("qpAnnSlsGwth"), RG.GetPrintOrderCalc(RG.GetCalc("QPSalesGrowth")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("qpGrsMgnDpr"), RG.GetPrintOrderCalc(RG.GetCalc("QPGrossMargin")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpOpExpDpr"), RG.GetPrintOrderCalc(RG.GetCalc("QPOpExp")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpNetARDays"), RG.GetPrintOrderCalc(RG.GetCalc("QPARDays")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpInvDOH"), RG.GetPrintOrderCalc(RG.GetCalc("QPInvDays")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpAPDays"), RG.GetPrintOrderCalc(RG.GetCalc("QPAPDays")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpCshSGACOGS"), RG.GetPrintOrderCalc(RG.GetCalc("QPCashToSGACogs")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("qpCapSpend"), RG.GetPrintOrderCalc(RG.GetCalc("QPCapSpending")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.DECIMAL_PRCSN_1, "2");
			Utility.PrintSummary(RG, rm.GetString("qpMiscBSGwthRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPMiscBSGrowth")));

			// SPA - Hist Formula same as Annual Sales Growth
			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpMiscISGwthRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPSalesGrowth")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpDeprRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPDeprecRate")));

			// SPA - Hist Formula same as Depreciation Rate
			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpDeprRtAccum"), RG.GetPrintOrderCalc(RG.GetCalc("QPDeprecRate")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "None");
			Utility.PrintSummary(RG, rm.GetString("qpEffTxRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPEffTaxRate")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpDivPyRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPDivPayoutRate")));

			Utility.Skip(RG, 1);
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			Utility.PrintSummary(RG, rm.GetString("qpIntExpRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPIntExpRate")));

			Utility.Skip(RG, 1);
			Utility.PrintSummary(RG, rm.GetString("qpIntIncRt"), RG.GetPrintOrderCalc(RG.GetCalc("QPIntIncRate")));
		
			RG.SetAuthorSetting(FORMATCOMMANDS.ROUND_FOR_REPORTS, "True");
			Utility.UnderlinePage(RG, 2);

			//amit: End outer group (Full Report)
			Utility.mT.AddEndRow(Utility.nRow);
			
			Utility.CloseReport(RG);

		}
	}
}
