using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.Reflection;
using System.Resources;
using System.Linq;
using System.Collections.Generic;

namespace MMAS
{
    public class CALCULATIONS
    {
        /// <summary>
        /// For DE123757, which accounts order does not match spreading grid
        /// Holds the calculations along with the account id's and then reorder them when printing account details
        /// </summary>
        public List<AccountCalculation> AccountCalculations { get; set; } = new List<AccountCalculation>();

        /// <summary>
        /// Add the calculations for every accounts of the type. If there are no accounts in customer, then we just add the DETAILTYPE
        /// </summary>
        /// <param name="RG">ReportGenerator instance</param>
        /// <param name="calcsLabel">Calc Label</param>
        /// <param name="typeID">Type ID</param>
        /// <param name="zeroMinus">If the value to print is using "0 - value"</param>
        private void AddDetailCalcsForType(ReportGenerator RG, string calcsLabel, int typeID, bool zeroMinus = false)
        {
            DetailCalcs detCalcs;
            detCalcs = RG.GetDetailCalcs(calcsLabel);

            if (detCalcs == null)
            {
                if (zeroMinus)
                {
                    detCalcs = 0 - RG.DETAILTYPE(typeID) * RG.CONV_RATE();
                }
                else
                {
                    detCalcs = RG.DETAILTYPE(typeID) * RG.CONV_RATE();
                }
                RG.AddCalc(calcsLabel, detCalcs);
            }
                    var accounts = RG.Context.Customer.Accounts.Cast<Account>().Where(a => a.TypeID == typeID);
                    if (accounts.Any())
                    {
                        foreach (var a in accounts)
                        {
                            DetailCalcs calcs;
                            if (zeroMinus)
                            {
                                calcs = 0 - RG.DETAILACCOUNT(a.Id) * RG.CONV_RATE();
                            }
                            else
                            {
                                calcs = RG.DETAILACCOUNT(a.Id) * RG.CONV_RATE();
                            }
                            AccountCalculations.Add(new AccountCalculation(calcsLabel, a, typeID, calcs));
                        }
                    }
                    else if (detCalcs != null)
                    {
                        AccountCalculations.Add(new AccountCalculation(calcsLabel, null, typeID, detCalcs));
                    }         
        }

        public void BSCalcs(ReportGenerator RG)
        {
            /// Load all the various balance sheet calculations.

            /// Load the calculations for SUM_BS_ACT & SUM_BS_ACT_PERCENT
            /// Current Assets
            if (RG.GetCalc("ActNotRecRel") == null)
                RG.AddCalc("ActNotRecRel", RG.MACRO(M.ACCTS_NOT_REC_REL));
            if (RG.GetCalc("TradeInv") == null)
                RG.AddCalc("TradeInv", RG.MACRO(M.TRADE_INV));
            if (RG.GetDetailCalcs("DTMemo0DecCA") == null)
                RG.AddCalc("DTMemo0DecCA", RG.DETAILAND(215, RG.ANDTYPE, 5, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTLifoRes") == null)
                RG.AddCalc("DTLifoRes", RG.DETAILAND(216, RG.ANDTYPE, 5, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOffBSCurAst") == null)
                RG.AddCalc("DTOffBSCurAst", RG.DETAILAND(217, RG.ANDTYPE, 5, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMemo2DecCA") == null)
                RG.AddCalc("DTMemo2DecCA", RG.DETAILAND(220, RG.ANDTYPE, 5, RG.ANDCLASS));
            if (RG.GetCalc("TotCurAst") == null)
                RG.AddCalc("TotCurAst", RG.MACRO(M.TOTAL_CURRENT_ASSETS));
            /// Non-Current Assets
            if (RG.GetCalc("OpNonCurAst") == null)
                RG.AddCalc("OpNonCurAst", RG.MACRO(M.OP_NON_CUR_AST));
            if (RG.GetCalc("IntangNet") == null)
                RG.AddCalc("IntangNet", RG.MACRO(M.INTANG_NET));
            if (RG.GetDetailCalcs("DTMemo0DecNCA") == null)
                RG.AddCalc("DTMemo0DecNCA", RG.DETAILAND(215, RG.ANDTYPE, 10, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTOffBSNonCurAst") == null)
                RG.AddCalc("DTOffBSNonCurAst", RG.DETAILAND(217, RG.ANDTYPE, 10, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMemo2DecNCA") == null)
                RG.AddCalc("DTMemo2DecNCA", RG.DETAILAND(220, RG.ANDTYPE, 10, RG.ANDCLASS));
            if (RG.GetCalc("TotNonCurAst") == null)
                RG.AddCalc("TotNonCurAst", RG.MACRO(M.TOTAL_NON_CURRENT_ASSETS));
            if (RG.GetCalc("TotalAssets") == null)
                RG.AddCalc("TotalAssets", RG.MACRO(M.TOTAL_ASSETS));
            /// Current Liabs
            if (RG.GetDetailCalcs("DTCPLTD") == null)
                RG.AddCalc("DTCPLTD", RG.DETAILTYPE(80) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTCPCapLeaseOb") == null)
                RG.AddCalc("DTCPCapLeaseOb", RG.DETAILTYPE(81) * RG.CONV_RATE());
            if (RG.GetCalc("IntDivPay") == null)
                RG.AddCalc("IntDivPay", RG.MACRO(M.INT_DIV_PAY));
            if (RG.GetDetailCalcs("DTMemo0DecCL") == null)
                RG.AddCalc("DTMemo0DecCL", RG.DETAILAND(215, RG.ANDTYPE, 15, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTOffBSCurLiabs") == null)
                RG.AddCalc("DTOffBSCurLiabs", RG.DETAILAND(218, RG.ANDTYPE, 15, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMemo2DecCL") == null)
                RG.AddCalc("DTMemo2DecCL", RG.DETAILAND(220, RG.ANDTYPE, 15, RG.ANDCLASS));
            if (RG.GetCalc("TotCurLiabs") == null)
                RG.AddCalc("TotCurLiabs", RG.MACRO(M.TOTAL_CURRENT_LIABILITIES));
            /// Non-Current Liabs
            if (RG.GetDetailCalcs("DTLTD") == null)
                RG.AddCalc("DTLTD", RG.DETAILTYPE(110) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTCapLeaseOb") == null)
                RG.AddCalc("DTCapLeaseOb", RG.DETAILTYPE(112) * RG.CONV_RATE());
            if (RG.GetCalc("OthNonCurLiab") == null)
                RG.AddCalc("OthNonCurLiab", RG.MACRO(M.OTH_NON_CUR_LIABS));
            if (RG.GetDetailCalcs("DTMemo0DecNCL") == null)
                RG.AddCalc("DTMemo0DecNCL", RG.DETAILAND(215, RG.ANDTYPE, 20, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTOffBSNonCurLiab") == null)
                RG.AddCalc("DTOffBSNonCurLiab", RG.DETAILAND(218, RG.ANDTYPE, 20, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMemo2DecNCL") == null)
                RG.AddCalc("DTMemo2DecNCL", RG.DETAILAND(220, RG.ANDTYPE, 20, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTMemo0DecNCL2") == null)
                RG.AddCalc("DTMemo0DecNCL2", RG.DETAILAND(215, RG.ANDTYPE, 22, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTMemo2DecNCL2") == null)
                RG.AddCalc("DTMemo2DecNCL2", RG.DETAILAND(220, RG.ANDTYPE, 22, RG.ANDCLASS));
            if (RG.GetCalc("TotNonCurLiabs") == null)
                RG.AddCalc("TotNonCurLiabs", RG.MACRO(M.TOTAL_NON_CURRENT_LIABILITIES));
            if (RG.GetCalc("TotLiabs") == null)
                RG.AddCalc("TotLiabs", RG.MACRO(M.TOTAL_LIABILITIES));
            /// Equity
            if (RG.GetCalc("Stock") == null)
                RG.AddCalc("Stock", RG.MACRO(M.STOCK));
            if (RG.GetCalc("OthEqty") == null)
                RG.AddCalc("OthEqty", RG.MACRO(M.OTH_EQTY));
            if (RG.GetDetailCalcs("DTRetEarn") == null)
                RG.AddCalc("DTRetEarn", RG.DETAILTYPE(140) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAccumOCI") == null)
                RG.AddCalc("DTAccumOCI", RG.DETAILTYPE(141) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMemo0DecEQ") == null)
                RG.AddCalc("DTMemo0DecEQ", RG.DETAILAND(215, RG.ANDTYPE, 25, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTMemo2DecEQ") == null)
                RG.AddCalc("DTMemo2DecEQ", RG.DETAILAND(220, RG.ANDTYPE, 25, RG.ANDCLASS));
            if (RG.GetCalc("TotNetWrth") == null)
                RG.AddCalc("TotNetWrth", RG.MACRO(M.NET_WORTH));
            if (RG.GetCalc("TotLiabsNetWorth") == null)
                RG.AddCalc("TotLiabsNetWorth", RG.MACRO(M.TOTAL_LIABILITIES) + RG.MACRO(M.NET_WORTH));
            ///CPF 8/28/03 These 2 calcs are TA & TL/NW without the conversion raet applied.  
            ///we created these so that we can compare unconverted data to tell whether customer is
            ///out of balance.
            if (RG.GetCalc("TotLiabsNetWorthNoConvRate") == null)
                RG.AddCalc("TotLiabsNetWorthNoConvRate", RG.MACRO(M.DISPLAY_TOTAL_LIABS_AND_NET_WORTH));
            if (RG.GetCalc("TotalAssetsNoConvRate") == null)
                RG.AddCalc("TotalAssetsNoConvRate", RG.MACRO(M.DISPLAY_TOTAL_ASSETS));

            /// Load calcs for DET_BS_ACT
            /// Current Assets
            if (RG.GetDetailCalcs("DTCashActs") == null)
                RG.AddCalc("DTCashActs", RG.DETAILTYPE(5) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMarkSecActs") == null)
                RG.AddCalc("DTMarkSecActs", RG.DETAILTYPE(7) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTARActs") == null)
                RG.AddCalc("DTARActs", RG.DETAILTYPE(10) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTBadDebtRes") == null)
                RG.AddCalc("DTBadDebtRes", RG.DETAILTYPE(11) * RG.CONV_RATE());
            if (RG.GetCalc("TotActsRcvNet") == null)
                RG.AddCalc("TotActsRcvNet", RG.MACRO(M.TOT_ACCTS_REC_NET));
            if (RG.GetDetailCalcs("DTActsNotRcvRelCo") == null)
                RG.AddCalc("DTActsNotRcvRelCo", RG.DETAILTYPE(13) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTActsNotRcvOth") == null)
                RG.AddCalc("DTActsNotRcvOth", RG.DETAILTYPE(12) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIncTaxRcv") == null)
                RG.AddCalc("DTIncTaxRcv", RG.DETAILAND(5, RG.ANDCLASS, 25, RG.ANDTYPE) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTInvRawMat") == null)
                RG.AddCalc("DTInvRawMat", RG.DETAILTYPE(15) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTInvWrkProc") == null)
                RG.AddCalc("DTInvWrkProc", RG.DETAILTYPE(16) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTInvFinGds") == null)
                RG.AddCalc("DTInvFinGds", RG.DETAILTYPE(17) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTInvOther") == null)
                RG.AddCalc("DTInvOther", RG.DETAILTYPE(20) * RG.CONV_RATE());
            if (RG.GetCalc("TotalInv") == null)
                RG.AddCalc("TotalInv", RG.MACRO(M.TOTAL_INVENTORY));
            if (RG.GetDetailCalcs("DTCostExcBill") == null)
                RG.AddCalc("DTCostExcBill", RG.DETAILTYPE(27) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOpCurAst") == null)
                RG.AddCalc("DTOpCurAst", RG.DETAILTYPE(30) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTNonOpCurAst") == null)
                RG.AddCalc("DTNonOpCurAst", RG.DETAILTYPE(35) * RG.CONV_RATE());
            /// Non-Current Assets
            if (RG.GetDetailCalcs("DTLand") == null)
                RG.AddCalc("DTLand", RG.DETAILTYPE(39) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTConstInPrg") == null)
                RG.AddCalc("DTConstInPrg", RG.DETAILTYPE(38) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOthFxdAsts") == null)
                RG.AddCalc("DTOthFxdAsts", RG.DETAILTYPE(40) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAccumDepr") == null)
                RG.AddCalc("DTAccumDepr", RG.DETAILTYPE(45) * RG.CONV_RATE());
            if (RG.GetCalc("NetFxdAsts") == null)
                RG.AddCalc("NetFxdAsts", RG.MACRO(M.NET_FIXED_ASSETS));
            if (RG.GetCalc("GrsFxdAsts") == null)
                RG.AddCalc("GrsFxdAsts", RG.MACRO(M.GROSS_FIXED_ASSETS));
            if (RG.GetDetailCalcs("DTLTReceiv") == null)
                RG.AddCalc("DTLTReceiv", RG.DETAILTYPE(50) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTInvestments") == null)
                RG.AddCalc("DTInvestments", RG.DETAILTYPE(55) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTLTPrepaids") == null)
                RG.AddCalc("DTLTPrepaids", RG.DETAILTYPE(62) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOpNonCurAst") == null)
                RG.AddCalc("DTOpNonCurAst", RG.DETAILTYPE(60) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIncTaxRcvble") == null)
                RG.AddCalc("DTIncTaxRcvble", RG.DETAILAND(10, RG.ANDCLASS, 25, RG.ANDTYPE) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTNonOpNonCurAst") == null)
                RG.AddCalc("DTNonOpNonCurAst", RG.DETAILTYPE(65) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIntangibles") == null)
                RG.AddCalc("DTIntangibles", RG.DETAILTYPE(70) * RG.CONV_RATE());
            if (RG.GetCalc("GrossIntang") == null)
                RG.AddCalc("GrossIntang", RG.TYPE(70) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAccAmort") == null)
                RG.AddCalc("DTAccAmort", RG.DETAILTYPE(71) * RG.CONV_RATE());
            /// Current Liabs
            if (RG.GetDetailCalcs("DTOvrDrftBook") == null)
                RG.AddCalc("DTOvrDrftBook", RG.DETAILTYPE(72) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOvrDrftIB") == null)
                RG.AddCalc("DTOvrDrftIB", RG.DETAILTYPE(73) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTSTPayables") == null)
                RG.AddCalc("DTSTPayables", RG.DETAILTYPE(75) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTActPayTrd") == null)
                RG.AddCalc("DTActPayTrd", RG.DETAILTYPE(85) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTActPayRelCo") == null)
                RG.AddCalc("DTActPayRelCo", RG.DETAILTYPE(87) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIntPay") == null)
                RG.AddCalc("DTIntPay", RG.DETAILTYPE(91) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTDivPay") == null)
                RG.AddCalc("DTDivPay", RG.DETAILTYPE(92) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAccrdLiabs") == null)
                RG.AddCalc("DTAccrdLiabs", RG.DETAILTYPE(90) * RG.CONV_RATE());
            if (RG.GetCalc("TotAccrdLiab") == null)
                RG.AddCalc("TotAccrdLiab", RG.MACRO(M.TOTAL_ACCRD_LIABS));
            if (RG.GetDetailCalcs("DTBillExcCost") == null)
                RG.AddCalc("DTBillExcCost", RG.DETAILTYPE(102) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTTaxPayable") == null)
                RG.AddCalc("DTTaxPayable", RG.DETAILTYPE(95) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOpCurLiabs") == null)
                RG.AddCalc("DTOpCurLiabs", RG.DETAILTYPE(100) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTNonOpCurLiabs") == null)
                RG.AddCalc("DTNonOpCurLiabs", RG.DETAILTYPE(105) * RG.CONV_RATE());
            /// Non-Current Liabs
            if (RG.GetDetailCalcs("DTNonOpNonCurLiab") == null)
                RG.AddCalc("DTNonOpNonCurLiab", RG.DETAILTYPE(125) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTDueToRelCo") == null)
                RG.AddCalc("DTDueToRelCo", RG.DETAILTYPE(127) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOpNonCurLiab") == null)
                RG.AddCalc("DTOpNonCurLiab", RG.DETAILTYPE(126) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTDefFedIncTax") == null)
                RG.AddCalc("DTDefFedIncTax", RG.DETAILTYPE(115) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTSubordDebtLiab") == null)
                RG.AddCalc("DTSubordDebtLiab", RG.DETAILTYPE(120) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTGrayAreaLiab") == null)
                RG.AddCalc("DTGrayAreaLiab", RG.DETAILTYPE(122) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOtherLiabGrayArea") == null)
                RG.AddCalc("DTOtherLiabGrayArea", RG.DETAILTYPE(123) * RG.CONV_RATE());
            /// Equity
            if (RG.GetDetailCalcs("DTSubDebtEq") == null)
                RG.AddCalc("DTSubDebtEq", RG.DETAILTYPE(134) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTGrayAreaEq") == null)
                RG.AddCalc("DTGrayAreaEq", RG.DETAILTYPE(135) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTComStk") == null)
                RG.AddCalc("DTComStk", RG.DETAILTYPE(130) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOthEq") == null)
                RG.AddCalc("DTOthEq", RG.DETAILTYPE(131) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTTreasStk") == null)
                RG.AddCalc("DTTreasStk", RG.DETAILTYPE(132) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTCurTran") == null)
                RG.AddCalc("DTCurTran", RG.DETAILTYPE(133) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTPrefStk") == null)
                RG.AddCalc("DTPrefStk", RG.DETAILTYPE(129) * RG.CONV_RATE());
            if (RG.GetCalc("WorkingCap") == null)
                RG.AddCalc("WorkingCap", RG.MACRO(M.WORKING_CAPITAL));
            if (RG.GetCalc("TangNetWrthAct") == null)
                RG.AddCalc("TangNetWrthAct", RG.MACRO(M.TANGIBLE_NET_WORTH));

            // SPA - Executive Fin Stmt Calcs 
            if (RG.GetCalc("CashNearCash") == null)
                RG.AddCalc("CashNearCash", RG.MACRO(M.CASH_NEAR_CASH));
            if (RG.GetCalc("OthCurAssets") == null)
                RG.AddCalc("OthCurAssets", RG.MACRO(M.OTHER_CUR_AST));
            if (RG.GetCalc("LTRecAndInv") == null)
                RG.AddCalc("LTRecAndInv", RG.MACRO(M.LT_RECV_AND_INV));
            if (RG.GetCalc("OthNonCurAsts") == null)
                RG.AddCalc("OthNonCurAsts", RG.GetCalc("OpNonCurAst") + RG.GetDetailCalcs("DTIncTaxRcvble").GetTotals(RG) + RG.GetDetailCalcs("DTNonOpNonCurAst").GetTotals(RG));
            if (RG.GetCalc("OdraftsSTPay") == null)
                RG.AddCalc("OdraftsSTPay", RG.MACRO(M.OVRDFTS_ST_PAY));
            if (RG.GetCalc("CPLTDAll") == null)
                RG.AddCalc("CPLTDAll", RG.MACRO(M.CPLTD_FROM_BALANCE_SHEET));
            if (RG.GetCalc("AcctsPayTot") == null)
                RG.AddCalc("AcctsPayTot", (RG.GetDetailCalcs("DTActPayTrd").GetTotals(RG) + RG.GetDetailCalcs("DTActPayRelCo").GetTotals(RG)));
            if (RG.GetCalc("OthCurLiabs") == null)
                RG.AddCalc("OthCurLiabs", (RG.GetDetailCalcs("DTBillExcCost").GetTotals(RG) + RG.GetDetailCalcs("DTNonOpCurLiabs").GetTotals(RG) + RG.GetDetailCalcs("DTOpCurLiabs").GetTotals(RG)));
            if (RG.GetCalc("LTDAndCapLse") == null)
                RG.AddCalc("LTDAndCapLse", RG.GetDetailCalcs("DTLTD").GetTotals(RG) + RG.GetDetailCalcs("DTCapLeaseOb").GetTotals(RG));
            if (RG.GetCalc("ExecOthNonCurLiab") == null)
                RG.AddCalc("ExecOthNonCurLiab", RG.MACRO(M.EXEC_OTH_NON_CUR_LAIBS));

        }

        public void ISCalcs(ReportGenerator RG)
        {
            AddDetailCalcsForType(RG, "DTSales", 145);
            AddDetailCalcsForType(RG, "DTSalesAdj", 147);

            if (RG.GetCalc("NetSalesRev") == null)
                RG.AddCalc("NetSalesRev", RG.MACRO(M.NET_SALES));

            AddDetailCalcsForType(RG, "DTCostOfSales", 150);
            AddDetailCalcsForType(RG, "DTCostOfSalesAdj", 152);

            if (RG.GetCalc("TotCostOfSalesRev") == null)
                RG.AddCalc("TotCostOfSalesRev", RG.MACRO(M.TOT_COST_OF_SALES_REV));

            AddDetailCalcsForType(RG, "DTOperInc", 157);
            AddDetailCalcsForType(RG, "DTSGAExp", 156);
            AddDetailCalcsForType(RG, "DTOffComp", 158);
            AddDetailCalcsForType(RG, "DTLeaseExp", 159);
            AddDetailCalcsForType(RG, "DTDeprec", 160);
            AddDetailCalcsForType(RG, "DTAmort", 162);
            AddDetailCalcsForType(RG, "DTOperExp", 155);
            AddDetailCalcsForType(RG, "DTESOPDiv", 207);
            if (RG.GetCalc("GrossProf") == null)
                RG.AddCalc("GrossProf", RG.MACRO(M.GROSS_PROFIT));
            if (RG.GetCalc("TotOthOpInc") == null)
                RG.AddCalc("TotOthOpInc", RG.TYPE(157) * RG.CONV_RATE());
            if (RG.GetCalc("TotOpExp") == null)
                RG.AddCalc("TotOpExp", RG.MACRO(M.TOTAL_OPERATING_EXP));

            AddDetailCalcsForType(RG, "DTIntInc", 165);
            AddDetailCalcsForType(RG, "DTIntExp", 170);
            AddDetailCalcsForType(RG, "DTIncFromSubs", 182);
            AddDetailCalcsForType(RG, "DTNonCashInc", 175);
            AddDetailCalcsForType(RG, "DTOthInc", 180);
            AddDetailCalcsForType(RG, "DTOthExp", 185);
            AddDetailCalcsForType(RG, "DTGLAssets", 184);
            AddDetailCalcsForType(RG, "DTNonCashExp", 176);
            AddDetailCalcsForType(RG, "DTCapInterest", 171);

            if (RG.GetCalc("NetOpProfit") == null)
                RG.AddCalc("NetOpProfit", RG.MACRO(M.NET_OPERATING_PROFIT));
            if (RG.GetCalc("TotIntExp") == null)
                RG.AddCalc("TotIntExp", RG.MACRO(M.TOT_INT_EXP));
            if (RG.GetCalc("TotIntInc") == null)
                RG.AddCalc("TotIntInc", RG.TYPE(165) * RG.CONV_RATE());
            if (RG.GetCalc("TotIntIncExp") == null)
                RG.AddCalc("TotIntIncExp", RG.MACRO(M.TOT_INT_INC_EXP));
            if (RG.GetCalc("TotOthIncExp") == null)
                RG.AddCalc("TotOthIncExp", RG.MACRO(M.TOT_OTH_INC_EXP));

            AddDetailCalcsForType(RG, "DTIncTax", 190);
            AddDetailCalcsForType(RG, "DTIncTaxCred", 192);
            AddDetailCalcsForType(RG, "DTMinorityInt", 196);
            AddDetailCalcsForType(RG, "DTAftTaxInc", 195);
            AddDetailCalcsForType(RG, "DTAftTaxExp", 200);
            AddDetailCalcsForType(RG, "DTAftTaxNonCash", 197);
            AddDetailCalcsForType(RG, "DTComDiv", 206, true);
            AddDetailCalcsForType(RG, "DTPrefDiv", 208, true);
            AddDetailCalcsForType(RG, "DTStockDiv", 205, true);
            AddDetailCalcsForType(RG, "DTAdjToRE", 210);

            if (RG.GetDetailCalcs("DTMemo0DecIS") == null)
                RG.AddCalc("DTMemo0DecIS", RG.DETAILAND(215, RG.ANDTYPE, 30, RG.ANDCLASS));
            if (RG.GetDetailCalcs("DTMemo2DecIS") == null)
                RG.AddCalc("DTMemo2DecIS", RG.DETAILAND(220, RG.ANDTYPE, 30, RG.ANDCLASS));
            if (RG.GetCalc("ProfB4Tax") == null)
                RG.AddCalc("ProfB4Tax", RG.MACRO(M.PROFIT_BEFORE_TAX));
            if (RG.GetCalc("TotIncTaxExp") == null)
                RG.AddCalc("TotIncTaxExp", RG.MACRO(M.TOT_INC_TAX_EXP));
            if (RG.GetCalc("ProfB4ExtrItem") == null)
                RG.AddCalc("ProfB4ExtrItem", RG.MACRO(M.PROFIT_BEFORE_EXTRAORDINARY_ITEMS));
            if (RG.GetCalc("NetProfit") == null)
                RG.AddCalc("NetProfit", RG.MACRO(M.NET_PROFIT));
            if (RG.GetCalc("EBIT") == null)
                RG.AddCalc("EBIT", RG.MACRO(M.EBIT));
            if (RG.GetCalc("EBITDA") == null)
                RG.AddCalc("EBITDA", RG.MACRO(M.EBITDA));
            if (RG.GetCalc("EBIDA") == null)
                RG.AddCalc("EBIDA", RG.MACRO(M.EBIDA));

            AddDetailCalcsForType(RG, "DTOthCompInc", 201);

            if (RG.GetCalc("CompInc") == null)
                RG.AddCalc("CompInc", RG.GetCalc("NetProfit") + RG.GetDetailCalcs("DTOthCompInc").GetTotals(RG));
            if (RG.GetCalc("SumNetSales") == null)
                RG.AddCalc("SumNetSales", RG.MACRO(M.SUM_NET_SALES));
            if (RG.GetCalc("NonCashIncExp") == null)
                RG.AddCalc("NonCashIncExp", RG.MACRO(M.NON_CASH_INC_EXP));
            if (RG.GetCalc("TotOpExpInc") == null)
                RG.AddCalc("TotOpExpInc", RG.GetCalc("TotOpExp") - RG.GetCalc("TotOthOpInc"));
            if (RG.GetCalc("OthIncExp") == null)
                RG.AddCalc("OthIncExp", RG.MACRO(M.OTHER_INCOME_EXPENSE_NET));

            //SPA - Executive Summary Calculations
            if (RG.GetCalc("ExecNetOpExp") == null)
                RG.AddCalc("ExecNetOpExp", RG.MACRO(M.EXEC_NET_OP_EXP));
            if (RG.GetCalc("ExecDepAmort") == null)
                RG.AddCalc("ExecDepAmort", RG.GetDetailCalcs("DTDeprec").GetTotals(RG) + RG.GetDetailCalcs("DTAmort").GetTotals(RG));
            if (RG.GetCalc("ExecOthIncExp") == null)
                RG.AddCalc("ExecOthIncExp", RG.GetCalc("OthIncExp") + RG.GetDetailCalcs("DTIncFromSubs").GetTotals(RG) + RG.GetDetailCalcs("DTGLAssets").GetTotals(RG));
            if (RG.GetCalc("CashDivAndWDs") == null)
                RG.AddCalc("CashDivAndWDs", RG.GetDetailCalcs("DTComDiv").GetTotals(RG) + RG.GetDetailCalcs("DTPrefDiv").GetTotals(RG));
            //SPA - this exact calc item also exists in Data Test Calcs 
            // must sort this out with Chad
            if (RG.GetCalc("ExtraItems") == null)
                RG.AddCalc("ExtraItems", RG.MACRO(M.EXTRA_ITEMS));

            AccountCalculations = AccountCalculations.OrderBy(ac => RG.Customer.Accounts.IndexOf(ac.Account)).ToList();
        }

        public void RatioCalcs(ReportGenerator RG)
        {
            ///Reference BSCalcs
            BSCalcs(RG);
            ISCalcs(RG);
            if (RG.GetCalc("QuickRatio") == null)
                RG.AddCalc("QuickRatio", RG.MACRO(M.QUICK_RATIO));
            if (RG.GetCalc("CurrRatio") == null)
                RG.AddCalc("CurrRatio", RG.MACRO(M.CURRENT_RATIO));
            if (RG.GetCalc("NetSalesWorkCap") == null)
                RG.AddCalc("NetSalesWorkCap", RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL));
            if (RG.GetCalc("NetWorthAct") == null)
                RG.AddCalc("NetWorthAct", RG.MACRO(M.NET_WORTH));
            if (RG.GetCalc("EffTangNW") == null)
                RG.AddCalc("EffTangNW", RG.MACRO(M.EFF_TANG_NET_WORTH));
            if (RG.GetCalc("DebtWorth") == null)
                RG.AddCalc("DebtWorth", RG.MACRO(M.DEBT_TO_WORTH));
            if (RG.GetCalc("DebtTangWorth") == null)
                RG.AddCalc("DebtTangWorth", RG.MACRO(M.DEBT_TO_TANG_WORTH));
            if (RG.GetCalc("DebtLsSubDbtETW") == null)
                RG.AddCalc("DebtLsSubDbtETW", RG.MACRO(M.DEBT_LESS_SUB_DEBT_LIAB_TO_EFF_TG_WORTH));
            if (RG.GetCalc("BorFndEffTgWth") == null)
                RG.AddCalc("BorFndEffTgWth", RG.MACRO(M.BORROWED_FUNDS_TO_EFF_TANG_WORTH));
            if (RG.GetCalc("FFOInterestExpense") == null)
                RG.AddCalc("FFOInterestExpense", RG.MACRO(M.FFO_INTEREST_TO_INTEREST));
            if (RG.GetCalc("DebtCoverageRatio") == null)
                RG.AddCalc("DebtCoverageRatio", RG.MACRO(M.CASH_FROM_OPS_TO_DEPT));
            if (RG.GetCalc("BorFndToEBITDA") == null)
                RG.AddCalc("BorFndToEBITDA", RG.MACRO(M.BORROWED_FUNDS_TO_EBITDA));
            if (RG.GetCalc("LTDbtNFA") == null)
                RG.AddCalc("LTDbtNFA", RG.MACRO(M.LT_DEBT_TO_NET_FIXED_ASSETS));
            if (RG.GetCalc("TotLiabTotAst") == null)
                RG.AddCalc("TotLiabTotAst", RG.MACRO(M.TOTAL_LIABILITIES_TO_TOTAL_ASSETS));
            if (RG.GetCalc("IntCover") == null)
                RG.AddCalc("IntCover", RG.MACRO(M.INTEREST_COVERAGE));
            if (RG.GetCalc("NetIncDepAmtCPLTD") == null)
                RG.AddCalc("NetIncDepAmtCPLTD", RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD));
            if (RG.GetCalc("NetIncDepAmtCPLTDpp") == null)
                RG.AddCalc("NetIncDepAmtCPLTDpp", RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD_PP));
            if (RG.GetCalc("UCACashFlowCov") == null)
                RG.AddCalc("UCACashFlowCov", RG.MACRO(M.UCA_CASH_FLOW_COVERAGE));
            if (RG.GetCalc("UCACashFlowCPLTDpp") == null)
                RG.AddCalc("UCACashFlowCPLTDpp", RG.MACRO(M.UCA_CASH_FLOW_TO_CPLTD_PP));
            if (RG.GetCalc("EBITDAIntExpCPLTD") == null)
                RG.AddCalc("EBITDAIntExpCPLTD", RG.MACRO(M.EBITDA_TO_INTEREST_EXP_PLUS_CPLTD));
            // KCZ Added Version V 6-11-03
            if (RG.GetCalc("EBITDAIntExpCPLTDpp") == null)
                RG.AddCalc("EBITDAIntExpCPLTDpp", RG.MACRO(M.EBITDA_TO_INTEREST_EXP_PLUS_CPLTD_PP));
            // KCZ Added Version V 6-11-03
            if (RG.GetCalc("OperExpensePercent") == null)
                RG.AddCalc("OperExpensePercent", RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT));
            if (RG.GetCalc("FixedChgCov") == null)
                RG.AddCalc("FixedChgCov", RG.MACRO(M.FIXED_CHG_COV));
            if (RG.GetCalc("ROA") == null)
                RG.AddCalc("ROA", RG.MACRO(M.RETURN_ON_ASSETS));
            if (RG.GetCalc("ROE") == null)
                RG.AddCalc("ROE", RG.MACRO(M.RETURN_ON_EQUITY));
            if (RG.GetCalc("GrossMargin") == null)
                RG.AddCalc("GrossMargin", RG.MACRO(M.GROSS_MARGIN));
            if (RG.GetCalc("OpPrftMgn") == null)
                RG.AddCalc("OpPrftMgn", RG.MACRO(M.OPERATING_PROFIT_MARGIN));
            if (RG.GetCalc("NetMargin") == null)
                RG.AddCalc("NetMargin", RG.MACRO(M.NET_MARGIN));
            if (RG.GetCalc("DivPayRate") == null)
                RG.AddCalc("DivPayRate", RG.MACRO(M.DIVIDEND_PAYOUT_RATE));
            if (RG.GetCalc("EffTaxRate") == null)
                RG.AddCalc("EffTaxRate", RG.MACRO(M.EFFECTIVE_TAX_RATE));        
            if (RG.GetCalc("EBITAMargin") == null)
                RG.AddCalc("EBITAMargin", RG.MACRO(M.EBITA_MARGIN));
            if (RG.GetCalc("EBITAAvgAssets") == null)
                RG.AddCalc("EBITAAvgAssets", RG.MACRO(M.EBITA_AVG_ASSETS));
            //CPF 9/18/03  I forgot to put the conditional check on bad debt reserve for loading
            //of the Grs Ar Days calc.  If Bad Debt is 0 then we should print a zero for Grs Ar Days.
            //if (RG.GetCalc("GrsARDays") == null)
            //	RG.AddCalc("GrsARDays", RG.MACRO(M.GROSS_ACCOUNTS_RECEIVABLE_DAYS));
            Calc BdDbt = RG.TYPE(11);
            if (RG.GetCalc("GrsARDays") == null)
            {
                RG.AddCalc("GrsARDays", new Calc());
                for (int x = 0; x < BdDbt.Count; x++)
                {
                    if (BdDbt[x] != 0)
                        RG.GetCalc("GrsARDays").Add(RG.MACRO(M.GROSS_ACCOUNTS_RECEIVABLE_DAYS)[x]);
                    else
                        RG.GetCalc("GrsARDays").Add(0);
                }
            }

            //CPF 9/9/03  I originally had this logic in the macro, but it was causing problems
            //in UP because this conditional logic is only to keep Gross and Net AR days from being the same.
            Calc ANRTrdLessBdDbt = RG.TYPE(10) - RG.TYPE(11);
            if (RG.GetCalc("NetARDays") == null)
            {
                RG.AddCalc("NetARDays", new Calc());
                for (int x = 0; x < ANRTrdLessBdDbt.Count; x++)
                {
                    if (ANRTrdLessBdDbt[x] > 0)
                        RG.GetCalc("NetARDays").Add(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[x]);
                    else
                        RG.GetCalc("NetARDays").Add(RG.MACRO(M.ERR_STRING)[x]);
                }
            }

            if (RG.GetDetailCalcs("RawMatDOH") == null)
                RG.AddCalc("RawMatDOH", ((RG.DETAILTYPE(15) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR())) * 365);
            if (RG.GetDetailCalcs("WrkInPrgDOH") == null)
                RG.AddCalc("WrkInPrgDOH", ((RG.DETAILTYPE(16) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR())) * 365);
            if (RG.GetDetailCalcs("FinGdsDOH") == null)
                RG.AddCalc("FinGdsDOH", ((RG.DETAILTYPE(17) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR())) * 365);
            if (RG.GetCalc("InvDOH") == null)
                RG.AddCalc("InvDOH", RG.MACRO(M.INVENTORY_DAYS_ON_HAND));
            if (RG.GetCalc("ActPayDOH") == null)
                RG.AddCalc("ActPayDOH", RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS));
            if (RG.GetCalc("NetSalesTotAst") == null)
                RG.AddCalc("NetSalesTotAst", RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS));
            if (RG.GetCalc("NetSalesNetWrth") == null)
                RG.AddCalc("NetSalesNetWrth", RG.MACRO(M.NET_SALES_TO_NET_WORTH));
            if (RG.GetCalc("NetSalesNetFxdAst") == null)
                RG.AddCalc("NetSalesNetFxdAst", RG.MACRO(M.NET_SALES_TO_NET_FIXED_ASSETS));
            if (RG.GetCalc("PftB4TxsTotAst") == null)
                RG.AddCalc("PftB4TxsTotAst", RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS));
            if (RG.GetCalc("CAPEXDepExp") == null)
                RG.AddCalc("CAPEXDepExp", RG.MACRO(M.CAPEX_DEPRECIATION_EXPENSE));
            if (RG.GetCalc("RevenueVolatility") == null)
                RG.AddCalc("RevenueVolatility", RG.MACRO(M.REVENUE_VOLATILITY));
            if (RG.GetCalc("CashToNetSales") == null)
                RG.AddCalc("CashToNetSales", RG.MACRO(M.CASH_TO_NET_SALES));
            if (RG.GetCalc("Log10NetSales") == null)
                RG.AddCalc("Log10NetSales", RG.MACRO(M.LOG_10_NET_SALES));
            if (RG.GetCalc("TotAstGwth") == null)
                RG.AddCalc("TotAstGwth", RG.MACRO(M.TOTAL_ASSETS_GROWTH));
            if (RG.GetCalc("TotLiabGwth") == null)
                RG.AddCalc("TotLiabGwth", RG.MACRO(M.TOTAL_LIABILITIES_GROWTH));
            if (RG.GetCalc("NetWrthGwth") == null)
                RG.AddCalc("NetWrthGwth", RG.MACRO(M.NET_WORTH_GROWTH));
            if (RG.GetCalc("NetSalesGwth") == null)
                RG.AddCalc("NetSalesGwth", RG.MACRO(M.NET_SALES_GROWTH));
            if (RG.GetCalc("OpProfitGwth") == null)
                RG.AddCalc("OpProfitGwth", RG.MACRO(M.OPERATING_PROFIT_GROWTH));
            if (RG.GetCalc("NetProfitGwth") == null)
                RG.AddCalc("NetProfitGwth", RG.MACRO(M.NET_PROFIT_GROWTH));
            if (RG.GetCalc("SusGrowth") == null)
                RG.AddCalc("SusGrowth", RG.MACRO(M.SUSTAINABLE_GROWTH));
            if (RG.GetCalc("OpExpSales") == null)
                RG.AddCalc("OpExpSales", RG.GetCalc("TotOpExp") % RG.GetCalc("NetSalesRev"));
            if (RG.GetCalc("PBTSales") == null)
                RG.AddCalc("PBTSales", RG.GetCalc("ProfB4Tax") % RG.GetCalc("NetSalesRev"));
            Calc NetFxdAstsLag = RG.MODIFYCALC(RG.GetCalc("NetFxdAsts"), RG.LAG);
            if (RG.GetCalc("ExpCapExpend") == null)
                RG.AddCalc("ExpCapExpend", RG.MACRO(M.EXP_CAP_EXPEND));

            if (RG.GetCalc("DebtToBookCapital") == null)
                RG.AddCalc("DebtToBookCapital", RG.MACRO(M.DEPT_TO_BOOK_CAP));
            if (RG.GetCalc("InputCashFlowCov") == null)
                RG.AddCalc("InputCashFlowCov", RG.MACRO(M.INPUT_CASH_FLOW_COVERAGE));

            if(RG.GetCalc("RcfToAdjustedDebt") == null)
                RG.AddCalc("RcfToAdjustedDebt", RG.MACRO(M.RCF_TO_ADJUSTED_DEBT));
            if (RG.GetCalc("RcfToNetAdjustedDebt") == null)
                RG.AddCalc("RcfToNetAdjustedDebt", RG.MACRO(M.RCF_TO_NET_ADJUSTED_DEBT));
            if (RG.GetCalc("RcfCAPEXToAdjustedDebt") == null)
                RG.AddCalc("RcfCAPEXToAdjustedDebt", RG.MACRO(M.RCF_CAPEX_TO_ADJUSTED_DEBT));
            if (RG.GetCalc("FcfToAdjustedDebt") == null)
                RG.AddCalc("FcfToAdjustedDebt", RG.MACRO(M.FCF_TO_ADJUSTED_DEBT));
            if (RG.GetCalc("FcfToNetAdjustedDebt") == null)
                RG.AddCalc("FcfToNetAdjustedDebt", RG.MACRO(M.FCF_TO_NET_ADJUSTED_DEBT));
            if (RG.GetCalc("FfoToAdjustedDebt") == null)
                RG.AddCalc("FfoToAdjustedDebt", RG.MACRO(M.FFO_TO_ADJUSTED_DEBT));
            if (RG.GetCalc("FfoToNetAdjustedDebt") == null)
                RG.AddCalc("FfoToNetAdjustedDebt", RG.MACRO(M.FFO_TO_NET_ADJUSTED_DEBT));
            if (RG.GetCalc("CAPEXToCfo") == null)
                RG.AddCalc("CAPEXToCfo", RG.MACRO(M.CAPEX_TO_CFO));
            if (RG.GetCalc("CFOToProfitBefExtra") == null)
                RG.AddCalc("CFOToProfitBefExtra", RG.MACRO(M.CFO_TO_PROFIT_BEFORE_EXTRA));
        }
        public void CredCompCalcs(ReportGenerator RG)
        {
            if (RG.GetCalc("WCAct") == null)
            {
                RG.AddCalc("WCAct", new Calc());
                RG.AddCalc("WCStnd", new Calc());
                RG.AddCalc("WCVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8000).Count; i++)
                    if (RG.ACCOUNT(8000)[i] != 0)
                    {
                        RG.GetCalc("WCAct").Add(RG.MACRO(M.WORKING_CAPITAL)[i]);
                        RG.GetCalc("WCStnd").Add(RG.ACCOUNT(8000)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("WCVar").Add(RG.GetCalc("WCAct")[i] - RG.GetCalc("WCStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("WCAct").Add(0);
                        RG.GetCalc("WCStnd").Add(0);
                        RG.GetCalc("WCVar").Add(0);
                    }
            }

            if (RG.GetCalc("QRAct") == null)
            {
                RG.AddCalc("QRAct", new Calc());
                RG.AddCalc("QRStnd", new Calc());
                RG.AddCalc("QRVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8100).Count; i++)
                    if (RG.ACCOUNT(8100)[i] != 0)
                    {
                        RG.GetCalc("QRAct").Add(RG.MACRO(M.QUICK_RATIO)[i]);
                        RG.GetCalc("QRStnd").Add(RG.ACCOUNT(8100)[i]);
                        RG.GetCalc("QRVar").Add(RG.GetCalc("QRAct")[i] - RG.GetCalc("QRStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("QRAct").Add(0);
                        RG.GetCalc("QRStnd").Add(0);
                        RG.GetCalc("QRVar").Add(0);
                    }
            }

            if (RG.GetCalc("CRAct") == null)
            {
                RG.AddCalc("CRAct", new Calc());
                RG.AddCalc("CRStnd", new Calc());
                RG.AddCalc("CRVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8050).Count; i++)
                    if (RG.ACCOUNT(8050)[i] != 0)
                    {
                        RG.GetCalc("CRAct").Add(RG.MACRO(M.CURRENT_RATIO)[i]);
                        RG.GetCalc("CRStnd").Add(RG.ACCOUNT(8050)[i]);
                        RG.GetCalc("CRVar").Add(RG.GetCalc("CRAct")[i] - RG.GetCalc("CRStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("CRAct").Add(0);
                        RG.GetCalc("CRStnd").Add(0);
                        RG.GetCalc("CRVar").Add(0);
                    }
            }

            if (RG.GetCalc("DTWVar1") == null)
            {
                RG.AddCalc("DTWVar1", new Calc());
                for (int i = 0; i < RG.MACRO(M.DEBT_TO_TANG_WORTH).Count; i++)
                    if (RG.MACRO(M.DEBT_TO_WORTH)[i] >= 0)
                        RG.GetCalc("DTWVar1").Add(0);
                    else
                        RG.GetCalc("DTWVar1").Add(1);

                RG.AddCalc("DTWVar2", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8150).Count; i++)
                    if (RG.ACCOUNT(8150)[i] >= 0)
                        RG.GetCalc("DTWVar2").Add(0);
                    else
                        RG.GetCalc("DTWVar2").Add(2);

                RG.AddCalc("DTWVar3", RG.GetCalc("DTWVar1") + RG.GetCalc("DTWVar2"));

                RG.AddCalc("DTWVar4", new Calc());
                for (int i = 0; i < RG.GetCalc("DTWVar3").Count; i++)
                    if ((RG.GetCalc("DTWVar3")[i] == 0) || (RG.GetCalc("DTWVar3")[i] == 3))
                        RG.GetCalc("DTWVar4").Add(RG.ACCOUNT(8150)[i] - RG.MACRO(M.DEBT_TO_TANG_WORTH)[i]);
                    else if ((RG.GetCalc("DTWVar3")[i] == 1) || (RG.GetCalc("DTWVar3")[i] == 2))
                        RG.GetCalc("DTWVar4").Add(RG.MACRO(M.DEBT_TO_TANG_WORTH)[i] - RG.ACCOUNT(8150)[i]);
                    else
                        RG.GetCalc("DTWVar4").Add(0);

                RG.AddCalc("DTWAct", new Calc());
                RG.AddCalc("DTWStnd", new Calc());
                RG.AddCalc("DTWVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8150).Count; i++)
                    if (RG.ACCOUNT(8150)[i] != 0)
                    {
                        RG.GetCalc("DTWAct").Add(RG.MACRO(M.DEBT_TO_TANG_WORTH)[i]);
                        RG.GetCalc("DTWStnd").Add(RG.ACCOUNT(8150)[i]);
                        RG.GetCalc("DTWVar").Add(RG.GetCalc("DTWVar4")[i]);
                    }
                    else
                    {
                        RG.GetCalc("DTWAct").Add(0);
                        RG.GetCalc("DTWStnd").Add(0);
                        RG.GetCalc("DTWVar").Add(0);
                    }
            }

            if (RG.GetCalc("ICAct") == null)
            {
                RG.AddCalc("ICAct", new Calc());
                RG.AddCalc("ICStnd", new Calc());
                RG.AddCalc("ICVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8170).Count; i++)
                    if (RG.ACCOUNT(8170)[i] != 0)
                    {
                        RG.GetCalc("ICAct").Add(RG.MACRO(M.INTEREST_COVERAGE)[i]);
                        RG.GetCalc("ICStnd").Add(RG.ACCOUNT(8170)[i]);
                        RG.GetCalc("ICVar").Add(RG.GetCalc("ICAct")[i] - RG.GetCalc("ICStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("ICAct").Add(0);
                        RG.GetCalc("ICStnd").Add(0);
                        RG.GetCalc("ICVar").Add(0);
                    }
            }

            if (RG.GetCalc("NIDAAct") == null)
            {
                RG.AddCalc("NIDAAct", new Calc());
                RG.AddCalc("NIDAStnd", new Calc());
                RG.AddCalc("NIDAVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8200).Count; i++)
                    if (RG.ACCOUNT(8200)[i] != 0)
                    {
                        RG.GetCalc("NIDAAct").Add(RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[i]);
                        RG.GetCalc("NIDAStnd").Add(RG.ACCOUNT(8200)[i]);
                        RG.GetCalc("NIDAVar").Add(RG.GetCalc("NIDAAct")[i] - RG.GetCalc("NIDAStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("NIDAAct").Add(0);
                        RG.GetCalc("NIDAStnd").Add(0);
                        RG.GetCalc("NIDAVar").Add(0);
                    }
            }

            if (RG.GetCalc("CEAct") == null)
            {
                RG.AddCalc("CEAct", new Calc());
                RG.AddCalc("CEStnd", new Calc());
                RG.AddCalc("CEVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8250).Count; i++)
                    if (RG.ACCOUNT(8250)[i] != 0)
                    {
                        RG.GetCalc("CEAct").Add(-1 * RG.MACRO(M.CAPITAL_EXPENDITURES)[i]);
                        RG.GetCalc("CEStnd").Add(RG.ACCOUNT(8250)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("CEVar").Add(RG.GetCalc("CEStnd")[i] - RG.GetCalc("CEAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("CEAct").Add(0);
                        RG.GetCalc("CEStnd").Add(0);
                        RG.GetCalc("CEVar").Add(0);
                    }
            }

            if (RG.GetCalc("NMAct") == null)
            {
                RG.AddCalc("NMAct", new Calc());
                RG.AddCalc("NMStnd", new Calc());
                RG.AddCalc("NMVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8300).Count; i++)
                    if (RG.ACCOUNT(8300)[i] != 0)
                    {
                        RG.GetCalc("NMAct").Add(RG.MACRO(M.NET_MARGIN)[i]);
                        RG.GetCalc("NMStnd").Add(RG.ACCOUNT(8300)[i]);
                        RG.GetCalc("NMVar").Add(RG.GetCalc("NMAct")[i] - RG.GetCalc("NMStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("NMAct").Add(0);
                        RG.GetCalc("NMStnd").Add(0);
                        RG.GetCalc("NMVar").Add(0);
                    }
            }

            if (RG.GetCalc("ROEAct") == null)
            {
                RG.AddCalc("ROEAct", new Calc());
                RG.AddCalc("ROEStnd", new Calc());
                RG.AddCalc("ROEVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8350).Count; i++)
                    if (RG.ACCOUNT(8350)[i] != 0)
                    {
                        RG.GetCalc("ROEAct").Add(RG.MACRO(M.RETURN_ON_EQUITY)[i]);
                        RG.GetCalc("ROEStnd").Add(RG.ACCOUNT(8350)[i]);
                        RG.GetCalc("ROEVar").Add(RG.GetCalc("ROEAct")[i] - RG.GetCalc("ROEStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("ROEAct").Add(0);
                        RG.GetCalc("ROEStnd").Add(0);
                        RG.GetCalc("ROEVar").Add(0);
                    }
            }

            if (RG.GetCalc("ROAAct") == null)
            {
                RG.AddCalc("ROAAct", new Calc());
                RG.AddCalc("ROAStnd", new Calc());
                RG.AddCalc("ROAVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8400).Count; i++)
                    if (RG.ACCOUNT(8400)[i] != 0)
                    {
                        RG.GetCalc("ROAAct").Add(RG.MACRO(M.RETURN_ON_ASSETS)[i]);
                        RG.GetCalc("ROAStnd").Add(RG.ACCOUNT(8400)[i]);
                        RG.GetCalc("ROAVar").Add(RG.GetCalc("ROAAct")[i] - RG.GetCalc("ROAStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("ROAAct").Add(0);
                        RG.GetCalc("ROAStnd").Add(0);
                        RG.GetCalc("ROAVar").Add(0);
                    }
            }

            if (RG.GetCalc("NARDAct") == null)
            {
                RG.AddCalc("NARDAct", new Calc());
                RG.AddCalc("NARDStnd", new Calc());
                RG.AddCalc("NARDVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8450).Count; i++)
                    if (RG.ACCOUNT(8450)[i] != 0)
                    {
                        RG.GetCalc("NARDAct").Add(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[i]);
                        RG.GetCalc("NARDStnd").Add(RG.ACCOUNT(8450)[i]);
                        RG.GetCalc("NARDVar").Add(RG.GetCalc("NARDStnd")[i] - RG.GetCalc("NARDAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("NARDAct").Add(0);
                        RG.GetCalc("NARDStnd").Add(0);
                        RG.GetCalc("NARDVar").Add(0);
                    }
            }

            if (RG.GetCalc("IDAct") == null)
            {
                RG.AddCalc("IDAct", new Calc());
                RG.AddCalc("IDStnd", new Calc());
                RG.AddCalc("IDVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8500).Count; i++)
                    if (RG.ACCOUNT(8500)[i] != 0)
                    {
                        RG.GetCalc("IDAct").Add(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[i]);
                        RG.GetCalc("IDStnd").Add(RG.ACCOUNT(8500)[i]);
                        RG.GetCalc("IDVar").Add(RG.GetCalc("IDStnd")[i] - RG.GetCalc("IDAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("IDAct").Add(0);
                        RG.GetCalc("IDStnd").Add(0);
                        RG.GetCalc("IDVar").Add(0);
                    }
            }

            if (RG.GetCalc("APDAct") == null)
            {
                RG.AddCalc("APDAct", new Calc());
                RG.AddCalc("APDStnd", new Calc());
                RG.AddCalc("APDVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8550).Count; i++)
                    if (RG.ACCOUNT(8550)[i] != 0)
                    {
                        RG.GetCalc("APDAct").Add(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[i]);
                        RG.GetCalc("APDStnd").Add(RG.ACCOUNT(8550)[i]);
                        RG.GetCalc("APDVar").Add(RG.GetCalc("APDStnd")[i] - RG.GetCalc("APDAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("APDAct").Add(0);
                        RG.GetCalc("APDStnd").Add(0);
                        RG.GetCalc("APDVar").Add(0);
                    }
            }

            if (RG.GetCalc("OCAct") == null)
            {
                RG.AddCalc("OCAct", new Calc());
                RG.AddCalc("OCStnd", new Calc());
                RG.AddCalc("OCVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8600).Count; i++)
                    if (RG.ACCOUNT(8600)[i] != 0)
                    {
                        RG.GetCalc("OCAct").Add(RG.TYPE(158)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("OCStnd").Add(RG.ACCOUNT(8600)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("OCVar").Add(RG.GetCalc("OCStnd")[i] - RG.GetCalc("OCAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("OCAct").Add(0);
                        RG.GetCalc("OCStnd").Add(0);
                        RG.GetCalc("OCVar").Add(0);
                    }
            }

            if (RG.GetCalc("LREAct") == null)
            {
                RG.AddCalc("LREAct", new Calc());
                RG.AddCalc("LREStnd", new Calc());
                RG.AddCalc("LREVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8650).Count; i++)
                    if (RG.ACCOUNT(8650)[i] != 0)
                    {
                        RG.GetCalc("LREAct").Add(RG.TYPE(159)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("LREStnd").Add(RG.ACCOUNT(8650)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("LREVar").Add(RG.GetCalc("LREStnd")[i] - RG.GetCalc("LREAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("LREAct").Add(0);
                        RG.GetCalc("LREStnd").Add(0);
                        RG.GetCalc("LREVar").Add(0);
                    }
            }

            if (RG.GetCalc("CDWAct") == null)
            {
                RG.AddCalc("CDWAct", new Calc());
                RG.AddCalc("CDWStnd", new Calc());
                RG.AddCalc("CDWVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8700).Count; i++)
                    if (RG.ACCOUNT(8700)[i] != 0)
                    {
                        RG.GetCalc("CDWAct").Add(RG.MACRO(M.CASH_DIVIDENDS_WITHDRAWALS)[i]);
                        RG.GetCalc("CDWStnd").Add(RG.ACCOUNT(8700)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("CDWVar").Add(RG.GetCalc("CDWStnd")[i] - RG.GetCalc("CDWAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("CDWAct").Add(0);
                        RG.GetCalc("CDWStnd").Add(0);
                        RG.GetCalc("CDWVar").Add(0);
                    }
            }

            if (RG.GetCalc("SDRAct") == null)
            {
                RG.AddCalc("SDRAct", new Calc());
                RG.AddCalc("SDRStnd", new Calc());
                RG.AddCalc("SDRVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8750).Count; i++)
                    if (RG.ACCOUNT(8750)[i] != 0)
                    {
                        RG.GetCalc("SDRAct").Add(RG.MACRO(M.SUBORD_DEBT_REPAYMENT)[i]);
                        RG.GetCalc("SDRStnd").Add(RG.ACCOUNT(8750)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("SDRVar").Add(RG.GetCalc("SDRStnd")[i] - RG.GetCalc("SDRAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("SDRAct").Add(0);
                        RG.GetCalc("SDRStnd").Add(0);
                        RG.GetCalc("SDRVar").Add(0);
                    }
            }

            if (RG.GetCalc("NDAct") == null)
            {
                RG.AddCalc("NDAct", new Calc());
                RG.AddCalc("NDStnd", new Calc());
                RG.AddCalc("NDVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8800).Count; i++)
                    if (RG.ACCOUNT(8800)[i] != 0)
                    {
                        RG.GetCalc("NDAct").Add(RG.MACRO(M.NEW_DEBT)[i]);
                        RG.GetCalc("NDStnd").Add(RG.ACCOUNT(8800)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("NDVar").Add(RG.GetCalc("NDStnd")[i] - RG.GetCalc("NDAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("NDAct").Add(0);
                        RG.GetCalc("NDStnd").Add(0);
                        RG.GetCalc("NDVar").Add(0);
                    }
            }

            if (RG.GetCalc("TNWAct") == null)
            {
                RG.AddCalc("TNWAct", new Calc());
                RG.AddCalc("TNWStnd", new Calc());
                RG.AddCalc("TNWVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8850).Count; i++)
                    if (RG.ACCOUNT(8850)[i] != 0)
                    {
                        RG.GetCalc("TNWAct").Add(RG.MACRO(M.TANGIBLE_NET_WORTH)[i]);
                        RG.GetCalc("TNWStnd").Add(RG.ACCOUNT(8850)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("TNWVar").Add(RG.GetCalc("TNWAct")[i] - RG.GetCalc("TNWStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("TNWAct").Add(0);
                        RG.GetCalc("TNWStnd").Add(0);
                        RG.GetCalc("TNWVar").Add(0);
                    }
            }

            if (RG.GetCalc("CBAct") == null)
            {
                RG.AddCalc("CBAct", new Calc());
                RG.AddCalc("CBStnd", new Calc());
                RG.AddCalc("CBVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8880).Count; i++)
                    if (RG.ACCOUNT(8880)[i] != 0)
                    {
                        RG.GetCalc("CBAct").Add(RG.MACRO(M.CASH_BALANCE)[i]);
                        RG.GetCalc("CBStnd").Add(RG.ACCOUNT(8880)[i] * RG.CONV_RATE()[i]);
                        RG.GetCalc("CBVar").Add(RG.GetCalc("CBAct")[i] - RG.GetCalc("CBStnd")[i]);
                    }
                    else
                    {
                        RG.GetCalc("CBAct").Add(0);
                        RG.GetCalc("CBStnd").Add(0);
                        RG.GetCalc("CBVar").Add(0);
                    }
            }

            if (RG.GetCalc("SGAct") == null)
            {
                RG.AddCalc("SGAct", new Calc());
                RG.AddCalc("SGStnd", new Calc());
                RG.AddCalc("SGVar", new Calc());
                for (int i = 0; i < RG.ACCOUNT(8900).Count; i++)
                    if (RG.ACCOUNT(8900)[i] != 0)
                    {
                        RG.GetCalc("SGAct").Add(RG.MACRO(M.NET_SALES_GROWTH)[i]);
                        RG.GetCalc("SGStnd").Add(RG.ACCOUNT(8900)[i]);
                        RG.GetCalc("SGVar").Add(RG.GetCalc("SGStnd")[i] - RG.GetCalc("SGAct")[i]);
                    }
                    else
                    {
                        RG.GetCalc("SGAct").Add(0);
                        RG.GetCalc("SGStnd").Add(0);
                        RG.GetCalc("SGVar").Add(0);
                    }
            }
        }
        public void QuickProjCalcs(ReportGenerator RG)
        // SPA - QP Calcs do not include ConvRate therefore recoding here
        {
            if (RG.GetCalc("QPSalesGrowth") == null)
                RG.AddCalc("QPSalesGrowth", RG.MACRO(M.HIST_CALC_SALES_GROWTH));
            if (RG.GetCalc("QPGrossMargin") == null)
                RG.AddCalc("QPGrossMargin", RG.MACRO(M.HIST_CALC_GROSS_MARGIN));
            if (RG.GetCalc("QPOpExp") == null)
                RG.AddCalc("QPOpExp", RG.MACRO(M.HIST_CALC_OP_EXP_SALES_EXCL_DEPR));
            if (RG.GetCalc("QPARDays") == null)
                RG.AddCalc("QPARDays", RG.MACRO(M.HIST_CALC_NET_ACCTS_RECV_DAYS));
            if (RG.GetCalc("QPInvDays") == null)
                RG.AddCalc("QPInvDays", RG.MACRO(M.HIST_CALC_INV_DAYS_ON_HAND_EXCL_DEPR));
            if (RG.GetCalc("QPAPDays") == null)
                RG.AddCalc("QPAPDays", RG.MACRO(M.HIST_CALC_ACCTS_PAY_DAYS_EXCL_DEPR));
            if (RG.GetCalc("QPCashToSGACogs") == null)
                RG.AddCalc("QPCashToSGACogs", RG.MACRO(M.HIST_CALC_CASH_TO_SGA_PLUS_COGS));
            if (RG.GetCalc("QPCapSpending") == null)
                RG.AddCalc("QPCapSpending", RG.MACRO(M.HIST_CALC_CHG_NET_FXD_ASTS_TO_CAP_SPEND));
            if (RG.GetCalc("QPMiscBSGrowth") == null)
                RG.AddCalc("QPMiscBSGrowth", RG.MACRO(M.HIST_CALC_MISC_BS_GRWTH_RATE));
            if (RG.GetCalc("QPDeprecRate") == null)
                RG.AddCalc("QPDeprecRate", RG.MACRO(M.HIST_CALC_DEPRECIATION_RATE));
            if (RG.GetCalc("QPEffTaxRate") == null)
                RG.AddCalc("QPEffTaxRate", RG.MACRO(M.HIST_CALC_EFFECTIVE_TAX_RATE));
            if (RG.GetCalc("QPDivPayoutRate") == null)
                RG.AddCalc("QPDivPayoutRate", RG.MACRO(M.HIST_CALC_DIV_PAYOUT_RATE));
            if (RG.GetCalc("QPIntExpRate") == null)
                RG.AddCalc("QPIntExpRate", RG.MACRO(M.HIST_CALC_INT_EXP_RATE));
            if (RG.GetCalc("QPIntIncRate") == null)
                RG.AddCalc("QPIntIncRate", RG.MACRO(M.HIST_CALC_INT_INC_RATE));
        }

        public void UCACFCalcs(ReportGenerator RG)
        {
            ///THIS SET OF CALCS USES THE DETAILED RECONCILIATION CALCS
            ///MAKE SURE TO LOAD THESE CALCS BEFORE USING THE UCA ONES.
            if (RG.GetDetailCalcs("DTCashSales") == null)
                RG.AddCalc("DTCashSales", RG.DETAILAND(15, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTSalesAdjCF") == null)
                RG.AddCalc("DTSalesAdjCF", -1 * RG.DETAILAND(20, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgRcvbls") == null)
                RG.AddCalc("DTChgRcvbls", (RG.DETAILAND(5, RG.ANDCLASS, 15, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 15, RG.ANDFLOW) * RG.CONV_RATE()));
            ///CPF 01/12/06 Log 898:  Split "Due from Rel Co - CP" into it's own flow.
            if (RG.GetDetailCalcs("DTChgDueFmRelCoCP") == null)
                RG.AddCalc("DTChgDueFmRelCoCP", (RG.DETAILAND(5, RG.ANDCLASS, 16, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 16, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgBadDbtRes") == null)
                RG.AddCalc("DTChgBadDbtRes", (RG.DETAILAND(5, RG.ANDCLASS, 20, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 20, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTBadDbtRes") == null)
                RG.AddCalc("DTBadDbtRes", -1 * RG.DETAILAND(21, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgCstExcBill") == null)
                RG.AddCalc("DTChgCstExcBill", (RG.DETAILFLOW(30, RG.LAG) * RG.CONV_RATE(RG.LAG)) - (RG.DETAILFLOW(30) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgBillExcCst") == null)
                RG.AddCalc("DTChgBillExcCst", (RG.DETAILAND(15, RG.ANDCLASS, 15, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 15, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgDefRev") == null)
                RG.AddCalc("DTChgDefRev", (RG.DETAILAND(20, RG.ANDCLASS, 15, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(20, RG.ANDCLASS, 15, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("CashCollFromSales") == null)
                RG.AddCalc("CashCollFromSales", RG.MACRO(M.CASH_COLLECTED_FROM_SALES));
            if (RG.GetDetailCalcs("DTCostOfSalesCF") == null)
                RG.AddCalc("DTCostOfSalesCF", -1 * RG.DETAILAND(25, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgInventory") == null)
                RG.AddCalc("DTChgInventory", (RG.DETAILAND(25, RG.ANDFLOW, 5, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(25, RG.ANDFLOW, 5, RG.ANDCLASS) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgSupplies") == null)
                RG.AddCalc("DTChgSupplies", (RG.DETAILAND(5, RG.ANDCLASS, 35, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 35, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgPurchases") == null)
                RG.AddCalc("DTChgPurchases", (RG.DETAILAND(25, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(25, RG.ANDFLOW, 15, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            ///CPF 01/12/06 Log 898:  Split "Due to Rel Co - CP" into it's own flow.
            if (RG.GetDetailCalcs("DTChgDueToRelCoCP") == null)
                RG.AddCalc("DTChgDueToRelCoCP", (RG.DETAILAND(26, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(26, RG.ANDFLOW, 15, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("CashPaidToSupp") == null)
                RG.AddCalc("CashPaidToSupp", RG.MACRO(M.CASH_PAID_TO_SUPPLIERS));
            if (RG.GetCalc("CashFromTradAct") == null)
                RG.AddCalc("CashFromTradAct", RG.MACRO(M.CASH_FROM_TRADING_ACTIVITIES));
            if (RG.GetDetailCalcs("DTSellExp") == null)
                RG.AddCalc("DTSellExp", -1 * RG.DETAILFLOW(55) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOpExp") == null)
                RG.AddCalc("DTOpExp", -1 * RG.DETAILAND(30, RG.ANDCLASS, 35, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgPrePds") == null)
                RG.AddCalc("DTChgPrePds", (RG.DETAILFLOW(40, RG.LAG) * RG.CONV_RATE(RG.LAG)) - (RG.DETAILFLOW(40) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgOvrdrfts") == null)
                RG.AddCalc("DTChgOvrdrfts", (RG.DETAILFLOW(37) * RG.CONV_RATE()) - (RG.DETAILFLOW(37, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgActPayOth") == null)
                RG.AddCalc("DTChgActPayOth", (RG.DETAILAND(27, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(27, RG.ANDFLOW, 15, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgCurOp") == null)
                RG.AddCalc("DTChgCurOp", (RG.DETAILAND(15, RG.ANDCLASS, 35, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 35, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("CashPdOpCost") == null)
                RG.AddCalc("CashPdOpCost", RG.MACRO(M.CASH_PAID_FOR_OPERATING_COSTS));
            if (RG.GetCalc("CashAfterOps") == null)
                RG.AddCalc("CashAfterOps", RG.MACRO(M.CASH_AFTER_OPERATIONS));
            ///The following expression does NOT exist in the current MMAS model.  However,
            ///the calculation remains for users who have not upgraded and may have added accts
            ///to this combination.
            if (RG.GetDetailCalcs("DTOthIncAccts") == null)
                RG.AddCalc("DTOthIncAccts", RG.DETAILAND(30, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE());
            ///Normal MMAS resumes here.
            if (RG.GetDetailCalcs("DTOthIncAccts2") == null)
            {
                 RG.AddCalc("DTOthIncAccts2", RG.DETAILAND(30, RG.ANDCLASS, 87, RG.ANDFLOW) * RG.CONV_RATE());
                //DetailCalcs DTOthIncAccts2 = new DetailCalcs();
                //DTOthIncAccts2.Add(RG.DETAILACCOUNT(7040)[0]);
                //DTOthIncAccts2.Add(RG.DETAILACCOUNT(7050)[0]);
                //RG.AddCalc("DTOthIncAccts2", DTOthIncAccts2*RG.CONV_RATE());
            }
               
            if (RG.GetDetailCalcs("DTOpInc") == null)
                RG.AddCalc("DTOpInc", RG.DETAILAND(30, RG.ANDCLASS, 45, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIntIncome") == null)
                RG.AddCalc("DTIntIncome", RG.DETAILAND(30, RG.ANDCLASS, 85, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTOthExpAct") == null)
            {
                RG.AddCalc("DTOthExpAct", -1 * RG.DETAILAND(30, RG.ANDCLASS, 115, RG.ANDFLOW) * RG.CONV_RATE());
                //DetailCalcs DTOthExpAct = new DetailCalcs();
                //DTOthExpAct.Add(RG.DETAILACCOUNT(7090)[0]);
                //DTOthExpAct.Add(RG.DETAILACCOUNT(7100)[0]);
                //DTOthExpAct.Add(RG.DETAILACCOUNT(7120)[0]);
                //RG.AddCalc("DTOthExpAct", -1 * DTOthExpAct * RG.CONV_RATE());
            }

            if (RG.GetDetailCalcs("DTAsstRvltn") == null)
            {
                DetailCalcs DTAsstRvltn = new DetailCalcs();
                //DetailCalcs bCalc = RG.DETAILACCOUNT(9953) * RG.CONV_RATE();
                //DetailCalcs aCalc = -1 * RG.DETAILACCOUNT(9954) * RG.CONV_RATE();
                
                DetailCalcs bCalc = RG.DETAILAND(30, RG.ANDCLASS, 86, RG.ANDFLOW) * RG.CONV_RATE();
                DetailCalcs aCalc = -1 * RG.DETAILAND(30, RG.ANDCLASS, 114, RG.ANDFLOW) * RG.CONV_RATE();
                for (int i = 0; i < bCalc.Count; i++ )
                    DTAsstRvltn.Add(bCalc[i]);
                for (int i = 0; i < aCalc.Count; i++)
                    DTAsstRvltn.Add(aCalc[i]);
                RG.AddCalc("DTAsstRvltn", DTAsstRvltn);
            }
            //Add  Gain(Loss) on Asset Revaluation
            if (RG.GetCalc("GainLossAssRev") == null)
                RG.AddCalc("GainLossAssRev", RG.MACRO(M.GAIN_LOSS_ON_ASS_REV));
            //Add  Gain(Loss) on Asset Revaluation (-)
            if (RG.GetCalc("GainLossAssRev2") == null)
                RG.AddCalc("GainLossAssRev2", -1 * RG.MACRO(M.GAIN_LOSS_ON_ASS_REV)); 

            if (RG.GetDetailCalcs("DTChgCurOpAst") == null)
                RG.AddCalc("DTChgCurOpAst", (RG.DETAILAND(5, RG.ANDCLASS, 50, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 50, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgLTOpAst") == null)
                RG.AddCalc("DTChgLTOpAst", (RG.DETAILAND(10, RG.ANDCLASS, 50, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(10, RG.ANDCLASS, 50, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgCurOpLiab") == null)
                RG.AddCalc("DTChgCurOpLiab", (RG.DETAILAND(15, RG.ANDCLASS, 50, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 50, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgOpNonCurLiab") == null)
                RG.AddCalc("DTChgOpNonCurLiab", (RG.DETAILAND(20, RG.ANDCLASS, 50, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(20, RG.ANDCLASS, 50, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTIncomeTaxes") == null)
                RG.AddCalc("DTIncomeTaxes", -1 * RG.DETAILAND(30, RG.ANDCLASS, 65, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTIncomeTaxCred") == null)
                RG.AddCalc("DTIncomeTaxCred", RG.DETAILFLOW(66) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgIncTaxRcv") == null)
                RG.AddCalc("DTChgIncTaxRcv", (RG.DETAILAND(5, RG.ANDCLASS, 65, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 65, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgDefIncTaxRec") == null)
                RG.AddCalc("DTChgDefIncTaxRec", (RG.DETAILAND(10, RG.ANDCLASS, 65, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(10, RG.ANDCLASS, 65, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgIncTaxPay") == null)
                RG.AddCalc("DTChgIncTaxPay", (RG.DETAILAND(15, RG.ANDCLASS, 65, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 65, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgDefFedIncTax") == null)
                RG.AddCalc("DTChgDefFedIncTax", (RG.DETAILAND(20, RG.ANDCLASS, 65, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(20, RG.ANDCLASS, 65, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("OthIncExpTxPd") == null)
                RG.AddCalc("OthIncExpTxPd", RG.MACRO(M.OTHER_INC_EXP_AND_TAXES_PAID));
            if (RG.GetCalc("NetCashAfterOps") == null)
                RG.AddCalc("NetCashAfterOps", RG.MACRO(M.NET_CASH_AFTER_OPERATIONS));
            if (RG.GetDetailCalcs("DTInterestExp") == null)
                RG.AddCalc("DTInterestExp", -1 * RG.DETAILAND(30, RG.ANDCLASS, 70, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgIntPay") == null)
                RG.AddCalc("DTChgIntPay", (RG.DETAILAND(15, RG.ANDCLASS, 70, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 70, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            //SPA - DTOthDeduct has no accounts assigned to this class and flow combo
            // as a result it gives errors when added into a Calc
            if (RG.GetDetailCalcs("DTOthDeduct") == null)
                RG.AddCalc("DTOthDeduct", -1 * RG.DETAILAND(30, RG.ANDCLASS, 130, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTDividends") == null)
                RG.AddCalc("DTDividends", -1 * RG.DETAILAND(32, RG.ANDCLASS, 130, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgDivPay") == null)
                RG.AddCalc("DTChgDivPay", (RG.DETAILAND(15, RG.ANDCLASS, 130, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 130, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("CashPdDivInt") == null)
                RG.AddCalc("CashPdDivInt", RG.MACRO(M.CASH_PAID_FOR_DIVIDENDS_AND_INTEREST));
            if (RG.GetCalc("NetCashInc") == null)
                RG.AddCalc("NetCashInc", RG.MACRO(M.NET_CASH_INCOME));
            ///10-3-02 This is where projections are blowing up when we run UCA.
            if (RG.GetCalc("DTCurPtnLTD") == null)
                RG.AddCalc("DTCurPtnLTD", -1 * (RG.DETAILFLOW(75, RG.LAG) * RG.YEAR() * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILFLOW(75, RG.CPLTD) * RG.CONV_RATE()));
            if (RG.GetCalc("CurPtnLTD") == null)
                //				RG.AddCalc("CurPtnLTD", -1 * (RG.FLOW(75, RG.LAG) * RG.YEAR() * RG.CONV_RATE(RG.LAG)) - 
                //					(RG.FLOW(75, RG.CPLTD) * RG.CONV_RATE()));
                RG.AddCalc("CurPtnLTD", RG.MACRO(M.CPLTD_FROM_UCA_CASH_FLOW));
            //???SPA - replace CurPtnLTD with macro CPLTD_FROM_UCA_CASH_FLOW
            if (RG.GetCalc("CashAftDebtAmrt") == null)
                //RG.AddCalc("CashAftDebtAmrt", RG.GetCalc("NetCashInc") + RG.GetCalc("CurPtnLTD"));
                RG.AddCalc("CashAftDebtAmrt", RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION));
            //???SPA - replace CashAftDebtAmrt with macro CASH_AFTER_DEBT_AMORTIZATION
            if (RG.GetDetailCalcs("DTProcFrmAstSale") == null)
                RG.AddCalc("DTProcFrmAstSale", RG.DETAILFLOW(96) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTCapExpend") == null)
                RG.AddCalc("DTCapExpend", -1 * RG.DETAILFLOW(97) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTCapInterestStat") == null)
                RG.AddCalc("DTCapInterestStat", -1 * RG.DETAILFLOW(98) * RG.CONV_RATE());
            if (RG.GetCalc("Flows96,97,98") == null)
                RG.AddCalc("Flows96,97,98", RG.FLOW(96) + RG.FLOW(97) + RG.FLOW(98));
            if (RG.GetDetailCalcs("DTChgFxdAsts") == null)
                RG.AddCalc("DTChgFxdAsts", (RG.DETAILAND(90, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(90, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()));
            RG.AddCalc("DTCFChgFxdAsts", (RG.DETAILAND(90, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                (RG.DETAILAND(90, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgReserves") == null)
                RG.AddCalc("DTChgReserves", (RG.DETAILAND(90, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(90, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTCFChgFxdAsts"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTChgReserves"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetDetailCalcs("DTChgAccDepr") == null)
                RG.AddCalc("DTChgAccDepr", (RG.DETAILAND(95, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(95, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            RG.AddCalc("DTCFChgAccDepr", (RG.DETAILAND(95, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()) -
                (RG.DETAILAND(95, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTCFChgAccDepr"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetDetailCalcs("DTDepreciation") == null)
                RG.AddCalc("DTDepreciation", -1 * RG.DETAILAND(95, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            RG.AddCalc("DTCFDepreciation", -1 * RG.DETAILAND(95, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTCFDepreciation"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetDetailCalcs("DTGnLsAstSale") == null)
                RG.AddCalc("DTGnLsAstSale", RG.DETAILAND(30, RG.ANDCLASS, 90, RG.ANDFLOW) * RG.CONV_RATE());
            RG.AddCalc("DTCFGnLsAstSale", RG.DETAILAND(30, RG.ANDCLASS, 90, RG.ANDFLOW) * RG.CONV_RATE());
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTCFGnLsAstSale"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetDetailCalcs("DTCapInterestUCA") == null)
                RG.AddCalc("DTCapInterestUCA", RG.DETAILAND(30, RG.ANDCLASS, 91, RG.ANDFLOW) * RG.CONV_RATE());
            RG.AddCalc("DTCFCapInterestUCA", RG.DETAILAND(30, RG.ANDCLASS, 91, RG.ANDFLOW) * RG.CONV_RATE());
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTCFCapInterestUCA"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        dc.Values[i] = 0;
                }
            }

            if (RG.GetCalc("ChgNetFxdAsts") == null)
                //			{
                //				RG.AddCalc("ChgNetFxdAsts", new Calc());
                //				RG.AddCalc("Flows96,97,98", RG.FLOW(96) + RG.FLOW(97) + RG.FLOW(98));
                //				for (int i = 0; i < RG.GetCalc("Flows96,97,98").Count; i++) 
                //					if (RG.GetCalc("Flows96,97,98")[i] != 0)
                //						RG.GetCalc("ChgNetFxdAsts").Add(RG.GetDetailCalcs("DTProcFrmAstSale").GetTotals(RG)[i] + RG.GetDetailCalcs("DTCapExpend").GetTotals(RG)[i] + RG.GetDetailCalcs("DTCapInterestStat").GetTotals(RG)[i]);
                //					else
                //						RG.GetCalc("ChgNetFxdAsts").Add(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS)[i]);
                //			}
                RG.AddCalc("ChgNetFxdAsts", RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF));
            //???SPA - replace ChgNetFxdAsts with macro CHG_IN_NET_FIXED_ASSETS_CF
            if (RG.GetDetailCalcs("DTIncFrmSubsid") == null)
                RG.AddCalc("DTIncFrmSubsid", RG.DETAILAND(30, RG.ANDCLASS, 110, RG.ANDFLOW) * RG.CONV_RATE());
            ///CPF 02/01/06 Log 1611:  When we move account "Loans to Related Co - CP" to Flow 80 (Log 1040), that means 
            ///that no accounts where left in flow 81.  As a result, subtracting two details calcs with no accounts caused
            ///a crash.
            if (RG.GetDetailCalcs("DTChgSTInvRelCo") == null)
            {
                ///CPF 02/01/06 Log 1611:  If there are accounts in this AND, proceed as normal
                if (RG.DETAILAND(5, RG.ANDCLASS, 81, RG.ANDFLOW).Count > 0)
                    RG.AddCalc("DTChgSTInvRelCo", (RG.DETAILAND(5, RG.ANDCLASS, 81, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                        (RG.DETAILAND(5, RG.ANDCLASS, 81, RG.ANDFLOW) * RG.CONV_RATE()));
                else
                    ///CPF 02/01/06 if not, then just load the normal AND, just so PrintDetail doesn' crash.
                    RG.AddCalc("DTChgSTInvRelCo", RG.DETAILAND(5, RG.ANDCLASS, 81, RG.ANDFLOW) * RG.CONV_RATE());
            }
            if (RG.GetDetailCalcs("DTChgSTInvest") == null)
                RG.AddCalc("DTChgSTInvest", (RG.DETAILAND(5, RG.ANDCLASS, 80, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(5, RG.ANDCLASS, 80, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgInvest") == null)
                RG.AddCalc("DTChgInvest", (RG.DETAILAND(10, RG.ANDCLASS, 80, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(10, RG.ANDCLASS, 80, RG.ANDFLOW) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTCompInc") == null)
                RG.AddCalc("DTCompInc", RG.DETAILFLOW(117) * RG.CONV_RATE());
            if (RG.GetCalc("ChgInvestments") == null)
                //				RG.AddCalc("ChgInvestments", RG.GetDetailCalcs("DTIncFrmSubsid").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvest").GetTotals(RG) + 
                //					RG.GetDetailCalcs("DTChgInvest").GetTotals(RG) + RG.GetDetailCalcs("DTCompInc").GetTotals(RG) + 
                //					RG.GetCalc("LINE(214)") + RG.GetCalc("LINE(212)") + RG.GetDetailCalcs("DTChgSTInvRelCo").GetTotals(RG));
                RG.AddCalc("ChgInvestments", RG.MACRO(M.CHG_IN_INVESTMENTS));
            //???SPA - replace ChgInvestments with macro CHG_IN_INVESTMENTS
            if (RG.GetDetailCalcs("DTChgIntang") == null)
                RG.AddCalc("DTChgIntang", (RG.DETAILAND(100, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(100, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgAccAmrt") == null)
                RG.AddCalc("DTChgAccAmrt", (RG.DETAILAND(120, RG.ANDFLOW, 10, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(120, RG.ANDFLOW, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTAmortization") == null)
                RG.AddCalc("DTAmortization", -1 * RG.DETAILAND(120, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("ChgNetIntang") == null)
                //RG.AddCalc("ChgNetIntang", RG.GetDetailCalcs("DTChgIntang").GetTotals(RG) + RG.GetDetailCalcs("DTChgAccAmrt").GetTotals(RG) + RG.GetDetailCalcs("DTAmortization").GetTotals(RG));
                RG.AddCalc("ChgNetIntang", RG.MACRO(M.CHG_IN_INTANG_CF));
            //???SPA - replace ChgNetIntang with macro CHG_IN_INTANG_CF
            if (RG.GetCalc("CashPdPlntInvest") == null)
                //RG.AddCalc("CashPdPlntInvest", RG.GetCalc("ChgNetFxdAsts") + RG.GetCalc("ChgInvestments") + RG.GetCalc("ChgNetIntang"));
                RG.AddCalc("CashPdPlntInvest", RG.MACRO(M.CASH_PAID_PLANT_INVEST));
            //???SPA - replace CashPdPlntInvest with macro CASH_PAID_PLANT_INVEST
            if (RG.GetDetailCalcs("DTExtrIncAftTxInc") == null)
                RG.AddCalc("DTExtrIncAftTxInc", RG.DETAILAND(30, RG.ANDCLASS, 88, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAftTxIncome") == null)
                RG.AddCalc("DTAftTxIncome", -1 * RG.DETAILAND(30, RG.ANDCLASS, 116, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTNonCashIncome") == null)
                RG.AddCalc("DTNonCashIncome", RG.DETAILFLOW(60) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTNonCashExpense") == null)
                RG.AddCalc("DTNonCashExpense", -1 * RG.DETAILFLOW(61) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTAftTxNnCashIncExp") == null)
                RG.AddCalc("DTAftTxNnCashIncExp", RG.DETAILFLOW(67) * RG.CONV_RATE());
            if (RG.GetCalc("ExtraordNonCashItems") == null)
                //				RG.AddCalc("ExtraordNonCashItems", RG.GetDetailCalcs("DTExtrIncAftTxInc").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxIncome").GetTotals(RG) + 
                //					RG.GetDetailCalcs("DTNonCashIncome").GetTotals(RG) + RG.GetDetailCalcs("DTNonCashExpense").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxNnCashIncExp").GetTotals(RG));
                RG.AddCalc("ExtraordNonCashItems", RG.MACRO(M.EXTRA_NON_CASH_ITEMS));
            //???SPA - replace ExtraordNonCashItems with macro EXTRA_NON_CASH_ITEMS
            if (RG.GetCalc("FinancingSurplus") == null)
                //RG.AddCalc("FinancingSurplus", RG.GetCalc("CashAftDebtAmrt") + RG.GetCalc("CashPdPlntInvest") + RG.GetCalc("ExtraordNonCashItems"));
                RG.AddCalc("FinancingSurplus", RG.MACRO(M.FIN_SURPLUS));
            //???SPA - replace FinancingSurplus with macro FIN_SURPLUS
            if (RG.GetDetailCalcs("DTChgSTBorr") == null)
                RG.AddCalc("DTChgSTBorr", (RG.DETAILAND(15, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 105, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgNonOpCurLiabs") == null)
                RG.AddCalc("DTChgNonOpCurLiabs", (RG.DETAILAND(15, RG.ANDCLASS, 106, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(15, RG.ANDCLASS, 106, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("ChgLTD") == null)
                //				RG.AddCalc("ChgLTD", RG.FLOW(125) * RG.CONV_RATE() - RG.FLOW(125, RG.LAG) * RG.CONV_RATE(RG.LAG) + 
                //					(RG.FLOW(75) * RG.CONV_RATE() - RG.FLOW(75, RG.LAG) * RG.CONV_RATE(RG.LAG)) +
                //					RG.FLOW(75, RG.LAG) * RG.YEAR() * RG.CONV_RATE(RG.LAG) + RG.FLOW(75, RG.CPLTD) * RG.CONV_RATE());
                RG.AddCalc("ChgLTD", RG.MACRO(M.CHG_IN_LTD));
            //???SPA - replace ChgLTD with macro CHG_IN_LTD
            if (RG.GetDetailCalcs("DTChgDefDebt") == null)
                RG.AddCalc("DTChgDefDebt", (RG.DETAILAND(20, RG.ANDCLASS, 107, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(20, RG.ANDCLASS, 107, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTDefIntExp") == null)
                RG.AddCalc("DTDefIntExp", -1 * RG.DETAILAND(30, RG.ANDCLASS, 107, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgDueRelCo") == null)
                RG.AddCalc("DTChgDueRelCo", (RG.DETAILAND(20, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(20, RG.ANDCLASS, 105, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgSubordDef") == null)
                RG.AddCalc("DTChgSubordDef", (RG.DETAILAND(22, RG.ANDCLASS, 108, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(22, RG.ANDCLASS, 108, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgSubordDbtLiab") == null)
                RG.AddCalc("DTChgSubordDbtLiab", (RG.DETAILAND(22, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(22, RG.ANDCLASS, 105, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgOthLiabGA") == null)
                RG.AddCalc("DTChgOthLiabGA", (RG.DETAILAND(22, RG.ANDCLASS, 106, RG.ANDFLOW) * RG.CONV_RATE()) -
                    (RG.DETAILAND(22, RG.ANDCLASS, 106, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("ChgCapLsNCInc") == null)
                //				RG.AddCalc("ChgCapLsNCInc", RG.GetCalc("LINE(280)") + (0 - RG.AND(102, RG.ANDFLOW, 32, RG.ANDCLASS) - 
                //					RG.AND(102, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(104, RG.ANDFLOW, 30, RG.ANDCLASS)) * RG.CONV_RATE());
                RG.AddCalc("ChgCapLsNCInc", RG.MACRO(M.CHG_CAP_LS_NCINC));
            //???SPA - replace ChgCapLsNCInc with macro CHG_CAP_LS_NCINC
            if (RG.GetDetailCalcs("DTChgCapItems") == null)
                RG.AddCalc("DTChgCapItems", (RG.DETAILAND(102, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(102, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgTreasStk") == null)
                RG.AddCalc("DTChgTreasStk", (RG.DETAILAND(105, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) -
                    (RG.DETAILAND(105, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()));
            if (RG.GetDetailCalcs("DTChgSubDebtEq") == null)
                RG.AddCalc("DTChgSubDebtEq", (RG.DETAILAND(102, RG.ANDFLOW, 22, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgSubDefer") == null)
                RG.AddCalc("DTChgSubDefer", (RG.DETAILAND(109, RG.ANDFLOW, 22, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgCurrTrans") == null)
                RG.AddCalc("DTChgCurrTrans", (RG.DETAILAND(5, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(5, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTDivStock") == null)
                RG.AddCalc("DTDivStock", -1 * RG.DETAILAND(102, RG.ANDFLOW, 32, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTDivOth") == null)
                RG.AddCalc("DTDivOth", -1 * RG.DETAILAND(102, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTMinInt") == null)
                RG.AddCalc("DTMinInt", -1 * RG.DETAILAND(104, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("TotExtFinanc") == null)
                //				RG.AddCalc("TotExtFinanc", RG.GetDetailCalcs("DTChgSTBorr").GetTotals(RG) + RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG) + RG.GetCalc("ChgLTD") + 
                //					RG.GetCalc("ChgCapLsNCInc") + RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG) + RG.GetDetailCalcs("DTChgSubordDbtLiab").GetTotals(RG) + 
                //					RG.GetDetailCalcs("DTChgDefDebt").GetTotals(RG) + RG.GetDetailCalcs("DTChgSubordDef").GetTotals(RG) +
                //					RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG) + RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG));
                RG.AddCalc("TotExtFinanc", RG.MACRO(M.TOT_EXT_FINANCING));
            //???SPA - replace TotExtFinanc with macro TOT_EXT_FINANCING
            if (RG.GetCalc("CashAftFinanc") == null)
                //RG.AddCalc("CashAftFinanc", RG.GetCalc("FinancingSurplus") + RG.GetCalc("TotExtFinanc"));
                RG.AddCalc("CashAftFinanc", RG.MACRO(M.CASH_AFTER_FINANCING));
            //???SPA - replace CashAftFinanc with macro CASH_AFTER_FINANCING
            if (RG.GetCalc("CFAdjstItems") == null)
                //				RG.AddCalc("CFAdjstItems", (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) + RG.AND(5, RG.ANDCLASS, 7, RG.ANDFLOW, RG.LAG)) * RG.CONV_RATE(RG.LAG) - 
                //					(RG.GetCalc("CashAftFinanc") + (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) + RG.AND(5, RG.ANDCLASS, 7, RG.ANDFLOW, RG.LAG)) * RG.CONV_RATE(RG.LAG) - 
                //					(RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW) + RG.AND(5, RG.ANDCLASS, 7, RG.ANDFLOW)) * RG.CONV_RATE()));
                RG.AddCalc("CFAdjstItems", RG.MACRO(M.CF_ADJ_ITEMS));
            //???SPA - replace CFAdjstItems with macro CF_ADJ_ITEMS
            if (RG.GetDetailCalcs("DTCashCF") == null)
                RG.AddCalc("DTCashCF", RG.DETAILAND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetDetailCalcs("DTNearCashCF") == null)
                RG.AddCalc("DTNearCashCF", RG.DETAILAND(5, RG.ANDCLASS, 7, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("CashAdjustment") == null)
                //				RG.AddCalc("CashAdjustment", 0 - (RG.GetCalc("CashAftFinanc") + (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) + 
                //					RG.AND(5, RG.ANDCLASS, 7, RG.ANDFLOW, RG.LAG)) * RG.CONV_RATE(RG.LAG) - (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW) + 
                //					RG.AND(5, RG.ANDCLASS, 7, RG.ANDFLOW)) * RG.CONV_RATE()));
                RG.AddCalc("CashAdjustment", RG.MACRO(M.CASH_ADJUSTMENT));
            //???SPA - replace CashAdjustment with macro CASH_ADJUSTMENT
            if (RG.GetCalc("EndCashEquiv") == null)
                //				RG.AddCalc("EndCashEquiv", RG.GetCalc("CashAftFinanc") + RG.GetDetailCalcs("DTCashCF").GetTotals(RG) + 
                //					RG.GetCalc("CashAdjustment") + RG.GetDetailCalcs("DTNearCashCF").GetTotals(RG));
                RG.AddCalc("EndCashEquiv", RG.MACRO(M.END_CASH_EQUIV));
            //???SPA - replace EndCashEquiv with macro END_CASH_EQUIV


            //SPA - Calculations for Sum UCA Cash Flow
            // might consider moving these to own calc set that calls UCACFCalcs
            if (RG.GetCalc("CFNetSales") == null)
                //RG.AddCalc("CFNetSales", RG.GetDetailCalcs("DTCashSales").GetTotals(RG)+RG.GetDetailCalcs("DTSalesAdjCF").GetTotals(RG));
                RG.AddCalc("CFNetSales", RG.MACRO(M.CF_NET_SALES));
            //???SPA - replace CFNetSales with macro CF_NET_SALES
            if (RG.GetCalc("CFChgARNet") == null)
                //RG.AddCalc("CFChgARNet", RG.GetDetailCalcs("DTChgRcvbls").GetTotals(RG)+RG.GetDetailCalcs("DTChgBadDbtRes").GetTotals(RG)+RG.GetDetailCalcs("DTBadDbtRes").GetTotals(RG));
                RG.AddCalc("CFChgARNet", RG.MACRO(M.CF_CHG_AR_NET));
            //???SPA - replace CFChgARNet with macro CF_CHG_AR_NET
            if (RG.GetCalc("ChgBillVsCosts") == null)
                //RG.AddCalc("ChgBillVsCosts", RG.GetDetailCalcs("DTChgCstExcBill").GetTotals(RG)+RG.GetDetailCalcs("DTChgBillExcCst").GetTotals(RG));
                RG.AddCalc("ChgBillVsCosts", RG.MACRO(M.CHG_BILL_VS_COSTS));
            //???SPA - replace ChgBillVsCosts with macro CHG_BILL_VS_COSTS
            if (RG.GetCalc("ChgTotInventory") == null)
                //RG.AddCalc("ChgTotInventory", RG.GetDetailCalcs("DTChgInventory").GetTotals(RG)+RG.GetDetailCalcs("DTChgSupplies").GetTotals(RG));
                RG.AddCalc("ChgTotInventory", RG.MACRO(M.CHG_TOT_INVENTORY));
            //???SPA - replace ChgTotInventory with macro CHG_TOT_INVENTORY
            if (RG.GetCalc("CFSGAExp") == null)
                //RG.AddCalc("CFSGAExp", RG.GetDetailCalcs("DTSellExp").GetTotals(RG)+RG.GetDetailCalcs("DTOpExp").GetTotals(RG));
                RG.AddCalc("CFSGAExp", RG.MACRO(M.CF_SGA_EXP));
            //???SPA - replace CFSGAExp with macro CF_SGA_EXP
            if (RG.GetCalc("ChgAccrlsOthPay") == null)
                //RG.AddCalc("ChgAccrlsOthPay", RG.GetDetailCalcs("DTChgActPayOth").GetTotals(RG)+RG.GetDetailCalcs("DTChgCurOp").GetTotals(RG));
                RG.AddCalc("ChgAccrlsOthPay", RG.MACRO(M.CHG_ACCRLS_OTH_PAY));
            //???SPA - replace ChgAccrlsOthPay with macro CHG_ACCRLS_OTH_PAY

            //SPA - this calculation should include "DTOthIncAccts"
            // but since this class and flow combo does not exist anymore it was giving me errors when I used it this calculation
            if (RG.GetCalc("CFOthIncExp") == null)
                //			{
                //				if (RG.GetDetailCalcs("DTOthIncAccts").Count == 0)
                //					RG.AddCalc("CFOthIncExp", RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG)+RG.GetDetailCalcs("DTOpInc").GetTotals(RG)+RG.GetDetailCalcs("DTIntIncome").GetTotals(RG)+RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG));
                //				else
                //					RG.AddCalc("CFOthIncExp", RG.GetDetailCalcs("DTOthIncAccts").GetTotals(RG)+RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG)+RG.GetDetailCalcs("DTOpInc").GetTotals(RG)+RG.GetDetailCalcs("DTIntIncome").GetTotals(RG)+RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG));
                //			}
                RG.AddCalc("CFOthIncExp", RG.MACRO(M.CF_OTH_INC_EXP));
            //???SPA - replace CFOthIncExp with macro CF_OTH_INC_EXP
            //SPA - we previously had to do the if logic above, but now the macro seems to handle this

            if (RG.GetCalc("ChgOthAstsLiabs") == null)
                //RG.AddCalc("ChgOthAstsLiabs", RG.GetDetailCalcs("DTChgCurOpAst").GetTotals(RG)+RG.GetDetailCalcs("DTChgLTOpAst").GetTotals(RG)+RG.GetDetailCalcs("DTChgCurOpLiab").GetTotals(RG)+RG.GetDetailCalcs("DTChgOpNonCurLiab").GetTotals(RG));
                RG.AddCalc("ChgOthAstsLiabs", RG.MACRO(M.CHG_OTH_ASTS_LIABS));
            //???SPA - replace ChgOthAstsLiabs with macro CHG_OTH_ASTS_LIABS
            if (RG.GetCalc("CFTaxesPIC") == null)
                //RG.AddCalc("CFTaxesPIC", RG.GetDetailCalcs("DTIncomeTaxes").GetTotals(RG)+RG.GetDetailCalcs("DTIncomeTaxCred").GetTotals(RG)+RG.GetDetailCalcs("DTChgIncTaxRcv").GetTotals(RG)+RG.GetDetailCalcs("DTChgDefIncTaxRec").GetTotals(RG)+RG.GetDetailCalcs("DTChgIncTaxPay").GetTotals(RG)+RG.GetDetailCalcs("DTChgDefFedIncTax").GetTotals(RG));
                RG.AddCalc("CFTaxesPIC", RG.MACRO(M.CF_TAXES_PIC));
            //???SPA - replace CFTaxesPIC with macro CF_TAXES_PIC

            // SPA - This CFDivsPIC calc should include DTOthDeduct but that item gives errors as no accounts are valid for its class and flow combo
            if (RG.GetCalc("CFDivsPIC") == null)
                //			{
                //				if (RG.GetDetailCalcs("DTOthDeduct").Count == 0)
                //					RG.AddCalc("CFDivsPIC", RG.GetDetailCalcs("DTDividends").GetTotals(RG)+RG.GetDetailCalcs("DTChgDivPay").GetTotals(RG));
                //				else
                //					RG.AddCalc("CFDivsPIC", RG.GetDetailCalcs("DTDividends").GetTotals(RG)+RG.GetDetailCalcs("DTChgDivPay").GetTotals(RG)+RG.GetDetailCalcs("DTOthDeduct").GetTotals(RG));
                //			}
                RG.AddCalc("CFDivsPIC", RG.MACRO(M.CF_DIV_PIC));
            //???SPA - replace CFDivsPIC with macro CF_DIV_PIC

            if (RG.GetCalc("ChgSTLoansOthPay") == null)
                //RG.AddCalc("ChgSTLoansOthPay", RG.GetDetailCalcs("DTChgSTBorr").GetTotals(RG)+RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG));
                RG.AddCalc("ChgSTLoansOthPay", RG.MACRO(M.CHG_ST_LOANS_OTH_PAY));
            //???SPA - replace ChgSTLoansOthPay with macro CHG_ST_LOANS_OTH_PAY
            if (RG.GetCalc("ChgLTSubDebt") == null)
                //RG.AddCalc("ChgLTSubDebt", RG.GetCalc("ChgLTD")+RG.GetDetailCalcs("DTChgDefDebt").GetTotals(RG)+RG.GetDetailCalcs("DTChgSubordDbtLiab").GetTotals(RG));
                RG.AddCalc("ChgLTSubDebt", RG.MACRO(M.CHG_LT_SUB_DEBT));
            //???SPA - replace ChgLTSubDebt with macro CHG_LT_SUB_DEBT
            if (RG.GetCalc("ChgGrayAreaLiab") == null)
                //RG.AddCalc("ChgGrayAreaLiab", RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG)+RG.GetDetailCalcs("DTChgSubordDef").GetTotals(RG));
                RG.AddCalc("ChgGrayAreaLiab", RG.MACRO(M.CHG_GRAY_AREA_LIAB));
            //???SPA - replace ChgGrayAreaLiab with macro CHG_GRAY_AREA_LIAB
            if (RG.GetCalc("CFBegCashEquiv") == null)
                //RG.AddCalc("CFBegCashEquiv", RG.GetDetailCalcs("DTCashCF").GetTotals(RG)+RG.GetDetailCalcs("DTNearCashCF").GetTotals(RG));
                RG.AddCalc("CFBegCashEquiv", RG.MACRO(M.CF_BEG_CASH_EQUIV));
            //???SPA - replace CFBegCashEquiv with macro CF_BEG_CASH_EQUIV
            if (RG.GetCalc("ECFOthCashExp") == null)
                //RG.AddCalc("ECFOthCashExp", RG.GetCalc("CFOthIncExp")+RG.GetCalc("ChgOthAstsLiabs"));
                RG.AddCalc("ECFOthCashExp", RG.MACRO(M.ECF_OTH_CASH_EXP));
            //???SPA - replace ECFOthCashExp with macro ECF_OTH_CASH_EXP
            if (RG.GetCalc("ECFIntPIC") == null)
                //RG.AddCalc("ECFIntPIC", RG.GetDetailCalcs("DTInterestExp").GetTotals(RG)+RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG));
                RG.AddCalc("ECFIntPIC", RG.MACRO(M.ECF_INT_PIC));
            //???SPA - replace ECFIntPIC with macro ECF_INT_PIC
            if (RG.GetCalc("ECFChgInvestIntang") == null)
                //RG.AddCalc("ECFChgInvestIntang", RG.GetCalc("ChgInvestments")+RG.GetCalc("ChgNetIntang"));
                RG.AddCalc("ECFChgInvestIntang", RG.MACRO(M.ECF_CHG_INVEST_INTANG));
            //???SPA - replace ECFChgInvestIntang with macro ECF_CHG_INVEST_INTANG            

        }
        public void DetReconCalcs(ReportGenerator RG)
        {
            FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();
            if (RG.GetCalc("LINE(202)") == null)
                RG.AddCalc("LINE(202)", RG.ACCOUNT(9950) - RG.ACCOUNT(9950, RG.LAG));
            if (RG.GetCalc("LINE(203)") == null)
                if (RG.GetCalc("LINE(202)").NonZero)
                    RG.AddCalc("LINE(203)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(203)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(207)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILAND(103, RG.ANDFLOW, 30, RG.ANDCLASS)) + FormatCommands.DetailCount(RG, RG.DETAILAND(103, RG.ANDFLOW, 32, RG.ANDCLASS)) > 0)
                {
                    RG.AddCalc("LINE(207)", new Calc(1, RG.Statements.Count));
                    RG.AddCalc("LINE(217)", RG.DETAILAND(103, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
                    RG.AddCalc("LINE(219)", RG.DETAILAND(103, RG.ANDFLOW, 32, RG.ANDCLASS) * RG.CONV_RATE());
                }
                else
                {
                    RG.AddCalc("LINE(207)", new Calc(0, RG.Statements.Count));
                }
            }
            if (RG.GetCalc("LINE(209)") == null)
                RG.AddCalc("LINE(209)", RG.GetCalc("LINE(203)") + RG.GetCalc("LINE(207)"));
            if (RG.GetCalc("LINE(204)") == null)
                if (RG.GetCalc("LINE(209)").NonZero)
                    RG.AddCalc("LINE(204)", RG.AND(103, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG));
                else
                    RG.AddCalc("LINE(204)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(206)") == null)
                //	RG.AddCalc("LINE(206)", ((RG.CONV_RATE() - RG.CONV_RATE(RG.LAG)) / RG.CONV_RATE(RG.LAG)) * RG.GetCalc("LINE(204)"));
                RG.AddCalc("LINE(206)", RG.MACRO(M.ADJ_CHG_EXCHANG_RATE));
            //???SPA - replace LINE(206) with macro ADJ_CHG_EXCHANG_RATE
            if (RG.GetCalc("LINE(208)") == null)
                //				if (RG.GetDetailCalcs("LINE(217)") != null & RG.GetDetailCalcs("LINE(219)") != null)
                //				{
                //					if (RG.GetDetailCalcs("LINE(217)").Count != 0)
                //						RG.AddCalc("LINE(208)",  RG.GetCalc("LINE(204)") + RG.GetCalc("LINE(206)") + RG.GetDetailCalcs("LINE(217)").GetTotals(RG) + RG.GetDetailCalcs("LINE(219)").GetTotals(RG));
                //					else
                //						RG.AddCalc("LINE(208)",  RG.GetCalc("LINE(204)") + RG.GetCalc("LINE(206)") + RG.GetDetailCalcs("LINE(219)").GetTotals(RG));
                //				}
                //				else
                //					RG.AddCalc("LINE(208)",  RG.GetCalc("LINE(204)") + RG.GetCalc("LINE(206)"));
                RG.AddCalc("LINE(208)", RG.MACRO(M.BEG_RE_RESTATED));
            //???SPA - replace LINE(208) with macro BEG_RE_RESTATED
            if (RG.GetCalc("LINE(210)") == null)
                //				if (RG.GetCalc("LINE(204)").NonZero)
                //					RG.AddCalc("LINE(210)", new Calc(0, RG.Statements.Count));
                //				else
                //					RG.AddCalc("LINE(210)", RG.AND(103, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("LINE(210)", RG.MACRO(M.BEG_RE));
            //???SPA - replace LINE(210) with macro BEG_RE
            if (RG.GetCalc("LINE(214)") == null)
                //RG.AddCalc("LINE(214)", ((RG.CONV_RATE() - RG.CONV_RATE(RG.LAG)) / RG.CONV_RATE(RG.LAG)) * (RG.TYPE(141, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("LINE(214)", RG.MACRO(M.OCI_ADJ_FROM_EXCHANGE_RATE));
            //???SPA - replace LINE(214) with macro OCI_ADJ_FROM_EXCHANGE_RATE
            if (RG.GetCalc("LINE(212)") == null)
                //				RG.AddCalc("LINE(212)", RG.TYPE(141)* RG.CONV_RATE() - RG.TYPE(141, RG.LAG) * RG.CONV_RATE(RG.LAG) - 
                //					RG.TYPE(201) * RG.CONV_RATE() - RG.GetCalc("LINE(214)"));
                RG.AddCalc("LINE(212)", RG.MACRO(M.OCI_RECLASS_ADJ));
            //???SPA - replace LINE(212) with macro OCI_RECLASS_ADJ
            if (RG.GetDetailCalcs("LINE(216)") == null)
                RG.AddCalc("LINE(216)", -1 * RG.DETAILAND(130, RG.ANDFLOW, 32, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(218)") == null)
                RG.AddCalc("LINE(218)", -1 * RG.DETAILAND(102, RG.ANDFLOW, 32, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(220)") == null)
                //				RG.AddCalc("LINE(220)", RG.GetCalc("LINE(208)") + RG.GetCalc("LINE(210)") + RG.MACRO(M.NET_PROFIT) + 
                //					RG.GetDetailCalcs("LINE(216)").GetTotals(RG) + RG.GetDetailCalcs("LINE(218)").GetTotals(RG) - (RG.AND(103, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()));
                RG.AddCalc("LINE(220)", RG.MACRO(M.UNEXPL_ADJ_RE));
            //???SPA - replace LINE(220) with macro UNEXPL_ADJ_RE
            if (RG.GetCalc("LINE(225)") == null)
                //				RG.AddCalc("LINE(225)", (RG.CLASS(25, RG.LAG) + RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) + 
                //					RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG))* RG.CONV_RATE(RG.LAG));
                ///CPF 6/19/03 Added the LAG to this call as a fix to the bug 192 in the eMFA Models tracker project/
                RG.AddCalc("LINE(225)", RG.MACRO(M.NET_WORTH, RG.LAG));
            //???SPA - replace LINE(225) with lag of macro NET_WORTH
            if (RG.GetCalc("LINE(230)") == null)
                //				if (RG.GetDetailCalcs("LINE(217)") != null & RG.GetDetailCalcs("LINE(219)") != null)
                //				{
                //					if (RG.GetDetailCalcs("LINE(217)").Count != 0)
                //						RG.AddCalc("LINE(230)", -1 * RG.GetCalc("LINE(220)") + RG.GetDetailCalcs("LINE(217)").GetTotals(RG) + RG.GetDetailCalcs("LINE(219)").GetTotals(RG) + RG.GetCalc("LINE(206)"));
                //					else
                //						RG.AddCalc("LINE(230)", -1 * RG.GetCalc("LINE(220)") + RG.GetDetailCalcs("LINE(219)").GetTotals(RG) + RG.GetCalc("LINE(206)"));
                //				}
                //				else
                //					RG.AddCalc("LINE(230)", -1 * RG.GetCalc("LINE(220)") + RG.GetCalc("LINE(206)"));
                RG.AddCalc("LINE(230)", RG.MACRO(M.ADJS_TO_RE));
            //???SPA - replace LINE(230) with macro ADJS_TO_RE
            if (RG.GetCalc("LINE(232)") == null)
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(201)) >= 1)
                    RG.AddCalc("LINE(232)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(232)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(233)") == null)
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(201)) > 1)
                    RG.AddCalc("LINE(233)", new Calc(2, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(233)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(234)") == null)
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) > 0)
                    RG.AddCalc("LINE(234)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(234)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(236)") == null)
                if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
                    RG.AddCalc("LINE(236)", new Calc(6, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(236)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(213)") == null)
                if ((FormatCommands.DetailCount(RG, RG.DETAILTYPE(141)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(201))) > 0)
                    RG.AddCalc("LINE(213)", RG.TYPE(141, RG.LAG) * RG.CONV_RATE(RG.LAG));
                else
                    RG.AddCalc("LINE(213)", new Calc(0, RG.Statements.Count));
            if (RG.GetCalc("LINE(235)") == null)
                RG.AddCalc("LINE(235)", (RG.AND(102, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()) - (RG.AND(102, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) +
                    ((RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS)) * RG.CONV_RATE()) -
                    ((RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG)) * RG.CONV_RATE(RG.LAG)) +
                    (RG.AND(25, RG.ANDCLASS, 5, RG.ANDFLOW) * RG.CONV_RATE()) - (RG.AND(25, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)) +
                    (RG.AND(105, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)) - (RG.AND(105, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()) +
                    (RG.AND(117, RG.ANDFLOW, 31, RG.ANDCLASS) * RG.CONV_RATE()) + RG.GetCalc("LINE(212)"));
            if (RG.GetDetailCalcs("LINE(240)") == null)
                RG.AddCalc("LINE(240)", (RG.DETAILAND(102, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE() -
                    RG.DETAILAND(102, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("LINE(341)") == null)
                RG.AddCalc("LINE(341)", (RG.DETAILAND(90, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE() -
                    RG.DETAILAND(90, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("LINE(241)") == null)
                RG.AddCalc("LINE(241)", (RG.DETAILAND(105, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG) -
                    RG.DETAILAND(105, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE()));          
            if (RG.GetDetailCalcs("LINE(242)") == null)
                RG.AddCalc("LINE(242)", RG.DETAILAND(117, RG.ANDFLOW, 31, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(243)") == null)
                RG.AddCalc("LINE(243)", ((RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS)) * RG.CONV_RATE() -
                    (RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG)) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("LINE(244)") == null)
                RG.AddCalc("LINE(244)", RG.DETAILAND(25, RG.ANDCLASS, 5, RG.ANDFLOW) * RG.CONV_RATE() -
                    RG.DETAILAND(25, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(250)") == null)
                //				RG.AddCalc("LINE(250)", RG.GetCalc("LINE(225)") + RG.MACRO(M.NET_PROFIT) + RG.GetDetailCalcs("LINE(216)").GetTotals(RG) + RG.GetDetailCalcs("LINE(218)").GetTotals(RG) + 
                //					RG.GetCalc("LINE(230)") + RG.GetDetailCalcs("LINE(240)").GetTotals(RG) + RG.GetDetailCalcs("LINE(241)").GetTotals(RG) + RG.GetCalc("LINE(243)") + 
                //					RG.GetDetailCalcs("LINE(244)").GetTotals(RG) + RG.GetDetailCalcs("LINE(242)").GetTotals(RG) + RG.GetCalc("LINE(212)") + RG.GetCalc("LINE(214)"));
                RG.AddCalc("LINE(250)", RG.MACRO(M.ENDING_NET_WORTH_CALCD));
            //???SPA - replace LINE(250) with macro ENDING_NET_WORTH_CALCD
            if (RG.GetCalc("LINE(265)") == null)
                //RG.AddCalc("LINE(265)", (RG.CLASS(25) + RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS)) * RG.CONV_RATE());
                RG.AddCalc("LINE(265)", RG.MACRO(M.NET_WORTH));
            //???SPA - replace LINE(265) with macro NET_WORTH
            if (RG.GetCalc("LINE(260)") == null)
                RG.AddCalc("LINE(260)", RG.GetCalc("LINE(265)") - RG.GetCalc("LINE(250)"));
            if (RG.GetCalc("LINE(280)") == null)
                //				RG.AddCalc("LINE(280)", RG.GetCalc("LINE(260)") + RG.GetCalc("LINE(230)") + RG.GetDetailCalcs("LINE(240)").GetTotals(RG) + RG.GetDetailCalcs("LINE(241)").GetTotals(RG) + 
                //					RG.GetCalc("LINE(243)") + RG.GetDetailCalcs("LINE(244)").GetTotals(RG));
                RG.AddCalc("LINE(280)", RG.MACRO(M.CF_FINANCING_ADJ));
            //???SPA - replace LINE(280) with macro CF_FINANCING_ADJ
            //SPA - breaking LINE(280) into sub component macros
            //SPA - macro ADJ_TO_RE_SUB1 = Lines 240 + 241 + 243 + 244
            //    - macro ADJ_TO_RE_SUB2 = Lines 216 + 218
            //    - macro ADJ_TO_RE_SUB3 = Line 242
            //    - macro ADJ_TO_RE_SUB4 = Line 217 + 219
            if (RG.GetCalc("EndRetEarn") == null)
                RG.AddCalc("EndRetEarn", RG.AND(103, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("IncDecNetWrth") == null)
                RG.AddCalc("IncDecNetWrth", RG.GetCalc("LINE(265)") - ((RG.CLASS(25, RG.LAG) + RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG)) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("LINE(300)") == null)
                RG.AddCalc("LINE(300)", (RG.CLASS(5, RG.LAG) - RG.CLASS(15, RG.LAG)) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(370)") == null)
                //RG.AddCalc("LINE(370)", ((RG.TYPE(39, RG.LAG) + RG.TYPE(38, RG.LAG) + RG.TYPE(40, RG.LAG) - RG.TYPE(45, RG.LAG)) * RG.CONV_RATE(RG.LAG)) - ((RG.TYPE(39) + RG.TYPE(38) + RG.TYPE(40) - RG.TYPE(45)) * RG.CONV_RATE()));
                RG.AddCalc("LINE(370)", RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_RECWC));
            //???SPA - replace LINE(370) with CHG_IN_NET_FIXED_ASSETS_RECWC
            if (RG.GetDetailCalcs("LINE(375)") == null)
                RG.AddCalc("LINE(375)", RG.DETAILTYPE(50, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILTYPE(50) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(380)") == null)
                RG.AddCalc("LINE(380)", RG.DETAILTYPE(55, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILTYPE(55) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(382)") == null)
                RG.AddCalc("LINE(382)", RG.DETAILTYPE(62, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILTYPE(62) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(385)") == null)
                RG.AddCalc("LINE(385)", RG.DETAILTYPE(60, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILTYPE(60) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(390)") == null)
                RG.AddCalc("LINE(390)", RG.DETAILAND(25, RG.ANDTYPE, 10, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILAND(25, RG.ANDTYPE, 10, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(395)") == null)
                RG.AddCalc("LINE(395)", RG.DETAILTYPE(65, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILTYPE(65) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(398)") == null)
                //RG.AddCalc("LINE(398)", (RG.TYPE(70, RG.LAG) - RG.TYPE(71, RG.LAG)) * RG.CONV_RATE(RG.LAG) - (RG.TYPE(70) - RG.TYPE(71)) * RG.CONV_RATE());
                RG.AddCalc("LINE(398)", RG.MACRO(M.CHG_IN_INTANGIBLES));
            //???SPA - replace LINE(398) with CHG_IN_INTANGIBLES
            if (RG.GetCalc("LINE(330)") == null)
                RG.AddCalc("LINE(330)", RG.TYPE(110) * RG.CONV_RATE() - RG.TYPE(110, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(335)") == null)
                RG.AddCalc("LINE(335)", RG.TYPE(112) * RG.CONV_RATE() - RG.TYPE(112, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetDetailCalcs("LINE(340)") == null)
                RG.AddCalc("LINE(340)", RG.DETAILTYPE(127) * RG.CONV_RATE() - RG.DETAILTYPE(127, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(345)") == null)
                //RG.AddCalc("LINE(345)", (RG.TYPE(125) + RG.TYPE(126)) * RG.CONV_RATE() - (RG.TYPE(125, RG.LAG) + RG.TYPE(126, RG.LAG)) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("LINE(345)", RG.MACRO(M.OTH_NON_CUR_LIABS_RECWC));
            //???SPA - replace LINE(345) with OTH_NON_CUR_LIABS_RECWC macro
            if (RG.GetDetailCalcs("LINE(350)") == null)
                RG.AddCalc("LINE(350)", RG.DETAILTYPE(115) * RG.CONV_RATE() - RG.DETAILTYPE(115, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(360)") == null)
                //RG.AddCalc("LINE(360)", (RG.TYPE(120) + RG.TYPE(122)) * RG.CONV_RATE() - (RG.TYPE(120, RG.LAG) + RG.TYPE(122, RG.LAG)) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("LINE(360)", RG.MACRO(M.OTH_LIABS_RECWC));
            //???SPA - replace LINE(360) with OTH_LIABS_RECWC
            if (RG.GetCalc("EndWorkCap") == null)
                RG.AddCalc("EndWorkCap", (RG.CLASS(5) - RG.CLASS(15)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(320)") == null)
                RG.AddCalc("LINE(320)", 0 - (RG.GetCalc("LINE(300)") + RG.GetCalc("IncDecNetWrth") + RG.GetCalc("LINE(330)") + RG.GetCalc("LINE(335)") + RG.GetDetailCalcs("LINE(340)").GetTotals(RG) +
                    RG.GetCalc("LINE(345)") + RG.GetDetailCalcs("LINE(350)").GetTotals(RG) + RG.GetCalc("LINE(360)") + RG.GetCalc("LINE(370)") + RG.GetDetailCalcs("LINE(375)").GetTotals(RG) + RG.GetDetailCalcs("LINE(380)").GetTotals(RG) +
                    RG.GetDetailCalcs("LINE(382)").GetTotals(RG) + RG.GetDetailCalcs("LINE(385)").GetTotals(RG) + RG.GetDetailCalcs("LINE(390)").GetTotals(RG) + RG.GetDetailCalcs("LINE(395)").GetTotals(RG) + RG.GetCalc("LINE(398)") - RG.GetCalc("EndWorkCap")));
            if (RG.GetDetailCalcs("DTReconCompInc") == null)
                RG.AddCalc("DTReconCompInc", RG.DETAILTYPE(201) * RG.CONV_RATE());
            if (RG.GetCalc("EndAccumOCI") == null)
                RG.AddCalc("EndAccumOCI", RG.TYPE(141) * RG.CONV_RATE());

            // SPA - Summary Reconciliations Calcs
            if (RG.GetCalc("StockPIC") == null)
                //RG.AddCalc("StockPIC", RG.GetDetailCalcs("LINE(240)").GetTotals(RG)+RG.GetDetailCalcs("LINE(241)").GetTotals(RG));
                RG.AddCalc("StockPIC", RG.MACRO(M.STOCK_PIC));
            //???SPA - replace StockPIC with macro STOCK_PIC
            if (RG.GetCalc("SumReconOpNonCurAsts") == null)
                //RG.AddCalc("SumReconOpNonCurAsts", RG.GetDetailCalcs("LINE(385)").GetTotals(RG)+RG.GetDetailCalcs("LINE(382)").GetTotals(RG));
                RG.AddCalc("SumReconOpNonCurAsts", RG.MACRO(M.SUM_RECON_OP_NON_CUR_ASTS));
            //???SPA - replace SumReconOpNonCurAsts with macro SUM_RECON_OP_NON_CUR_ASTS
            if (RG.GetCalc("SumReconOthNonCurLiabs") == null)
                //RG.AddCalc("SumReconOthNonCurLiabs", RG.GetDetailCalcs("LINE(340)").GetTotals(RG)+RG.GetCalc("LINE(345)")+RG.GetDetailCalcs("LINE(350)").GetTotals(RG)+RG.GetCalc("LINE(360)"));
                RG.AddCalc("SumReconOthNonCurLiabs", RG.MACRO(M.SUM_RECON_OTH_NON_CUR_LIABS));
            //???SPA - replace SumReconOthNonCurLiabs with macro SUM_RECON_OTH_NON_CUR_LIABS

            // SPA - Exec Recon & Ratios - Recon section calcs
            if (RG.GetCalc("EReconChgLTRecInv") == null)
                //RG.AddCalc("EReconChgLTRecInv", RG.GetDetailCalcs("LINE(375)").GetTotals(RG)+RG.GetDetailCalcs("LINE(380)").GetTotals(RG));
                RG.AddCalc("EReconChgLTRecInv", RG.MACRO(M.ERECON_CHG_LT_REC_INV));
            //SPA - replace EReconChgLTRecInvwith macro ERECON_CHG_LT_REC_INV
            if (RG.GetCalc("EReconChgOthLTAsts") == null)
                //RG.AddCalc("EReconChgOthLTAsts", RG.GetDetailCalcs("LINE(390)").GetTotals(RG)+RG.GetDetailCalcs("LINE(395)").GetTotals(RG)+RG.GetCalc("SumReconOpNonCurAsts"));
                RG.AddCalc("EReconChgOthLTAsts", RG.MACRO(M.ERECON_CHG_OTH_LT_ASTS));
            //SPA - replace EReconChgOthLTAsts with macro ERECON_CHG_OTH_LT_ASTS
            if (RG.GetCalc("EReconChgLTD") == null)
                //RG.AddCalc("EReconChgLTD", RG.GetCalc("LINE(330)")+RG.GetCalc("LINE(335)"));
                RG.AddCalc("EReconChgLTD", RG.MACRO(M.ERECON_CHG_LTD));
            //SPA - replace EReconChgLTD with macro ERECON_CHG_LTD


        }
        public void FAS_CF_Dir_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("CashRecFrmCust") == null)
                RG.AddCalc("CashRecFrmCust", RG.GetCalc("CashCollFromSales") - (RG.FLOW(30, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.FLOW(30) * RG.CONV_RATE()) -
                    (RG.AND(15, RG.ANDCLASS, 15, RG.ANDFLOW) * RG.CONV_RATE() - RG.AND(15, RG.ANDCLASS, 15, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgOthPurch") == null)
                RG.AddCalc("DTChgOthPurch", (RG.DETAILAND(27, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE()) -
                    (RG.DETAILAND(27, RG.ANDFLOW, 15, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetDetailCalcs("DTChgCostExcBill") == null)
                RG.AddCalc("DTChgCostExcBill", RG.DETAILFLOW(30, RG.LAG) * RG.CONV_RATE(RG.LAG) - RG.DETAILFLOW(30) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTChgBillExcCost") == null)
                RG.AddCalc("DTChgBillExcCost", RG.DETAILAND(15, RG.ANDCLASS, 15, RG.ANDFLOW) * RG.CONV_RATE() -
                    RG.DETAILAND(15, RG.ANDCLASS, 15, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("CashPdSuppEmp") == null)
                RG.AddCalc("CashPdSuppEmp", RG.GetCalc("CashPdOpCost") + RG.GetCalc("CashPaidToSupp") + RG.GetDetailCalcs("DTChgCurOpAst").GetTotals(RG) +
                    RG.GetDetailCalcs("DTChgLTOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpLiab").GetTotals(RG) + RG.GetDetailCalcs("DTChgOpNonCurLiab").GetTotals(RG) +
                    RG.GetDetailCalcs("DTChgBillExcCst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCstExcBill").GetTotals(RG));
            if (RG.GetCalc("InterestPaid") == null)
                RG.AddCalc("InterestPaid", RG.GetDetailCalcs("DTInterestExp").GetTotals(RG) + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG) + RG.GetDetailCalcs("DTCapInterestUCA").GetTotals(RG));
            if (RG.GetCalc("IncTaxPaid") == null)
                RG.AddCalc("IncTaxPaid", RG.GetDetailCalcs("DTIncomeTaxes").GetTotals(RG) + RG.GetDetailCalcs("DTIncomeTaxCred").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxRcv").GetTotals(RG) +
                    RG.GetDetailCalcs("DTChgDefIncTaxRec").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxPay").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefFedIncTax").GetTotals(RG));
            if (RG.GetCalc("IntDivRcvd") == null)
                RG.AddCalc("IntDivRcvd", RG.GetDetailCalcs("DTIntIncome").GetTotals(RG) + RG.GetDetailCalcs("DTIncFrmSubsid").GetTotals(RG));
            if (RG.GetCalc("MiscCashRcvPd") == null)
            {
                //Subtract AsstRvltn from the subtotal
               // double NegOne = -1;
               //Calc NegDTAsstRvltn = NegOne*RG.GetDetailCalcs("DTAsstRvltn").GetTotals(RG);
                if (RG.GetDetailCalcs("DTOthIncAccts").Count == 0)
                {
                    ///CPF 02/01/06 Log 1611:  If there are no accounts in this AND, DO NOT include it in calc
                    if (RG.GetDetailCalcs("DTChgSTInvRelCo").Count == 0)
                        RG.AddCalc("MiscCashRcvPd", RG.GetDetailCalcs("DTOpInc").GetTotals(RG) + RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG) + RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG) + RG.GetDetailCalcs("DTExtrIncAftTxInc").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxIncome").GetTotals(RG));
                    else
                        RG.AddCalc("MiscCashRcvPd", RG.GetDetailCalcs("DTOpInc").GetTotals(RG) + RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG) + RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG) + RG.GetDetailCalcs("DTExtrIncAftTxInc").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxIncome").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvRelCo").GetTotals(RG) );
                }
                else
                {
                    ///CPF 02/01/06 Log 1611:  If there are no accounts in this AND, DO NOT include it in calc
                    if (RG.GetDetailCalcs("DTChgSTInvRelCo").Count == 0)
                        RG.AddCalc("MiscCashRcvPd", RG.GetDetailCalcs("DTOthIncAccts").GetTotals(RG) + RG.GetDetailCalcs("DTOpInc").GetTotals(RG) + RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG) + RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG) + RG.GetDetailCalcs("DTExtrIncAftTxInc").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxIncome").GetTotals(RG) );
                    else
                        RG.AddCalc("MiscCashRcvPd", RG.GetDetailCalcs("DTOthIncAccts").GetTotals(RG) + RG.GetDetailCalcs("DTOpInc").GetTotals(RG) + RG.GetDetailCalcs("DTOthExpAct").GetTotals(RG) + RG.GetDetailCalcs("DTOthIncAccts2").GetTotals(RG) + RG.GetDetailCalcs("DTExtrIncAftTxInc").GetTotals(RG) + RG.GetDetailCalcs("DTAftTxIncome").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvRelCo").GetTotals(RG) );
                }
            }
            if (RG.GetCalc("NetCashProvOp") == null)
                RG.AddCalc("NetCashProvOp", RG.GetCalc("CashCollFromSales") - (RG.GetDetailCalcs("DTChgBillExcCst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCstExcBill").GetTotals(RG)) +
                    RG.GetCalc("CashPdSuppEmp") + RG.GetCalc("InterestPaid") + RG.GetCalc("IncTaxPaid") + RG.GetCalc("IntDivRcvd") + RG.GetCalc("MiscCashRcvPd"));
            //SPA - fixed this calc 8/20/2002 - was incorrectly identical to ChgNetFxdAsts from UCA
            if (RG.GetCalc("FASChgNetFxdAsts") == null)
            {
                RG.AddCalc("FASChgNetFxdAsts", new Calc());
                for (int i = 0; i < RG.GetCalc("Flows96,97,98").Count; i++)
                    if (RG.GetCalc("Flows96,97,98")[i] != 0)
                        RG.GetCalc("FASChgNetFxdAsts").Add(RG.GetCalc("ChgNetFxdAsts")[i]);
                    else
                        RG.GetCalc("FASChgNetFxdAsts").Add(RG.GetCalc("ChgNetFxdAsts")[i] - RG.GetDetailCalcs("DTCapInterestUCA").GetTotals(RG)[i]);
            }
            if (RG.GetDetailCalcs("DTChgMarkSec") == null)
                RG.AddCalc("DTChgMarkSec", RG.DETAILAND(5, RG.ANDCLASS, 7, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG) -
                    RG.DETAILAND(5, RG.ANDCLASS, 7, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetCalc("FASChgInvest") == null)
                RG.AddCalc("FASChgInvest", RG.GetDetailCalcs("DTChgMarkSec").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvest").GetTotals(RG) +
                    RG.GetDetailCalcs("DTChgInvest").GetTotals(RG) + RG.GetDetailCalcs("DTCompInc").GetTotals(RG) + RG.GetCalc("LINE(212)") + RG.GetCalc("LINE(214)"));
            if (RG.GetCalc("NetCashUsedInvst") == null)
                //RG.AddCalc("NetCashUsedInvst", RG.GetCalc("FASChgNetFxdAsts") + RG.GetCalc("FASChgInvest") + RG.GetCalc("ChgNetIntang")); 
                RG.AddCalc("NetCashUsedInvst", RG.GetCalc("FASChgNetFxdAsts") + RG.GetCalc("FASChgInvest") + RG.GetCalc("ChgNetIntang") + RG.GetDetailCalcs("DTAsstRvltn").GetTotals(RG));               
            if (RG.GetCalc("ProcLessPymts") == null)
                RG.AddCalc("ProcLessPymts", (RG.FLOW(76) - RG.FLOW(77)) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTProcFrBorr") == null)
                RG.AddCalc("DTProcFrBorr", RG.DETAILFLOW(76) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTPrinPytDbt") == null)
                RG.AddCalc("DTPrinPytDbt", -1 * RG.DETAILFLOW(77) * RG.CONV_RATE());
            RG.AddCalc("DTFASChgSTBorr", (RG.DETAILAND(15, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE()) -
                (RG.DETAILAND(15, RG.ANDCLASS, 105, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTFASChgSTBorr"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetDetailCalcs("DTFASDChgCPLTD") == null)
                RG.AddCalc("DTFASDChgCPLTD", RG.DETAILAND(15, RG.ANDCLASS, 75, RG.ANDFLOW) * RG.CONV_RATE() -
                    RG.DETAILAND(15, RG.ANDCLASS, 75, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));

            RG.AddCalc("DTFASChgCPLTD", RG.DETAILAND(15, RG.ANDCLASS, 75, RG.ANDFLOW) * RG.CONV_RATE() -
                RG.DETAILAND(15, RG.ANDCLASS, 75, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTFASChgCPLTD"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        dc.Values[i] = 0;
                }
            }

            if (RG.GetCalc("FASChgLTD") == null)
            {
                RG.AddCalc("FASChgLTD", new Calc());
                for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        RG.GetCalc("FASChgLTD").Add(0);
                    else
                        RG.GetCalc("FASChgLTD").Add(RG.FLOW(125)[i] * RG.CONV_RATE()[i] - RG.FLOW(125, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i]);
                }
            }

            RG.AddCalc("DTFASChgDefDebt", (RG.DETAILAND(20, RG.ANDCLASS, 107, RG.ANDFLOW) * RG.CONV_RATE()) -
                (RG.DETAILAND(20, RG.ANDCLASS, 107, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTFASChgDefDebt"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            RG.AddCalc("DTFASChgSubordDef", (RG.DETAILAND(22, RG.ANDCLASS, 108, RG.ANDFLOW) * RG.CONV_RATE()) -
                (RG.DETAILAND(22, RG.ANDCLASS, 108, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTFASChgSubordDef"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            RG.AddCalc("DTFASChgSubordDbtLiab", (RG.DETAILAND(22, RG.ANDCLASS, 105, RG.ANDFLOW) * RG.CONV_RATE()) -
                (RG.DETAILAND(22, RG.ANDCLASS, 105, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            foreach (DetailCalc dc in RG.GetDetailCalcs("DTFASChgSubordDbtLiab"))
            {
                for (int i = 0; i < dc.Values.Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        dc.Values[i] = 0;
                }
            }
            if (RG.GetCalc("NetChgBorrow") == null)
            {
                RG.AddCalc("NetChgBorrow", new Calc());
                for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        RG.GetCalc("NetChgBorrow").Add(RG.GetCalc("ProcLessPymts")[i]);
                    else
                        RG.GetCalc("NetChgBorrow").Add(RG.GetDetailCalcs("DTFASChgSTBorr").GetTotals(RG)[i] + RG.GetDetailCalcs("DTFASChgCPLTD").GetTotals(RG)[i] +
                            RG.GetCalc("FASChgLTD")[i] + RG.GetDetailCalcs("DTFASChgDefDebt").GetTotals(RG)[i] + RG.GetDetailCalcs("DTFASChgSubordDef").GetTotals(RG)[i] + RG.GetDetailCalcs("DTFASChgSubordDbtLiab").GetTotals(RG)[i]);
                }
            }
            if (RG.GetCalc("LINE(2450)") == null)
                RG.AddCalc("LINE(2450)", RG.GetCalc("LINE(280)") - RG.GetDetailCalcs("LINE(244)").GetTotals(RG) + (RG.FLOW(60) - RG.FLOW(61) + RG.FLOW(67) - RG.AND(102, RG.ANDFLOW, 32, RG.ANDCLASS) - RG.AND(102, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(104, RG.ANDFLOW, 30, RG.ANDCLASS)) * RG.CONV_RATE());
            if (RG.GetCalc("NetCashProvFin") == null)
                if (RG.GetDetailCalcs("DTOthDeduct").Count == 0)
                    RG.AddCalc("NetCashProvFin", RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG) + RG.GetCalc("LINE(2450)") +
                        RG.GetDetailCalcs("DTDividends").GetTotals(RG) + RG.GetDetailCalcs("DTChgDivPay").GetTotals(RG) + RG.GetCalc("NetChgBorrow") +
                        RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG));
                else
                    RG.AddCalc("NetCashProvFin", RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG) + RG.GetCalc("LINE(2450)") +
                        RG.GetDetailCalcs("DTOthDeduct").GetTotals(RG) + RG.GetDetailCalcs("DTDividends").GetTotals(RG) + RG.GetDetailCalcs("DTChgDivPay").GetTotals(RG) +
                        RG.GetCalc("NetChgBorrow") + RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG));
            if (RG.GetCalc("ChgInCashEquiv") == null)
                RG.AddCalc("ChgInCashEquiv", RG.GetCalc("NetCashProvOp") + RG.GetCalc("NetCashUsedInvst") + RG.GetCalc("NetCashProvFin") + RG.GetDetailCalcs("LINE(244)").GetTotals(RG));
            if (RG.GetCalc("FASAdjstItems") == null)
                RG.AddCalc("FASAdjstItems", (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG) - (RG.GetCalc("ChgInCashEquiv") +
                    RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG) - (RG.AND(5, RG.ANDCLASS, 5, RG.ANDFLOW)) * RG.CONV_RATE() +
                    RG.FLOW(140) * RG.CONV_RATE())));
            if (RG.GetCalc("FASCashAdjustment") == null)
                RG.AddCalc("FASCashAdjustment", 0 - (RG.GetCalc("ChgInCashEquiv") + RG.MACRO(M.AND_CASH_LAGGED) -
                    RG.MACRO(M.AND_CASH)));
            if (RG.GetCalc("CashEquivEOP") == null)
                RG.AddCalc("CashEquivEOP", RG.GetCalc("ChgInCashEquiv") + RG.MACRO(M.AND_CASH_LAGGED) + RG.GetCalc("FASCashAdjustment"));

        }
        public void FAS_CF_Ind_Calcs(ReportGenerator RG)
        {
            if (RG.GetDetailCalcs("DTFASIDepr") == null)
                RG.AddCalc("DTFASIDepr", RG.DETAILAND(30, RG.ANDCLASS, 95, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(2710)") == null)
                RG.AddCalc("LINE(2710)", RG.DETAILAND(30, RG.ANDCLASS, 120, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTFASIDefIntExp") == null)
                RG.AddCalc("DTFASIDefIntExp", RG.DETAILAND(30, RG.ANDCLASS, 107, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(2730)") == null)
                RG.AddCalc("LINE(2730)", 0 - RG.DETAILAND(30, RG.ANDCLASS, 60, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(2733)") == null)
                RG.AddCalc("LINE(2733)", RG.DETAILAND(30, RG.ANDCLASS, 61, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(2732)") == null)
                RG.AddCalc("LINE(2732)", 0 - RG.DETAILAND(67, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("LINE(2731)") == null)
                RG.AddCalc("LINE(2731)", RG.DETAILAND(30, RG.ANDCLASS, 104, RG.ANDFLOW) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("DTFASIGLAstSale") == null)
                RG.AddCalc("DTFASIGLAstSale", 0 - RG.DETAILAND(30, RG.ANDCLASS, 90, RG.ANDFLOW) * RG.CONV_RATE());

            if (RG.GetDetailCalcs("ICFDTAsstRvltn")== null)
                RG.AddCalc("ICFDTAsstRvltn", 0 - RG.GetDetailCalcs("DTAsstRvltn"));
            if (RG.GetCalc("TotAdjstmnts") == null)
            {
                ///CPF 02/01/06 Log 1611:  If there are no accounts in this AND, DO NOT include it in calc
                if (RG.GetDetailCalcs("DTChgSTInvRelCo").Count == 0)
                    RG.AddCalc("TotAdjstmnts", RG.AND(95, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE() + RG.GetDetailCalcs("LINE(2710)").GetTotals(RG) - RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG) + RG.GetDetailCalcs("LINE(2730)").GetTotals(RG) +
                        RG.GetDetailCalcs("LINE(2731)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2732)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2733)").GetTotals(RG) - (RG.AND(30, RG.ANDCLASS, 90, RG.ANDFLOW) * RG.CONV_RATE()) + RG.GetDetailCalcs("DTChgBadDbtRes").GetTotals(RG) + RG.GetDetailCalcs("DTChgInventory").GetTotals(RG) + RG.GetDetailCalcs("DTChgSupplies").GetTotals(RG) + RG.GetDetailCalcs("DTChgPrePds").GetTotals(RG) + RG.GetDetailCalcs("DTChgCostExcBill").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgPurchases").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueToRelCoCP").GetTotals(RG) + RG.GetDetailCalcs("DTChgOvrdrfts").GetTotals(RG) + RG.GetDetailCalcs("DTChgBillExcCost").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOp").GetTotals(RG) + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxPay").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgDefFedIncTax").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxRcv").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefIncTaxRec").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgLTOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpLiab").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgOpNonCurLiab").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefRev").GetTotals(RG) + RG.GetDetailCalcs("DTChgRcvbls").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthPurch").GetTotals(RG) +
                        RG.GetDetailCalcs("ICFDTAsstRvltn").GetTotals(RG));
                else
                    RG.AddCalc("TotAdjstmnts", RG.AND(95, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE() + RG.GetDetailCalcs("LINE(2710)").GetTotals(RG) - RG.GetDetailCalcs("DTDefIntExp").GetTotals(RG) + RG.GetDetailCalcs("LINE(2730)").GetTotals(RG) +
                        RG.GetDetailCalcs("LINE(2731)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2732)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2733)").GetTotals(RG) - (RG.AND(30, RG.ANDCLASS, 90, RG.ANDFLOW) * RG.CONV_RATE()) + RG.GetDetailCalcs("DTChgBadDbtRes").GetTotals(RG) + RG.GetDetailCalcs("DTChgInventory").GetTotals(RG) + RG.GetDetailCalcs("DTChgSupplies").GetTotals(RG) + RG.GetDetailCalcs("DTChgPrePds").GetTotals(RG) + RG.GetDetailCalcs("DTChgCostExcBill").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgPurchases").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueToRelCoCP").GetTotals(RG) + RG.GetDetailCalcs("DTChgOvrdrfts").GetTotals(RG) + RG.GetDetailCalcs("DTChgBillExcCost").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOp").GetTotals(RG) + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxPay").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgDefFedIncTax").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxRcv").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefIncTaxRec").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgLTOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpLiab").GetTotals(RG) +
                        RG.GetDetailCalcs("DTChgOpNonCurLiab").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefRev").GetTotals(RG) + RG.GetDetailCalcs("DTChgRcvbls").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthPurch").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvRelCo").GetTotals(RG) +
                        RG.GetDetailCalcs("ICFDTAsstRvltn").GetTotals(RG));
            }
            //SPA - calculations for Summary FAS reports - direct and indirect
            ///CPF 05/30/06 Log 1699 - Removed Chg in Due to Rel Co - CP because it is now printed seperately on Summary Reports.
            if (RG.GetCalc("FASIChgAPTrdOth") == null)
                RG.AddCalc("FASIChgAPTrdOth", RG.GetDetailCalcs("DTChgPurchases").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthPurch").GetTotals(RG));
            if (RG.GetCalc("FASIChgAccruals") == null)
                RG.AddCalc("FASIChgAccruals", RG.GetDetailCalcs("DTChgBillExcCost").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOp").GetTotals(RG) + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG));
            if (RG.GetCalc("FASINonCashIncExp") == null)
                RG.AddCalc("FASINonCashIncExp", RG.GetDetailCalcs("LINE(2730)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2733)").GetTotals(RG) + RG.GetDetailCalcs("LINE(2731)").GetTotals(RG));
            ///CPF 05/30/06 Log 1699 - Removed Chg in Due From Rel Co - CP because it is now printed seperately on Summary Reports.
            if (RG.GetCalc("FASIChgNetRec") == null)
                //				RG.AddCalc("FASIChgNetRec", RG.GetDetailCalcs("DTChgRcvbls").GetTotals(RG)+RG.GetDetailCalcs("DTChgBadDbtRes").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG));
                RG.AddCalc("FASIChgNetRec", RG.GetDetailCalcs("DTChgRcvbls").GetTotals(RG) + RG.GetDetailCalcs("DTChgBadDbtRes").GetTotals(RG));
            if (RG.GetCalc("FASIChgPrePdsCostEB") == null)
                RG.AddCalc("FASIChgPrePdsCostEB", RG.GetDetailCalcs("DTChgPrePds").GetTotals(RG) + RG.GetDetailCalcs("DTChgCostExcBill").GetTotals(RG));
            if (RG.GetCalc("FASIChgTax") == null)
                RG.AddCalc("FASIChgTax", RG.GetDetailCalcs("DTChgIncTaxPay").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefFedIncTax").GetTotals(RG) + RG.GetDetailCalcs("DTChgIncTaxRcv").GetTotals(RG) + RG.GetDetailCalcs("DTChgDefIncTaxRec").GetTotals(RG));
            if (RG.GetCalc("FASIChgOpItems") == null)
                RG.AddCalc("FASIChgOpItems", RG.GetDetailCalcs("DTChgCurOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgLTOpAst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOpLiab").GetTotals(RG) + RG.GetDetailCalcs("DTChgOpNonCurLiab").GetTotals(RG));
            if (RG.GetCalc("FASIChgSTInv") == null)
                RG.AddCalc("FASIChgSTInv", RG.GetDetailCalcs("DTChgMarkSec").GetTotals(RG) + RG.GetDetailCalcs("DTChgSTInvest").GetTotals(RG));
            if (RG.GetCalc("FASIChgLTInv") == null)
                RG.AddCalc("FASIChgLTInv", RG.GetDetailCalcs("DTChgInvest").GetTotals(RG) + RG.GetDetailCalcs("DTCompInc").GetTotals(RG) + RG.GetCalc("LINE(212)") + RG.GetCalc("LINE(214)"));
            if (RG.GetCalc("FASIChgSubDbt") == null)
            {
                RG.AddCalc("FASIChgSubDbt", new Calc());
                for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        RG.GetCalc("FASIChgSubDbt").Add(0);
                    else
                        RG.GetCalc("FASIChgSubDbt").Add(RG.GetDetailCalcs("DTChgSubordDef").GetTotals(RG)[i] + RG.GetDetailCalcs("DTChgSubordDbtLiab").GetTotals(RG)[i]);
                }
            }
            if (RG.GetCalc("FASIDepAmort") == null)
                RG.AddCalc("FASIDepAmort", RG.GetDetailCalcs("DTFASIDepr").GetTotals(RG) + RG.GetDetailCalcs("LINE(2710)").GetTotals(RG));
            if (RG.GetCalc("FASDChgAccruals") == null)
                RG.AddCalc("FASDChgAccruals", RG.GetDetailCalcs("DTChgBillExcCost").GetTotals(RG) + RG.GetDetailCalcs("DTChgCurOp").GetTotals(RG));
            if (RG.GetCalc("FASSumChgLTD") == null)
            {
                RG.AddCalc("FASSumChgLTD", new Calc());
                for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        RG.GetCalc("FASSumChgLTD").Add(0);
                    else
                        RG.GetCalc("FASSumChgLTD").Add(RG.GetDetailCalcs("DTChgDefDebt").GetTotals(RG)[i] + RG.GetCalc("FASChgLTD")[i]);
                }
            }
            //SPA - calcs for exec FAS reports
            if (RG.GetCalc("FASChgOthSTLTLiabs") == null)
                RG.AddCalc("FASChgOthSTLTLiabs", RG.GetDetailCalcs("DTChgNonOpCurLiabs").GetTotals(RG) + RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG) + RG.GetDetailCalcs("DTChgOthLiabGA").GetTotals(RG));
            if (RG.GetCalc("FASEChgSTLiabs") == null)
            {
                RG.AddCalc("FASEChgSTLiabs", new Calc());
                for (int i = 0; i < RG.GetCalc("ProcLessPymts").Count; i++)
                {
                    if (RG.GetCalc("ProcLessPymts")[i] != 0)
                        RG.GetCalc("FASEChgSTLiabs").Add(0);
                    else
                        RG.GetCalc("FASEChgSTLiabs").Add(RG.GetDetailCalcs("DTChgSTBorr").GetTotals(RG)[i] + RG.GetDetailCalcs("DTFASChgCPLTD").GetTotals(RG)[i]);
                }
            }
            if (RG.GetCalc("FASENonCashItems") == null)
                RG.AddCalc("FASENonCashItems", RG.GetCalc("FASIDepAmort") + RG.GetDetailCalcs("DTFASIDefIntExp").GetTotals(RG) + RG.GetCalc("FASINonCashIncExp") + RG.GetDetailCalcs("LINE(2732)").GetTotals(RG));

        }
        public void CF_MGMT_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("LINE(972)") == null)
                RG.AddCalc("LINE(972)", (RG.AND(30, RG.ANDCLASS, 15, RG.ANDFLOW) - RG.AND(30, RG.ANDCLASS, 20, RG.ANDFLOW)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(978)") == null)
                RG.AddCalc("LINE(978)", (RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS)) * RG.CONV_RATE());
            if (RG.GetCalc("GrsMgnPlsDepr") == null)
                RG.AddCalc("GrsMgnPlsDepr", ((RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS)) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            if (RG.GetCalc("OpExpExclDepr") == null)
                RG.AddCalc("OpExpExclDepr", ((RG.AND(55, RG.ANDFLOW, 30, RG.ANDCLASS) + RG.AND(35, RG.ANDFLOW, 30, RG.ANDCLASS) + RG.AND(21, RG.ANDFLOW, 30, RG.ANDCLASS)) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            // KCZ Added 6-13-03 Version V
            if (RG.GetCalc("OpPrftMgnPlsDepr") == null)
                RG.AddCalc("OpPrftMgnPlsDepr", RG.GetCalc("GrsMgnPlsDepr") - RG.GetCalc("OpExpExclDepr"));
            // KCZ end of addition
            if (RG.GetCalc("LINE(974)") == null)
                RG.AddCalc("LINE(974)", RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(976)") == null)
            {
                RG.AddCalc("LINE(976)", new Calc());
                Calc LINE974LAG = RG.MODIFYCALC(RG.GetCalc("LINE(974)"), RG.LAG);
                for (int i = 0; i < RG.GetCalc("LINE(974)").Count; i++)
                    if (RG.GetCalc("LINE(974)")[i] == 0)
                        RG.GetCalc("LINE(976)").Add(RG.GetCalc("NetSalesGwth")[i]);
                    else
                        RG.GetCalc("LINE(976)").Add(((RG.GetCalc("LINE(974)")[i] / RG.YEAR()[i] - LINE974LAG[i] / RG.YEAR(RG.LAG)[i]) / (LINE974LAG[i] / RG.YEAR(RG.LAG)[i])) * 100);
            }
            if (RG.GetCalc("LINE(979)") == null)
                RG.AddCalc("LINE(979)", ((RG.AND(55, RG.ANDFLOW, 30, RG.ANDCLASS)) + (RG.AND(35, RG.ANDFLOW, 30, RG.ANDCLASS)) + (RG.AND(21, RG.ANDFLOW, 30, RG.ANDCLASS))) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(980)") == null)
                RG.AddCalc("LINE(980)", RG.AND(5, RG.ANDCLASS, 15, RG.ANDFLOW) - RG.AND(5, RG.ANDCLASS, 20, RG.ANDFLOW));
            if (RG.GetCalc("LINE(981)") == null)
            {
                RG.AddCalc("LINE(981)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(980)").Count; i++)
                    if (RG.GetCalc("LINE(980)")[i] > 0)
                        RG.GetCalc("LINE(981)").Add(1);
                    else
                        RG.GetCalc("LINE(981)").Add(0);
            }
            if (RG.GetCalc("LINE(984)") == null)
                RG.AddCalc("LINE(984)", (((RG.AND(15, RG.ANDFLOW, 5, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 5, RG.ANDCLASS)) /
                    ((RG.GetCalc("LINE(972)") / RG.CONV_RATE() / RG.YEAR()) * (1 - (RG.ACCOUNT(9750) / 100)))) * 365) / RG.GetCalc("LINE(981)"));
            if (RG.GetCalc("LINE(1605)") == null)
            {
                // KCZ Changed 2 instances of TotCostOfSalesRev to LINE(974) per log #216 7-29-03
                RG.AddCalc("LINE(1605)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(974)").Count; i++)
                    if (RG.GetCalc("LINE(974)")[i] == 0)
                        RG.GetCalc("LINE(1605)").Add(RG.MACRO(M.NET_SALES)[i] / RG.YEAR()[i]);
                    else
                        RG.GetCalc("LINE(1605)").Add((RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS)[i] / RG.YEAR()[i]) * RG.CONV_RATE()[i]);
            }
            if (RG.GetCalc("LINE(1701)") == null)
                RG.AddCalc("LINE(1701)", ((RG.AND(25, RG.ANDFLOW, 5, RG.ANDCLASS) * RG.CONV_RATE()) / RG.GetCalc("LINE(1605)")) * 365);
            if (RG.GetCalc("LINE(1728)") == null)
                RG.AddCalc("LINE(1728)", ((RG.AND(25, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE()) / RG.GetCalc("LINE(1605)")) * 365);
            if (RG.GetCalc("LINE(1729)") == null)
                RG.AddCalc("LINE(1729)", (RG.AND(35, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(40, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(40, RG.ANDFLOW, 10, RG.ANDCLASS) + RG.AND(30, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(16, RG.ANDFLOW, 5, RG.ANDCLASS)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(1732)") == null)
                RG.AddCalc("LINE(1732)", RG.AND(35, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(1741)") == null)
                RG.AddCalc("LINE(1741)", (RG.GetCalc("LINE(1732)") / (RG.GetCalc("LINE(979)") / RG.YEAR())) * 365);
            if (RG.GetCalc("LINE(1731)") == null)
                RG.AddCalc("LINE(1731)", (RG.AND(37, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(15, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(27, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(26, RG.ANDFLOW, 15, RG.ANDCLASS)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(9980)") == null)
                RG.AddCalc("LINE(9980)", RG.YEAR() / RG.YEAR(RG.LAG));
            Calc LINE978LAG = RG.MODIFYCALC(RG.GetCalc("LINE(978)"), RG.LAG);
            if (RG.GetCalc("BegGrsPrft") == null)
                RG.AddCalc("BegGrsPrft", LINE978LAG * RG.GetCalc("LINE(9980)"));
            if (RG.GetCalc("LINE(982)") == null)
                RG.AddCalc("LINE(982)", RG.GetCalc("BegGrsPrft") * RG.GetCalc("NetSalesGwth") / 100);
            if (RG.GetCalc("LINE(983)") == null)
                RG.AddCalc("LINE(983)", RG.GetCalc("LINE(978)") - LINE978LAG * RG.GetCalc("LINE(9980)") - RG.GetCalc("LINE(982)"));
            Calc LINE979LAG = RG.MODIFYCALC(RG.GetCalc("LINE(979)"), RG.LAG);
            if (RG.GetCalc("BegOpExp") == null)
                RG.AddCalc("BegOpExp", -1 * LINE979LAG * RG.GetCalc("LINE(9980)"));
            if (RG.GetCalc("LINE(985)") == null)
                RG.AddCalc("LINE(985)", RG.GetCalc("BegOpExp") * RG.GetCalc("NetSalesGwth") / 100);
            if (RG.GetCalc("LINE(986)") == null)
                RG.AddCalc("LINE(986)", -1 * RG.GetCalc("LINE(979)") + LINE979LAG * RG.GetCalc("LINE(9980)") - RG.GetCalc("LINE(985)"));
            if (RG.GetCalc("LINE(987)") == null)
                RG.AddCalc("LINE(987)", RG.GetCalc("LINE(978)") - RG.GetCalc("LINE(979)"));
            if (RG.GetCalc("LINE(988)") == null)
                RG.AddCalc("LINE(988)", (RG.AND(15, RG.ANDFLOW, 5, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 5, RG.ANDCLASS) - RG.AND(15, RG.ANDFLOW, 20, RG.ANDCLASS)) * RG.CONV_RATE());
            Calc LINE988LAG = RG.MODIFYCALC(RG.GetCalc("LINE(988)"), RG.LAG);
            if (RG.GetCalc("LINE(990)") == null)
                RG.AddCalc("LINE(990)", -1 * LINE988LAG * RG.GetCalc("NetSalesGwth") / 100);
            if (RG.GetCalc("LINE(995)") == null)
                RG.AddCalc("LINE(995)", LINE988LAG - RG.GetCalc("LINE(990)") - RG.GetCalc("LINE(988)"));
            if (RG.GetCalc("LINE(1700)") == null)
                RG.AddCalc("LINE(1700)", RG.AND(25, RG.ANDFLOW, 5, RG.ANDCLASS) * RG.CONV_RATE());
            Calc LINE1700LAG = RG.MODIFYCALC(RG.GetCalc("LINE(1700)"), RG.LAG);
            if (RG.GetCalc("LINE(1705)") == null)
                RG.AddCalc("LINE(1705)", -1 * LINE1700LAG * RG.GetCalc("LINE(976)") / 100);
            if (RG.GetCalc("LINE(1713)") == null)
                RG.AddCalc("LINE(1713)", LINE1700LAG - RG.GetCalc("LINE(1705)") - RG.GetCalc("LINE(1700)"));
            if (RG.GetCalc("LINE(1715)") == null)
                ///CPF 04/11/06 Log 898:  Added FLOW(16) AND CLASS(5).
                RG.AddCalc("LINE(1715)", (RG.AND(35, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(40, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(40, RG.ANDFLOW, 10, RG.ANDCLASS) + RG.AND(30, RG.ANDFLOW, 5, RG.ANDCLASS) + RG.AND(16, RG.ANDFLOW, 5, RG.ANDCLASS)) * RG.CONV_RATE());
            Calc LINE1715LAG = RG.MODIFYCALC(RG.GetCalc("LINE(1715)"), RG.LAG);
            if (RG.GetCalc("LINE(1720)") == null)
                RG.AddCalc("LINE(1720)", -1 * LINE1715LAG * RG.GetCalc("NetSalesGwth") / 100);
            if (RG.GetCalc("LINE(1725)") == null)
                RG.AddCalc("LINE(1725)", LINE1715LAG - RG.GetCalc("LINE(1720)") - RG.GetCalc("LINE(1715)"));
            if (RG.GetCalc("LINE(1730)") == null)
                RG.AddCalc("LINE(1730)", RG.AND(25, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE());
            Calc LINE1730LAG = RG.MODIFYCALC(RG.GetCalc("LINE(1730)"), RG.LAG);
            if (RG.GetCalc("LINE(1735)") == null)
                RG.AddCalc("LINE(1735)", LINE1730LAG * RG.GetCalc("LINE(976)") / 100);
            if (RG.GetCalc("LINE(1737)") == null)
                RG.AddCalc("LINE(1737)", RG.GetCalc("LINE(1730)") - RG.GetCalc("LINE(1735)") - LINE1730LAG);
            if (RG.GetCalc("LINE(1749)") == null)
                RG.AddCalc("LINE(1749)", (RG.GetCalc("LINE(979)") / RG.YEAR() - LINE979LAG / RG.YEAR(RG.LAG)) % (LINE979LAG / RG.YEAR(RG.LAG)));
            Calc LINE1732LAG = RG.MODIFYCALC(RG.GetCalc("LINE(1732)"), RG.LAG);
            if (RG.GetCalc("LINE(1750)") == null)
                RG.AddCalc("LINE(1750)", LINE1732LAG * RG.GetCalc("LINE(1749)") / 100);
            if (RG.GetCalc("LINE(1755)") == null)
                RG.AddCalc("LINE(1755)", RG.GetCalc("LINE(1732)") - RG.GetCalc("LINE(1750)") - LINE1732LAG);
            if (RG.GetCalc("LINE(1760)") == null)
                ///CPF 04/11/06 Log 898:  Added FLOW(26) AND CLASS(15)
                RG.AddCalc("LINE(1760)", (RG.AND(37, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(15, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(27, RG.ANDFLOW, 15, RG.ANDCLASS) + RG.AND(26, RG.ANDFLOW, 15, RG.ANDCLASS)) * RG.CONV_RATE());
            Calc LINE1760LAG = RG.MODIFYCALC(RG.GetCalc("LINE(1760)"), RG.LAG);
            if (RG.GetCalc("LINE(1765)") == null)
                RG.AddCalc("LINE(1765)", LINE1760LAG * RG.GetCalc("NetSalesGwth") / 100);
            if (RG.GetCalc("LINE(1768)") == null)
                RG.AddCalc("LINE(1768)", RG.GetCalc("LINE(1760)") - RG.GetCalc("LINE(1765)") - LINE1760LAG);
            if (RG.GetCalc("LINE(1770)") == null)
                RG.AddCalc("LINE(1770)", RG.GetCalc("LINE(995)") + RG.GetCalc("LINE(1713)") + RG.GetCalc("LINE(1725)") + RG.GetCalc("LINE(1737)") + RG.GetCalc("LINE(1755)") + RG.GetCalc("LINE(1768)"));
            if (RG.GetCalc("LINE(1775)") == null)
                RG.AddCalc("LINE(1775)", RG.GetCalc("LINE(990)") + RG.GetCalc("LINE(1705)") + RG.GetCalc("LINE(1735)"));
            if (RG.GetCalc("LINE(1771)") == null)
                RG.AddCalc("LINE(1771)", RG.GetCalc("LINE(990)") + RG.GetCalc("LINE(1705)") + RG.GetCalc("LINE(1720)") + RG.GetCalc("LINE(1735)") + RG.GetCalc("LINE(1750)") + RG.GetCalc("LINE(1765)"));
            if (RG.GetCalc("LINE(1772)") == null)
                RG.AddCalc("LINE(1772)", RG.GetCalc("LINE(1770)") + RG.GetCalc("LINE(1771)"));
            if (RG.GetCalc("TotMgmtTA") == null)
                RG.AddCalc("TotMgmtTA", RG.GetCalc("LINE(995)") + RG.GetCalc("LINE(1713)") + RG.GetCalc("LINE(1737)"));
            if (RG.GetCalc("TotMgmtOF") == null)
                RG.AddCalc("TotMgmtOF", RG.GetCalc("LINE(1725)") + RG.GetCalc("LINE(1755)") + RG.GetCalc("LINE(1768)"));
            if (RG.GetCalc("TotGwthTA") == null)
                RG.AddCalc("TotGwthTA", RG.GetCalc("LINE(990)") + RG.GetCalc("LINE(1705)") + RG.GetCalc("LINE(1735)"));
            if (RG.GetCalc("TotGwthOF") == null)
                RG.AddCalc("TotGwthOF", RG.GetCalc("LINE(1720)") + RG.GetCalc("LINE(1750)") + RG.GetCalc("LINE(1765)"));
            if (RG.GetCalc("CashOps") == null)
                RG.AddCalc("CashOps", RG.GetCalc("LINE(987)") + RG.GetCalc("LINE(1772)"));
        }
        public void Data_Test_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("LIFOReserve") == null)
                RG.AddCalc("LIFOReserve", RG.TYPE(216) * RG.CONV_RATE());
            if (RG.GetCalc("CurrentPortionLTD") == null)
                RG.AddCalc("CurrentPortionLTD", (RG.TYPE(80) + RG.TYPE(81)) * RG.CONV_RATE());
            if (RG.GetCalc("ChgInSTDebt") == null)
                RG.AddCalc("ChgInSTDebt", (RG.TYPE(75) * RG.CONV_RATE() - RG.TYPE(75, RG.LAG) * RG.CONV_RATE(RG.LAG)) + (RG.TYPE(73) * RG.CONV_RATE() - RG.TYPE(73, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("LINE(9300)") == null)
                RG.AddCalc("LINE(9300)", RG.TYPE(130, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(9301)") == null)
            {
                RG.AddCalc("LINE(9301)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(9300)").Count; i++)
                    if (RG.GetCalc("LINE(9300)")[i] == 0)
                        RG.GetCalc("LINE(9301)").Add(RG.TYPE(130)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(9301)").Add(RG.GetCalc("LINE(9300)")[i]);
            }
            if (RG.GetCalc("%ChgComStk") == null)
                RG.AddCalc("%ChgComStk", (RG.TYPE(130) * RG.CONV_RATE() - RG.TYPE(130, RG.LAG) * RG.CONV_RATE(RG.LAG)) % RG.GetCalc("LINE(9301)"));
            if (RG.GetCalc("LINE(9305)") == null)
                RG.AddCalc("LINE(9305)", RG.TYPE(129, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("LINE(9306)") == null)
            {
                RG.AddCalc("LINE(9306)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(9305)").Count; i++)
                    if (RG.GetCalc("LINE(9305)")[i] == 0)
                        RG.GetCalc("LINE(9306)").Add(RG.TYPE(129)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(9306)").Add(RG.GetCalc("LINE(9305)")[i]);
            }
            if (RG.GetCalc("%ChgPrefStk") == null)
                RG.AddCalc("%ChgPrefStk", (RG.TYPE(129) * RG.CONV_RATE() - RG.TYPE(129, RG.LAG) * RG.CONV_RATE(RG.LAG)) % RG.GetCalc("LINE(9306)"));
            if (RG.GetCalc("AdjToRE") == null)
                RG.AddCalc("AdjToRE", RG.TYPE(210) * RG.CONV_RATE() + RG.GetCalc("LINE(206)"));
            if (RG.GetCalc("NonOpIncExp") == null)
                RG.AddCalc("NonOpIncExp", RG.GetCalc("TotOthIncExp") + RG.GetCalc("TotIntExp"));
            //			if (RG.GetCalc("ExtraItems") == null)
            //				RG.AddCalc("ExtraItems", (RG.TYPE(195) - RG.TYPE(200) + RG.TYPE(197)) * RG.CONV_RATE());
            if (RG.GetCalc("NFATNW") == null)
                RG.AddCalc("NFATNW", RG.GetCalc("NetFxdAsts") / RG.GetCalc("TangNetWrthAct"));
            if (RG.GetCalc("LINE(9200)") == null)
                RG.AddCalc("LINE(9200)", (RG.TYPE(216) + RG.TYPE(217)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(9201)") == null)
                RG.AddCalc("LINE(9201)", RG.TYPE(218) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(9202)") == null)
                RG.AddCalc("LINE(9202)", RG.GetCalc("TangNetWrthAct") + ((1 - RG.GetCalc("EffTaxRate") / 100) * RG.GetCalc("LINE(9200)")));
            if (RG.GetCalc("OffBSLever") == null)
                RG.AddCalc("OffBSLever", (RG.GetCalc("TotLiabs") + RG.GetCalc("LINE(9201)") + (RG.GetCalc("EffTaxRate") / 100 * RG.GetCalc("LINE(9200)"))) / RG.GetCalc("LINE(9202)"));
            if (RG.GetCalc("LINE(9098)") == null)
                RG.AddCalc("LINE(9098)", ((RG.TYPE(80) + RG.TYPE(81)) * RG.CONV_RATE() - (RG.GetDetailCalcs("DTInterestExp").GetTotals(RG) / RG.YEAR() + RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG))));
            if (RG.GetCalc("LINE(9099)") == null)
            {
                RG.AddCalc("LINE(9099)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(9098)").Count; i++)
                    if (RG.GetCalc("LINE(9098)")[i] <= 0)
                        RG.GetCalc("LINE(9099)").Add(0);
                    else
                        RG.GetCalc("LINE(9099)").Add(RG.GetCalc("LINE(9098)")[i]);
            }
            if (RG.GetCalc("CashCover") == null)
                RG.AddCalc("CashCover", (RG.GetCalc("NetCashAfterOps") / RG.YEAR()) / RG.GetCalc("LINE(9099)"));
            if (RG.GetCalc("LINE(9110)") == null)
            {
                RG.AddCalc("LINE(9110)", new Calc());
                for (int i = 0; i < RG.MACRO(M.NET_PROFIT).Count; i++)
                    if (RG.MACRO(M.NET_PROFIT)[i] <= 0)
                        RG.GetCalc("LINE(9110)").Add(0);
                    else
                        RG.GetCalc("LINE(9110)").Add(1);
            }
            if (RG.GetCalc("RetentRate") == null)
                RG.AddCalc("RetentRate", (100 - RG.GetCalc("DivPayRate")) / RG.GetCalc("LINE(9110)"));
            if (RG.GetCalc("TotAstSales") == null)
                RG.AddCalc("TotAstSales", RG.GetCalc("TotalAssets") / (RG.GetCalc("NetSalesRev") / RG.YEAR()));
            if (RG.GetCalc("OthAstTotAst") == null)
                RG.AddCalc("OthAstTotAst", (RG.TYPE(55) + RG.TYPE(60) + RG.TYPE(65)) * RG.CONV_RATE() / RG.GetCalc("TotalAssets"));
            if (RG.GetCalc("STDebtTotAst") == null)
                RG.AddCalc("STDebtTotAst", (RG.CLASS(15) - RG.TYPE(80) - RG.TYPE(81)) * RG.CONV_RATE() / RG.GetCalc("TotalAssets"));
            if (RG.GetCalc("AccOthCurLiabs") == null)
                RG.AddCalc("AccOthCurLiabs", RG.GetCalc("LINE(1755)") + RG.GetCalc("LINE(1768)"));
            if (RG.GetCalc("DepreciationRate") == null)
                RG.AddCalc("DepreciationRate", (RG.TYPE(40) - RG.TYPE(45)) / ((RG.TYPE(152) + RG.TYPE(160)) / RG.YEAR()));
        }
        public void NotesFSCalcs(ReportGenerator RG)
        {
            if (RG.GetCalc("ProjStat") == null)
                RG.AddCalc("ProjStat", RG.DETAILAND(240, RG.ANDTYPE, 35, RG.ANDCLASS));
            if (RG.GetCalc("HistStat") == null)
                RG.AddCalc("HistStat", RG.DETAILAND(215, RG.ANDTYPE, 35, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("SICCode") == null)
                RG.AddCalc("SICCode", RG.DETAILAND(219, RG.ANDTYPE, 35, RG.ANDCLASS));
            if (RG.GetCalc("PerCashSales") == null)
                RG.AddCalc("PerCashSales", RG.DETAILAND(220, RG.ANDTYPE, 35, RG.ANDCLASS));
            if (RG.GetCalc("AdjToIntang") == null)
                RG.AddCalc("AdjToIntang", RG.DETAILAND(222, RG.ANDTYPE, 35, RG.ANDCLASS) * RG.CONV_RATE());
            if (RG.GetCalc("ConvRate") == null)
                RG.AddCalc("ConvRate", RG.DETAILAND(221, RG.ANDTYPE, 35, RG.ANDCLASS));
            if (RG.GetDetailCalcs("AstFootNotes1") == null)
                RG.AddCalc("AstFootNotes1", RG.DETAILAND(212, RG.ANDTYPE, 5, RG.ANDCLASS));
            if (RG.GetDetailCalcs("AstFootNotes2") == null)
                RG.AddCalc("AstFootNotes2", RG.DETAILAND(212, RG.ANDTYPE, 10, RG.ANDCLASS));
            if (RG.GetDetailCalcs("LIABEQNotes1") == null)
                RG.AddCalc("LIABEQNotes1", RG.DETAILAND(212, RG.ANDTYPE, 15, RG.ANDCLASS));
            if (RG.GetDetailCalcs("LIABEQNotes2") == null)
                RG.AddCalc("LIABEQNotes2", RG.DETAILAND(212, RG.ANDTYPE, 20, RG.ANDCLASS));
            if (RG.GetDetailCalcs("LIABEQNotes3") == null)
                RG.AddCalc("LIABEQNotes3", RG.DETAILAND(212, RG.ANDTYPE, 22, RG.ANDCLASS));
            if (RG.GetDetailCalcs("LIABEQNotes4") == null)
                RG.AddCalc("LIABEQNotes4", RG.DETAILAND(212, RG.ANDTYPE, 25, RG.ANDCLASS));
            if (RG.GetDetailCalcs("ISFootNotes") == null)
                RG.AddCalc("ISFootNotes", RG.DETAILAND(212, RG.ANDTYPE, 30, RG.ANDCLASS));
            if (RG.GetDetailCalcs("StatFootNotes") == null)
                RG.AddCalc("StatFootNotes", RG.DETAILAND(212, RG.ANDTYPE, 35, RG.ANDCLASS));
        }
        public void ABLCalcs(ReportGenerator RG)
        {
            FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

            if (RG.GetCalc("LINE(5500)") == null)
            {
                RG.AddCalc("LINE(5500)", new Calc());
                for (int i = 0; i < RG.TYPE(248).Count; i++)
                    if (RG.TYPE(248)[i] != 0)
                        RG.GetCalc("LINE(5500)").Add(RG.TYPE(248)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5500)").Add((RG.TYPE(10)[i] - RG.TYPE(11)[i]) * RG.CONV_RATE()[i]);
            }
            if (RG.GetDetailCalcs("LINE(5501)") == null)
                RG.AddCalc("LINE(5501)", RG.DETAILTYPE(250) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5502)") == null)
                RG.AddCalc("LINE(5502)", RG.MACRO(M.TOTAL_ACCTS_RECVBLE) - RG.GetDetailCalcs("LINE(5501)").GetTotals(RG));
            if (RG.GetCalc("LINE(5503)") == null)
            {
                RG.AddCalc("LINE(5503)", new Calc());
                for (int i = 0; i < RG.MACRO(M.TOTAL_ACCTS_RECVBLE).Count; i++)
                    if (RG.GetCalc("LINE(5502)")[i] > 0)
                        RG.GetCalc("LINE(5503)").Add(RG.GetCalc("LINE(5502)")[i]);
                    else
                        RG.GetCalc("LINE(5503)").Add(0);
            }

            /// formatting calcs for the AR section
            /// determine if the subtotal should print.  Should print only if "sets" exist (a $ amount with a % advance)
            if (RG.GetCalc("LINE(5750)") == null)
            {
                RG.AddCalc("LINE(5750)", new Calc());
                for (int i = 0; i < RG.MACRO(M.TOTAL_ACCTS_RECVBLE).Count; i++)
                    if (RG.MACRO(M.TOTAL_ACCTS_RECVBLE)[i] != 0)
                        RG.GetCalc("LINE(5750)").Add(1);
                    else
                        RG.GetCalc("LINE(5750)").Add(0);
            }
            if (RG.GetCalc("LINE(5752)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(250)) > 0)
                    RG.AddCalc("LINE(5752)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5752)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5753)") == null)
                RG.AddCalc("LINE(5753)", RG.GetCalc("LINE(5750)") + RG.GetCalc("LINE(5752)"));
            if (RG.GetCalc("LINE(5754)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5753)").Count; i++)
                    /// if 5753 = 2 for any period then we have both AR and AR adjust.
                    if (RG.GetCalc("LINE(5753)")[i] == 2)
                    {
                        RG.AddCalc("LINE(5754)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5754)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetDetailCalcs("ACCT(1020)") == null)
                RG.AddCalc("ACCT(1020)", RG.DETAILACCOUNT(1020));
            if (RG.GetCalc("LINE(5760)") == null)
                RG.AddCalc("LINE(5760)", RG.GetCalc("LINE(5754)") + RG.GetCalc("LINE(5750)"));
            if (RG.GetCalc("LINE(5761)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5760)").Count; i++)
                    /// if 5760 is 1 or 2 for any period then we have either AR or eligible AR.
                    if (RG.GetCalc("LINE(5760)")[i] > 0)
                    {
                        RG.AddCalc("LINE(5761)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5761)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5762)") == null)
            {
                for (int i = 0; i < RG.ACCOUNT(1020).Count; i++)
                    if (RG.ACCOUNT(1020)[i] != 0)
                    {
                        RG.AddCalc("LINE(5762)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5762)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5763)") == null)
                RG.AddCalc("LINE(5763)", RG.GetCalc("LINE(5761)") + RG.GetCalc("LINE(5762)"));
            if (RG.GetCalc("LINE(5504)") == null)
                RG.AddCalc("LINE(5504)", RG.GetCalc("LINE(5503)") * RG.ACCOUNT(1020) / 100);
            if (RG.GetDetailCalcs("TYPE(254)") == null)
                RG.AddCalc("TYPE(254)", RG.DETAILTYPE(254) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(256)") == null)
                RG.AddCalc("TYPE(256)", RG.DETAILTYPE(256) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5508)") == null)
            {
                RG.AddCalc("LINE(5508)", new Calc());
                for (int i = 0; i < RG.TYPE(254).Count; i++)
                    if (RG.TYPE(254)[i] != 0)
                        RG.GetCalc("LINE(5508)").Add(RG.TYPE(254)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5508)").Add(RG.GetCalc("LINE(5504)")[i]);
            }
            if (RG.GetCalc("LINE(5505)") == null)
            {
                RG.AddCalc("LINE(5505)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5508)").Count; i++)
                    /// if b15 > b16
                    if (RG.GetCalc("LINE(5504)")[i] > RG.GetCalc("LINE(5508)")[i])
                        RG.GetCalc("LINE(5505)").Add(RG.GetCalc("LINE(5508)")[i]);
                    else
                        RG.GetCalc("LINE(5505)").Add(RG.GetCalc("LINE(5504)")[i]);
            }
            if (RG.GetCalc("LINE(5506)") == null)
                RG.AddCalc("LINE(5506)", RG.GetCalc("LINE(5505)") - RG.TYPE(256) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5507)") == null)
            {
                RG.AddCalc("LINE(5507)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5506)").Count; i++)
                    if (RG.GetCalc("LINE(5506)")[i] > 0)
                        RG.GetCalc("LINE(5507)").Add(RG.GetCalc("LINE(5506)")[i]);
                    else
                        RG.GetCalc("LINE(5507)").Add(0);
            }
            if (RG.GetCalc("LINE(5765)") == null)
            {
                RG.AddCalc("LINE(5765)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5504)").Count; i++)
                    if (RG.GetCalc("LINE(5504)")[i] != 0)
                        RG.GetCalc("LINE(5765)").Add(1);
                    else
                        RG.GetCalc("LINE(5765)").Add(0);
            }
            if (RG.GetCalc("LINE(5757)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(254)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(256)) > 0)
                    RG.AddCalc("LINE(5757)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5757)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5758)") == null)
                RG.AddCalc("LINE(5758)", RG.GetCalc("LINE(5765)") + RG.GetCalc("LINE(5757)"));
            if (RG.GetCalc("LINE(5511)") == null)
            {
                RG.AddCalc("LINE(5511)", new Calc());
                for (int i = 0; i < RG.TYPE(258).Count; i++)
                    if (RG.TYPE(258)[i] != 0)
                        RG.GetCalc("LINE(5511)").Add(RG.TYPE(258)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5511)").Add(RG.TYPE(15)[i] * RG.CONV_RATE()[i]);
            }
            if (RG.GetDetailCalcs("ACCT(4950)") == null)
                RG.AddCalc("ACCT(4950)", RG.DETAILACCOUNT(4950));
            if (RG.GetCalc("LINE(5512)") == null)
            {
                RG.AddCalc("LINE(5512)", new Calc());
                for (int i = 0; i < RG.TYPE(260).Count; i++)
                    if (RG.TYPE(260)[i] != 0)
                        RG.GetCalc("LINE(5512)").Add(RG.TYPE(260)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5512)").Add(RG.TYPE(16)[i] * RG.CONV_RATE()[i]);
            }
            if (RG.GetDetailCalcs("ACCT(4980)") == null)
                RG.AddCalc("ACCT(4980)", RG.DETAILACCOUNT(4980));
            if (RG.GetCalc("LINE(5513)") == null)
            {
                RG.AddCalc("LINE(5513)", new Calc());
                for (int i = 0; i < RG.TYPE(262).Count; i++)
                    if (RG.TYPE(262)[i] != 0)
                        RG.GetCalc("LINE(5513)").Add(RG.TYPE(262)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5513)").Add(RG.TYPE(17)[i] * RG.CONV_RATE()[i]);
            }
            if (RG.GetDetailCalcs("ACCT(5010)") == null)
                RG.AddCalc("ACCT(5010)", RG.DETAILACCOUNT(5010));
            /// formatting calcualtions for inventory section
            /// determine if the subtotal should print.  should print only if an "sets" exist.
            if (RG.GetCalc("LINE(5700)") == null)
            {
                RG.AddCalc("LINE(5700)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5511)").Count; i++)
                    if (RG.GetCalc("LINE(5511)")[i] != 0)
                        RG.GetCalc("LINE(5700)").Add(1);
                    else
                        RG.GetCalc("LINE(5700)").Add(0);
            }
            if (RG.GetCalc("LINE(5702)") == null)
            {
                RG.AddCalc("LINE(5702)", new Calc());
                for (int i = 0; i < RG.ACCOUNT(4950).Count; i++)
                    if (RG.ACCOUNT(4950)[i] != 0)
                        RG.GetCalc("LINE(5702)").Add(1);
                    else
                        RG.GetCalc("LINE(5702)").Add(0);
            }
            if (RG.GetCalc("LINE(5703)") == null)
                RG.AddCalc("LINE(5703)", RG.GetCalc("LINE(5700)") + RG.GetCalc("LINE(5702)"));
            if (RG.GetCalc("LINE(5704)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5703)").Count; i++)
                    /// if 5703 = 2 for any period then we have both RM and RM adjust.
                    if (RG.GetCalc("LINE(5703)")[i] == 2)
                    {
                        RG.AddCalc("LINE(5704)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5704)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5706)") == null)
            {
                RG.AddCalc("LINE(5706)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5512)").Count; i++)
                    if (RG.GetCalc("LINE(5512)")[i] != 0)
                        RG.GetCalc("LINE(5706)").Add(1);
                    else
                        RG.GetCalc("LINE(5706)").Add(0);
            }
            if (RG.GetCalc("LINE(5708)") == null)
            {
                RG.AddCalc("LINE(5708)", new Calc());
                for (int i = 0; i < RG.ACCOUNT(4980).Count; i++)
                    if (RG.ACCOUNT(4980)[i] != 0)
                        RG.GetCalc("LINE(5708)").Add(1);
                    else
                        RG.GetCalc("LINE(5708)").Add(0);
            }
            if (RG.GetCalc("LINE(5710)") == null)
                RG.AddCalc("LINE(5710)", RG.GetCalc("LINE(5706)") + RG.GetCalc("LINE(5708)"));
            if (RG.GetCalc("LINE(5711)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5710)").Count; i++)
                    /// if 5710 = 2 for any period then we have both WIP and WIP adjust.
                    if (RG.GetCalc("LINE(5710)")[i] == 2)
                    {
                        RG.AddCalc("LINE(5711)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5711)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5715)") == null)
            {
                RG.AddCalc("LINE(5715)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5513)").Count; i++)
                    if (RG.GetCalc("LINE(5513)")[i] != 0)
                        RG.GetCalc("LINE(5715)").Add(1);
                    else
                        RG.GetCalc("LINE(5715)").Add(0);
            }
            if (RG.GetCalc("LINE(5716)") == null)
            {
                RG.AddCalc("LINE(5716)", new Calc());
                for (int i = 0; i < RG.ACCOUNT(5010).Count; i++)
                    if (RG.ACCOUNT(5010)[i] != 0)
                        RG.GetCalc("LINE(5716)").Add(1);
                    else
                        RG.GetCalc("LINE(5716)").Add(0);
            }
            if (RG.GetCalc("LINE(5717)") == null)
                RG.AddCalc("LINE(5717)", RG.GetCalc("LINE(5715)") + RG.GetCalc("LINE(5716)"));
            if (RG.GetCalc("LINE(5718)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5717)").Count; i++)
                    /// if 5717 = 2 for any period then we have both FG and FG adjust.
                    if (RG.GetCalc("LINE(5717)")[i] == 2)
                    {
                        RG.AddCalc("LINE(5718)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5718)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5720)") == null)
                RG.AddCalc("LINE(5720)", RG.GetCalc("LINE(5704)") + RG.GetCalc("LINE(5711)") + RG.GetCalc("LINE(5718)"));
            if (RG.GetCalc("LINE(5514)") == null)
            {
                RG.AddCalc("LINE(5514)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5720)").Count; i++)
                    if (RG.GetCalc("LINE(5720)")[i] > 0)
                        RG.GetCalc("LINE(5514)").Add((RG.GetCalc("LINE(5511)")[i] * RG.ACCOUNT(4950)[i] / 100) +
                            (RG.GetCalc("LINE(5512)")[i] * RG.ACCOUNT(4980)[i] / 100) + (RG.GetCalc("LINE(5513)")[i] * RG.ACCOUNT(5010)[i] / 100));
                    else
                        RG.GetCalc("LINE(5514)").Add(0);
            }
            if (RG.GetDetailCalcs("TYPE(264)") == null)
                RG.AddCalc("TYPE(264)", RG.DETAILTYPE(264) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(266)") == null)
                RG.AddCalc("TYPE(266)", RG.DETAILTYPE(266) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5509)") == null)
            {
                RG.AddCalc("LINE(5509)", new Calc());
                for (int i = 0; i < RG.TYPE(264).Count; i++)
                    if (RG.TYPE(264)[i] != 0)
                        RG.GetCalc("LINE(5509)").Add(RG.TYPE(264)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5509)").Add(RG.GetCalc("LINE(5514)")[i]);
            }
            if (RG.GetCalc("LINE(5515)") == null)
            {
                RG.AddCalc("LINE(5515)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5514)").Count; i++)
                    // if b27 < b28
                    if (RG.GetCalc("LINE(5514)")[i] < RG.GetCalc("LINE(5509)")[i])
                        RG.GetCalc("LINE(5515)").Add(RG.GetCalc("LINE(5514)")[i]);
                    else
                        RG.GetCalc("LINE(5515)").Add(RG.GetCalc("LINE(5509)")[i]);
            }
            if (RG.GetCalc("LINE(5516)") == null)
                RG.AddCalc("LINE(5516)", RG.GetCalc("LINE(5515)") - RG.TYPE(266) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5517)") == null)
            {
                RG.AddCalc("LINE(5517)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5516)").Count; i++)
                    if (RG.GetCalc("LINE(5516)")[i] > 0)
                        RG.GetCalc("LINE(5517)").Add(RG.GetCalc("LINE(5516)")[i]);
                    else
                        RG.GetCalc("LINE(5517)").Add(0);
            }
            if (RG.GetDetailCalcs("TYPE(268)") == null)
                RG.AddCalc("TYPE(268)", RG.DETAILTYPE(268) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(270)") == null)
                RG.AddCalc("TYPE(270)", RG.DETAILTYPE(270) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5731)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(264)) + FormatCommands.DetailCount(RG, RG.DETAILTYPE(266)) > 0)
                    RG.AddCalc("LINE(5731)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5731)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5732)") == null)
            {
                RG.AddCalc("LINE(5732)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5517)").Count; i++)
                    if (RG.GetCalc("LINE(5517)")[i] != 0)
                        RG.GetCalc("LINE(5732)").Add(1);
                    else
                        RG.GetCalc("LINE(5732)").Add(0);
            }
            if (RG.GetCalc("LINE(5733)") == null)
                RG.AddCalc("LINE(5733)", RG.GetCalc("LINE(5731)") + RG.GetCalc("LINE(5732)"));
            /// formatting calculations for the orders section
            if (RG.GetCalc("LINE(5850)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(268)) > 0)
                    RG.AddCalc("LINE(5850)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5850)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5852)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(270)) > 0)
                    RG.AddCalc("LINE(5852)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5852)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5853)") == null)
                RG.AddCalc("LINE(5853)", RG.GetCalc("LINE(5850)") + RG.GetCalc("LINE(5852)"));
            if (RG.GetCalc("LINE(5854)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5853)").Count; i++)
                    /// if 5853 = 2 for any period then we have both orders and adjusts.
                    if (RG.GetCalc("LINE(5853)")[i] == 2)
                    {
                        RG.AddCalc("LINE(5854)", new Calc(2, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5854)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5521)") == null)
                RG.AddCalc("LINE(5521)", (RG.TYPE(268) - RG.TYPE(270)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5522)") == null)
            {
                RG.AddCalc("LINE(5522)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5521)").Count; i++)
                    if (RG.GetCalc("LINE(5521)")[i] > 0)
                        RG.GetCalc("LINE(5522)").Add(RG.GetCalc("LINE(5521)")[i]);
                    else
                        RG.GetCalc("LINE(5522)").Add(0);
            }
            if (RG.GetDetailCalcs("ACCT(5640)") == null)
                RG.AddCalc("ACCT(5640)", RG.DETAILACCOUNT(5640));
            if (RG.GetCalc("LINE(5860)") == null)
                RG.AddCalc("LINE(5860)", RG.GetCalc("LINE(5854)") + RG.GetCalc("LINE(5850)"));
            if (RG.GetCalc("LINE(5861)") == null)
            {
                for (int i = 0; i < RG.GetCalc("LINE(5860)").Count; i++)
                    /// if 5860 is 1 or 2, then have orders or eligible orders
                    if (RG.GetCalc("LINE(5860)")[i] > 0)
                    {
                        RG.AddCalc("LINE(5861)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5861)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5862)") == null)
            {
                for (int i = 0; i < RG.ACCOUNT(5640).Count; i++)
                    if (RG.ACCOUNT(5640)[i] != 0)
                    {
                        RG.AddCalc("LINE(5862)", new Calc(1, RG.Statements.Count));
                        break;
                    }
                    else
                        RG.AddCalc("LINE(5862)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5863)") == null)
                RG.AddCalc("LINE(5863)", RG.GetCalc("LINE(5862)") + RG.GetCalc("LINE(5861)"));
            if (RG.GetCalc("LINE(5523)") == null)
                RG.AddCalc("LINE(5523)", RG.GetCalc("LINE(5522)") * RG.ACCOUNT(5640) / 100);
            if (RG.GetDetailCalcs("TYPE(272)") == null)
                RG.AddCalc("TYPE(272)", RG.DETAILTYPE(272) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5510)") == null)
            {
                RG.AddCalc("LINE(5510)", new Calc());
                for (int i = 0; i < RG.TYPE(272).Count; i++)
                    if (RG.TYPE(272)[i] != 0)
                        RG.GetCalc("LINE(5510)").Add(RG.TYPE(272)[i] * RG.CONV_RATE()[i]);
                    else
                        RG.GetCalc("LINE(5510)").Add(RG.GetCalc("LINE(5523)")[i]);
            }
            if (RG.GetCalc("LINE(5524)") == null)
            {
                RG.AddCalc("LINE(5524)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5523)").Count; i++)
                    if (RG.GetCalc("LINE(5523)")[i] > RG.GetCalc("LINE(5510)")[i])
                        RG.GetCalc("LINE(5524)").Add(RG.GetCalc("LINE(5510)")[i]);
                    else
                        RG.GetCalc("LINE(5524)").Add(RG.GetCalc("LINE(5523)")[i]);
            }
            if (RG.GetCalc("LINE(5525)") == null)
            {
                RG.AddCalc("LINE(5525)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5524)").Count; i++)
                    if (RG.GetCalc("LINE(5524)")[i] > 0)
                        RG.GetCalc("LINE(5525)").Add(RG.GetCalc("LINE(5524)")[i]);
                    else
                        RG.GetCalc("LINE(5525)").Add(0);
            }
            if (RG.GetCalc("LINE(5865)") == null)
            {
                RG.AddCalc("LINE(5865)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5523)").Count; i++)
                    if (RG.GetCalc("LINE(5523)")[i] != 0)
                        RG.GetCalc("LINE(5865)").Add(1);
                    else
                        RG.GetCalc("LINE(5865)").Add(0);
            }
            if (RG.GetCalc("LINE(5867)") == null)
            {
                if (FormatCommands.DetailCount(RG, RG.DETAILTYPE(272)) > 0)
                    RG.AddCalc("LINE(5867)", new Calc(1, RG.Statements.Count));
                else
                    RG.AddCalc("LINE(5867)", new Calc(0, RG.Statements.Count));
            }
            if (RG.GetCalc("LINE(5868)") == null)
                RG.AddCalc("LINE(5868)", RG.GetCalc("LINE(5865)") + RG.GetCalc("LINE(5867)"));
            if (RG.GetCalc("LINE(5529)") == null)
                RG.AddCalc("LINE(5529)", RG.GetCalc("LINE(5500)") + RG.GetCalc("LINE(5511)") + RG.GetCalc("LINE(5512)") +
                    RG.GetCalc("LINE(5513)") + (RG.TYPE(268) * RG.CONV_RATE()));
            if (RG.GetCalc("LINE(5530)") == null)
                RG.AddCalc("LINE(5530)", RG.GetDetailCalcs("LINE(5501)").GetTotals(RG) + (RG.TYPE(270) * RG.CONV_RATE()));
            if (RG.GetCalc("EligAssets") == null)
                RG.AddCalc("EligAssets", RG.GetCalc("LINE(5529)") - RG.GetCalc("LINE(5530)"));
            if (RG.GetCalc("LINE(5531)") == null)
                RG.AddCalc("LINE(5531)", RG.GetCalc("LINE(5504)") + RG.GetCalc("LINE(5514)") + RG.GetCalc("LINE(5523)"));
            ///if b15 - b16 > 0
            if (RG.GetCalc("LINE(5532)") == null)
                RG.AddCalc("LINE(5532)", RG.GetCalc("LINE(5504)") - (RG.TYPE(254) * RG.CONV_RATE()));
            if (RG.GetCalc("LINE(5533)") == null)
            {
                RG.AddCalc("LINE(5533)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5532)").Count; i++)
                    if (RG.GetCalc("LINE(5532)")[i] > 0)
                        RG.GetCalc("LINE(5533)").Add(RG.GetCalc("LINE(5532)")[i]);
                    else
                        RG.GetCalc("LINE(5533)").Add(0);
            }
            if (RG.GetCalc("LINE(5534)") == null)
            {
                RG.AddCalc("LINE(5534)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5505)").Count; i++)
                    if (RG.GetCalc("LINE(5505)")[i] > 0)
                        RG.GetCalc("LINE(5534)").Add(RG.GetCalc("LINE(5533)")[i]);
                    else
                        RG.GetCalc("LINE(5534)").Add(0);
            }
            if (RG.GetCalc("LINE(5535)") == null)
            {
                RG.AddCalc("LINE(5535)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5514)").Count; i++)
                    ///if b27-b28 > 0
                    if (RG.GetCalc("LINE(5514)")[i] > (RG.TYPE(264)[i] * RG.CONV_RATE()[i]))
                        RG.GetCalc("LINE(5535)").Add(0);
                    else
                        RG.GetCalc("LINE(5535)").Add(1);
            }
            if (RG.GetCalc("LINE(5536)") == null)
                RG.AddCalc("LINE(5536)", RG.GetCalc("LINE(5514)") - (RG.TYPE(264) * RG.CONV_RATE()));
            if (RG.GetCalc("LINE(5537)") == null)
            {
                RG.AddCalc("LINE(5537)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5536)").Count; i++)
                    if (RG.GetCalc("LINE(5536)")[i] > 0)
                        RG.GetCalc("LINE(5537)").Add(RG.GetCalc("LINE(5536)")[i]);
                    else
                        RG.GetCalc("LINE(5537)").Add(0);
            }
            if (RG.GetCalc("LINE(5538)") == null)
            {
                RG.AddCalc("LINE(5538)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5535)").Count; i++)
                    if (RG.GetCalc("LINE(5535)")[i] == 0)
                        RG.GetCalc("LINE(5538)").Add(RG.GetCalc("LINE(5537)")[i]);
                    else
                        RG.GetCalc("LINE(5538)").Add(0);
            }
            ///if b37 - b38 > 0
            if (RG.GetCalc("LINE(5539)") == null)
                RG.AddCalc("LINE(5539)", RG.GetCalc("LINE(5523)") - RG.GetCalc("LINE(5525)"));
            if (RG.GetCalc("LINE(5540)") == null)
            {
                RG.AddCalc("LINE(5540)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5539)").Count; i++)
                    if (RG.GetCalc("LINE(5539)")[i] > 0)
                        RG.GetCalc("LINE(5540)").Add(RG.GetCalc("LINE(5539)")[i]);
                    else
                        RG.GetCalc("LINE(5540)").Add(0);
            }
            if (RG.GetCalc("LINE(5541)") == null)
            {
                RG.AddCalc("LINE(5541)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5524)").Count; i++)
                    if (RG.GetCalc("LINE(5524)")[i] > 0)
                        RG.GetCalc("LINE(5541)").Add(RG.GetCalc("LINE(5540)")[i]);
                    else
                        RG.GetCalc("LINE(5541)").Add(0);
            }
            if (RG.GetCalc("ExclDueToCaps") == null)
                RG.AddCalc("ExclDueToCaps", RG.GetCalc("LINE(5534)") + RG.GetCalc("LINE(5538)") + RG.GetCalc("LINE(5541)"));
            if (RG.GetCalc("TotSenLeinDed") == null)
                RG.AddCalc("TotSenLeinDed", (RG.TYPE(256) + RG.TYPE(266)) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5542)") == null)
                RG.AddCalc("LINE(5542)", RG.GetCalc("LINE(5507)") + RG.GetCalc("LINE(5517)") + RG.GetCalc("LINE(5525)"));
            if (RG.GetDetailCalcs("TYPE(274)") == null)
                RG.AddCalc("TYPE(274)", RG.DETAILTYPE(274) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(276)") == null)
                RG.AddCalc("TYPE(276)", RG.DETAILTYPE(276) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(278)") == null)
                RG.AddCalc("TYPE(278)", RG.DETAILTYPE(278) * RG.CONV_RATE());
            if (RG.GetDetailCalcs("TYPE(280)") == null)
                RG.AddCalc("TYPE(280)", RG.DETAILTYPE(280) * RG.CONV_RATE());
            if (RG.GetCalc("LINE(5543)") == null)
            {
                RG.AddCalc("LINE(5543)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(5542)").Count; i++)
                    if (RG.GetCalc("LINE(5542)")[i] < (RG.TYPE(274)[i] * RG.CONV_RATE()[i]))
                        RG.GetCalc("LINE(5543)").Add(RG.GetCalc("LINE(5542)")[i] - ((RG.TYPE(276)[i] + RG.TYPE(278)[i] + RG.TYPE(280)[i]) * RG.CONV_RATE()[i]));
                    else
                        RG.GetCalc("LINE(5543)").Add((RG.TYPE(274)[i] - RG.TYPE(276)[i] - RG.TYPE(278)[i] - RG.TYPE(280)[i]) * RG.CONV_RATE()[i]);
            }
        }
        public void BS_Assumption_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("ACCT(1050)") == null)
            {
                RG.AddCalc("ACCT(1050)", RG.DETAILACCOUNT(1050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1050)", (RG.ACCOUNT(1050) * RG.CONV_RATE()) - (RG.ACCOUNT(1050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1050)", ((RG.ACCOUNT(1050) * RG.CONV_RATE()) - (RG.ACCOUNT(1050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1050)", (RG.ACCOUNT(1050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1100)") == null)
            {
                RG.AddCalc("ACCT(1100)", RG.DETAILACCOUNT(1100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1100)", (RG.ACCOUNT(1100) * RG.CONV_RATE()) - (RG.ACCOUNT(1100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1100)", ((RG.ACCOUNT(1100) * RG.CONV_RATE()) - (RG.ACCOUNT(1100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1100)", (RG.ACCOUNT(1100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1150)") == null)
            {
                RG.AddCalc("ACCT(1150)", RG.DETAILACCOUNT(1150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1150)", (RG.ACCOUNT(1150) * RG.CONV_RATE()) - (RG.ACCOUNT(1150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1150)", ((RG.ACCOUNT(1150) * RG.CONV_RATE()) - (RG.ACCOUNT(1150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1150)", (RG.ACCOUNT(1150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1200)") == null)
            {
                RG.AddCalc("ACCT(1200)", RG.DETAILACCOUNT(1200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1200)", (RG.ACCOUNT(1200) * RG.CONV_RATE()) - (RG.ACCOUNT(1200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1200)", ((RG.ACCOUNT(1200) * RG.CONV_RATE()) - (RG.ACCOUNT(1200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1200)", (RG.ACCOUNT(1200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("DOHGrsRec(1200)", (RG.ACCOUNT(1200) * RG.CONV_RATE()) / (RG.MACRO(M.NET_SALES) / RG.YEAR()) * 365);
            }
            if (RG.GetCalc("ACCT(1230)") == null)
            {
                RG.AddCalc("ACCT(1230)", RG.DETAILACCOUNT(1230) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1230)", (RG.ACCOUNT(1230) * RG.CONV_RATE()) - (RG.ACCOUNT(1230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1230)", ((RG.ACCOUNT(1230) * RG.CONV_RATE()) - (RG.ACCOUNT(1230, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1230)", (RG.ACCOUNT(1230) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            //amit: 12/06/05 tracker log# 1497
            if (RG.GetCalc("ACCT(1240)") == null)
            {
                RG.AddCalc("ACCT(1240)", RG.DETAILACCOUNT(1240) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1240)", (RG.ACCOUNT(1240) * RG.CONV_RATE()) - (RG.ACCOUNT(1240, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1240)", ((RG.ACCOUNT(1240) * RG.CONV_RATE()) - (RG.ACCOUNT(1240, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1240, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1240)", (RG.ACCOUNT(1240) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }

            if (RG.GetCalc("ACCT(1250)") == null)
            {
                RG.AddCalc("ACCT(1250)", RG.DETAILACCOUNT(1250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1250)", (RG.ACCOUNT(1250) * RG.CONV_RATE()) - (RG.ACCOUNT(1250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1250)", ((RG.ACCOUNT(1250) * RG.CONV_RATE()) - (RG.ACCOUNT(1250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1250)", (RG.ACCOUNT(1250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1300)") == null)
            {
                RG.AddCalc("ACCT(1300)", RG.DETAILACCOUNT(1300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1300)", (RG.ACCOUNT(1300) * RG.CONV_RATE()) - (RG.ACCOUNT(1300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1300)", ((RG.ACCOUNT(1300) * RG.CONV_RATE()) - (RG.ACCOUNT(1300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1300)", (RG.ACCOUNT(1300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1670)") == null)
            {
                RG.AddCalc("ACCT(1670)", RG.DETAILACCOUNT(1670) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1670)", (RG.ACCOUNT(1670) * RG.CONV_RATE()) - (RG.ACCOUNT(1670, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1670)", ((RG.ACCOUNT(1670) * RG.CONV_RATE()) - (RG.ACCOUNT(1670, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1670, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1670)", (RG.ACCOUNT(1670) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1680)") == null)
            {
                RG.AddCalc("ACCT(1680)", RG.DETAILACCOUNT(1680) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1680)", (RG.ACCOUNT(1680) * RG.CONV_RATE()) - (RG.ACCOUNT(1680, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1680)", ((RG.ACCOUNT(1680) * RG.CONV_RATE()) - (RG.ACCOUNT(1680, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1680, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1680)", (RG.ACCOUNT(1680) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1400)") == null)
            {
                RG.AddCalc("ACCT(1400)", RG.DETAILACCOUNT(1400) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1400)", (RG.ACCOUNT(1400) * RG.CONV_RATE()) - (RG.ACCOUNT(1400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1400)", ((RG.ACCOUNT(1400) * RG.CONV_RATE()) - (RG.ACCOUNT(1400, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1400)", (RG.ACCOUNT(1400) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("DayOnHand(1400)", (RG.ACCOUNT(1400) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR()) * 365);
            }
            if (RG.GetCalc("ACCT(1450)") == null)
            {
                RG.AddCalc("ACCT(1450)", RG.DETAILACCOUNT(1450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1450)", (RG.ACCOUNT(1450) * RG.CONV_RATE()) - (RG.ACCOUNT(1450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1450)", ((RG.ACCOUNT(1450) * RG.CONV_RATE()) - (RG.ACCOUNT(1450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1450)", (RG.ACCOUNT(1450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("DayOnHand(1450)", (RG.ACCOUNT(1450) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR()) * 365);
            }
            if (RG.GetCalc("ACCT(1500)") == null)
            {
                RG.AddCalc("ACCT(1500)", RG.DETAILACCOUNT(1500) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1500)", (RG.ACCOUNT(1500) * RG.CONV_RATE()) - (RG.ACCOUNT(1500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1500)", ((RG.ACCOUNT(1500) * RG.CONV_RATE()) - (RG.ACCOUNT(1500, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1500)", (RG.ACCOUNT(1500) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("DayOnHand(1500)", (RG.ACCOUNT(1500) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR()) * 365);
            }
            if (RG.GetCalc("ACCT(1550)") == null)
            {
                RG.AddCalc("ACCT(1550)", RG.DETAILACCOUNT(1550) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1550)", (RG.ACCOUNT(1550) * RG.CONV_RATE()) - (RG.ACCOUNT(1550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1550)", ((RG.ACCOUNT(1550) * RG.CONV_RATE()) - (RG.ACCOUNT(1550, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1550)", (RG.ACCOUNT(1550) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1600)") == null)
            {
                RG.AddCalc("ACCT(1600)", RG.DETAILACCOUNT(1600) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1600)", (RG.ACCOUNT(1600) * RG.CONV_RATE()) - (RG.ACCOUNT(1600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1600)", ((RG.ACCOUNT(1600) * RG.CONV_RATE()) - (RG.ACCOUNT(1600, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1600)", (RG.ACCOUNT(1600) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1650)") == null)
            {
                RG.AddCalc("ACCT(1650)", RG.DETAILACCOUNT(1650) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1650)", (RG.ACCOUNT(1650) * RG.CONV_RATE()) - (RG.ACCOUNT(1650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1650)", ((RG.ACCOUNT(1650) * RG.CONV_RATE()) - (RG.ACCOUNT(1650, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1650)", (RG.ACCOUNT(1650) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1350)") == null)
            {
                RG.AddCalc("ACCT(1350)", RG.DETAILACCOUNT(1350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1350)", (RG.ACCOUNT(1350) * RG.CONV_RATE()) - (RG.ACCOUNT(1350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1350)", ((RG.ACCOUNT(1350) * RG.CONV_RATE()) - (RG.ACCOUNT(1350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1350)", (RG.ACCOUNT(1350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1700)") == null)
            {
                RG.AddCalc("ACCT(1700)", RG.DETAILACCOUNT(1700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1700)", (RG.ACCOUNT(1700) * RG.CONV_RATE()) - (RG.ACCOUNT(1700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1700)", ((RG.ACCOUNT(1700) * RG.CONV_RATE()) - (RG.ACCOUNT(1700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1700)", (RG.ACCOUNT(1700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(1750)") == null)
            {
                RG.AddCalc("ACCT(1750)", RG.DETAILACCOUNT(1750) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1750)", (RG.ACCOUNT(1750) * RG.CONV_RATE()) - (RG.ACCOUNT(1750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1750)", ((RG.ACCOUNT(1750) * RG.CONV_RATE()) - (RG.ACCOUNT(1750, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1750)", (RG.ACCOUNT(1750) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ Added for account 1790 - Update to Version V 6-11-03
            if (RG.GetCalc("ACCT(1790)") == null)
            {
                RG.AddCalc("ACCT(1790)", RG.DETAILACCOUNT(1790) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1790)", (RG.ACCOUNT(1790) * RG.CONV_RATE()) - (RG.ACCOUNT(1790, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1790)", ((RG.ACCOUNT(1790) * RG.CONV_RATE()) - (RG.ACCOUNT(1790, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1790, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1790)", (RG.ACCOUNT(1790) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ End of addition

            if (RG.GetCalc("ACCT(1800)") == null)
            {
                RG.AddCalc("ACCT(1800)", RG.DETAILACCOUNT(1800) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(1800)", (RG.ACCOUNT(1800) * RG.CONV_RATE()) - (RG.ACCOUNT(1800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(1800)", ((RG.ACCOUNT(1800) * RG.CONV_RATE()) - (RG.ACCOUNT(1800, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(1800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(1800)", (RG.ACCOUNT(1800) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            ///The Non-Current Asset Accounts start here
            if (RG.GetCalc("ACCT(2050)") == null)
            {
                RG.AddCalc("ACCT(2050)", RG.DETAILACCOUNT(2050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2050)", (RG.ACCOUNT(2050) * RG.CONV_RATE()) - (RG.ACCOUNT(2050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2050)", ((RG.ACCOUNT(2050) * RG.CONV_RATE()) - (RG.ACCOUNT(2050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2050)", (RG.ACCOUNT(2050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2070)") == null)
            {
                RG.AddCalc("ACCT(2070)", RG.DETAILACCOUNT(2070) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2070)", (RG.ACCOUNT(2070) * RG.CONV_RATE()) - (RG.ACCOUNT(2070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2070)", ((RG.ACCOUNT(2070) * RG.CONV_RATE()) - (RG.ACCOUNT(2070, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2070)", (RG.ACCOUNT(2070) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2100)") == null)
            {
                RG.AddCalc("ACCT(2100)", RG.DETAILACCOUNT(2100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2100)", (RG.ACCOUNT(2100) * RG.CONV_RATE()) - (RG.ACCOUNT(2100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2100)", ((RG.ACCOUNT(2100) * RG.CONV_RATE()) - (RG.ACCOUNT(2100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2100)", (RG.ACCOUNT(2100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2150)") == null)
            {
                RG.AddCalc("ACCT(2150)", RG.DETAILACCOUNT(2150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2150)", (RG.ACCOUNT(2150) * RG.CONV_RATE()) - (RG.ACCOUNT(2150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2150)", ((RG.ACCOUNT(2150) * RG.CONV_RATE()) - (RG.ACCOUNT(2150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2150)", (RG.ACCOUNT(2150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2200)") == null)
            {
                RG.AddCalc("ACCT(2200)", RG.DETAILACCOUNT(2200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2200)", (RG.ACCOUNT(2200) * RG.CONV_RATE()) - (RG.ACCOUNT(2200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2200)", ((RG.ACCOUNT(2200) * RG.CONV_RATE()) - (RG.ACCOUNT(2200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2200)", (RG.ACCOUNT(2200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2250)") == null)
            {
                RG.AddCalc("ACCT(2250)", RG.DETAILACCOUNT(2250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2250)", (RG.ACCOUNT(2250) * RG.CONV_RATE()) - (RG.ACCOUNT(2250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2250)", ((RG.ACCOUNT(2250) * RG.CONV_RATE()) - (RG.ACCOUNT(2250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2250)", (RG.ACCOUNT(2250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2300)") == null)
            {
                RG.AddCalc("ACCT(2300)", RG.DETAILACCOUNT(2300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2300)", (RG.ACCOUNT(2300) * RG.CONV_RATE()) - (RG.ACCOUNT(2300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2300)", ((RG.ACCOUNT(2300) * RG.CONV_RATE()) - (RG.ACCOUNT(2300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2300)", (RG.ACCOUNT(2300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2350)") == null)
            {
                RG.AddCalc("ACCT(2350)", RG.DETAILACCOUNT(2350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2350)", (RG.ACCOUNT(2350) * RG.CONV_RATE()) - (RG.ACCOUNT(2350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2350)", ((RG.ACCOUNT(2350) * RG.CONV_RATE()) - (RG.ACCOUNT(2350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2350)", (RG.ACCOUNT(2350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2360)") == null)
            {
                RG.AddCalc("ACCT(2360)", RG.DETAILACCOUNT(2360) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2360)", (RG.ACCOUNT(2360) * RG.CONV_RATE()) - (RG.ACCOUNT(2360, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2360)", ((RG.ACCOUNT(2360) * RG.CONV_RATE()) - (RG.ACCOUNT(2360, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2360, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2360)", (RG.ACCOUNT(2360) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("TYPE(40)") == null)
            {
                if (RG.TYPE(40).NonZero)
                    RG.AddCalc("TYPE(40)", RG.TYPE(40) * RG.CONV_RATE());
                else
                    RG.AddCalc("TYPE(40)", new Calc(0, RG.Statements.Count));
                RG.AddCalc("ActIDOvPer(40)", (RG.TYPE(40) * RG.CONV_RATE()) - (RG.TYPE(40, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(40)", ((RG.TYPE(40) * RG.CONV_RATE()) - (RG.TYPE(40, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.TYPE(40, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("LINE(3000)") == null)
                RG.AddCalc("LINE(3000)", (RG.TYPE(152) + RG.TYPE(160) + RG.TYPE(45)) * RG.CONV_RATE());
            if (RG.GetCalc("BegAccumDepr") == null)
                RG.AddCalc("BegAccumDepr", RG.TYPE(45, RG.LAG) * RG.CONV_RATE(RG.LAG));
            if (RG.GetCalc("PlusDeprExp") == null)
                RG.AddCalc("PlusDeprExp", (RG.TYPE(152) + RG.TYPE(160)) * RG.CONV_RATE());
            if (RG.GetCalc("PurchSaleAst") == null)
                RG.AddCalc("PurchSaleAst", (RG.TYPE(45) * RG.CONV_RATE()) - (RG.TYPE(45, RG.LAG) * RG.CONV_RATE(RG.LAG)) - ((RG.TYPE(152) + RG.TYPE(160)) * RG.CONV_RATE()));
            if (RG.GetCalc("EndAccumDepr") == null)
                RG.AddCalc("EndAccumDepr", RG.TYPE(45) * RG.CONV_RATE());
            if (RG.GetCalc("ActIDOvPer(45)") == null)
                RG.AddCalc("ActIDOvPer(45)", (RG.TYPE(45) * RG.CONV_RATE()) - (RG.TYPE(45, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("%IDOvPP(45)") == null)
                RG.AddCalc("%IDOvPP(45)", ((RG.TYPE(45) * RG.CONV_RATE()) - (RG.TYPE(45, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.TYPE(45, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            if (RG.GetCalc("%NetSales(45)") == null)
                RG.AddCalc("%NetSales(45)", (RG.TYPE(45) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            if (RG.GetCalc("%GrsFxdAsts(45)") == null)
                RG.AddCalc("%GrsFxdAsts(45)", (RG.TYPE(45) * RG.CONV_RATE()) % (RG.TYPE(40) * RG.CONV_RATE()));
            if (RG.GetCalc("ACCT(2450)") == null)
            {
                RG.AddCalc("ACCT(2450)", RG.DETAILACCOUNT(2450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2450)", (RG.ACCOUNT(2450) * RG.CONV_RATE()) - (RG.ACCOUNT(2450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2450)", ((RG.ACCOUNT(2450) * RG.CONV_RATE()) - (RG.ACCOUNT(2450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2450)", (RG.ACCOUNT(2450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2500)") == null)
            {
                RG.AddCalc("ACCT(2500)", RG.DETAILACCOUNT(2500) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2500)", (RG.ACCOUNT(2500) * RG.CONV_RATE()) - (RG.ACCOUNT(2500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2500)", ((RG.ACCOUNT(2500) * RG.CONV_RATE()) - (RG.ACCOUNT(2500, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2500)", (RG.ACCOUNT(2500) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2530)") == null)
            {
                RG.AddCalc("ACCT(2530)", RG.DETAILACCOUNT(2530) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2530)", (RG.ACCOUNT(2530) * RG.CONV_RATE()) - (RG.ACCOUNT(2530, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2530)", ((RG.ACCOUNT(2530) * RG.CONV_RATE()) - (RG.ACCOUNT(2530, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2530, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2530)", (RG.ACCOUNT(2530) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2550)") == null)
            {
                RG.AddCalc("ACCT(2550)", RG.DETAILACCOUNT(2550) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2550)", (RG.ACCOUNT(2550) * RG.CONV_RATE()) - (RG.ACCOUNT(2550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2550)", ((RG.ACCOUNT(2550) * RG.CONV_RATE()) - (RG.ACCOUNT(2550, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2550)", (RG.ACCOUNT(2550) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2600)") == null)
            {
                RG.AddCalc("ACCT(2600)", RG.DETAILACCOUNT(2600) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2600)", (RG.ACCOUNT(2600) * RG.CONV_RATE()) - (RG.ACCOUNT(2600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2600)", ((RG.ACCOUNT(2600) * RG.CONV_RATE()) - (RG.ACCOUNT(2600, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2600)", (RG.ACCOUNT(2600) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2650)") == null)
            {
                RG.AddCalc("ACCT(2650)", RG.DETAILACCOUNT(2650) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2650)", (RG.ACCOUNT(2650) * RG.CONV_RATE()) - (RG.ACCOUNT(2650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2650)", ((RG.ACCOUNT(2650) * RG.CONV_RATE()) - (RG.ACCOUNT(2650, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2650)", (RG.ACCOUNT(2650) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2800)") == null)
            {
                RG.AddCalc("ACCT(2800)", RG.DETAILACCOUNT(2800) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2800)", (RG.ACCOUNT(2800) * RG.CONV_RATE()) - (RG.ACCOUNT(2800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2800)", ((RG.ACCOUNT(2800) * RG.CONV_RATE()) - (RG.ACCOUNT(2800, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2800)", (RG.ACCOUNT(2800) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2700)") == null)
            {
                RG.AddCalc("ACCT(2700)", RG.DETAILACCOUNT(2700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2700)", (RG.ACCOUNT(2700) * RG.CONV_RATE()) - (RG.ACCOUNT(2700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2700)", ((RG.ACCOUNT(2700) * RG.CONV_RATE()) - (RG.ACCOUNT(2700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2700)", (RG.ACCOUNT(2700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ Addition of Account 2740 Version V 6-11-03
            if (RG.GetCalc("ACCT(2740)") == null)
            {
                RG.AddCalc("ACCT(2740)", RG.DETAILACCOUNT(2740) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2740)", (RG.ACCOUNT(2740) * RG.CONV_RATE()) - (RG.ACCOUNT(2740, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2740)", ((RG.ACCOUNT(2740) * RG.CONV_RATE()) - (RG.ACCOUNT(2740, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2740, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2740)", (RG.ACCOUNT(2740) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ End of Addition

            if (RG.GetCalc("ACCT(2750)") == null)
            {
                RG.AddCalc("ACCT(2750)", RG.DETAILACCOUNT(2750) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2750)", (RG.ACCOUNT(2750) * RG.CONV_RATE()) - (RG.ACCOUNT(2750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2750)", ((RG.ACCOUNT(2750) * RG.CONV_RATE()) - (RG.ACCOUNT(2750, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2750)", (RG.ACCOUNT(2750) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2850)") == null)
            {
                RG.AddCalc("ACCT(2850)", RG.DETAILACCOUNT(2850) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2850)", (RG.ACCOUNT(2850) * RG.CONV_RATE()) - (RG.ACCOUNT(2850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2850)", ((RG.ACCOUNT(2850) * RG.CONV_RATE()) - (RG.ACCOUNT(2850, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2850)", (RG.ACCOUNT(2850) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2900)") == null)
            {
                RG.AddCalc("ACCT(2900)", RG.DETAILACCOUNT(2900) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2900)", (RG.ACCOUNT(2900) * RG.CONV_RATE()) - (RG.ACCOUNT(2900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2900)", ((RG.ACCOUNT(2900) * RG.CONV_RATE()) - (RG.ACCOUNT(2900, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2900)", (RG.ACCOUNT(2900) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("TYPE(70)") == null)
            {
                RG.AddCalc("TYPE(70)", RG.DETAILTYPE(70) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(70)", (RG.TYPE(70) * RG.CONV_RATE()) - (RG.TYPE(70, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(70)", ((RG.TYPE(70) * RG.CONV_RATE()) - (RG.TYPE(70, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.TYPE(70, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(70)", (RG.TYPE(70) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(2820)") == null)
            {
                RG.AddCalc("ACCT(2820)", RG.DETAILACCOUNT(2820) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(2820)", (RG.ACCOUNT(2820) * RG.CONV_RATE()) - (RG.ACCOUNT(2820, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(2820)", ((RG.ACCOUNT(2820) * RG.CONV_RATE()) - (RG.ACCOUNT(2820, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(2820, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(2820)", (RG.ACCOUNT(2820) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%GrsIntang(2820)", (RG.ACCOUNT(2820) * RG.CONV_RATE()) % (RG.TYPE(70) * RG.CONV_RATE()));
            }
            ///Here start the current liability accounts.
            if (RG.GetCalc("ACCT(3050)") == null)
            {
                RG.AddCalc("ACCT(3050)", RG.DETAILACCOUNT(3050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3050)", (RG.ACCOUNT(3050) * RG.CONV_RATE()) - (RG.ACCOUNT(3050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3050)", ((RG.ACCOUNT(3050) * RG.CONV_RATE()) - (RG.ACCOUNT(3050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3050)", (RG.ACCOUNT(3050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3070)") == null)
            {
                RG.AddCalc("ACCT(3070)", RG.DETAILACCOUNT(3070) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3070)", (RG.ACCOUNT(3070) * RG.CONV_RATE()) - (RG.ACCOUNT(3070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3070)", ((RG.ACCOUNT(3070) * RG.CONV_RATE()) - (RG.ACCOUNT(3070, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3070)", (RG.ACCOUNT(3070) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3100)") == null)
            {
                RG.AddCalc("ACCT(3100)", RG.DETAILACCOUNT(3100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3100)", (RG.ACCOUNT(3100) * RG.CONV_RATE()) - (RG.ACCOUNT(3100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3100)", ((RG.ACCOUNT(3100) * RG.CONV_RATE()) - (RG.ACCOUNT(3100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3100)", (RG.ACCOUNT(3100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3150)") == null)
            {
                RG.AddCalc("ACCT(3150)", RG.DETAILACCOUNT(3150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3150)", (RG.ACCOUNT(3150) * RG.CONV_RATE()) - (RG.ACCOUNT(3150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3150)", ((RG.ACCOUNT(3150) * RG.CONV_RATE()) - (RG.ACCOUNT(3150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3150)", (RG.ACCOUNT(3150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3200)") == null)
            {
                RG.AddCalc("ACCT(3200)", RG.DETAILACCOUNT(3200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3200)", (RG.ACCOUNT(3200) * RG.CONV_RATE()) - (RG.ACCOUNT(3200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3200)", ((RG.ACCOUNT(3200) * RG.CONV_RATE()) - (RG.ACCOUNT(3200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3200)", (RG.ACCOUNT(3200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%LTDAccts(3200)", RG.ACCOUNT(3200) % RG.TYPE(110));
            }
            if (RG.GetCalc("ACCT(3250)") == null)
            {
                RG.AddCalc("ACCT(3250)", RG.DETAILACCOUNT(3250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3250)", (RG.ACCOUNT(3250) * RG.CONV_RATE()) - (RG.ACCOUNT(3250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3250)", ((RG.ACCOUNT(3250) * RG.CONV_RATE()) - (RG.ACCOUNT(3250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3250)", (RG.ACCOUNT(3250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%LTDAccts(3250)", RG.ACCOUNT(3250) % RG.TYPE(110));
            }
            if (RG.GetCalc("ACCT(3300)") == null)
            {
                RG.AddCalc("ACCT(3300)", RG.DETAILACCOUNT(3300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3300)", (RG.ACCOUNT(3300) * RG.CONV_RATE()) - (RG.ACCOUNT(3300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3300)", ((RG.ACCOUNT(3300) * RG.CONV_RATE()) - (RG.ACCOUNT(3300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3300)", (RG.ACCOUNT(3300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%LTDAccts(3300)", RG.ACCOUNT(3300) % RG.TYPE(110));
            }
            if (RG.GetCalc("ACCT(3350)") == null)
            {
                RG.AddCalc("ACCT(3350)", RG.DETAILACCOUNT(3350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3350)", (RG.ACCOUNT(3350) * RG.CONV_RATE()) - (RG.ACCOUNT(3350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3350)", ((RG.ACCOUNT(3350) * RG.CONV_RATE()) - (RG.ACCOUNT(3350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3350)", (RG.ACCOUNT(3350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%CapLseOb(3350)", RG.ACCOUNT(3350) % (RG.ACCOUNT(3350) + RG.ACCOUNT(3360) + RG.ACCOUNT(4200) + RG.ACCOUNT(4210)));
            }
            if (RG.GetCalc("ACCT(3360)") == null)
            {
                RG.AddCalc("ACCT(3360)", RG.DETAILACCOUNT(3360) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3360)", (RG.ACCOUNT(3360) * RG.CONV_RATE()) - (RG.ACCOUNT(3360, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3360)", ((RG.ACCOUNT(3360) * RG.CONV_RATE()) - (RG.ACCOUNT(3360, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3360, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3360)", (RG.ACCOUNT(3360) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%CapLseOb(3360)", RG.ACCOUNT(3360) % (RG.ACCOUNT(3350) + RG.ACCOUNT(3360) + RG.ACCOUNT(4200) + RG.ACCOUNT(4210)));
            }
            if (RG.GetCalc("ACCT(3370)") == null)
            {
                RG.AddCalc("ACCT(3370)", RG.DETAILACCOUNT(3370) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3370)", (RG.ACCOUNT(3370) * RG.CONV_RATE()) - (RG.ACCOUNT(3370, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3370)", ((RG.ACCOUNT(3370) * RG.CONV_RATE()) - (RG.ACCOUNT(3370, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3370, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3370)", (RG.ACCOUNT(3370) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3400)") == null)
            {
                RG.AddCalc("ACCT(3400)", RG.DETAILACCOUNT(3400) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3400)", (RG.ACCOUNT(3400) * RG.CONV_RATE()) - (RG.ACCOUNT(3400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3400)", ((RG.ACCOUNT(3400) * RG.CONV_RATE()) - (RG.ACCOUNT(3400, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3400)", (RG.ACCOUNT(3400) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%DaysOnHand(3400)", (RG.ACCOUNT(3400) * RG.CONV_RATE()) / (RG.MACRO(M.DAYS_ON_HAND) / RG.YEAR()) * 365);
            }
            if (RG.GetCalc("ACCT(3450)") == null)
            {
                RG.AddCalc("ACCT(3450)", RG.DETAILACCOUNT(3450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3450)", (RG.ACCOUNT(3450) * RG.CONV_RATE()) - (RG.ACCOUNT(3450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3450)", ((RG.ACCOUNT(3450) * RG.CONV_RATE()) - (RG.ACCOUNT(3450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3450)", (RG.ACCOUNT(3450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3500)") == null)
            {
                RG.AddCalc("ACCT(3500)", RG.DETAILACCOUNT(3500) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3500)", (RG.ACCOUNT(3500) * RG.CONV_RATE()) - (RG.ACCOUNT(3500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3500)", ((RG.ACCOUNT(3500) * RG.CONV_RATE()) - (RG.ACCOUNT(3500, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3500)", (RG.ACCOUNT(3500) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3600)") == null)
            {
                RG.AddCalc("ACCT(3600)", RG.DETAILACCOUNT(3600) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3600)", (RG.ACCOUNT(3600) * RG.CONV_RATE()) - (RG.ACCOUNT(3600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3600)", ((RG.ACCOUNT(3600) * RG.CONV_RATE()) - (RG.ACCOUNT(3600, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3600)", (RG.ACCOUNT(3600) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3650)") == null)
            {
                RG.AddCalc("ACCT(3650)", RG.DETAILACCOUNT(3650) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3650)", (RG.ACCOUNT(3650) * RG.CONV_RATE()) - (RG.ACCOUNT(3650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3650)", ((RG.ACCOUNT(3650) * RG.CONV_RATE()) - (RG.ACCOUNT(3650, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3650)", (RG.ACCOUNT(3650) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3550)") == null)
            {
                RG.AddCalc("ACCT(3550)", RG.DETAILACCOUNT(3550) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3550)", (RG.ACCOUNT(3550) * RG.CONV_RATE()) - (RG.ACCOUNT(3550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3550)", ((RG.ACCOUNT(3550) * RG.CONV_RATE()) - (RG.ACCOUNT(3550, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3550)", (RG.ACCOUNT(3550) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3700)") == null)
            {
                RG.AddCalc("ACCT(3700)", RG.DETAILACCOUNT(3700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3700)", (RG.ACCOUNT(3700) * RG.CONV_RATE()) - (RG.ACCOUNT(3700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3700)", ((RG.ACCOUNT(3700) * RG.CONV_RATE()) - (RG.ACCOUNT(3700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3700)", (RG.ACCOUNT(3700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3750)") == null)
            {
                RG.AddCalc("ACCT(3750)", RG.DETAILACCOUNT(3750) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3750)", (RG.ACCOUNT(3750) * RG.CONV_RATE()) - (RG.ACCOUNT(3750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3750)", ((RG.ACCOUNT(3750) * RG.CONV_RATE()) - (RG.ACCOUNT(3750, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3750)", (RG.ACCOUNT(3750) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3800)") == null)
            {
                RG.AddCalc("ACCT(3800)", RG.DETAILACCOUNT(3800) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3800)", (RG.ACCOUNT(3800) * RG.CONV_RATE()) - (RG.ACCOUNT(3800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3800)", ((RG.ACCOUNT(3800) * RG.CONV_RATE()) - (RG.ACCOUNT(3800, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3800)", (RG.ACCOUNT(3800) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3920)") == null)
            {
                RG.AddCalc("ACCT(3920)", RG.DETAILACCOUNT(3920) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3920)", (RG.ACCOUNT(3920) * RG.CONV_RATE()) - (RG.ACCOUNT(3920, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3920)", ((RG.ACCOUNT(3920) * RG.CONV_RATE()) - (RG.ACCOUNT(3920, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3920, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3920)", (RG.ACCOUNT(3920) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3850)") == null)
            {
                RG.AddCalc("ACCT(3850)", RG.DETAILACCOUNT(3850) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3850)", (RG.ACCOUNT(3850) * RG.CONV_RATE()) - (RG.ACCOUNT(3850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3850)", ((RG.ACCOUNT(3850) * RG.CONV_RATE()) - (RG.ACCOUNT(3850, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3850)", (RG.ACCOUNT(3850) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3900)") == null)
            {
                RG.AddCalc("ACCT(3900)", RG.DETAILACCOUNT(3900) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3900)", (RG.ACCOUNT(3900) * RG.CONV_RATE()) - (RG.ACCOUNT(3900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3900)", ((RG.ACCOUNT(3900) * RG.CONV_RATE()) - (RG.ACCOUNT(3900, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3900)", (RG.ACCOUNT(3900) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%ProfB4Tax(3900)", (RG.ACCOUNT(3900) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3910)") == null)
            {
                RG.AddCalc("ACCT(3910)", RG.DETAILACCOUNT(3910) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3910)", (RG.ACCOUNT(3910) * RG.CONV_RATE()) - (RG.ACCOUNT(3910, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3910)", ((RG.ACCOUNT(3910) * RG.CONV_RATE()) - (RG.ACCOUNT(3910, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3910, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3910)", (RG.ACCOUNT(3910) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
                RG.AddCalc("%ProfB4Tax(3910)", (RG.ACCOUNT(3910) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3960)") == null)
            {
                RG.AddCalc("ACCT(3960)", RG.DETAILACCOUNT(3960) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3960)", (RG.ACCOUNT(3960) * RG.CONV_RATE()) - (RG.ACCOUNT(3960, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3960)", ((RG.ACCOUNT(3960) * RG.CONV_RATE()) - (RG.ACCOUNT(3960, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3960, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3960)", (RG.ACCOUNT(3960) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(3970)") == null)
            {
                RG.AddCalc("ACCT(3970)", RG.DETAILACCOUNT(3970) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3970)", (RG.ACCOUNT(3970) * RG.CONV_RATE()) - (RG.ACCOUNT(3970, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3970)", ((RG.ACCOUNT(3970) * RG.CONV_RATE()) - (RG.ACCOUNT(3970, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3970, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3970)", (RG.ACCOUNT(3970) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ Added 3940 Version V 6-11-03
            if (RG.GetCalc("ACCT(3940)") == null)
            {
                RG.AddCalc("ACCT(3940)", RG.DETAILACCOUNT(3940) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3940)", (RG.ACCOUNT(3940) * RG.CONV_RATE()) - (RG.ACCOUNT(3940, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3940)", ((RG.ACCOUNT(3940) * RG.CONV_RATE()) - (RG.ACCOUNT(3940, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3940, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3940)", (RG.ACCOUNT(3940) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ end of addition
            if (RG.GetCalc("ACCT(3950)") == null)
            {
                RG.AddCalc("ACCT(3950)", RG.DETAILACCOUNT(3950) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(3950)", (RG.ACCOUNT(3950) * RG.CONV_RATE()) - (RG.ACCOUNT(3950, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(3950)", ((RG.ACCOUNT(3950) * RG.CONV_RATE()) - (RG.ACCOUNT(3950, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(3950, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(3950)", (RG.ACCOUNT(3950) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            ///Non-current liabs
            if (RG.GetCalc("ACCT(4050)") == null)
            {
                RG.AddCalc("ACCT(4050)", RG.DETAILACCOUNT(4050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4050)", (RG.ACCOUNT(4050) * RG.CONV_RATE()) - (RG.ACCOUNT(4050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4050)", ((RG.ACCOUNT(4050) * RG.CONV_RATE()) - (RG.ACCOUNT(4050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4050)", (RG.ACCOUNT(4050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4100)") == null)
            {
                RG.AddCalc("ACCT(4100)", RG.DETAILACCOUNT(4100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4100)", (RG.ACCOUNT(4100) * RG.CONV_RATE()) - (RG.ACCOUNT(4100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4100)", ((RG.ACCOUNT(4100) * RG.CONV_RATE()) - (RG.ACCOUNT(4100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4100)", (RG.ACCOUNT(4100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4150)") == null)
            {
                RG.AddCalc("ACCT(4150)", RG.DETAILACCOUNT(4150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4150)", (RG.ACCOUNT(4150) * RG.CONV_RATE()) - (RG.ACCOUNT(4150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4150)", ((RG.ACCOUNT(4150) * RG.CONV_RATE()) - (RG.ACCOUNT(4150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4150)", (RG.ACCOUNT(4150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4220)") == null)
            {
                RG.AddCalc("ACCT(4220)", RG.DETAILACCOUNT(4220) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4220)", (RG.ACCOUNT(4220) * RG.CONV_RATE()) - (RG.ACCOUNT(4220, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4220)", ((RG.ACCOUNT(4220) * RG.CONV_RATE()) - (RG.ACCOUNT(4220, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4220, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4220)", (RG.ACCOUNT(4220) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4230)") == null)
            {
                RG.AddCalc("ACCT(4230)", RG.DETAILACCOUNT(4230) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4230)", (RG.ACCOUNT(4230) * RG.CONV_RATE()) - (RG.ACCOUNT(4230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4230)", ((RG.ACCOUNT(4230) * RG.CONV_RATE()) - (RG.ACCOUNT(4230, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4230)", (RG.ACCOUNT(4230) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4200)") == null)
            {
                RG.AddCalc("ACCT(4200)", RG.DETAILACCOUNT(4200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4200)", (RG.ACCOUNT(4200) * RG.CONV_RATE()) - (RG.ACCOUNT(4200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4200)", ((RG.ACCOUNT(4200) * RG.CONV_RATE()) - (RG.ACCOUNT(4200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4200)", (RG.ACCOUNT(4200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4210)") == null)
            {
                RG.AddCalc("ACCT(4210)", RG.DETAILACCOUNT(4210) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4210)", (RG.ACCOUNT(4210) * RG.CONV_RATE()) - (RG.ACCOUNT(4210, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4210)", ((RG.ACCOUNT(4210) * RG.CONV_RATE()) - (RG.ACCOUNT(4210, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4210, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4210)", (RG.ACCOUNT(4210) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4400)") == null)
            {
                RG.AddCalc("ACCT(4400)", RG.DETAILACCOUNT(4400) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4400)", (RG.ACCOUNT(4400) * RG.CONV_RATE()) - (RG.ACCOUNT(4400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4400)", ((RG.ACCOUNT(4400) * RG.CONV_RATE()) - (RG.ACCOUNT(4400, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4400)", (RG.ACCOUNT(4400) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4250)") == null)
            {
                RG.AddCalc("ACCT(4250)", RG.DETAILACCOUNT(4250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4250)", (RG.ACCOUNT(4250) * RG.CONV_RATE()) - (RG.ACCOUNT(4250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4250)", ((RG.ACCOUNT(4250) * RG.CONV_RATE()) - (RG.ACCOUNT(4250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4250)", (RG.ACCOUNT(4250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4300)") == null)
            {
                RG.AddCalc("ACCT(4300)", RG.DETAILACCOUNT(4300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4300)", (RG.ACCOUNT(4300) * RG.CONV_RATE()) - (RG.ACCOUNT(4300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4300)", ((RG.ACCOUNT(4300) * RG.CONV_RATE()) - (RG.ACCOUNT(4300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4300)", (RG.ACCOUNT(4300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4330)") == null)
            {
                RG.AddCalc("ACCT(4330)", RG.DETAILACCOUNT(4330) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4330)", (RG.ACCOUNT(4330) * RG.CONV_RATE()) - (RG.ACCOUNT(4330, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4330)", ((RG.ACCOUNT(4330) * RG.CONV_RATE()) - (RG.ACCOUNT(4330, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4330, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4330)", (RG.ACCOUNT(4330) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4340)") == null)
            {
                RG.AddCalc("ACCT(4340)", RG.DETAILACCOUNT(4340) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4340)", (RG.ACCOUNT(4340) * RG.CONV_RATE()) - (RG.ACCOUNT(4340, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4340)", ((RG.ACCOUNT(4340) * RG.CONV_RATE()) - (RG.ACCOUNT(4340, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4340, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4340)", (RG.ACCOUNT(4340) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4350)") == null)
            {
                RG.AddCalc("ACCT(4350)", RG.DETAILACCOUNT(4350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4350)", (RG.ACCOUNT(4350) * RG.CONV_RATE()) - (RG.ACCOUNT(4350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4350)", ((RG.ACCOUNT(4350) * RG.CONV_RATE()) - (RG.ACCOUNT(4350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4350)", (RG.ACCOUNT(4350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // KCZ Added 4390 Version V 6-11-03
            if (RG.GetCalc("ACCT(4390)") == null)
            {
                RG.AddCalc("ACCT(4390)", RG.DETAILACCOUNT(4390) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4390)", (RG.ACCOUNT(4390) * RG.CONV_RATE()) - (RG.ACCOUNT(4390, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4390)", ((RG.ACCOUNT(4390) * RG.CONV_RATE()) - (RG.ACCOUNT(4390, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4390, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4390)", (RG.ACCOUNT(4390) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            // end of addition
            if (RG.GetCalc("ACCT(4450)") == null)
            {
                RG.AddCalc("ACCT(4450)", RG.DETAILACCOUNT(4450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4450)", (RG.ACCOUNT(4450) * RG.CONV_RATE()) - (RG.ACCOUNT(4450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4450)", ((RG.ACCOUNT(4450) * RG.CONV_RATE()) - (RG.ACCOUNT(4450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4450)", (RG.ACCOUNT(4450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4600)") == null)
            {
                RG.AddCalc("ACCT(4600)", RG.DETAILACCOUNT(4600) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4600)", (RG.ACCOUNT(4600) * RG.CONV_RATE()) - (RG.ACCOUNT(4600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4600)", ((RG.ACCOUNT(4600) * RG.CONV_RATE()) - (RG.ACCOUNT(4600, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4600)", (RG.ACCOUNT(4600) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4660)") == null)
            {
                RG.AddCalc("ACCT(4660)", RG.DETAILACCOUNT(4660) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4660)", (RG.ACCOUNT(4660) * RG.CONV_RATE()) - (RG.ACCOUNT(4660, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4660)", ((RG.ACCOUNT(4660) * RG.CONV_RATE()) - (RG.ACCOUNT(4660, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4660, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4660)", (RG.ACCOUNT(4660) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4680)") == null)
            {
                RG.AddCalc("ACCT(4680)", RG.DETAILACCOUNT(4680) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4680)", (RG.ACCOUNT(4680) * RG.CONV_RATE()) - (RG.ACCOUNT(4680, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4680)", ((RG.ACCOUNT(4680) * RG.CONV_RATE()) - (RG.ACCOUNT(4680, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4680, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4680)", (RG.ACCOUNT(4680) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4700)") == null)
            {
                RG.AddCalc("ACCT(4700)", RG.DETAILACCOUNT(4700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4700)", (RG.ACCOUNT(4700) * RG.CONV_RATE()) - (RG.ACCOUNT(4700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4700)", ((RG.ACCOUNT(4700) * RG.CONV_RATE()) - (RG.ACCOUNT(4700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4700)", (RG.ACCOUNT(4700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4800)") == null)
            {
                RG.AddCalc("ACCT(4800)", RG.DETAILACCOUNT(4800) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4800)", (RG.ACCOUNT(4800) * RG.CONV_RATE()) - (RG.ACCOUNT(4800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4800)", ((RG.ACCOUNT(4800) * RG.CONV_RATE()) - (RG.ACCOUNT(4800, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4800)", (RG.ACCOUNT(4800) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            ///Here is the Equity Section
            if (RG.GetCalc("ACCT(4650)") == null)
            {
                RG.AddCalc("ACCT(4650)", RG.DETAILACCOUNT(4650) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4650)", (RG.ACCOUNT(4650) * RG.CONV_RATE()) - (RG.ACCOUNT(4650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4650)", ((RG.ACCOUNT(4650) * RG.CONV_RATE()) - (RG.ACCOUNT(4650, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4650)", (RG.ACCOUNT(4650) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4670)") == null)
            {
                RG.AddCalc("ACCT(4670)", RG.DETAILACCOUNT(4670) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4670)", (RG.ACCOUNT(4670) * RG.CONV_RATE()) - (RG.ACCOUNT(4670, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4670)", ((RG.ACCOUNT(4670) * RG.CONV_RATE()) - (RG.ACCOUNT(4670, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4670, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4670)", (RG.ACCOUNT(4670) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4690)") == null)
            {
                RG.AddCalc("ACCT(4690)", RG.DETAILACCOUNT(4690) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4690)", (RG.ACCOUNT(4690) * RG.CONV_RATE()) - (RG.ACCOUNT(4690, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4690)", ((RG.ACCOUNT(4690) * RG.CONV_RATE()) - (RG.ACCOUNT(4690, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4690, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4690)", (RG.ACCOUNT(4690) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4750)") == null)
            {
                RG.AddCalc("ACCT(4750)", RG.DETAILACCOUNT(4750) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4750)", (RG.ACCOUNT(4750) * RG.CONV_RATE()) - (RG.ACCOUNT(4750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4750)", ((RG.ACCOUNT(4750) * RG.CONV_RATE()) - (RG.ACCOUNT(4750, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4750)", (RG.ACCOUNT(4750) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(4850)") == null)
            {
                RG.AddCalc("ACCT(4850)", RG.DETAILACCOUNT(4850) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(4850)", (RG.ACCOUNT(4850) * RG.CONV_RATE()) - (RG.ACCOUNT(4850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(4850)", ((RG.ACCOUNT(4850) * RG.CONV_RATE()) - (RG.ACCOUNT(4850, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(4850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(4850)", (RG.ACCOUNT(4850) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5050)") == null)
            {
                RG.AddCalc("ACCT(5050)", RG.DETAILACCOUNT(5050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5050)", (RG.ACCOUNT(5050) * RG.CONV_RATE()) - (RG.ACCOUNT(5050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5050)", ((RG.ACCOUNT(5050) * RG.CONV_RATE()) - (RG.ACCOUNT(5050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5050)", (RG.ACCOUNT(5050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5100)") == null)
            {
                RG.AddCalc("ACCT(5100)", RG.DETAILACCOUNT(5100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5100)", (RG.ACCOUNT(5100) * RG.CONV_RATE()) - (RG.ACCOUNT(5100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5100)", ((RG.ACCOUNT(5100) * RG.CONV_RATE()) - (RG.ACCOUNT(5100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5100)", (RG.ACCOUNT(5100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5150)") == null)
            {
                RG.AddCalc("ACCT(5150)", RG.DETAILACCOUNT(5150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5150)", (RG.ACCOUNT(5150) * RG.CONV_RATE()) - (RG.ACCOUNT(5150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5150)", ((RG.ACCOUNT(5150) * RG.CONV_RATE()) - (RG.ACCOUNT(5150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5150)", (RG.ACCOUNT(5150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5200)") == null)
            {
                RG.AddCalc("ACCT(5200)", RG.DETAILACCOUNT(5200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5200)", (RG.ACCOUNT(5200) * RG.CONV_RATE()) - (RG.ACCOUNT(5200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5200)", ((RG.ACCOUNT(5200) * RG.CONV_RATE()) - (RG.ACCOUNT(5200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5200)", (RG.ACCOUNT(5200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5250)") == null)
            {
                RG.AddCalc("ACCT(5250)", RG.DETAILACCOUNT(5250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5250)", (RG.ACCOUNT(5250) * RG.CONV_RATE()) - (RG.ACCOUNT(5250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5250)", ((RG.ACCOUNT(5250) * RG.CONV_RATE()) - (RG.ACCOUNT(5250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5250)", (RG.ACCOUNT(5250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5420)") == null)
            {
                RG.AddCalc("ACCT(5420)", RG.DETAILACCOUNT(5420) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5420)", (RG.ACCOUNT(5420) * RG.CONV_RATE()) - (RG.ACCOUNT(5420, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5420)", ((RG.ACCOUNT(5420) * RG.CONV_RATE()) - (RG.ACCOUNT(5420, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5420, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5420)", (RG.ACCOUNT(5420) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5410)") == null)
            {
                RG.AddCalc("ACCT(5410)", RG.DETAILACCOUNT(5410) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5410)", (RG.ACCOUNT(5410) * RG.CONV_RATE()) - (RG.ACCOUNT(5410, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5410)", ((RG.ACCOUNT(5410) * RG.CONV_RATE()) - (RG.ACCOUNT(5410, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5410, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5410)", (RG.ACCOUNT(5410) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
            if (RG.GetCalc("ACCT(5450)") == null)
            {
                RG.AddCalc("ACCT(5450)", RG.DETAILACCOUNT(5450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(5450)", (RG.ACCOUNT(5450) * RG.CONV_RATE()) - (RG.ACCOUNT(5450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(5450)", ((RG.ACCOUNT(5450) * RG.CONV_RATE()) - (RG.ACCOUNT(5450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(5450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(5450)", (RG.ACCOUNT(5450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES) * RG.YEAR());
            }
        }
        public void IS_Assumption_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("ACCT(6050)") == null)
            {
                RG.AddCalc("ACCT(6050)", RG.DETAILACCOUNT(6050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6050)", (RG.ACCOUNT(6050) * RG.CONV_RATE()) - (RG.ACCOUNT(6050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6050)", ((RG.ACCOUNT(6050) * RG.CONV_RATE()) - (RG.ACCOUNT(6050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("ACCT(6070)") == null)
            {
                RG.AddCalc("ACCT(6070)", RG.DETAILACCOUNT(6070) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6070)", (RG.ACCOUNT(6070) * RG.CONV_RATE()) - (RG.ACCOUNT(6070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6070)", ((RG.ACCOUNT(6070) * RG.CONV_RATE()) - (RG.ACCOUNT(6070, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6070, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("ACCT(6100)") == null)
            {
                RG.AddCalc("ACCT(6100)", RG.DETAILACCOUNT(6100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6100)", (RG.ACCOUNT(6100) * RG.CONV_RATE()) - (RG.ACCOUNT(6100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6100)", ((RG.ACCOUNT(6100) * RG.CONV_RATE()) - (RG.ACCOUNT(6100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("ACCT(6150)") == null)
            {
                RG.AddCalc("ACCT(6150)", RG.DETAILACCOUNT(6150) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6150)", (RG.ACCOUNT(6150) * RG.CONV_RATE()) - (RG.ACCOUNT(6150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6150)", ((RG.ACCOUNT(6150) * RG.CONV_RATE()) - (RG.ACCOUNT(6150, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("ACCT(6200)") == null)
            {
                RG.AddCalc("ACCT(6200)", RG.DETAILACCOUNT(6200) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6200)", (RG.ACCOUNT(6200) * RG.CONV_RATE()) - (RG.ACCOUNT(6200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6200)", ((RG.ACCOUNT(6200) * RG.CONV_RATE()) - (RG.ACCOUNT(6200, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
            }
            if (RG.GetCalc("ACCT(6250)") == null)
            {
                RG.AddCalc("ACCT(6250)", RG.DETAILACCOUNT(6250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6250)", (RG.ACCOUNT(6250) * RG.CONV_RATE()) - (RG.ACCOUNT(6250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6250)", ((RG.ACCOUNT(6250) * RG.CONV_RATE()) - (RG.ACCOUNT(6250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6250)", (RG.ACCOUNT(6250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));

            }
            if (RG.GetCalc("ACCT(6270)") == null)
            {
                RG.AddCalc("ACCT(6270)", RG.DETAILACCOUNT(6270) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6270)", (RG.ACCOUNT(6270) * RG.CONV_RATE()) - (RG.ACCOUNT(6270, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6270)", ((RG.ACCOUNT(6270) * RG.CONV_RATE()) - (RG.ACCOUNT(6270, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6270, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6270)", (RG.ACCOUNT(6270) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6300)") == null)
            {
                RG.AddCalc("ACCT(6300)", RG.DETAILACCOUNT(6300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6300)", (RG.ACCOUNT(6300) * RG.CONV_RATE()) - (RG.ACCOUNT(6300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6300)", ((RG.ACCOUNT(6300) * RG.CONV_RATE()) - (RG.ACCOUNT(6300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6300)", (RG.ACCOUNT(6300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6350)") == null)
            {
                RG.AddCalc("ACCT(6350)", RG.DETAILACCOUNT(6350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6350)", (RG.ACCOUNT(6350) * RG.CONV_RATE()) - (RG.ACCOUNT(6350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6350)", ((RG.ACCOUNT(6350) * RG.CONV_RATE()) - (RG.ACCOUNT(6350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6350)", (RG.ACCOUNT(6350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6400)") == null)
            {
                RG.AddCalc("ACCT(6400)", RG.DETAILACCOUNT(6400) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6400)", (RG.ACCOUNT(6400) * RG.CONV_RATE()) - (RG.ACCOUNT(6400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6400)", ((RG.ACCOUNT(6400) * RG.CONV_RATE()) - (RG.ACCOUNT(6400, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6400)", (RG.ACCOUNT(6400) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6420)") == null)
            {
                RG.AddCalc("ACCT(6420)", RG.DETAILACCOUNT(6420) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6420)", (RG.ACCOUNT(6420) * RG.CONV_RATE()) - (RG.ACCOUNT(6420, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6420)", ((RG.ACCOUNT(6420) * RG.CONV_RATE()) - (RG.ACCOUNT(6420, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6420, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6420)", (RG.ACCOUNT(6420) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6450)") == null)
            {
                RG.AddCalc("ACCT(6450)", RG.DETAILACCOUNT(6450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6450)", (RG.ACCOUNT(6450) * RG.CONV_RATE()) - (RG.ACCOUNT(6450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6450)", ((RG.ACCOUNT(6450) * RG.CONV_RATE()) - (RG.ACCOUNT(6450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6450)", (RG.ACCOUNT(6450) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6470)") == null)
            {
                RG.AddCalc("ACCT(6470)", RG.DETAILACCOUNT(6470) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6470)", (RG.ACCOUNT(6470) * RG.CONV_RATE()) - (RG.ACCOUNT(6470, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6470)", ((RG.ACCOUNT(6470) * RG.CONV_RATE()) - (RG.ACCOUNT(6470, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6470, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6470)", (RG.ACCOUNT(6470) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6490)") == null)
            {
                RG.AddCalc("ACCT(6490)", RG.DETAILACCOUNT(6490) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6490)", (RG.ACCOUNT(6490) * RG.CONV_RATE()) - (RG.ACCOUNT(6490, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6490)", ((RG.ACCOUNT(6490) * RG.CONV_RATE()) - (RG.ACCOUNT(6490, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6490, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6490)", (RG.ACCOUNT(6490) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6550)") == null)
            {
                RG.AddCalc("ACCT(6550)", RG.DETAILACCOUNT(6550) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6550)", (RG.ACCOUNT(6550) * RG.CONV_RATE()) - (RG.ACCOUNT(6550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6550)", ((RG.ACCOUNT(6550) * RG.CONV_RATE()) - (RG.ACCOUNT(6550, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6550)", (RG.ACCOUNT(6550) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6560)") == null)
            {
                RG.AddCalc("ACCT(6560)", RG.DETAILACCOUNT(6560) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6560)", (RG.ACCOUNT(6560) * RG.CONV_RATE()) - (RG.ACCOUNT(6560, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6560)", ((RG.ACCOUNT(6560) * RG.CONV_RATE()) - (RG.ACCOUNT(6560, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6560, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6560)", (RG.ACCOUNT(6560) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6570)") == null)
            {
                RG.AddCalc("ACCT(6570)", RG.DETAILACCOUNT(6570) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6570)", (RG.ACCOUNT(6570) * RG.CONV_RATE()) - (RG.ACCOUNT(6570, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6570)", ((RG.ACCOUNT(6570) * RG.CONV_RATE()) - (RG.ACCOUNT(6570, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6570, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6570)", (RG.ACCOUNT(6570) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6580)") == null)
            {
                RG.AddCalc("ACCT(6580)", RG.DETAILACCOUNT(6580) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6580)", (RG.ACCOUNT(6580) * RG.CONV_RATE()) - (RG.ACCOUNT(6580, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6580)", ((RG.ACCOUNT(6580) * RG.CONV_RATE()) - (RG.ACCOUNT(6580, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6580, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6580)", (RG.ACCOUNT(6580) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6600)") == null)
            {
                RG.AddCalc("ACCT(6600)", RG.DETAILACCOUNT(6600) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6600)", (RG.ACCOUNT(6600) * RG.CONV_RATE()) - (RG.ACCOUNT(6600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6600)", ((RG.ACCOUNT(6600) * RG.CONV_RATE()) - (RG.ACCOUNT(6600, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6600)", (RG.ACCOUNT(6600) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%GrsFxdAsts(6600)", RG.ACCOUNT(6600) % (RG.TYPE(39) + RG.TYPE(38) + RG.TYPE(40)));
            }
            if (RG.GetCalc("ACCT(6650)") == null)
            {
                RG.AddCalc("ACCT(6650)", RG.DETAILACCOUNT(6650) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6650)", (RG.ACCOUNT(6650) * RG.CONV_RATE()) - (RG.ACCOUNT(6650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6650)", ((RG.ACCOUNT(6650) * RG.CONV_RATE()) - (RG.ACCOUNT(6650, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6650)", (RG.ACCOUNT(6650) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%Intang(6650)", RG.ACCOUNT(6650) % RG.TYPE(70));
            }
            if (RG.GetCalc("ACCT(6500)") == null)
            {
                RG.AddCalc("ACCT(6500)", RG.DETAILACCOUNT(6500) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6500)", (RG.ACCOUNT(6500) * RG.CONV_RATE()) - (RG.ACCOUNT(6500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6500)", ((RG.ACCOUNT(6500) * RG.CONV_RATE()) - (RG.ACCOUNT(6500, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6500)", (RG.ACCOUNT(6500) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6700)") == null)
            {
                RG.AddCalc("ACCT(6700)", RG.DETAILACCOUNT(6700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6700)", (RG.ACCOUNT(6700) * RG.CONV_RATE()) - (RG.ACCOUNT(6700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6700)", ((RG.ACCOUNT(6700) * RG.CONV_RATE()) - (RG.ACCOUNT(6700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6700)", (RG.ACCOUNT(6700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6750)") == null)
            {
                RG.AddCalc("ACCT(6750)", RG.DETAILACCOUNT(6750) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6750)", (RG.ACCOUNT(6750) * RG.CONV_RATE()) - (RG.ACCOUNT(6750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6750)", ((RG.ACCOUNT(6750) * RG.CONV_RATE()) - (RG.ACCOUNT(6750, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6750, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6750)", (RG.ACCOUNT(6750) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7530)") == null)
            {
                RG.AddCalc("ACCT(7530)", RG.DETAILACCOUNT(7530) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7530)", (RG.ACCOUNT(7530) * RG.CONV_RATE()) - (RG.ACCOUNT(7530, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7530)", ((RG.ACCOUNT(7530) * RG.CONV_RATE()) - (RG.ACCOUNT(7530, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7530, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7530)", (RG.ACCOUNT(7530) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6800)") == null)
            {
                RG.AddCalc("ACCT(6800)", RG.DETAILACCOUNT(6800) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6800)", (RG.ACCOUNT(6800) * RG.CONV_RATE()) - (RG.ACCOUNT(6800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6800)", ((RG.ACCOUNT(6800) * RG.CONV_RATE()) - (RG.ACCOUNT(6800, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6800, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6800)", (RG.ACCOUNT(6800) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6850)") == null)
            {
                RG.AddCalc("ACCT(6850)", RG.DETAILACCOUNT(6850) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6850)", (RG.ACCOUNT(6850) * RG.CONV_RATE()) - (RG.ACCOUNT(6850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6850)", ((RG.ACCOUNT(6850) * RG.CONV_RATE()) - (RG.ACCOUNT(6850, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6850, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6850)", (RG.ACCOUNT(6850) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6870)") == null)
            {
                RG.AddCalc("ACCT(6870)", RG.DETAILACCOUNT(6870) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6870)", (RG.ACCOUNT(6870) * RG.CONV_RATE()) - (RG.ACCOUNT(6870, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6870)", ((RG.ACCOUNT(6870) * RG.CONV_RATE()) - (RG.ACCOUNT(6870, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6870, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6870)", (RG.ACCOUNT(6870) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6880)") == null)
            {
                RG.AddCalc("ACCT(6880)", RG.DETAILACCOUNT(6880) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6880)", (RG.ACCOUNT(6880) * RG.CONV_RATE()) - (RG.ACCOUNT(6880, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6880)", ((RG.ACCOUNT(6880) * RG.CONV_RATE()) - (RG.ACCOUNT(6880, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6880, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6880)", (RG.ACCOUNT(6880) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(6900)") == null)
            {
                RG.AddCalc("ACCT(6900)", RG.DETAILACCOUNT(6900) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(6900)", (RG.ACCOUNT(6900) * RG.CONV_RATE()) - (RG.ACCOUNT(6900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(6900)", ((RG.ACCOUNT(6900) * RG.CONV_RATE()) - (RG.ACCOUNT(6900, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(6900, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(6900)", (RG.ACCOUNT(6900) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7000)") == null)
            {
                RG.AddCalc("ACCT(7000)", RG.DETAILACCOUNT(7000) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7000)", (RG.ACCOUNT(7000) * RG.CONV_RATE()) - (RG.ACCOUNT(7000, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7000)", ((RG.ACCOUNT(7000) * RG.CONV_RATE()) - (RG.ACCOUNT(7000, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7000, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7000)", (RG.ACCOUNT(7000) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7010)") == null)
            {
                RG.AddCalc("ACCT(7010)", RG.DETAILACCOUNT(7010) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7010)", (RG.ACCOUNT(7010) * RG.CONV_RATE()) - (RG.ACCOUNT(7010, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7010)", ((RG.ACCOUNT(7010) * RG.CONV_RATE()) - (RG.ACCOUNT(7010, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7010, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7010)", (RG.ACCOUNT(7010) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ Added for 7040 Version V 6-11-03
            if (RG.GetCalc("ACCT(7040)") == null)
            {
                RG.AddCalc("ACCT(7040)", RG.DETAILACCOUNT(7040) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7040)", (RG.ACCOUNT(7040) * RG.CONV_RATE()) - (RG.ACCOUNT(7040, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7040)", ((RG.ACCOUNT(7040) * RG.CONV_RATE()) - (RG.ACCOUNT(7040, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7040, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7040)", (RG.ACCOUNT(7040) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ end of Addition 7040

            if (RG.GetCalc("ACCT(7050)") == null)
            {
                RG.AddCalc("ACCT(7050)", RG.DETAILACCOUNT(7050) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7050)", (RG.ACCOUNT(7050) * RG.CONV_RATE()) - (RG.ACCOUNT(7050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7050)", ((RG.ACCOUNT(7050) * RG.CONV_RATE()) - (RG.ACCOUNT(7050, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7050, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7050)", (RG.ACCOUNT(7050) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ Added for 7090 Version V 6-1-03
            if (RG.GetCalc("ACCT(7090)") == null)
            {
                RG.AddCalc("ACCT(7090)", RG.DETAILACCOUNT(7090) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7090)", (RG.ACCOUNT(7090) * RG.CONV_RATE()) - (RG.ACCOUNT(7090, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7090)", ((RG.ACCOUNT(7090) * RG.CONV_RATE()) - (RG.ACCOUNT(7090, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7090, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7090)", (RG.ACCOUNT(7090) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ end of Addition 7040

            if (RG.GetCalc("ACCT(7100)") == null)
            {
                RG.AddCalc("ACCT(7100)", RG.DETAILACCOUNT(7100) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7100)", (RG.ACCOUNT(7100) * RG.CONV_RATE()) - (RG.ACCOUNT(7100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7100)", ((RG.ACCOUNT(7100) * RG.CONV_RATE()) - (RG.ACCOUNT(7100, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7100, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7100)", (RG.ACCOUNT(7100) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7120)") == null)
            {
                RG.AddCalc("ACCT(7120)", RG.DETAILACCOUNT(7120) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7120)", (RG.ACCOUNT(7120) * RG.CONV_RATE()) - (RG.ACCOUNT(7120, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7120)", ((RG.ACCOUNT(7120) * RG.CONV_RATE()) - (RG.ACCOUNT(7120, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7120, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7120)", (RG.ACCOUNT(7120) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7150)") == null)
            {
                RG.AddCalc("ACCT(7150)", RG.DETAILACCOUNT(7150) * RG.CONV_RATE());
                RG.AddCalc("ACCT(7150)LAG", RG.ACCOUNT(7150, RG.LAG) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("ActIDOvPer(7150)", (RG.ACCOUNT(7150) * RG.CONV_RATE()) - (RG.ACCOUNT(7150, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7150)", (RG.ACCOUNT(7150) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%IDOvPP(7150)", new Calc());
                double d7150Cur;
                double d7150Lag;
                for (int i = 0; i < RG.ACCOUNT(7150).Count; i++)
                    if ((RG.ACCOUNT(7150)[i] > 0) && (RG.ACCOUNT(7150, RG.LAG)[i] > 0))
                    {
                        d7150Cur = RG.ACCOUNT(7150)[i] * RG.CONV_RATE()[i];
                        d7150Lag = RG.ACCOUNT(7150, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                        RG.GetCalc("%IDOvPP(7150)").Add((d7150Cur - d7150Lag) / d7150Lag * 100);
                    }
                    else
                    {
                        if ((RG.ACCOUNT(7150)[i] < 0) && (RG.ACCOUNT(7150, RG.LAG)[i] < 0))
                        {
                            d7150Cur = RG.ACCOUNT(7150)[i] * RG.CONV_RATE()[i];
                            d7150Lag = RG.ACCOUNT(7150, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                            RG.GetCalc("%IDOvPP(7150)").Add((d7150Cur - d7150Lag) / d7150Lag * -100);
                        }
                        else
                            RG.GetCalc("%IDOvPP(7150)").Add(RG.MACRO(M.ERR_STRING)[i]);
                    }
            }
            if (RG.GetCalc("ACCT(7250)") == null)
            {
                RG.AddCalc("ACCT(7250)", RG.DETAILACCOUNT(7250) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7250)", (RG.ACCOUNT(7250) * RG.CONV_RATE()) - (RG.ACCOUNT(7250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7250)", ((RG.ACCOUNT(7250) * RG.CONV_RATE()) - (RG.ACCOUNT(7250, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7250, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7250)", (RG.ACCOUNT(7250) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%PBT(7250)", (RG.ACCOUNT(7250) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX));
            }
            if (RG.GetCalc("ACCT(7300)") == null)
            {
                RG.AddCalc("ACCT(7300)", RG.DETAILACCOUNT(7300) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7300)", (RG.ACCOUNT(7300) * RG.CONV_RATE()) - (RG.ACCOUNT(7300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7300)", ((RG.ACCOUNT(7300) * RG.CONV_RATE()) - (RG.ACCOUNT(7300, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7300, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7300)", (RG.ACCOUNT(7300) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%PBT(7300)", (RG.ACCOUNT(7300) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX));
            }
            if (RG.GetCalc("ACCT(7320)") == null)
            {
                RG.AddCalc("ACCT(7320)", RG.DETAILACCOUNT(7320) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7320)", (RG.ACCOUNT(7320) * RG.CONV_RATE()) - (RG.ACCOUNT(7320, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7320)", ((RG.ACCOUNT(7320) * RG.CONV_RATE()) - (RG.ACCOUNT(7320, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7320, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7320)", (RG.ACCOUNT(7320) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%PBT(7320)", (RG.ACCOUNT(7320) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX));
            }
            if (RG.GetCalc("ACCT(7230)") == null)
            {
                RG.AddCalc("ACCT(7230)", RG.DETAILACCOUNT(7230) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7230)", (RG.ACCOUNT(7230) * RG.CONV_RATE()) - (RG.ACCOUNT(7230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7230)", ((RG.ACCOUNT(7230) * RG.CONV_RATE()) - (RG.ACCOUNT(7230, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7230, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7230)", (RG.ACCOUNT(7230) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%PBT(7230)", (RG.ACCOUNT(7230) * RG.CONV_RATE()) % RG.MACRO(M.PROFIT_BEFORE_TAX));
            }
            if (RG.GetCalc("ACCT(7200)") == null)
            {
                RG.AddCalc("ACCT(7200)", RG.DETAILACCOUNT(7200) * RG.CONV_RATE());
                RG.AddCalc("ACCT(7200)LAG", RG.ACCOUNT(7200, RG.LAG) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("ActIDOvPer(7200)", (RG.ACCOUNT(7200) * RG.CONV_RATE()) - (RG.ACCOUNT(7200, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7200)", (RG.ACCOUNT(7200) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("%IDOvPP(7200)", new Calc());
                double d7200Cur;
                double d7200Lag;
                for (int i = 0; i < RG.ACCOUNT(7200).Count; i++)
                    if ((RG.ACCOUNT(7200)[i] > 0) && (RG.ACCOUNT(7200, RG.LAG)[i] > 0))
                    {
                        d7200Cur = RG.ACCOUNT(7200)[i] * RG.CONV_RATE()[i];
                        d7200Lag = RG.ACCOUNT(7200, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                        RG.GetCalc("%IDOvPP(7200)").Add((d7200Cur - d7200Lag) / d7200Lag * 100);
                    }
                    else
                    {
                        if ((RG.ACCOUNT(7200)[i] < 0) && (RG.ACCOUNT(7200, RG.LAG)[i] < 0))
                        {
                            d7200Cur = RG.ACCOUNT(7200)[i] * RG.CONV_RATE()[i];
                            d7200Lag = RG.ACCOUNT(7200, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                            RG.GetCalc("%IDOvPP(7200)").Add((d7200Cur - d7200Lag) / d7200Lag * -100);
                        }
                        else
                            RG.GetCalc("%IDOvPP(7200)").Add(RG.MACRO(M.ERR_STRING)[i]);
                    }
            }
            if (RG.GetCalc("ACCT(7350)") == null)
            {
                RG.AddCalc("ACCT(7350)", RG.DETAILACCOUNT(7350) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7350)", (RG.ACCOUNT(7350) * RG.CONV_RATE()) - (RG.ACCOUNT(7350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7350)", ((RG.ACCOUNT(7350) * RG.CONV_RATE()) - (RG.ACCOUNT(7350, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7350, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7350)", (RG.ACCOUNT(7350) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7400)") == null)
            {
                RG.AddCalc("ACCT(7400)", RG.DETAILACCOUNT(7400) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7400)", (RG.ACCOUNT(7400) * RG.CONV_RATE()) - (RG.ACCOUNT(7400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7400)", ((RG.ACCOUNT(7400) * RG.CONV_RATE()) - (RG.ACCOUNT(7400, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7400, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7400)", (RG.ACCOUNT(7400) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7470)") == null)
            {
                RG.AddCalc("ACCT(7470)", RG.DETAILACCOUNT(7470) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7470)", (RG.ACCOUNT(7470) * RG.CONV_RATE()) - (RG.ACCOUNT(7470, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7470)", ((RG.ACCOUNT(7470) * RG.CONV_RATE()) - (RG.ACCOUNT(7470, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7470, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7470)", (RG.ACCOUNT(7470) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7480)") == null)
            {
                RG.AddCalc("ACCT(7480)", RG.DETAILACCOUNT(7480) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7480)", (RG.ACCOUNT(7480) * RG.CONV_RATE()) - (RG.ACCOUNT(7480, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7480)", ((RG.ACCOUNT(7480) * RG.CONV_RATE()) - (RG.ACCOUNT(7480, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7480, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7480)", (RG.ACCOUNT(7480) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7700)") == null)
            {
                RG.AddCalc("ACCT(7700)", RG.DETAILACCOUNT(7700) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7700)", (RG.ACCOUNT(7700) * RG.CONV_RATE()) - (RG.ACCOUNT(7700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7700)", ((RG.ACCOUNT(7700) * RG.CONV_RATE()) - (RG.ACCOUNT(7700, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7700, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7700)", (RG.ACCOUNT(7700) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7720)") == null)
            {
                RG.AddCalc("ACCT(7720)", RG.DETAILACCOUNT(7720) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7720)", (RG.ACCOUNT(7720) * RG.CONV_RATE()) - (RG.ACCOUNT(7720, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7720)", ((RG.ACCOUNT(7720) * RG.CONV_RATE()) - (RG.ACCOUNT(7720, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7720, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7720)", (RG.ACCOUNT(7720) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7740)") == null)
            {
                RG.AddCalc("ACCT(7740)", RG.DETAILACCOUNT(7740) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7740)", (RG.ACCOUNT(7740) * RG.CONV_RATE()) - (RG.ACCOUNT(7740, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7740)", ((RG.ACCOUNT(7740) * RG.CONV_RATE()) - (RG.ACCOUNT(7740, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7740, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7740)", (RG.ACCOUNT(7740) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7760)") == null)
            {
                RG.AddCalc("ACCT(7760)", RG.DETAILACCOUNT(7760) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7760)", (RG.ACCOUNT(7760) * RG.CONV_RATE()) - (RG.ACCOUNT(7760, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7760)", ((RG.ACCOUNT(7760) * RG.CONV_RATE()) - (RG.ACCOUNT(7760, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7760, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7760)", (RG.ACCOUNT(7760) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            if (RG.GetCalc("ACCT(7780)") == null)
            {
                RG.AddCalc("ACCT(7780)", RG.DETAILACCOUNT(7780) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7780)", (RG.ACCOUNT(7780) * RG.CONV_RATE()) - (RG.ACCOUNT(7780, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7780)", ((RG.ACCOUNT(7780) * RG.CONV_RATE()) - (RG.ACCOUNT(7780, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7780, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7780)", (RG.ACCOUNT(7780) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ Added 7790 Version V 6-11-03
            if (RG.GetCalc("ACCT(7790)") == null)
            {
                RG.AddCalc("ACCT(7790)", RG.DETAILACCOUNT(7790) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7790)", (RG.ACCOUNT(7790) * RG.CONV_RATE()) - (RG.ACCOUNT(7790, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7790)", ((RG.ACCOUNT(7790) * RG.CONV_RATE()) - (RG.ACCOUNT(7790, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7790, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(7790)", (RG.ACCOUNT(7790) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }
            // KCZ end of addition 7790

            if (RG.GetCalc("ACCT(7500)") == null)
            {
                RG.AddCalc("ACCT(7500)", RG.DETAILACCOUNT(7500) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7500)", (RG.ACCOUNT(7500) * RG.CONV_RATE()) - (RG.ACCOUNT(7500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7500)", ((RG.ACCOUNT(7500) * RG.CONV_RATE()) - (RG.ACCOUNT(7500, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7500, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetProfit(7500)", (RG.ACCOUNT(7500) * RG.CONV_RATE()) % RG.MACRO(M.NET_PROFIT));
            }
            if (RG.GetCalc("ACCT(7520)") == null)
            {
                RG.AddCalc("ACCT(7520)", RG.DETAILACCOUNT(7520) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7520)", (RG.ACCOUNT(7520) * RG.CONV_RATE()) - (RG.ACCOUNT(7520, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7520)", ((RG.ACCOUNT(7520) * RG.CONV_RATE()) - (RG.ACCOUNT(7520, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7520, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetProfit(7520)", (RG.ACCOUNT(7520) * RG.CONV_RATE()) % RG.MACRO(M.NET_PROFIT));
            }
            if (RG.GetCalc("ACCT(7450)") == null)
            {
                RG.AddCalc("ACCT(7450)", RG.DETAILACCOUNT(7450) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7450)", (RG.ACCOUNT(7450) * RG.CONV_RATE()) - (RG.ACCOUNT(7450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7450)", ((RG.ACCOUNT(7450) * RG.CONV_RATE()) - (RG.ACCOUNT(7450, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7450, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetProfit(7450)", (RG.ACCOUNT(7450) * RG.CONV_RATE()) % RG.MACRO(M.NET_PROFIT));
            }
            if (RG.GetCalc("ACCT(7550)") == null)
            {
                RG.AddCalc("ACCT(7550)", RG.DETAILACCOUNT(7550) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(7550)", (RG.ACCOUNT(7550) * RG.CONV_RATE()) - (RG.ACCOUNT(7550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7550)", ((RG.ACCOUNT(7550) * RG.CONV_RATE()) - (RG.ACCOUNT(7550, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(7550, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetProfit(7550)", (RG.ACCOUNT(7550) * RG.CONV_RATE()) % RG.MACRO(M.NET_PROFIT));
            }
            if (RG.GetCalc("ACCT(7600)") == null)
            {
                RG.AddCalc("ACCT(7600)", RG.DETAILACCOUNT(7600) * RG.CONV_RATE());
                RG.AddCalc("ACCT(7600)LAG", RG.ACCOUNT(7600, RG.LAG) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("ActIDOvPer(7600)", (RG.ACCOUNT(7600) * RG.CONV_RATE()) - (RG.ACCOUNT(7600, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7600)", new Calc());
                double d7600Cur;
                double d7600Lag;
                for (int i = 0; i < RG.ACCOUNT(7600).Count; i++)
                    if ((RG.ACCOUNT(7600)[i] > 0) && (RG.ACCOUNT(7600, RG.LAG)[i] > 0))
                    {
                        d7600Cur = RG.ACCOUNT(7600)[i] * RG.CONV_RATE()[i];
                        d7600Lag = RG.ACCOUNT(7600, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                        RG.GetCalc("%IDOvPP(7600)").Add((d7600Cur - d7600Lag) / d7600Lag * 100);
                    }
                    else
                    {
                        if ((RG.ACCOUNT(7600)[i] < 0) && (RG.ACCOUNT(7600, RG.LAG)[i] < 0))
                        {
                            d7600Cur = RG.ACCOUNT(7600)[i] * RG.CONV_RATE()[i];
                            d7600Lag = RG.ACCOUNT(7600, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                            RG.GetCalc("%IDOvPP(7600)").Add((d7600Cur - d7600Lag) / d7600Lag * -100);
                        }
                        else
                            RG.GetCalc("%IDOvPP(7600)").Add(RG.MACRO(M.ERR_STRING)[i]);
                    }
            }
            if (RG.GetCalc("ACCT(7650)") == null)
            {
                RG.AddCalc("ACCT(7650)", RG.DETAILACCOUNT(7650) * RG.CONV_RATE());
                RG.AddCalc("ACCT(7650)LAG", RG.ACCOUNT(7650, RG.LAG) * RG.CONV_RATE(RG.LAG));
                RG.AddCalc("ActIDOvPer(7650)", (RG.ACCOUNT(7650) * RG.CONV_RATE()) - (RG.ACCOUNT(7650, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(7650)", new Calc());
                double d7650Cur;
                double d7650Lag;
                for (int i = 0; i < RG.ACCOUNT(7650).Count; i++)
                    if ((RG.ACCOUNT(7650)[i] > 0) && (RG.ACCOUNT(7650, RG.LAG)[i] > 0))
                    {
                        d7650Cur = RG.ACCOUNT(7650)[i] * RG.CONV_RATE()[i];
                        d7650Lag = RG.ACCOUNT(7650, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                        RG.GetCalc("%IDOvPP(7650)").Add((d7650Cur - d7650Lag) / d7650Lag * 100);
                    }
                    else
                    {
                        if ((RG.ACCOUNT(7650)[i] < 0) && (RG.ACCOUNT(7650, RG.LAG)[i] < 0))
                        {
                            d7650Cur = RG.ACCOUNT(7650)[i] * RG.CONV_RATE()[i];
                            d7650Lag = RG.ACCOUNT(7650, RG.LAG)[i] * RG.CONV_RATE(RG.LAG)[i];
                            RG.GetCalc("%IDOvPP(7650)").Add((d7650Cur - d7650Lag) / d7650Lag * -100);
                        }
                        else
                            RG.GetCalc("%IDOvPP(7650)").Add(RG.MACRO(M.ERR_STRING)[i]);
                    }
            }

            if (RG.GetCalc("ACCT(9953)") == null)
            {
                RG.AddCalc("ACCT(9953)", RG.DETAILACCOUNT(9953) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(9953)", (RG.ACCOUNT(9953) * RG.CONV_RATE()) - (RG.ACCOUNT(9953, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(9953)", ((RG.ACCOUNT(9953) * RG.CONV_RATE()) - (RG.ACCOUNT(9953, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(9953, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(9953)", (RG.ACCOUNT(9953) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }

            if (RG.GetCalc("ACCT(9954)") == null)
            {
                RG.AddCalc("ACCT(9954)", RG.DETAILACCOUNT(9954) * RG.CONV_RATE());
                RG.AddCalc("ActIDOvPer(9954)", (RG.ACCOUNT(9954) * RG.CONV_RATE()) - (RG.ACCOUNT(9954, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%IDOvPP(9954)", ((RG.ACCOUNT(9954) * RG.CONV_RATE()) - (RG.ACCOUNT(9954, RG.LAG) * RG.CONV_RATE(RG.LAG))) % (RG.ACCOUNT(9954, RG.LAG) * RG.CONV_RATE(RG.LAG)));
                RG.AddCalc("%NetSales(9954)", (RG.ACCOUNT(9954) * RG.CONV_RATE()) % RG.MACRO(M.NET_SALES));
            }



        }
        public void Peer_Comp_Ind_Val(ReportGenerator RG)
        {
            ISCalcs(RG);

            ///***CPF 11/6/02 Load the resource manager.
            ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);
            PeerStatement ps;
            int BaseId = -1;
            int PeerId = -1;
            int VarId = -1;
            int PBaseId;
            int PPeerId;
            int PVarId = 0;

            foreach (Statement s in RG.Statements)
            {
                if (s.Peer == true)
                {
                    PeerId = s.Id;
                    ps = (PeerStatement)s;
                    BaseId = ps.BaseStatementID;
                }
                else if (s.Variance == true)
                    VarId = s.Id;
            }

            PPeerId = RG.Statements.IndexOf(RG.Context.Statements[PeerId.ToString()]);
            if (VarId != -1)
                PVarId = RG.Statements.IndexOf(RG.Context.Statements[VarId.ToString()]);
            PBaseId = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);
            if (PBaseId < 0)
                return;

            if (RG.GetCalc("LINE(61)") == null)
                RG.AddCalc("LINE(61)", 1 * RG.YEAR());
            if (RG.GetCalc("LINE(62)") == null)
            {
                RG.AddCalc("LINE(62)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (RG.GetCalc("LINE(61)")[i] == 1)
                        RG.GetCalc("LINE(62)").Add(1);
                    else
                        RG.GetCalc("LINE(62)").Add(0);
                }
            }
            if (RG.GetCalc("LINE(64)") == null)
            {
                RG.AddCalc("LINE(64)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    RG.GetCalc("LINE(64)").Add(1 * RG.YEAR(RG.LAG)[i]);
                }
            }
            if (RG.GetCalc("LINE(65)") == null)
            {
                RG.AddCalc("LINE(65)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (RG.GetCalc("LINE(64)")[i] == 1)
                        RG.GetCalc("LINE(65)").Add(1);
                    else
                        RG.GetCalc("LINE(65)").Add(0);
                }
            }
            if (RG.GetCalc("LINE(70)") == null)
                RG.AddCalc("LINE(70)", RG.GetCalc("LINE(62)") + RG.GetCalc("LINE(65)"));
            if (RG.GetCalc("LINE(72)") == null)
            {
                RG.AddCalc("LINE(72)", new Calc());
                RG.AddCalc("LINE(73)", new Calc());
                RG.AddCalc("LINE(74)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (RG.GetCalc("LINE(70)")[i] < 2)
                    {
                        RG.GetCalc("LINE(72)").Add(9);
                        RG.GetCalc("LINE(73)").Add(243);
                        RG.GetCalc("LINE(74)").Add(27);
                    }
                    else
                    {
                        RG.GetCalc("LINE(72)").Add(0);
                        RG.GetCalc("LINE(73)").Add(0);
                        RG.GetCalc("LINE(74)").Add(0);
                    }
                }
            }

            ///************************************************************************
            ///*  DETERMINE IF WHAT TYPE OF STATEMENT IS BEING ANALYZED
            ///************************************************************************
            ///        *  Reviewed
            ///************************************************************************
            if (RG.GetCalc("LINE(39)") == null)
            {
                RG.AddCalc("LINE(39)", new Calc());
                RG.AddCalc("LINE(40)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civRevUC"))
                        {
                            RG.GetCalc("LINE(39)").Add(2);
                            RG.GetCalc("LINE(40)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civRevMC"))
                        {
                            RG.GetCalc("LINE(39)").Add(0);
                            RG.GetCalc("LINE(40)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(39)").Add(0);
                            RG.GetCalc("LINE(40)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(39)").Add(0);
                        RG.GetCalc("LINE(40)").Add(0);
                    }
                }
                RG.AddCalc("LINE(59)", RG.GetCalc("LINE(39)") + RG.GetCalc("LINE(40)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        *  QUALIFIED
            ///************************************************************************
            string c1 = RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString();
            string c2 = rm.GetString("civQualUC");
            if (RG.GetCalc("LINE(41)") == null)
            {
                RG.AddCalc("LINE(41)", new Calc());
                RG.AddCalc("LINE(42)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civQualUC"))
                        {
                            RG.GetCalc("LINE(41)").Add(2);
                            RG.GetCalc("LINE(42)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civQualMC"))
                        {
                            RG.GetCalc("LINE(41)").Add(0);
                            RG.GetCalc("LINE(42)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(41)").Add(0);
                            RG.GetCalc("LINE(42)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(41)").Add(0);
                        RG.GetCalc("LINE(42)").Add(0);
                    }
                }
                RG.AddCalc("LINE(43)", RG.GetCalc("LINE(41)") + RG.GetCalc("LINE(42)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        *  UNQUALIFIED
            ///************************************************************************
            if (RG.GetCalc("LINE(44)") == null)
            {
                RG.AddCalc("LINE(44)", new Calc());
                RG.AddCalc("LINE(45)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civUnqUC"))
                        {
                            RG.GetCalc("LINE(44)").Add(2);
                            RG.GetCalc("LINE(45)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civUnqMC"))
                        {
                            RG.GetCalc("LINE(44)").Add(0);
                            RG.GetCalc("LINE(45)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(44)").Add(0);
                            RG.GetCalc("LINE(45)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(44)").Add(0);
                        RG.GetCalc("LINE(45)").Add(0);
                    }
                }
                RG.AddCalc("LINE(46)", RG.GetCalc("LINE(44)") + RG.GetCalc("LINE(45)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        * DISCLAIMER
            ///************************************************************************
            if (RG.GetCalc("LINE(47)") == null)
            {
                RG.AddCalc("LINE(47)", new Calc());
                RG.AddCalc("LINE(48)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civDiscUC"))
                        {
                            RG.GetCalc("LINE(47)").Add(2);
                            RG.GetCalc("LINE(48)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civDiscMC"))
                        {
                            RG.GetCalc("LINE(47)").Add(0);
                            RG.GetCalc("LINE(48)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(47)").Add(0);
                            RG.GetCalc("LINE(48)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(47)").Add(0);
                        RG.GetCalc("LINE(48)").Add(0);
                    }
                }
                RG.AddCalc("LINE(49)", RG.GetCalc("LINE(47)") + RG.GetCalc("LINE(48)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        * TAX RETURN
            ///************************************************************************
            if (RG.GetCalc("LINE(50)") == null)
            {
                RG.AddCalc("LINE(50)", new Calc());
                RG.AddCalc("LINE(51)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civTxRetUC"))
                        {
                            RG.GetCalc("LINE(50)").Add(2);
                            RG.GetCalc("LINE(51)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civTxRetMC"))
                        {
                            RG.GetCalc("LINE(50)").Add(0);
                            RG.GetCalc("LINE(51)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(50)").Add(0);
                            RG.GetCalc("LINE(51)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(50)").Add(0);
                        RG.GetCalc("LINE(51)").Add(0);
                    }
                }
                RG.AddCalc("LINE(71)", RG.GetCalc("LINE(50)") + RG.GetCalc("LINE(51)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        * COMPILED'
            ///************************************************************************
            if (RG.GetCalc("LINE(52)") == null)
            {
                RG.AddCalc("LINE(52)", new Calc());
                RG.AddCalc("LINE(54)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civCompUC"))
                        {
                            RG.GetCalc("LINE(52)").Add(2);
                            RG.GetCalc("LINE(54)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civCompMC"))
                        {
                            RG.GetCalc("LINE(52)").Add(0);
                            RG.GetCalc("LINE(54)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(52)").Add(0);
                            RG.GetCalc("LINE(54)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(52)").Add(0);
                        RG.GetCalc("LINE(54)").Add(0);
                    }
                }
                RG.AddCalc("LINE(53)", RG.GetCalc("LINE(52)") + RG.GetCalc("LINE(54)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        * CO.PREP'D
            ///************************************************************************
            if (RG.GetCalc("LINE(55)") == null)
            {
                RG.AddCalc("LINE(55)", new Calc());
                RG.AddCalc("LINE(56)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == PBaseId)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civCoPpdUC"))
                        {
                            RG.GetCalc("LINE(55)").Add(2);
                            RG.GetCalc("LINE(56)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civCoPpdMC"))
                        {
                            RG.GetCalc("LINE(55)").Add(0);
                            RG.GetCalc("LINE(56)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(55)").Add(0);
                            RG.GetCalc("LINE(56)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(55)").Add(0);
                        RG.GetCalc("LINE(56)").Add(0);
                    }
                }
                RG.AddCalc("LINE(57)", RG.GetCalc("LINE(55)") + RG.GetCalc("LINE(56)") + RG.GetCalc("LINE(62)"));
                RG.AddCalc("LINE(58)", RG.GetCalc("LINE(52)") + RG.GetCalc("LINE(54)") + RG.GetCalc("LINE(55)") + RG.GetCalc("LINE(56)") + RG.GetCalc("LINE(62)"));
            }
            ///************************************************************************
            ///        * ADVERSE OPINION
            ///************************************************************************
            if (RG.GetCalc("LINE(66)") == null)
            {
                RG.AddCalc("LINE(66)", new Calc());
                RG.AddCalc("LINE(67)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (i == RG.Statements.Count - 1)
                    {
                        if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civAdvUC"))
                        {
                            RG.GetCalc("LINE(66)").Add(2);
                            RG.GetCalc("LINE(67)").Add(0);
                        }
                        else if (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[i].ToString() == rm.GetString("civAdvMC"))
                        {
                            RG.GetCalc("LINE(66)").Add(0);
                            RG.GetCalc("LINE(67)").Add(2);
                        }
                        else
                        {
                            RG.GetCalc("LINE(66)").Add(0);
                            RG.GetCalc("LINE(67)").Add(0);
                        }
                    }
                    else
                    {
                        RG.GetCalc("LINE(66)").Add(0);
                        RG.GetCalc("LINE(67)").Add(0);
                    }
                }
                RG.AddCalc("LINE(68)", RG.GetCalc("LINE(66)") + RG.GetCalc("LINE(67)") + RG.GetCalc("LINE(62)"));
            }
            if (RG.GetCalc("LINE(69)") == null)
                RG.AddCalc("LINE(69)", RG.GetCalc("LINE(66)") + RG.GetCalc("LINE(67)") + RG.GetCalc("LINE(41)") + RG.GetCalc("LINE(42)") +
                                       RG.GetCalc("LINE(44)") + RG.GetCalc("LINE(45)") + RG.GetCalc("LINE(47)") + RG.GetCalc("LINE(48)") +
                                       RG.GetCalc("LINE(52)") + RG.GetCalc("LINE(54)") + RG.GetCalc("LINE(55)") + RG.GetCalc("LINE(56)") +
                                       RG.GetCalc("LINE(62)") + RG.GetCalc("LINE(39)") + RG.GetCalc("LINE(40)") + RG.GetCalc("LINE(50)") +
                                       RG.GetCalc("LINE(51)"));
            //			if (RG.GetCalc("LINE(82)") == null)
            //				RG.AddCalc("LINE(82)", RG.IND(7));
            //			if (RG.GetCalc("LINE(4159)") == null)
            //				RG.AddCalc("LINE(4159)", RG.IND(94));
            if (RG.GetCalc("LINE(4160)") == null)
            {
                RG.AddCalc("LINE(4160)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    ///if (RG.GetCalc("LINE(4159)")[i] > 0)
                    if (RG.IND(94) > 0)
                        RG.GetCalc("LINE(4160)").Add(4);
                    else
                        RG.GetCalc("LINE(4160)").Add(0);
                }
            }
            if (RG.GetCalc("LINE(4161)") == null)
            {
                RG.AddCalc("LINE(4161)", new Calc());
                RG.AddCalc("LINE(4162)", new Calc());
                RG.AddCalc("LINE(4163)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    if (RG.IND_Category == (int)ePeerCategory.Assets)
                    {
                        RG.GetCalc("LINE(4161)").Add(1);
                        RG.GetCalc("LINE(4162)").Add(0);
                        RG.GetCalc("LINE(4163)").Add(0);
                    }
                    else if (RG.IND_Category == (int)ePeerCategory.Totals)
                    {
                        RG.GetCalc("LINE(4161)").Add(0);
                        RG.GetCalc("LINE(4162)").Add(2);
                        RG.GetCalc("LINE(4163)").Add(0);
                    }
                    else if (RG.IND_Category == (int)ePeerCategory.Sales)
                    {
                        RG.GetCalc("LINE(4161)").Add(0);
                        RG.GetCalc("LINE(4162)").Add(0);
                        RG.GetCalc("LINE(4163)").Add(3);
                    }
                }
            }
            if (RG.GetCalc("LINE(4164)") == null)
                RG.AddCalc("LINE(4164)", RG.GetCalc("LINE(4160)") + RG.GetCalc("LINE(4161)") + RG.GetCalc("LINE(4162)") + RG.GetCalc("LINE(4163)"));
            //       *  IF = 0  THEN NO YEAR AND NO INDUSTRY DATA
            //       *  IF = 1  THEN NO YEAR AND ASSET SIZE
            //       *  IF = 2  THEN NO YEAR AND SALES SIZE
            //       *  IF = 3  THEN NO YEAR AND ALL
            //       *  IF = 4  THEN YEAR AND NO INDUSTRY DATA
            //       *  IF = 5  THEN YEAR AND ASSET SIZE
            //       *  IF = 6  THEN YEAR AND SALES SIZE
            //       *  IF = 7  THEN YEAR AND ALL
            //
            //			if (RG.GetCalc("LINE(33)") == null)
            //				RG.AddCalc("LINE(33)", RG.IND(33));
            if (RG.GetCalc("LINE(5)") == null)
            {
                RG.AddCalc("LINE(5)", new Calc());
                for (int i = 0; i < RG.Statements.Count; i++)
                {
                    ///if (RG.GetCalc("LINE(33)")[i] == 100)
                    if (RG.IND(33) == 100)
                        RG.GetCalc("LINE(5)").Add(1);
                    else
                        RG.GetCalc("LINE(5)").Add(0);
                }
            }
            ///Cash & Equivalents
            if (RG.GetCalc("LINE(7014)") == null)
            {
                RG.AddCalc("LINE(7014)", RG.MACRO(M.CASH_NEAR_CASH) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRCashEq", new Calc());
                RG.GetCalc("PRCashEq").Add(RG.GetCalc("LINE(7014)")[PBaseId]);
                RG.GetCalc("PRCashEq").Add(RG.IND(8));
                if (VarId != -1)
                    RG.GetCalc("PRCashEq").Add(RG.GetCalc("LINE(7014)")[PBaseId] - RG.IND(8));
            }
            ///Trade Receivables - (net)
            if (RG.GetCalc("LINE(7015)") == null)
            {
                RG.AddCalc("LINE(7015)", RG.MACRO(M.TOT_ACCTS_REC_NET) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRTrdRcv", new Calc());
                RG.GetCalc("PRTrdRcv").Add(RG.GetCalc("LINE(7015)")[PBaseId]);
                RG.GetCalc("PRTrdRcv").Add(RG.IND(9));
                if (VarId != -1)
                    RG.GetCalc("PRTrdRcv").Add(RG.GetCalc("LINE(7015)")[PBaseId] - RG.IND(9));
            }
            ///A/R - Current Retention (contractor only)
            if (RG.GetCalc("LINE(9015)") == null)
            {
                RG.AddCalc("LINE(9015)", RG.TYPE(12) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRARCurRet", new Calc());
                RG.GetCalc("PRARCurRet").Add(RG.GetCalc("LINE(9015)")[PBaseId]);
                RG.GetCalc("PRARCurRet").Add(RG.IND(10));
                if (VarId != -1)
                    RG.GetCalc("PRARCurRet").Add(RG.GetCalc("LINE(9015)")[PBaseId] - RG.IND(10));
            }
            ///Inventory
            if (RG.GetCalc("LINE(7016)") == null)
            {
                RG.AddCalc("LINE(7016)", RG.MACRO(M.TOTAL_INVENTORY) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRInv", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRInv").Add(RG.GetCalc("LINE(7016)")[PBaseId]);
                    RG.GetCalc("PRInv").Add(RG.IND(11));
                    if (VarId != -1)
                        RG.GetCalc("PRInv").Add(RG.GetCalc("LINE(7016)")[PBaseId] - RG.IND(11));
                }
                else
                {
                    RG.GetCalc("PRInv").Add(RG.GetCalc("LINE(7016)")[PBaseId]);
                    RG.GetCalc("PRInv").Add(RG.IND(10));
                    if (VarId != -1)
                        RG.GetCalc("PRInv").Add(RG.GetCalc("LINE(7016)")[PBaseId] - RG.IND(10));
                }
            }
            ///All Other Current Assets (non-contractors)
            if (RG.GetCalc("LINE(7017)") == null)
            {
                RG.AddCalc("LINE(7017)", RG.MACRO(M.OTH_CUR_AST_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("LINE(9017)", (RG.AND(5, RG.ANDCLASS, 25, RG.ANDTYPE) + RG.TYPE(30) + RG.TYPE(35) + RG.TYPE(13)) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRAllOthCurAst", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRAllOthCurAst").Add(RG.GetCalc("LINE(9017)")[PBaseId]);
                    RG.GetCalc("PRAllOthCurAst").Add(RG.IND(13));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthCurAst").Add(RG.GetCalc("LINE(9017)")[PBaseId] - RG.IND(13));
                }
                else
                {
                    RG.GetCalc("PRAllOthCurAst").Add(RG.GetCalc("LINE(7017)")[PBaseId]);
                    RG.GetCalc("PRAllOthCurAst").Add(RG.IND(11));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthCurAst").Add(RG.GetCalc("LINE(7017)")[PBaseId] - RG.IND(11));
                }
            }
            ///Costs in Excess of Billings (contractor only)
            if (RG.GetCalc("LINE(9018)") == null)
            {
                RG.AddCalc("LINE(9018)", RG.TYPE(27) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRCstExcBil", new Calc());
                RG.GetCalc("PRCstExcBil").Add(RG.GetCalc("LINE(9018)")[PBaseId]);
                RG.GetCalc("PRCstExcBil").Add(RG.IND(12));
                if (VarId != -1)
                    RG.GetCalc("PRCstExcBil").Add(RG.GetCalc("LINE(9018)")[PBaseId] - RG.IND(12));
            }
            ///Total Current Assets
            if (RG.GetCalc("LINE(7018)") == null)
            {
                RG.AddCalc("LINE(7018)", RG.GetCalc("LINE(7014)") + RG.GetCalc("LINE(7015)") + RG.GetCalc("LINE(7016)") + RG.GetCalc("LINE(7017)"));
                RG.AddCalc("PRTotCurAst", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRTotCurAst").Add(RG.GetCalc("LINE(7018)")[PBaseId]);
                    RG.GetCalc("PRTotCurAst").Add(RG.IND(14));
                    if (VarId != -1)
                        RG.GetCalc("PRTotCurAst").Add(RG.GetCalc("LINE(7018)")[PBaseId] - RG.IND(14));
                }
                else
                {
                    RG.GetCalc("PRTotCurAst").Add(RG.GetCalc("LINE(7018)")[PBaseId]);
                    RG.GetCalc("PRTotCurAst").Add(RG.IND(12));
                    if (VarId != -1)
                        RG.GetCalc("PRTotCurAst").Add(RG.GetCalc("LINE(7018)")[PBaseId] - RG.IND(12));
                }
            }
            ///Fixed Assets (net)
            if (RG.GetCalc("LINE(7019)") == null)
            {
                RG.AddCalc("LINE(7019)", RG.MACRO(M.NET_FIXED_ASSETS) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRFxdAstNt", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRFxdAstNt").Add(RG.GetCalc("LINE(7019)")[PBaseId]);
                    RG.GetCalc("PRFxdAstNt").Add(RG.IND(15));
                    if (VarId != -1)
                        RG.GetCalc("PRFxdAstNt").Add(RG.GetCalc("LINE(7019)")[PBaseId] - RG.IND(15));
                }
                else
                {
                    RG.GetCalc("PRFxdAstNt").Add(RG.GetCalc("LINE(7019)")[PBaseId]);
                    RG.GetCalc("PRFxdAstNt").Add(RG.IND(13));
                    if (VarId != -1)
                        RG.GetCalc("PRFxdAstNt").Add(RG.GetCalc("LINE(7019)")[PBaseId] - RG.IND(13));
                }
            }
            ///Intangibles
            if (RG.GetCalc("LINE(7020)") == null)
            {
                RG.AddCalc("LINE(7020)", RG.MACRO(M.INTANG_NET) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRIntang", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRIntang").Add(RG.GetCalc("LINE(7020)")[PBaseId]);
                    RG.GetCalc("PRIntang").Add(RG.IND(17));
                    if (VarId != -1)
                        RG.GetCalc("PRIntang").Add(RG.GetCalc("LINE(7020)")[PBaseId] - RG.IND(17));
                }
                else
                {
                    RG.GetCalc("PRIntang").Add(RG.GetCalc("LINE(7020)")[PBaseId]);
                    RG.GetCalc("PRIntang").Add(RG.IND(14));
                    if (VarId != -1)
                        RG.GetCalc("PRIntang").Add(RG.GetCalc("LINE(7020)")[PBaseId] - RG.IND(14));
                }
            }
            ///JV & Investments (contractors)
            if (RG.GetCalc("LINE(9020)") == null)
            {
                RG.AddCalc("LINE(9020)", (RG.TYPE(55)) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRJVInt", new Calc());
                RG.GetCalc("PRJVInt").Add(RG.GetCalc("LINE(9020)")[PBaseId]);
                RG.GetCalc("PRJVInt").Add(RG.IND(16));
                if (VarId != -1)
                    RG.GetCalc("PRJVInt").Add(RG.GetCalc("LINE(9020)")[PBaseId] - RG.IND(16));
            }
            ///All Other Non-Current (non-contractors)
            if (RG.GetCalc("LINE(7021)") == null)
            {
                RG.AddCalc("LINE(7021)", RG.MACRO(M.OTH_NON_CUR_AST_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("LINE(9021)", RG.MACRO(M.OTH_NON_CUR_AST_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRAllOthNCAst", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRAllOthNCAst").Add(RG.GetCalc("LINE(9021)")[PBaseId]);
                    RG.GetCalc("PRAllOthNCAst").Add(RG.IND(18));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthNCAst").Add(RG.GetCalc("LINE(9021)")[PBaseId] - RG.IND(18));
                }
                else
                {
                    RG.GetCalc("PRAllOthNCAst").Add(RG.GetCalc("LINE(7021)")[PBaseId]);
                    RG.GetCalc("PRAllOthNCAst").Add(RG.IND(15));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthNCAst").Add(RG.GetCalc("LINE(7021)")[PBaseId] - RG.IND(15));
                }
            }
            ///Total Non-Current Assets
            if (RG.GetCalc("LINE(7022)") == null)
            {
                RG.AddCalc("LINE(7022)", RG.GetCalc("LINE(7019)") + RG.GetCalc("LINE(7020)") + RG.GetCalc("LINE(7021)"));
                RG.AddCalc("PRTotNCAst", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRTotNCAst").Add(RG.GetCalc("LINE(7022)")[PBaseId]);
                    RG.GetCalc("PRTotNCAst").Add(RG.IND(15) + RG.IND(16) + RG.IND(17) + RG.IND(18));
                    if (VarId != -1)
                        RG.GetCalc("PRTotNCAst").Add(RG.GetCalc("LINE(7022)")[PBaseId] - (RG.IND(15) + RG.IND(16) + RG.IND(17) + RG.IND(18)));
                }
                else
                {
                    RG.GetCalc("PRTotNCAst").Add(RG.GetCalc("LINE(7022)")[PBaseId]);
                    RG.GetCalc("PRTotNCAst").Add(RG.IND(13) + RG.IND(14) + RG.IND(15));
                    if (VarId != -1)
                        RG.GetCalc("PRTotNCAst").Add(RG.GetCalc("LINE(7022)")[PBaseId] - (RG.IND(13) + RG.IND(14) + RG.IND(15)));
                }
            }
            ///Notes Payable-Short Term
            if (RG.GetCalc("LINE(7023)") == null)
            {
                RG.AddCalc("LINE(7023)", RG.MACRO(M.NOTES_PAYABLE_ST) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRNotPayST", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRNotPayST").Add(RG.GetCalc("LINE(7023)")[PBaseId]);
                    RG.GetCalc("PRNotPayST").Add(RG.IND(20));
                    if (VarId != -1)
                        RG.GetCalc("PRNotPayST").Add(RG.GetCalc("LINE(7023)")[PBaseId] - RG.IND(20));
                }
                else
                {
                    RG.GetCalc("PRNotPayST").Add(RG.GetCalc("LINE(7023)")[PBaseId]);
                    RG.GetCalc("PRNotPayST").Add(RG.IND(17));
                    if (VarId != -1)
                        RG.GetCalc("PRNotPayST").Add(RG.GetCalc("LINE(7023)")[PBaseId] - RG.IND(17));
                }
            }
            ///Current Maturities-L/T/D
            if (RG.GetCalc("LINE(7024)") == null)
            {
                RG.AddCalc("LINE(7024)", RG.MACRO(M.CPLTD_FROM_BALANCE_SHEET) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRCurMatLTD", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRCurMatLTD").Add(RG.GetCalc("LINE(7024)")[PBaseId]);
                    RG.GetCalc("PRCurMatLTD").Add(RG.IND(25));
                    if (VarId != -1)
                        RG.GetCalc("PRCurMatLTD").Add(RG.GetCalc("LINE(7024)")[PBaseId] - RG.IND(25));
                }
                else
                {
                    RG.GetCalc("PRCurMatLTD").Add(RG.GetCalc("LINE(7024)")[PBaseId]);
                    RG.GetCalc("PRCurMatLTD").Add(RG.IND(18));
                    if (VarId != -1)
                        RG.GetCalc("PRCurMatLTD").Add(RG.GetCalc("LINE(7024)")[PBaseId] - RG.IND(18));
                }
            }
            ///Trade Payables
            if (RG.GetCalc("LINE(7025)") == null)
            {
                RG.AddCalc("LINE(7025)", RG.TYPE(85) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRTrdPay", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRTrdPay").Add(RG.GetCalc("LINE(7025)")[PBaseId]);
                    RG.GetCalc("PRTrdPay").Add(RG.IND(21));
                    if (VarId != -1)
                        RG.GetCalc("PRTrdPay").Add(RG.GetCalc("LINE(7025)")[PBaseId] - RG.IND(21));
                }
                else
                {
                    RG.GetCalc("PRTrdPay").Add(RG.GetCalc("LINE(7025)")[PBaseId]);
                    RG.GetCalc("PRTrdPay").Add(RG.IND(19));
                    if (VarId != -1)
                        RG.GetCalc("PRTrdPay").Add(RG.GetCalc("LINE(7025)")[PBaseId] - RG.IND(19));
                }
            }
            ///A/P Current Retention (contractor only)
            if (RG.GetCalc("LINE(9025)") == null)
            {
                RG.AddCalc("LINE(9025)", RG.TYPE(87) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRAPRetent", new Calc());
                RG.GetCalc("PRAPRetent").Add(RG.GetCalc("LINE(9025)")[PBaseId]);
                RG.GetCalc("PRAPRetent").Add(RG.IND(22));
                if (VarId != -1)
                    RG.GetCalc("PRAPRetent").Add(RG.GetCalc("LINE(9025)")[PBaseId] - RG.IND(22));
            }
            ///Billings in Excess of Costs (contractor only)
            if (RG.GetCalc("LINE(9026)") == null)
            {
                RG.AddCalc("LINE(9026)", RG.TYPE(102) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRBillExcCst", new Calc());
                RG.GetCalc("PRBillExcCst").Add(RG.GetCalc("LINE(9026)")[PBaseId]);
                RG.GetCalc("PRBillExcCst").Add(RG.IND(23));
                if (VarId != -1)
                    RG.GetCalc("PRBillExcCst").Add(RG.GetCalc("LINE(9026)")[PBaseId] - RG.IND(23));
            }
            ///Income Taxes Payable
            if (RG.GetCalc("LINE(7026)") == null)
            {
                RG.AddCalc("LINE(7026)", RG.TYPE(95) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRIncTaxPay", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRIncTaxPay").Add(RG.GetCalc("LINE(7026)")[PBaseId]);
                    RG.GetCalc("PRIncTaxPay").Add(RG.IND(24));
                    if (VarId != -1)
                        RG.GetCalc("PRIncTaxPay").Add(RG.GetCalc("LINE(7026)")[PBaseId] - RG.IND(24));
                }
                else
                {
                    RG.GetCalc("PRIncTaxPay").Add(RG.GetCalc("LINE(7026)")[PBaseId]);
                    RG.GetCalc("PRIncTaxPay").Add(RG.IND(20));
                    if (VarId != -1)
                        RG.GetCalc("PRIncTaxPay").Add(RG.GetCalc("LINE(7026)")[PBaseId] - RG.IND(20));
                }
            }
            ///All Other Current (non-contractor)
            if (RG.GetCalc("LINE(7027)") == null)
            {
                RG.AddCalc("LINE(7027)", RG.MACRO(M.OTH_CUR_LIAB_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("LINE(9027)", RG.MACRO(M.OTH_CUR_LIAB_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRAllOthCurLb", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRAllOthCurLb").Add(RG.GetCalc("LINE(9027)")[PBaseId]);
                    RG.GetCalc("PRAllOthCurLb").Add(RG.IND(26));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthCurLb").Add(RG.GetCalc("LINE(9027)")[PBaseId] - RG.IND(26));
                }
                else
                {
                    RG.GetCalc("PRAllOthCurLb").Add(RG.GetCalc("LINE(7027)")[PBaseId]);
                    RG.GetCalc("PRAllOthCurLb").Add(RG.IND(21));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthCurLb").Add(RG.GetCalc("LINE(7027)")[PBaseId] - RG.IND(21));
                }
            }
            ///Total Current Liabs
            if (RG.GetCalc("LINE(7028)") == null)
            {
                RG.AddCalc("LINE(7028)", RG.GetCalc("LINE(7023)") + RG.GetCalc("LINE(7024)") + RG.GetCalc("LINE(7025)") + RG.GetCalc("LINE(7026)") + RG.GetCalc("LINE(7027)"));
                RG.AddCalc("PRTotCurLiab", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRTotCurLiab").Add(RG.GetCalc("LINE(7028)")[PBaseId]);
                    RG.GetCalc("PRTotCurLiab").Add(RG.IND(27));
                    if (VarId != -1)
                        RG.GetCalc("PRTotCurLiab").Add(RG.GetCalc("LINE(7028)")[PBaseId] - RG.IND(27));
                }
                else
                {
                    RG.GetCalc("PRTotCurLiab").Add(RG.GetCalc("LINE(7028)")[PBaseId]);
                    RG.GetCalc("PRTotCurLiab").Add(RG.IND(22));
                    if (VarId != -1)
                        RG.GetCalc("PRTotCurLiab").Add(RG.GetCalc("LINE(7028)")[PBaseId] - RG.IND(22));
                }
            }
            ///Long Term Debt
            if (RG.GetCalc("LINE(7029)") == null)
            {
                RG.AddCalc("LINE(7029)", RG.MACRO(M.LTD_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRLTD", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRLTD").Add(RG.GetCalc("LINE(7029)")[PBaseId]);
                    RG.GetCalc("PRLTD").Add(RG.IND(28));
                    if (VarId != -1)
                        RG.GetCalc("PRLTD").Add(RG.GetCalc("LINE(7029)")[PBaseId] - RG.IND(28));
                }
                else
                {
                    RG.GetCalc("PRLTD").Add(RG.GetCalc("LINE(7029)")[PBaseId]);
                    RG.GetCalc("PRLTD").Add(RG.IND(23));
                    if (VarId != -1)
                        RG.GetCalc("PRLTD").Add(RG.GetCalc("LINE(7029)")[PBaseId] - RG.IND(23));
                }
            }
            ///Deferred Taxes
            if (RG.GetCalc("LINE(7030)") == null)
            {
                RG.AddCalc("LINE(7030)", RG.TYPE(115) * RG.CONV_RATE() % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRDefTax", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRDefTax").Add(RG.GetCalc("LINE(7030)")[PBaseId]);
                    RG.GetCalc("PRDefTax").Add(RG.IND(29));
                    if (VarId != -1)
                        RG.GetCalc("PRDefTax").Add(RG.GetCalc("LINE(7030)")[PBaseId] - RG.IND(29));
                }
                else
                {
                    RG.GetCalc("PRDefTax").Add(RG.GetCalc("LINE(7030)")[PBaseId]);
                    RG.GetCalc("PRDefTax").Add(RG.IND(24));
                    if (VarId != -1)
                        RG.GetCalc("PRDefTax").Add(RG.GetCalc("LINE(7030)")[PBaseId] - RG.IND(24));
                }
            }
            ///All Other Non-Current
            if (RG.GetCalc("LINE(7031)") == null)
            {
                RG.AddCalc("LINE(7031)", RG.MACRO(M.OTH_NON_CUR_LIAB_PEER_CIV) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRAllOthNCLiab", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRAllOthNCLiab").Add(RG.GetCalc("LINE(7031)")[PBaseId]);
                    RG.GetCalc("PRAllOthNCLiab").Add(RG.IND(30));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthNCLiab").Add(RG.GetCalc("LINE(7031)")[PBaseId] - RG.IND(30));
                }
                else
                {
                    RG.GetCalc("PRAllOthNCLiab").Add(RG.GetCalc("LINE(7031)")[PBaseId]);
                    RG.GetCalc("PRAllOthNCLiab").Add(RG.IND(25));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthNCLiab").Add(RG.GetCalc("LINE(7031)")[PBaseId] - RG.IND(25));
                }
            }
            ///Total Non-Current Liabs
            if (RG.GetCalc("LINE(7032)") == null)
            {
                RG.AddCalc("LINE(7032)", RG.GetCalc("LINE(7029)") + RG.GetCalc("LINE(7030)") + RG.GetCalc("LINE(7031)"));
                RG.AddCalc("PRTotNCLiab", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRTotNCLiab").Add(RG.GetCalc("LINE(7032)")[PBaseId]);
                    RG.GetCalc("PRTotNCLiab").Add(RG.IND(28) + RG.IND(29) + RG.IND(30));
                    if (VarId != -1)
                    {
                        if (RG.MACRO(M.TOTAL_ASSETS)[PBaseId] != 0)
                            RG.GetCalc("PRTotNCLiab").Add(RG.GetCalc("LINE(7032)")[PBaseId] - (RG.IND(28) + RG.IND(29) + RG.IND(30)));
                        else
                            RG.GetCalc("PRTotNCLiab").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRTotNCLiab").Add(RG.GetCalc("LINE(7032)")[PBaseId]);
                    RG.GetCalc("PRTotNCLiab").Add(RG.IND(23) + RG.IND(24) + RG.IND(25));
                    if (VarId != -1)
                    {
                        if (RG.MACRO(M.TOTAL_ASSETS)[PBaseId] != 0)
                            RG.GetCalc("PRTotNCLiab").Add(RG.GetCalc("LINE(7032)")[PBaseId] - (RG.IND(23) + RG.IND(24) + RG.IND(25)));
                        else
                            RG.GetCalc("PRTotNCLiab").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Net Worth
            if (RG.GetCalc("LINE(7033)") == null)
            {
                RG.AddCalc("LINE(7033)", RG.MACRO(M.NET_WORTH) % RG.MACRO(M.TOTAL_ASSETS));
                RG.AddCalc("PRNetWrth", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRNetWrth").Add(RG.GetCalc("LINE(7033)")[PBaseId]);
                    RG.GetCalc("PRNetWrth").Add(RG.IND(31));
                    if (VarId != -1)
                        RG.GetCalc("PRNetWrth").Add(RG.GetCalc("LINE(7033)")[PBaseId] - RG.IND(31));
                }
                else
                {
                    RG.GetCalc("PRNetWrth").Add(RG.GetCalc("LINE(7033)")[PBaseId]);
                    RG.GetCalc("PRNetWrth").Add(RG.IND(26));
                    if (VarId != -1)
                        RG.GetCalc("PRNetWrth").Add(RG.GetCalc("LINE(7033)")[PBaseId] - RG.IND(26));
                }
            }
            ///Gross Profit
            if (RG.GetCalc("LINE(7034)") == null)
            {
                RG.AddCalc("LINE(7034)", RG.MACRO(M.GROSS_PROFIT) % RG.MACRO(M.NET_SALES));
                RG.AddCalc("PRGrsPft", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRGrsPft").Add(RG.GetCalc("LINE(7034)")[PBaseId]);
                    RG.GetCalc("PRGrsPft").Add(RG.IND(34));
                    if (VarId != -1)
                        RG.GetCalc("PRGrsPft").Add(RG.GetCalc("LINE(7034)")[PBaseId] - RG.IND(34));
                }
                else
                {
                    RG.GetCalc("PRGrsPft").Add(RG.GetCalc("LINE(7034)")[PBaseId]);
                    RG.GetCalc("PRGrsPft").Add(RG.IND(29));
                    if (VarId != -1)
                        RG.GetCalc("PRGrsPft").Add(RG.GetCalc("LINE(7034)")[PBaseId] - RG.IND(29));
                }
            }
            ///Net Sales
            if (RG.GetCalc("LINE(110)") == null)
                RG.AddCalc("LINE(110)", RG.MACRO(M.NET_SALES));
            if (RG.GetCalc("LINE(115)") == null)
                RG.AddCalc("LINE(115)", RG.MACRO(M.TOT_COST_OF_SALES_REV));
            if (RG.GetCalc("LINE(120)") == null)
                RG.AddCalc("LINE(120)", RG.MACRO(M.GROSS_PROFIT));
            if (RG.GetCalc("LINE(130)") == null)
                RG.AddCalc("LINE(130)", RG.MACRO(M.NET_OPERATING_PROFIT));
            if (RG.GetCalc("LINE(140)") == null)
                RG.AddCalc("LINE(140)", RG.MACRO(M.TOT_OTH_INC_EXP));
            if (RG.GetCalc("LINE(150)") == null)
                RG.AddCalc("LINE(150)", RG.GetCalc("LINE(130)") + RG.GetCalc("LINE(140)"));
            ///Operating Expense
            ///Log 1891 lh 2/26/07 exclude Operating Income from Operating Expense line item
            if (RG.GetCalc("LINE(7035)") == null)
            {
                RG.AddCalc("LINE(7035)", (RG.GetCalc("LINE(120)") - RG.GetCalc("LINE(130)") + RG.GetDetailCalcs("DTOperInc").GetTotals(RG)) % RG.GetCalc("LINE(110)"));
                RG.AddCalc("PROpExp", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PROpExp").Add(RG.GetCalc("LINE(7035)")[PBaseId]);
                    RG.GetCalc("PROpExp").Add(RG.IND(35));
                    if (VarId != -1)
                        RG.GetCalc("PROpExp").Add(RG.GetCalc("LINE(7035)")[PBaseId] - RG.IND(35));
                }
                else
                {
                    RG.GetCalc("PROpExp").Add(RG.GetCalc("LINE(7035)")[PBaseId]);
                    RG.GetCalc("PROpExp").Add(RG.IND(30));
                    if (VarId != -1)
                        RG.GetCalc("PROpExp").Add(RG.GetCalc("LINE(7035)")[PBaseId] - RG.IND(30));
                    //amit:05/17/06 log#1689 Changed 33 to 30 for above IND values to match MFA.
                }
            }
            ///Operating Profit
            if (RG.GetCalc("LINE(7036)") == null)
            {
                RG.AddCalc("LINE(7036)", RG.GetCalc("LINE(130)") % RG.GetCalc("LINE(110)"));
                RG.AddCalc("PROpPft", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PROpPft").Add(RG.GetCalc("LINE(7036)")[PBaseId]);
                    RG.GetCalc("PROpPft").Add(RG.IND(36));
                    if (VarId != -1)
                        RG.GetCalc("PROpPft").Add(RG.GetCalc("LINE(7036)")[PBaseId] - RG.IND(36));
                }
                else
                {
                    RG.GetCalc("PROpPft").Add(RG.GetCalc("LINE(7036)")[PBaseId]);
                    RG.GetCalc("PROpPft").Add(RG.IND(31));
                    if (VarId != -1)
                        RG.GetCalc("PROpPft").Add(RG.GetCalc("LINE(7036)")[PBaseId] - RG.IND(31));
                }
            }
            ///All Other Expenses (net)
            if (RG.GetCalc("LINE(7038)") == null)
            {
                RG.AddCalc("LINE(7038)", RG.GetCalc("LINE(140)") % RG.GetCalc("LINE(110)"));
                RG.AddCalc("PRAllOthExp", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRAllOthExp").Add(RG.GetCalc("LINE(7038)")[PBaseId]);
                    RG.GetCalc("PRAllOthExp").Add(RG.IND(37));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthExp").Add(RG.GetCalc("LINE(7038)")[PBaseId] - RG.IND(37));
                }
                else
                {
                    RG.GetCalc("PRAllOthExp").Add(RG.GetCalc("LINE(7038)")[PBaseId]);
                    RG.GetCalc("PRAllOthExp").Add(RG.IND(32));
                    if (VarId != -1)
                        RG.GetCalc("PRAllOthExp").Add(RG.GetCalc("LINE(7038)")[PBaseId] - RG.IND(32));
                }
            }
            ///Profit Before Taxes
            if (RG.GetCalc("LINE(7037)") == null)
            {
                RG.AddCalc("LINE(7037)", RG.GetCalc("LINE(150)") % RG.GetCalc("LINE(110)"));
                RG.AddCalc("PRPftB4Tx", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRPftB4Tx").Add(RG.GetCalc("LINE(7037)")[PBaseId]);
                    RG.GetCalc("PRPftB4Tx").Add(RG.IND(38));
                    if (VarId != -1)
                        RG.GetCalc("PRPftB4Tx").Add(RG.GetCalc("LINE(7037)")[PBaseId] - RG.IND(38));
                }
                else
                {
                    RG.GetCalc("PRPftB4Tx").Add(RG.GetCalc("LINE(7037)")[PBaseId]);
                    RG.GetCalc("PRPftB4Tx").Add(RG.IND(33));
                    if (VarId != -1)
                        RG.GetCalc("PRPftB4Tx").Add(RG.GetCalc("LINE(7037)")[PBaseId] - RG.IND(33));
                }
            }
            ///RATIO VALUES WILL START BEING CALCULATED HERE
            ///CURRENT RATIO
            if (RG.GetCalc("PRUppCR") == null)
            {
                RG.AddCalc("PRUppCR", new Calc());
                RG.AddCalc("PRMedCR", new Calc());
                RG.AddCalc("PRLowCR", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId]);
                    RG.GetCalc("PRUppCR").Add(RG.IND(40));
                    RG.GetCalc("PRMedCR").Add(0);
                    RG.GetCalc("PRMedCR").Add(RG.IND(41));
                    RG.GetCalc("PRLowCR").Add(0);
                    RG.GetCalc("PRLowCR").Add(RG.IND(42));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(40));
                        RG.GetCalc("PRMedCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(41));
                        RG.GetCalc("PRLowCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(42));
                    }
                }
                else
                {
                    RG.GetCalc("PRUppCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId]);
                    RG.GetCalc("PRUppCR").Add(RG.IND(34));
                    RG.GetCalc("PRMedCR").Add(0);
                    RG.GetCalc("PRMedCR").Add(RG.IND(35));
                    RG.GetCalc("PRLowCR").Add(0);
                    RG.GetCalc("PRLowCR").Add(RG.IND(36));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(34));
                        RG.GetCalc("PRMedCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(35));
                        RG.GetCalc("PRLowCR").Add(RG.MACRO(M.CURRENT_RATIO)[PBaseId] - RG.IND(36));
                    }
                }
            }
            ///QUICK RATIO
            if (RG.GetCalc("PRUppQR") == null)
            {
                RG.AddCalc("PRUppQR", new Calc());
                RG.AddCalc("PRMedQR", new Calc());
                RG.AddCalc("PRLowQR", new Calc());

                RG.GetCalc("PRUppQR").Add(RG.MACRO(M.QUICK_RATIO)[PBaseId]);
                RG.GetCalc("PRUppQR").Add(RG.IND(37));
                RG.GetCalc("PRMedQR").Add(0);
                RG.GetCalc("PRMedQR").Add(RG.IND(38));
                RG.GetCalc("PRLowQR").Add(0);
                RG.GetCalc("PRLowQR").Add(RG.IND(39));
                if (VarId != -1)
                {
                    RG.GetCalc("PRUppQR").Add(RG.MACRO(M.QUICK_RATIO)[PBaseId] - RG.IND(37));
                    RG.GetCalc("PRMedQR").Add(RG.MACRO(M.QUICK_RATIO)[PBaseId] - RG.IND(38));
                    RG.GetCalc("PRLowQR").Add(RG.MACRO(M.QUICK_RATIO)[PBaseId] - RG.IND(39));
                }
            }
            ///RECEIVABLES/PAYABLES
            if (RG.GetCalc("PRUppRecPay") == null)
            {
                RG.AddCalc("LINE(8213)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(7025)").Count; i++)
                {
                    if (RG.GetCalc("LINE(7025)")[i] >= 0)
                        RG.GetCalc("LINE(8213)").Add(RG.GetCalc("LINE(7015)")[i] / RG.GetCalc("LINE(7025)")[i]);
                    else
                        RG.GetCalc("LINE(8213)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppRecPay", new Calc());
                RG.AddCalc("PRMedRecPay", new Calc());
                RG.AddCalc("PRLowRecPay", new Calc());

                RG.GetCalc("PRUppRecPay").Add(RG.GetCalc("LINE(8213)")[PBaseId]);
                RG.GetCalc("PRUppRecPay").Add(RG.IND(43));
                RG.GetCalc("PRMedRecPay").Add(0);
                RG.GetCalc("PRMedRecPay").Add(RG.IND(44));
                RG.GetCalc("PRLowRecPay").Add(0);
                RG.GetCalc("PRLowRecPay").Add(RG.IND(45));
                if (VarId != -1)
                {
                    if (RG.IND(43) != 0)
                        RG.GetCalc("PRUppRecPay").Add(RG.GetCalc("LINE(8213)")[PBaseId] - RG.IND(43));
                    else
                        RG.GetCalc("PRUppRecPay").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    if (RG.IND(44) != 0)
                        RG.GetCalc("PRMedRecPay").Add(RG.GetCalc("LINE(8213)")[PBaseId] - RG.IND(44));
                    else
                        RG.GetCalc("PRMedRecPay").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    if (RG.IND(45) != 0)
                        RG.GetCalc("PRLowRecPay").Add(RG.GetCalc("LINE(8213)")[PBaseId] - RG.IND(45));
                    else
                        RG.GetCalc("PRLowRecPay").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                }
            }
            ///AR DAYS TURNOVER
            if (RG.GetCalc("PRUppARDaysTO") == null)
            {
                RG.AddCalc("LINE(8071)", RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS));
                RG.AddCalc("PRUppARDaysTO", new Calc());
                RG.AddCalc("PRMedARDaysTO", new Calc());
                RG.AddCalc("PRLowARDaysTO", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId]);
                    RG.GetCalc("PRUppARDaysTO").Add(RG.IND(79));
                    RG.GetCalc("PRMedARDaysTO").Add(0);
                    RG.GetCalc("PRMedARDaysTO").Add(RG.IND(80));
                    RG.GetCalc("PRLowARDaysTO").Add(0);
                    RG.GetCalc("PRLowARDaysTO").Add(RG.IND(81));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(79));
                        RG.GetCalc("PRMedARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(80));
                        RG.GetCalc("PRLowARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(81));
                    }
                }
                else
                {
                    RG.GetCalc("PRUppARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId]);
                    RG.GetCalc("PRUppARDaysTO").Add(RG.IND(82));
                    RG.GetCalc("PRMedARDaysTO").Add(0);
                    RG.GetCalc("PRMedARDaysTO").Add(RG.IND(83));
                    RG.GetCalc("PRLowARDaysTO").Add(0);
                    RG.GetCalc("PRLowARDaysTO").Add(RG.IND(84));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(82));
                        RG.GetCalc("PRMedARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(83));
                        RG.GetCalc("PRLowARDaysTO").Add(RG.GetCalc("LINE(8071)")[PBaseId] - RG.IND(84));
                    }
                }
            }
            ///INVENTORY DAYS
            if (RG.GetCalc("PRUppInvDays") == null)
            {
                RG.AddCalc("PRUppInvDays", new Calc());
                RG.AddCalc("PRMedInvDays", new Calc());
                RG.AddCalc("PRLowInvDays", new Calc());

                RG.GetCalc("PRUppInvDays").Add(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId]);
                RG.GetCalc("PRUppInvDays").Add(RG.IND(85));
                RG.GetCalc("PRMedInvDays").Add(0);
                RG.GetCalc("PRMedInvDays").Add(RG.IND(86));
                RG.GetCalc("PRLowInvDays").Add(0);
                RG.GetCalc("PRLowInvDays").Add(RG.IND(87));
                if (VarId != -1)
                {
                    RG.GetCalc("PRUppInvDays").Add(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId] - RG.IND(85));
                    RG.GetCalc("PRMedInvDays").Add(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId] - RG.IND(86));
                    RG.GetCalc("PRLowInvDays").Add(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId] - RG.IND(87));
                }
            }
            ///AP DAYS TURNOVER
            if (RG.GetCalc("PRUppAPDaysTO") == null)
            {
                RG.AddCalc("LINE(8091)", RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS));
                RG.AddCalc("PRUppAPDaysTO", new Calc());
                RG.AddCalc("PRMedAPDaysTO", new Calc());
                RG.AddCalc("PRLowAPDaysTO", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId]);
                    RG.GetCalc("PRUppAPDaysTO").Add(RG.IND(82));
                    RG.GetCalc("PRMedAPDaysTO").Add(0);
                    RG.GetCalc("PRMedAPDaysTO").Add(RG.IND(83));
                    RG.GetCalc("PRLowAPDaysTO").Add(0);
                    RG.GetCalc("PRLowAPDaysTO").Add(RG.IND(84));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(82));
                        RG.GetCalc("PRMedAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(83));
                        RG.GetCalc("PRLowAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(84));
                    }
                }
                else
                {
                    RG.GetCalc("PRUppAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId]);
                    RG.GetCalc("PRUppAPDaysTO").Add(RG.IND(88));
                    RG.GetCalc("PRMedAPDaysTO").Add(0);
                    RG.GetCalc("PRMedAPDaysTO").Add(RG.IND(89));
                    RG.GetCalc("PRLowAPDaysTO").Add(0);
                    RG.GetCalc("PRLowAPDaysTO").Add(RG.IND(90));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(88));
                        RG.GetCalc("PRMedAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(89));
                        RG.GetCalc("PRLowAPDaysTO").Add(RG.GetCalc("LINE(8091)")[PBaseId] - RG.IND(90));
                    }
                }
            }
            ///SALES/WORKING CAPITAL
            if (RG.GetCalc("PRUppSlsWrkCap") == null)
            {
                RG.AddCalc("LINE(8173)", new Calc());
                for (int i = 0; i < RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL).Count; i++)
                {
                    if (RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL)[i] >= 0)
                        RG.GetCalc("LINE(8173)").Add(RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL)[i]);
                    else
                        RG.GetCalc("LINE(8173)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppSlsWrkCap", new Calc());
                RG.AddCalc("PRMedSlsWrkCap", new Calc());
                RG.AddCalc("PRLowSlsWrkCap", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppSlsWrkCap").Add(RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL)[PBaseId]);
                    RG.GetCalc("PRUppSlsWrkCap").Add(RG.IND(52));
                    RG.GetCalc("PRMedSlsWrkCap").Add(0);
                    RG.GetCalc("PRMedSlsWrkCap").Add(RG.IND(53));
                    RG.GetCalc("PRLowSlsWrkCap").Add(0);
                    RG.GetCalc("PRLowSlsWrkCap").Add(RG.IND(54));
                    //amit: 09/15/05 Changes from != to >=
                    if (VarId != -1)
                    {
                        if (RG.IND(52) >= 0)
                            RG.GetCalc("PRUppSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(52));
                        else
                            RG.GetCalc("PRUppSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(53) >= 0)
                            RG.GetCalc("PRMedSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(53));
                        else
                            RG.GetCalc("PRMedSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(54) >= 0)
                            RG.GetCalc("PRLowSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(54));
                        else
                            RG.GetCalc("PRLowSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppSlsWrkCap").Add(RG.MACRO(M.NET_SALES_TO_WORKING_CAPITAL)[PBaseId]);
                    RG.GetCalc("PRUppSlsWrkCap").Add(RG.IND(49));
                    RG.GetCalc("PRMedSlsWrkCap").Add(0);
                    RG.GetCalc("PRMedSlsWrkCap").Add(RG.IND(50));
                    RG.GetCalc("PRLowSlsWrkCap").Add(0);
                    RG.GetCalc("PRLowSlsWrkCap").Add(RG.IND(51));
                    //amit: 09/15/05 Changes from != to >=
                    if (VarId != -1)
                    {
                        if (RG.IND(49) >= 0)
                            RG.GetCalc("PRUppSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(49));
                        else
                            RG.GetCalc("PRUppSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(50) >= 0)
                            RG.GetCalc("PRMedSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(50));
                        else
                            RG.GetCalc("PRMedSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(51) >= 0)
                            RG.GetCalc("PRLowSlsWrkCap").Add(RG.GetCalc("LINE(8173)")[PBaseId] - RG.IND(51));
                        else
                            RG.GetCalc("PRLowSlsWrkCap").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///INTEREST COVERAGE
            if (RG.GetCalc("PRUppIntCov") == null)
            {
                RG.AddCalc("LINE(8101)", new Calc());
                for (int i = 0; i < RG.MACRO(M.INTEREST_COVERAGE).Count; i++)
                {
                    if (RG.MACRO(M.INTEREST_COVERAGE)[i] >= 0)
                        RG.GetCalc("LINE(8101)").Add(RG.MACRO(M.INTEREST_COVERAGE)[i]);
                    else
                        RG.GetCalc("LINE(8101)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppIntCov", new Calc());
                RG.AddCalc("PRMedIntCov", new Calc());
                RG.AddCalc("PRLowIntCov", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppIntCov").Add(RG.MACRO(M.INTEREST_COVERAGE)[PBaseId]);
                    RG.GetCalc("PRUppIntCov").Add(RG.IND(55));
                    RG.GetCalc("PRMedIntCov").Add(0);
                    RG.GetCalc("PRMedIntCov").Add(RG.IND(56));
                    RG.GetCalc("PRLowIntCov").Add(0);
                    RG.GetCalc("PRLowIntCov").Add(RG.IND(57));
                    //amit: 09/15/05 Changes from != to >=
                    if (VarId != -1)
                    {
                        if (RG.IND(55) >= 0)
                            RG.GetCalc("PRUppIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(55));
                        else
                            RG.GetCalc("PRUppIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(56) >= 0)
                            RG.GetCalc("PRMedIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(56));
                        else
                            RG.GetCalc("PRMedIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(57) >= 0)
                            RG.GetCalc("PRLowIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(57));
                        else
                            RG.GetCalc("PRLowIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppIntCov").Add(RG.MACRO(M.INTEREST_COVERAGE)[PBaseId]);
                    RG.GetCalc("PRUppIntCov").Add(RG.IND(52));
                    RG.GetCalc("PRMedIntCov").Add(0);
                    RG.GetCalc("PRMedIntCov").Add(RG.IND(53));
                    RG.GetCalc("PRLowIntCov").Add(0);
                    RG.GetCalc("PRLowIntCov").Add(RG.IND(54));
                    //amit: 09/15/05 Changes from != to >=
                    if (VarId != -1)
                    {
                        if (RG.IND(52) >= 0)
                            RG.GetCalc("PRUppIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(52));
                        else
                            RG.GetCalc("PRUppIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(53) >= 0)
                            RG.GetCalc("PRMedIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(53));
                        else
                            RG.GetCalc("PRMedIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(54) >= 0)
                            RG.GetCalc("PRLowIntCov").Add(RG.GetCalc("LINE(8101)")[PBaseId] - RG.IND(54));
                        else
                            RG.GetCalc("PRLowIntCov").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Net Income+Depr+Amort-Divs/CPLTD'
            if (RG.GetCalc("PRUppNIDpAmDvCPLTD") == null)
            {
                RG.AddCalc("LINE(8111)", new Calc());
                for (int i = 0; i < RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD).Count; i++)
                {
                    if (RG.MACRO(M.FUNDS_FLOW_COVERAGE)[i] >= 0)
                        RG.GetCalc("LINE(8111)").Add(RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[i]);
                    else
                        RG.GetCalc("LINE(8111)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppNIDpAmDvCPLTD", new Calc());
                RG.AddCalc("PRMedNIDpAmDvCPLTD", new Calc());
                RG.AddCalc("PRLowNIDpAmDvCPLTD", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[PBaseId]);
                    RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.IND(58));
                    RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(0);
                    RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.IND(59));
                    RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(0);
                    RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.IND(60));
                    if (VarId != -1)
                    {
                        if (RG.IND(58) >= 0)
                            RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(58));
                        else
                            RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(59) >= 0)
                            RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(59));
                        else
                            RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(60) >= 0)
                            RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(60));
                        else
                            RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[PBaseId]);
                    RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.IND(55));
                    RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(0);
                    RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.IND(56));
                    RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(0);
                    RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.IND(57));
                    if (VarId != -1)
                    {
                        if (RG.IND(55) >= 0)
                            RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(55));
                        else
                            RG.GetCalc("PRUppNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(56) >= 0)
                            RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(56));
                        else
                            RG.GetCalc("PRMedNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(57) >= 0)
                            RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.GetCalc("LINE(8111)")[PBaseId] - RG.IND(57));
                        else
                            RG.GetCalc("PRLowNIDpAmDvCPLTD").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Net Fixed Asset/TNW
            if (RG.GetCalc("PRUppNFATNW") == null)
            {
                RG.AddCalc("LINE(8181)", RG.MACRO(M.NET_FIXED_ASSETS) / RG.MACRO(M.TANGIBLE_NET_WORTH));
                RG.AddCalc("LINE(8183)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(8181)").Count; i++)
                {
                    if (RG.GetCalc("LINE(8181)")[i] >= 0)
                        RG.GetCalc("LINE(8183)").Add(RG.GetCalc("LINE(8181)")[i]);
                    else
                        RG.GetCalc("LINE(8183)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppNFATNW", new Calc());
                RG.AddCalc("PRMedNFATNW", new Calc());
                RG.AddCalc("PRLowNFATNW", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppNFATNW").Add(RG.GetCalc("LINE(8181)")[PBaseId]);
                    RG.GetCalc("PRUppNFATNW").Add(RG.IND(61));
                    RG.GetCalc("PRMedNFATNW").Add(0);
                    RG.GetCalc("PRMedNFATNW").Add(RG.IND(62));
                    RG.GetCalc("PRLowNFATNW").Add(0);
                    RG.GetCalc("PRLowNFATNW").Add(RG.IND(63));
                    if (VarId != -1)
                    {
                        if (RG.IND(61) >= 0)
                            RG.GetCalc("PRUppNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(61));
                        else
                            RG.GetCalc("PRUppNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(62) >= 0)
                            RG.GetCalc("PRMedNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(62));
                        else
                            RG.GetCalc("PRMedNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(63) >= 0)
                            RG.GetCalc("PRLowNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(63));
                        else
                            RG.GetCalc("PRLowNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppNFATNW").Add(RG.GetCalc("LINE(8181)")[PBaseId]);
                    RG.GetCalc("PRUppNFATNW").Add(RG.IND(58));
                    RG.GetCalc("PRMedNFATNW").Add(0);
                    RG.GetCalc("PRMedNFATNW").Add(RG.IND(59));
                    RG.GetCalc("PRLowNFATNW").Add(0);
                    RG.GetCalc("PRLowNFATNW").Add(RG.IND(60));
                    if (VarId != -1)
                    {
                        if (RG.IND(58) >= 0)
                            RG.GetCalc("PRUppNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(58));
                        else
                            RG.GetCalc("PRUppNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(59) >= 0)
                            RG.GetCalc("PRMedNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(59));
                        else
                            RG.GetCalc("PRMedNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(60) >= 0)
                            RG.GetCalc("PRLowNFATNW").Add(RG.GetCalc("LINE(8183)")[PBaseId] - RG.IND(60));
                        else
                            RG.GetCalc("PRLowNFATNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Debt/Tang Net Worth
            if (RG.GetCalc("PRUppDbtTNW") == null)
            {
                RG.AddCalc("LINE(8121)", new Calc());
                for (int i = 0; i < RG.MACRO(M.DEBT_TO_TANG_WORTH).Count; i++)
                {
                    if (RG.MACRO(M.DEBT_TO_TANG_WORTH)[i] >= 0)
                        RG.GetCalc("LINE(8121)").Add(RG.MACRO(M.DEBT_TO_TANG_WORTH)[i]);
                    else
                        RG.GetCalc("LINE(8121)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppDbtTNW", new Calc());
                RG.AddCalc("PRMedDbtTNW", new Calc());
                RG.AddCalc("PRLowDbtTNW", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppDbtTNW").Add(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId]);
                    RG.GetCalc("PRUppDbtTNW").Add(RG.IND(64));
                    RG.GetCalc("PRMedDbtTNW").Add(0);
                    RG.GetCalc("PRMedDbtTNW").Add(RG.IND(65));
                    RG.GetCalc("PRLowDbtTNW").Add(0);
                    RG.GetCalc("PRLowDbtTNW").Add(RG.IND(66));
                    if (VarId != -1)
                    {
                        if (RG.IND(64) != 0)
                            RG.GetCalc("PRUppDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(64));
                        else
                            RG.GetCalc("PRUppDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(65) != 0)
                            RG.GetCalc("PRMedDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(65));
                        else
                            RG.GetCalc("PRMedDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(66) != 0)
                            RG.GetCalc("PRLowDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(66));
                        else
                            RG.GetCalc("PRLowDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppDbtTNW").Add(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId]);
                    RG.GetCalc("PRUppDbtTNW").Add(RG.IND(61));
                    RG.GetCalc("PRMedDbtTNW").Add(0);
                    RG.GetCalc("PRMedDbtTNW").Add(RG.IND(62));
                    RG.GetCalc("PRLowDbtTNW").Add(0);
                    RG.GetCalc("PRLowDbtTNW").Add(RG.IND(63));
                    if (VarId != -1)
                    {
                        if (RG.IND(61) != 0)
                            RG.GetCalc("PRUppDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(61));
                        else
                            RG.GetCalc("PRUppDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(62) != 0)
                            RG.GetCalc("PRMedDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(62));
                        else
                            RG.GetCalc("PRMedDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(63) != 0)
                            RG.GetCalc("PRLowDbtTNW").Add(RG.GetCalc("LINE(8121)")[PBaseId] - RG.IND(63));
                        else
                            RG.GetCalc("PRLowDbtTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Profit B4 Taxes/Tang Net Worth
            if (RG.GetCalc("PRUppPftB4TxTNW") == null)
            {
                RG.AddCalc("LINE(982)", (RG.MACRO(M.PROFIT_BEFORE_TAX) / RG.YEAR()) / RG.MACRO(M.TANGIBLE_NET_WORTH) * 100);
                RG.AddCalc("LINE(8131)", new Calc());
                for (int i = 0; i < RG.GetCalc("LINE(982)").Count; i++)
                {
                    if (RG.GetCalc("LINE(982)")[i] >= 0)
                        RG.GetCalc("LINE(8131)").Add(RG.GetCalc("LINE(982)")[i]);
                    else
                        RG.GetCalc("LINE(8131)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppPftB4TxTNW", new Calc());
                RG.AddCalc("PRMedPftB4TxTNW", new Calc());
                RG.AddCalc("PRLowPftB4TxTNW", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppPftB4TxTNW").Add(RG.GetCalc("LINE(982)")[PBaseId]);
                    RG.GetCalc("PRUppPftB4TxTNW").Add(RG.IND(67));
                    RG.GetCalc("PRMedPftB4TxTNW").Add(0);
                    RG.GetCalc("PRMedPftB4TxTNW").Add(RG.IND(68));
                    RG.GetCalc("PRLowPftB4TxTNW").Add(0);
                    RG.GetCalc("PRLowPftB4TxTNW").Add(RG.IND(69));
                    if (VarId != -1)
                    {
                        if (RG.IND(67) >= 0)
                            RG.GetCalc("PRUppPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(67));
                        else
                            RG.GetCalc("PRUppPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(68) >= 0)
                            RG.GetCalc("PRMedPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(68));
                        else
                            RG.GetCalc("PRMedPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(69) >= 0)
                            RG.GetCalc("PRLowPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(69));
                        else
                            RG.GetCalc("PRLowPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppPftB4TxTNW").Add(RG.GetCalc("LINE(982)")[PBaseId]);
                    RG.GetCalc("PRUppPftB4TxTNW").Add(RG.IND(64));
                    RG.GetCalc("PRMedPftB4TxTNW").Add(0);
                    RG.GetCalc("PRMedPftB4TxTNW").Add(RG.IND(65));
                    RG.GetCalc("PRLowPftB4TxTNW").Add(0);
                    RG.GetCalc("PRLowPftB4TxTNW").Add(RG.IND(66));
                    if (VarId != -1)
                    {
                        if (RG.IND(64) >= 0)
                            RG.GetCalc("PRUppPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(64));
                        else
                            RG.GetCalc("PRUppPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(65) >= 0)
                            RG.GetCalc("PRMedPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(65));
                        else
                            RG.GetCalc("PRMedPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(66) >= 0)
                            RG.GetCalc("PRLowPftB4TxTNW").Add(RG.GetCalc("LINE(8131)")[PBaseId] - RG.IND(66));
                        else
                            RG.GetCalc("PRLowPftB4TxTNW").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Profit B4 Taxes/Total Assets
            if (RG.GetCalc("PRUppPftB4TxTA") == null)
            {
                RG.AddCalc("LINE(982)", (RG.MACRO(M.PROFIT_BEFORE_TAX) / RG.YEAR()) / RG.MACRO(M.TANGIBLE_NET_WORTH) * 100);
                RG.AddCalc("LINE(8141)", new Calc());
                for (int i = 0; i < RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS).Count; i++)
                {
                    if (RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS)[i] >= 0)
                        RG.GetCalc("LINE(8141)").Add(RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS)[i]);
                    else
                        RG.GetCalc("LINE(8141)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppPftB4TxTA", new Calc());
                RG.AddCalc("PRMedPftB4TxTA", new Calc());
                RG.AddCalc("PRLowPftB4TxTA", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppPftB4TxTA").Add(RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS)[PBaseId]);
                    RG.GetCalc("PRUppPftB4TxTA").Add(RG.IND(70));
                    RG.GetCalc("PRMedPftB4TxTA").Add(0);
                    RG.GetCalc("PRMedPftB4TxTA").Add(RG.IND(71));
                    RG.GetCalc("PRLowPftB4TxTA").Add(0);
                    RG.GetCalc("PRLowPftB4TxTA").Add(RG.IND(72));
                    if (VarId != -1)
                    {
                        if (RG.IND(70) >= 0)
                            RG.GetCalc("PRUppPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(70));
                        else
                            RG.GetCalc("PRUppPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(71) >= 0)
                            RG.GetCalc("PRMedPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(71));
                        else
                            RG.GetCalc("PRMedPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(72) >= 0)
                            RG.GetCalc("PRLowPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(72));
                        else
                            RG.GetCalc("PRLowPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
                else
                {
                    RG.GetCalc("PRUppPftB4TxTA").Add(RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS)[PBaseId]);
                    RG.GetCalc("PRUppPftB4TxTA").Add(RG.IND(67));
                    RG.GetCalc("PRMedPftB4TxTA").Add(0);
                    RG.GetCalc("PRMedPftB4TxTA").Add(RG.IND(68));
                    RG.GetCalc("PRLowPftB4TxTA").Add(0);
                    RG.GetCalc("PRLowPftB4TxTA").Add(RG.IND(69));
                    if (VarId != -1)
                    {
                        if (RG.IND(67) >= 0)
                            RG.GetCalc("PRUppPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(67));
                        else
                            RG.GetCalc("PRUppPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(68) >= 0)
                            RG.GetCalc("PRMedPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(68));
                        else
                            RG.GetCalc("PRMedPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                        if (RG.IND(69) >= 0)
                            RG.GetCalc("PRLowPftB4TxTA").Add(RG.GetCalc("LINE(8141)")[PBaseId] - RG.IND(69));
                        else
                            RG.GetCalc("PRLowPftB4TxTA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    }
                }
            }
            ///Sales/Net Fixed Assets
            if (RG.GetCalc("PRUppSlsNFA") == null)
            {
                RG.AddCalc("PRUppSlsNFA", new Calc());
                RG.AddCalc("PRMedSlsNFA", new Calc());
                RG.AddCalc("PRLowSlsNFA", new Calc());

                RG.GetCalc("PRUppSlsNFA").Add(RG.MACRO(M.NET_SALES_TO_NET_FIXED_ASSETS)[PBaseId]);
                RG.GetCalc("PRUppSlsNFA").Add(RG.IND(70));
                RG.GetCalc("PRMedSlsNFA").Add(0);
                RG.GetCalc("PRMedSlsNFA").Add(RG.IND(71));
                RG.GetCalc("PRLowSlsNFA").Add(0);
                RG.GetCalc("PRLowSlsNFA").Add(RG.IND(72));
                if (VarId != -1)
                {
                    RG.GetCalc("PRUppSlsNFA").Add(RG.MACRO(M.NET_SALES_TO_NET_FIXED_ASSETS)[PBaseId] - RG.IND(70));
                    RG.GetCalc("PRMedSlsNFA").Add(RG.MACRO(M.NET_SALES_TO_NET_FIXED_ASSETS)[PBaseId] - RG.IND(71));
                    RG.GetCalc("PRLowSlsNFA").Add(RG.MACRO(M.NET_SALES_TO_NET_FIXED_ASSETS)[PBaseId] - RG.IND(72));
                }
            }
            ///Sales/Total Assets
            if (RG.GetCalc("PRUppSlsTA") == null)
            {
                RG.AddCalc("PRUppSlsTA", new Calc());
                RG.AddCalc("PRMedSlsTA", new Calc());
                RG.AddCalc("PRLowSlsTA", new Calc());

                RG.GetCalc("PRUppSlsTA").Add(RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS)[PBaseId]);
                RG.GetCalc("PRUppSlsTA").Add(RG.IND(73));
                RG.GetCalc("PRMedSlsTA").Add(0);
                RG.GetCalc("PRMedSlsTA").Add(RG.IND(74));
                RG.GetCalc("PRLowSlsTA").Add(0);
                RG.GetCalc("PRLowSlsTA").Add(RG.IND(75));
                if (VarId != -1)
                {
                    RG.GetCalc("PRUppSlsTA").Add(RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS)[PBaseId] - RG.IND(73));
                    RG.GetCalc("PRMedSlsTA").Add(RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS)[PBaseId] - RG.IND(74));
                    RG.GetCalc("PRLowSlsTA").Add(RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS)[PBaseId] - RG.IND(75));
                }
            }
            ///Depr & Amort/Sales (%)
            if (RG.GetCalc("PRUppDepAmtSls") == null)
            {
                RG.AddCalc("LINE(8191)", RG.MACRO(M.DEPR_AMRT_PEER_CIV) / RG.MACRO(M.NET_SALES) * 100);
                RG.AddCalc("PRUppDepAmtSls", new Calc());
                RG.AddCalc("PRMedDepAmtSls", new Calc());
                RG.AddCalc("PRLowDepAmtSls", new Calc());

                RG.GetCalc("PRUppDepAmtSls").Add(RG.GetCalc("LINE(8191)")[PBaseId]);
                RG.GetCalc("PRUppDepAmtSls").Add(RG.IND(76));
                RG.GetCalc("PRMedDepAmtSls").Add(0);
                RG.GetCalc("PRMedDepAmtSls").Add(RG.IND(77));
                RG.GetCalc("PRLowDepAmtSls").Add(0);
                RG.GetCalc("PRLowDepAmtSls").Add(RG.IND(78));
                if (VarId != -1)
                {
                    RG.GetCalc("PRUppDepAmtSls").Add(RG.GetCalc("LINE(8191)")[PBaseId] - RG.IND(76));
                    RG.GetCalc("PRMedDepAmtSls").Add(RG.GetCalc("LINE(8191)")[PBaseId] - RG.IND(77));
                    RG.GetCalc("PRLowDepAmtSls").Add(RG.GetCalc("LINE(8191)")[PBaseId] - RG.IND(78));
                }
            }
            ///Officer Comp/Sales (%)
            if (RG.GetCalc("PRUppOffCompSls") == null)
            {
                RG.AddCalc("LINE(8201)", RG.TYPE(158) * RG.CONV_RATE() / RG.MACRO(M.NET_SALES) * 100);
                RG.AddCalc("PRUppOffCompSls", new Calc());
                RG.AddCalc("PRMedOffCompSls", new Calc());
                RG.AddCalc("PRLowOffCompSls", new Calc());
                if (RG.IND(33) == 100)
                {
                    RG.GetCalc("PRUppOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId]);
                    RG.GetCalc("PRUppOffCompSls").Add(RG.IND(76));
                    RG.GetCalc("PRMedOffCompSls").Add(0);
                    RG.GetCalc("PRMedOffCompSls").Add(RG.IND(77));
                    RG.GetCalc("PRLowOffCompSls").Add(0);
                    RG.GetCalc("PRLowOffCompSls").Add(RG.IND(78));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(76));
                        RG.GetCalc("PRMedOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(77));
                        RG.GetCalc("PRLowOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(78));
                    }
                }
                else
                {
                    RG.GetCalc("PRUppOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId]);
                    RG.GetCalc("PRUppOffCompSls").Add(RG.IND(79));
                    RG.GetCalc("PRMedOffCompSls").Add(0);
                    RG.GetCalc("PRMedOffCompSls").Add(RG.IND(80));
                    RG.GetCalc("PRLowOffCompSls").Add(0);
                    RG.GetCalc("PRLowOffCompSls").Add(RG.IND(81));
                    if (VarId != -1)
                    {
                        RG.GetCalc("PRUppOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(79));
                        RG.GetCalc("PRMedOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(80));
                        RG.GetCalc("PRLowOffCompSls").Add(RG.GetCalc("LINE(8201)")[PBaseId] - RG.IND(81));
                    }
                }
            }
            ///Debt/EBITDA
            if (RG.GetCalc("PRUppDbtEBITDA") == null)
            {
                RG.AddCalc("LINE(8301)", new Calc());
                for (int i = 0; i < RG.MACRO(M.BORROWED_FUNDS_TO_EBITDA).Count; i++)
                {
                    if (RG.MACRO(M.BORROWED_FUNDS_TO_EBITDA)[i] >= 0)
                        RG.GetCalc("LINE(8301)").Add(RG.MACRO(M.BORROWED_FUNDS_TO_EBITDA)[i]);
                    else
                        RG.GetCalc("LINE(8301)").Add(RG.MACRO(M.ERR_STRING)[i]);
                }
                RG.AddCalc("PRUppDbtEBITDA", new Calc());
                RG.AddCalc("PRMedDbtEBITDA", new Calc());
                RG.AddCalc("PRLowDbtEBITDA", new Calc());

                RG.GetCalc("PRUppDbtEBITDA").Add(RG.MACRO(M.BORROWED_FUNDS_TO_EBITDA)[PBaseId]);
                RG.GetCalc("PRUppDbtEBITDA").Add(RG.IND(169));
                RG.GetCalc("PRMedDbtEBITDA").Add(0);
                RG.GetCalc("PRMedDbtEBITDA").Add(RG.IND(170));
                RG.GetCalc("PRLowDbtEBITDA").Add(0);
                RG.GetCalc("PRLowDbtEBITDA").Add(RG.IND(171));
                if (VarId != -1)
                {
                    if (RG.IND(169) != 0)
                        RG.GetCalc("PRUppDbtEBITDA").Add(RG.GetCalc("LINE(8301)")[PBaseId] - RG.IND(169));
                    else
                        RG.GetCalc("PRUppDbtEBITDA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    if (RG.IND(170) != 0)
                        RG.GetCalc("PRMedDbtEBITDA").Add(RG.GetCalc("LINE(8301)")[PBaseId] - RG.IND(170));
                    else
                        RG.GetCalc("PRMedDbtEBITDA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                    if (RG.IND(171) != 0)
                        RG.GetCalc("PRLowDbtEBITDA").Add(RG.GetCalc("LINE(8301)")[PBaseId] - RG.IND(171));
                    else
                        RG.GetCalc("PRLowDbtEBITDA").Add(RG.MACRO(M.ERR_STRING)[PBaseId]);
                }
            }
            ///RiskCalc 1 Yr KCZ Added 6-24-03 to make match MMAS Version V
            if (RG.GetCalc("PRUppRC1Yr") == null)
            {
                RG.AddCalc("PRUppRC1Yr", new Calc());
                RG.AddCalc("PRMedRC1Yr", new Calc());
                RG.AddCalc("PRLowRC1Yr", new Calc());

                RG.GetCalc("PRUppRC1Yr").Add(0);
                RG.GetCalc("PRUppRC1Yr").Add(RG.IND(114));
                RG.GetCalc("PRMedRC1Yr").Add(0);
                RG.GetCalc("PRMedRC1Yr").Add(RG.IND(115));
                RG.GetCalc("PRLowRC1Yr").Add(0);
                RG.GetCalc("PRLowRC1Yr").Add(RG.IND(116));
            }
            // end of 1 Year
            ///RiskCalc 5 Yr KCZ Added 6-24-03 to make match MMAS Version V
            if (RG.GetCalc("PRUppRC5Yr") == null)
            {
                RG.AddCalc("PRUppRC5Yr", new Calc());
                RG.AddCalc("PRMedRC5Yr", new Calc());
                RG.AddCalc("PRLowRC5Yr", new Calc());

                RG.GetCalc("PRUppRC5Yr").Add(0);
                RG.GetCalc("PRUppRC5Yr").Add(RG.IND(117));
                RG.GetCalc("PRMedRC5Yr").Add(0);
                RG.GetCalc("PRMedRC5Yr").Add(RG.IND(118));
                RG.GetCalc("PRLowRC5Yr").Add(0);
                RG.GetCalc("PRLowRC5Yr").Add(RG.IND(119));
            }
            // end of 5 Year

        }
        public void GlobalCashFlowCalcs(ReportGenerator RG)
        {
            DetReconCalcs(RG);
            UCACFCalcs(RG);
            FAS_CF_Dir_Calcs(RG);

            if (RG.GetCalc("MMAS_Sales") == null)
                RG.AddCalc("MMAS_Sales", RG.MACRO(M.NET_SALES));

            if (RG.GetCalc("MMAS_NetIncome") == null)
                RG.AddCalc("MMAS_NetIncome", RG.MACRO(M.NET_PROFIT));

            if (RG.GetCalc("MMAS_OpCashFlow") == null)
                RG.AddCalc("MMAS_OpCashFlow", RG.GetCalc("CashCollFromSales") - (RG.GetDetailCalcs("DTChgBillExcCst").GetTotals(RG) + RG.GetDetailCalcs("DTChgCstExcBill").GetTotals(RG)) +
                    RG.GetCalc("CashPdSuppEmp") + RG.GetCalc("InterestPaid") + RG.GetCalc("IncTaxPaid") + RG.GetCalc("IntDivRcvd") + RG.GetCalc("MiscCashRcvPd"));

            //End of calcs needed for MMAS_OpCashFlow

            if (RG.GetCalc("MMAS_WorkingCapital") == null)
                RG.AddCalc("MMAS_WorkingCapital", RG.MACRO(M.WORKING_CAPITAL));

            if (RG.GetCalc("MMAS_CurrentAssets") == null)
                RG.AddCalc("MMAS_CurrentAssets", RG.MACRO(M.TOTAL_CURRENT_ASSETS));

            if (RG.GetCalc("MMAS_TotalAssets") == null)
                RG.AddCalc("MMAS_TotalAssets", RG.MACRO(M.TOTAL_ASSETS));

            if (RG.GetCalc("MMAS_CurrentLiabs") == null)
                RG.AddCalc("MMAS_CurrentLiabs", RG.MACRO(M.TOTAL_CURRENT_LIABILITIES));

            if (RG.GetCalc("MMAS_TotalLiabs") == null)
                RG.AddCalc("MMAS_TotalLiabs", RG.MACRO(M.TOTAL_LIABILITIES));

            if (RG.GetCalc("MMAS_TotalNetWorth") == null)
                RG.AddCalc("MMAS_TotalNetWorth", RG.MACRO(M.NET_WORTH));

            if (RG.GetCalc("MMAS_ProjectedDebt") == null)
                RG.AddCalc("MMAS_ProjectedDebt", (RG.TYPE(T.CurPortionLTD) + RG.TYPE(T.LongTermebt) + RG.TYPE(T.CapitalLeaseOblig)) * RG.CONV_RATE());

            if (RG.GetCalc("MMAS_TotalSTDebt") == null)
                RG.AddCalc("MMAS_TotalSTDebt", (RG.TYPE(T.ShortTermPayables) + RG.TYPE(T.CurPortionLTD) + RG.TYPE(T.CPSubDebt)) * RG.CONV_RATE());

            if (RG.GetCalc("MMAS_TotalLTDebt") == null)
                RG.AddCalc("MMAS_TotalLTDebt", RG.TYPE(T.LongTermebt) * RG.CONV_RATE());

            //the following calcs are used for the combined Ratios
            if (RG.GetCalc("MMAS_EBITDA") == null)
                RG.AddCalc("MMAS_EBITDA", RG.MACRO(M.EBITDA));

            if (RG.GetCalc("MMAS_CPLTD") == null)
                RG.AddCalc("MMAS_CPLTD", RG.MACRO(M.CPLTD_FROM_BALANCE_SHEET));

            if (RG.GetCalc("MMAS_CPLTDpp") == null)
                RG.AddCalc("MMAS_CPLTDpp", RG.MACRO(M.CPLTD_FROM_BALANCE_SHEET, RG.LAG));

            if (RG.GetCalc("MMAS_InterestExpense") == null)
                RG.AddCalc("MMAS_InterestExpense", RG.MACRO(M.TOT_INT_EXP));

            if (RG.GetCalc("MMAS_NetCashAfterOps") == null)
                RG.AddCalc("MMAS_NetCashAfterOps", RG.MACRO(M.NET_CASH_AFTER_OPERATIONS));

            if (RG.GetCalc("MMAS_NetCashProvOps") == null)
                RG.AddCalc("MMAS_NetCashProvOps", RG.GetCalc("NetCashProvOp"));

            if (RG.GetCalc("MMAS_UCA_Denominator") == null)
                RG.AddCalc("MMAS_UCA_Denominator", (RG.GetCalc("MMAS_CPLTD") - (RG.AND(15, RG.ANDCLASS, 70, RG.ANDFLOW) * RG.CONV_RATE() - RG.AND(15, RG.ANDCLASS, 70, RG.ANDFLOW, RG.LAG) * (RG.CONV_RATE(RG.LAG)) - RG.AND(30, RG.ANDCLASS, 70, RG.ANDFLOW) / RG.YEAR() * RG.CONV_RATE() - RG.AND(30, RG.ANDCLASS, 130, RG.ANDFLOW) / RG.YEAR() * RG.CONV_RATE() - RG.AND(32, RG.ANDCLASS, 130, RG.ANDFLOW) / RG.YEAR() * RG.CONV_RATE() + RG.AND(15, RG.ANDCLASS, 130, RG.ANDFLOW) * RG.CONV_RATE() - RG.AND(15, RG.ANDCLASS, 130, RG.ANDFLOW, RG.LAG) * (RG.CONV_RATE(RG.LAG)))));

            if (RG.GetCalc("MMAS_NetFixedAssets") == null)
                RG.AddCalc("MMAS_NetFixedAssets", RG.MACRO(M.NET_FIXED_ASSETS));

            if (RG.GetCalc("MMAS_IntCov_Numerator") == null)
                RG.AddCalc("MMAS_IntCov_Numerator", RG.MACRO(M.EBIT));

            if (RG.GetCalc("MMAS_IntCov_Denominator") == null)
                RG.AddCalc("MMAS_IntCov_Denominator", (RG.TYPE(T.InterestExpense) - RG.TYPE(T.CapitalizedInterest)) * RG.CONV_RATE());

        }
        public void InputCashFlowCalcs(ReportGenerator RG)
        {
            Calc convRate = new Calc(1, RG.Statements.Count);
			string Flabel = "F_{0}";
            string label = string.Empty;

			foreach (FinancialAnalyst.Class c in RG.Customer.Model.Classes)
			{
				foreach (int d in c.Flows)
				{
					label = string.Format(Flabel, d);
					if (RG.GetDetailCalcs(label) == null)
						RG.AddCalc(label, RG.DETAILFLOW(d) * RG.CONV_RATE());
				}
            }

            if (RG.GetCalc("begOfPerCashEquiv") == null)
                RG.AddCalc("begOfPerCashEquiv", RG.MACRO(M.ICF_BEG_OF_PERIOD_CASH));

            if (RG.GetCalc("endOfPerCashEquiv") == null)
                RG.AddCalc("endOfPerCashEquiv", RG.MACRO(M.ICF_END_OF_PERIOD_CASH));

            if (RG.GetCalc("cfFrmInvestAct") == null)
                RG.AddCalc("cfFrmInvestAct", RG.MACRO(M.NET_CASH_USED_IN_INVESTING_ACTIV));

            if (RG.GetCalc("cfFrmFinAct") == null)
                RG.AddCalc("cfFrmFinAct", RG.MACRO(M.NET_CASH_USED_IN_FINANCING_ACTIV));
        }

        public void InputCFDIR_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("cfFrmOprAct") == null)
                RG.AddCalc("cfFrmOprAct", RG.MACRO(M.NET_CASH_FRM_OPER_ACTIV_DIRECT));

            if (RG.GetCalc("cfChgInCashEquiv") == null)
                RG.AddCalc("cfChgInCashEquiv", RG.MACRO(M.ICF_TOTAL_MOVEMENTS_IN_CASH_DIRECT));

            if (RG.GetCalc("unExplAdjToCash") == null)
                RG.AddCalc("unExplAdjToCash", RG.MACRO(M.UNEXPLAINED_ADJ_TO_CASH_DIRECT));
          
        }

        public void InputCFIND_Calcs(ReportGenerator RG)
        {
            if (RG.GetCalc("cfFrmOprActInd") == null)
                RG.AddCalc("cfFrmOprActInd", RG.MACRO(M.NET_CASH_FRM_OPER_ACTIV_IND));

            if (RG.GetCalc("cfChgInCashEquivInd") == null)
                RG.AddCalc("cfChgInCashEquivInd", RG.MACRO(M.ICF_TOTAL_MOVEMENTS_IN_CASH));

            if (RG.GetCalc("cfUnexplainedAdjToCashInd") == null)
                RG.AddCalc("cfUnexplainedAdjToCashInd", RG.MACRO(M.UNEXPLAINED_ADJ_TO_CASH));
        }

    }
}
