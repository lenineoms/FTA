using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class DET_BS_PERCENT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// ***CPF Load the Balance Sheet Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BSCalcs(RG);				

			///***CPF 7/26/02 Call the base balance sheet code. 
			MMAS_Utility.DETAILED_BALANCE_SHEET(RG, FORMATCOMMANDS.PERCENT);

		}
	}
}
