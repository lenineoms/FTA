using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class SUM_RECON:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);
			Calcs.DetReconCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("srecReconRE"));
			Utility.UnderlinePage(RG, 1);

			if (RG.GetCalc("LINE(209)").NonZero)
			{
				Utility.PrintLabel(RG, rm.GetString("srecBegRE"));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintSummary(RG, rm.GetString("srecAsPrevRept"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(204)")));
			}

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			if (FormatCommands.DetailCount(RG, RG.GetPrintOrderDetailCalcs(RG.DETAILAND(103, RG.ANDFLOW, 30, RG.ANDCLASS))) + FormatCommands.DetailCount(RG, RG.GetPrintOrderDetailCalcs(RG.DETAILAND(103, RG.ANDFLOW, 32, RG.ANDCLASS))) > 0)
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(217)"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(219)"));
			}

			if (RG.GetCalc("LINE(202)").NonZero)
				Utility.PrintSummary(RG, rm.GetString("srecAdjChgExgRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(206)")));

			if (RG.GetCalc("LINE(209)").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("srecBegRERst"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(208)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			if (RG.GetCalc("LINE(204)").NonZero == false)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("srecRE"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(210)")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			}

			//SPA - changed label from Net Income to Net Profit to match MFA report
			  // is this a bug in the Det Recon report?
			Utility.PrintSummary(RG, rm.GetString("srecNetPft"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfit")));

			Utility.PrintSummary(RG, rm.GetString("srecDivWithCash"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(216)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecDivStk"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(218)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecUnexplAdjRE"), -1 * RG.GetPrintOrderCalc(RG.GetCalc("LINE(220)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("srecEndRE"), RG.GetPrintOrderCalc(RG.GetCalc("EndRetEarn")));
			Utility.UnderlinePage(RG, 2);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("srecReconNW"));
			Utility.UnderlinePage(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("srecBegNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(225)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("srecNetPft"), RG.GetPrintOrderCalc(RG.GetCalc("NetProfit")));
			Utility.PrintSummary(RG, rm.GetString("srecDivWithCash"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(216)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecDivStk"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(218)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecAdjsRE"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(230)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			//amit: 06/07/04 Added a check before printing. 
			if ( RG.GetCalc("LINE(235)").NonZero)
				Utility.PrintLabel(RG,rm.GetString("srecIncDecr"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("srecStkPdInCap"), RG.GetPrintOrderCalc(RG.GetCalc("StockPIC")));
			Utility.PrintSummary(RG, rm.GetString("srecOthGyArEq"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(243)")));
			Utility.PrintSummary(RG, rm.GetString("srecCurrTran"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(244)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecOCI"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(242)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecOCIReclsAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(212)")));
			Utility.PrintSummary(RG, rm.GetString("srecOCIAdjChgExRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(214)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			//SPA - Assuming Chad commented this out b/c DO_IF_ANY not working
			  // I'll put it in to always print
			  // must resolve this issue here and in the Det Recon
			///COMPARE LINE(250) TO LINE(265)
			///IF NOT = DO_IF_ANY THEN PRINT 'Ending Net Worth(As Calc Above)' LINE(250)
			for (int i = 0; i < RG.GetCalc("LINE(250)").Count; i++) 
				///if (RG.GetCalc("LINE(250)")[i] != double.NaN && RG.GetCalc("LINE(250)")[i] != RG.GetCalc("LINE(265)")[i])
				if (double.IsNaN(RG.GetCalc("LINE(250)")[i]) == false && RG.GetCalc("LINE(250)")[i] != RG.GetCalc("LINE(265)")[i])
				{
					Utility.PrintSummary(RG, rm.GetString("srecEndNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(250)")));
					break;
				}
			
			Utility.PrintSummary(RG, rm.GetString("srecUnexAdjNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(260)")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("srecActEndNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(265)")));
			Utility.PrintSummary(RG, rm.GetString("srecIncDecNW"), RG.GetPrintOrderCalc(RG.GetCalc("IncDecNetWrth")));
			Utility.UnderlinePage(RG, 2);
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintCenter(RG, rm.GetString("srecRecWorkCap"));
			Utility.UnderlinePage(RG, 1);

			Utility.PrintSummary(RG, rm.GetString("srecBegWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(300)")));
			Utility.PrintLabel(RG, rm.GetString("srecDecIncNonCurAst"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("srecTotFixAstNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(370)")));
			Utility.PrintSummary(RG, rm.GetString("srecActNtRcLT"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(375)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecInvest"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(380)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecOpNonCurAsts"), RG.GetPrintOrderCalc(RG.GetCalc("SumReconOpNonCurAsts")));
			Utility.PrintSummary(RG, rm.GetString("srecDefIncTxRecov"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(390)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecNonOpNonCurAst"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("LINE(395)").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("srecIntangNet"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(398)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintLabel(RG, rm.GetString("srecIncDecNonCurLiab"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("srecLTD"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(330)")));			
			Utility.PrintSummary(RG, rm.GetString("srecCapLseObl"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(335)")));
			Utility.PrintSummary(RG, rm.GetString("srecOthNonCurLiab"), RG.GetPrintOrderCalc(RG.GetCalc("SumReconOthNonCurLiabs")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("srecIncDecNWlc"), RG.GetPrintOrderCalc(RG.GetCalc("IncDecNetWrth")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("srecUnexAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(320)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("srecEndWorkCap"), RG.GetPrintOrderCalc(RG.GetCalc("EndWorkCap")));

			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
