using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class SUM_IS_ACT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.ISCalcs(RG);

			/// Call the base income statement
			MMAS_Utility.SUMMARY_INCOME_STATEMENT(RG, FORMATCOMMANDS.ACTUAL);

			//			StreamWriter sw = new StreamWriter("C:\\Det_IS_Act.txt");
			//			sw.Write(RG.Writer.Commands);
			//			sw.Close();
		}
	}
}
