using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;

namespace MMAS
{
	public class EXEC_FIN_STMT_ACT:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			/// ***SPA - Load the Balance Sheet Calculations.
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.BSCalcs(RG);
			Calcs.ISCalcs(RG);

			///***SPA - 7/26/02 Call the exec fin stmt code. 
			MMAS_Utility.EXECUTIVE_BALANCE_SHEET(RG,FORMATCOMMANDS.ACTUAL);

		}
	}
}

