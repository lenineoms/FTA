using System.Collections;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;

namespace MMAS
{
	/// <summary>
	/// Summary description for FIN_PERFORM_ANALYSIS.
	/// </summary>
	public class FIN_PERFORM_ANALYSIS: FinancialAnalyst.IReport
	{
		ReportGenerator RG= null;
		PRINTCOMMANDS Utility = new PRINTCOMMANDS();
		FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();
		ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);
		//CASH_FLOW_SUMMARY csh = null;
		
		private int pBaseID = 0; //statement ID
		//bool useIndustry  = true;
		int CurMonth = 0;
		int PrevMonth = 0;
		int CurYear = 0;
		int PrevYear = 0;
		string CurDate = "";
		string PrevDate = "";
		bool isSeviceInd = false;
		public bool isProperPeer = false;
		private int indCat = 0; //Industry Category

		public void Execute(ReportGenerator RGG)
		{
			RG = RGG;
			double test = RG.IND(1);
			int id = RG.BaseStatementID;
			//This variable will store the stmt index of the base comparison stmt
			pBaseID = RG.Statements.IndexOf(RG.Context.Statements[id.ToString()]);
            
							
			FormatCommands.LoadFormatDefaults(RG);
			Utility.CreatePageHeader(RG, true);
			//csh = new CASH_FLOW_SUMMARY(RG, rm, FormatCommands, Utility, pBaseID);
			
			CurMonth = (int)(RG.STMT_PERIODS()[pBaseID]);
			PrevMonth = (int)(RG.STMT_PERIODS(RG.LAG)[pBaseID]);
			CurYear = (int)(RG.STMT_YEAR()[pBaseID]);
			PrevYear = (int)(RG.STMT_YEAR(RG.LAG)[pBaseID]);

            DateTime curDateTime;
            DateTime.TryParse(RG.STMT_DATE()[pBaseID].ToString(), out curDateTime);
            if (curDateTime != null && curDateTime != DateTime.MinValue)
            {
                CurDate = curDateTime.ToShortDateString();
            }

            DateTime prevDateTime;
            DateTime.TryParse(RG.STMT_DATE(RG.LAG)[pBaseID].ToString(), out prevDateTime);
            if (prevDateTime != null && prevDateTime != DateTime.MinValue)
            {
                PrevDate = prevDateTime.ToShortDateString();
            }
			
			intro();

            isSeviceInd = isServiceIndustry();
            isProperPeer = isValidDB(RG);
	
			printSalesGrowth();
			calculateProfitability();  
			printProfitB4TaxToTNW();
			printProfitB4TaxTotAssets();
			printNetSalesToTotalAssets();
			printActReceivable();
			printInventory();
			if (!this.isSeviceInd)
				printActPayable();
			printNetSalesToNetFixAssets();
			calculateDebtService();
			printCurrentRatio();
			printQuickRatio();
			printLeverage();
			printSustainGrowth();
			printCapitalExpMgmt();
            //log# 1819
            Utility.PrintParagraph(RG, " ");
            Utility.PrintNotes(RG);
					
		}

		public void intro ()
		{
			string header = "";
			int ind = 0;
			string sAdtMthVal  = ""; //Audit Method
			string sDate       = null; //Statement Date
			string auditMethod = ""; //audit method
			
			int period  = 0;
				
			sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[pBaseID].ToString()).ToLower();
			period = (int)(RG.STMT_PERIODS()[pBaseID]);

            DateTime curDateTime;
            DateTime.TryParse(RG.STMT_DATE()[pBaseID].ToString(), out curDateTime);
            if (curDateTime != null && curDateTime != DateTime.MinValue)
            {
                sDate = curDateTime.ToShortDateString();
            }


            
			int month = (int)(RG.STMT_MONTH()[pBaseID]);
			int year = (int)(RG.STMT_YEAR()[pBaseID]);
			int dbType = RG.DATABASE_TYPE();

			if (dbType == 3) indCat = dbType;

			ind = (RG.IND(94) > 0) ? 4 : 0;

			if (dbType != 4) //4 = No Peer Database Selected
			{
				if (RG.IND_Category == (int)ePeerCategory.Assets)
					indCat= 1;
				else if (RG.IND_Category == (int)ePeerCategory.Sales)
					indCat= 2;
				else if (RG.IND_Category == (int)ePeerCategory.Totals)
					indCat = 3;
				indCat = indCat + ind;
			}
			
			#region Audit Type Compare			
			if (rm.GetString("fsUnqUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsUnQalified").ToLower();
				auditMethod = "unqualified";
			}
			else if (rm.GetString("fsTxRetUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsTxRetUC").ToLower();
				auditMethod = "taxreturn";
			}
			else if (rm.GetString("fsRevUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsRevUC").ToLower();
				auditMethod = "reviewed";
			}
			
			else if (rm.GetString("fsQualUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsQualUC").ToLower();
				auditMethod = "qualified";
			}
			else if (rm.GetString("fsCompUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsCompUC").ToLower();
				auditMethod = "compiled";
			}
			else if (rm.GetString("fsCoPpdUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsCoPpd");
				auditMethod = "companyprepared";
			}
			else if (rm.GetString("fscivProj").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fscivProj");
				auditMethod = "projection";
			}
			else if (rm.GetString("fsDiscUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsDiscUC").ToLower();
				auditMethod = "disclaimer";
			}
			else if (rm.GetString("fsAdvUC").ToLower().Equals(sAdtMthVal) )
			{
				sAdtMthVal = rm.GetString("fsAdvUC").ToLower();
				auditMethod = "adverse";
			}
			#endregion Audit Type Compare

			#region Audit Desc
			if (period == 12)
			{
				if (auditMethod.Equals("taxreturn"))
					printReport("", rm.GetString("fsBsdTxRtFY") + " " + year, true);
				else if (auditMethod.Equals("disclaimer"))
					printReport("", rm.GetString("fsBsdDscFY") + " " + year, true);
				else if (auditMethod.Equals("adverse"))
					printReport("", rm.GetString("fsBsdAdvOp") + " " + year, true);
				else if (auditMethod != "")
					printReport("", string.Format(rm.GetString("fsbasedAnnual"), " " +sAdtMthVal+" ", year), true );
				else 
					printReport("", string.Format(rm.GetString("fsbasedAnnual"), " ", year), true );
					
			}
			else
			{
				if (auditMethod.Equals("taxreturn"))
					printReport("", string.Format(rm.GetString("fsbaseTaxInterim"), period, sDate), true);
				else if (auditMethod.Equals("disclaimer"))
					printReport("", string.Format(rm.GetString("fsbaseDisInterim"), period, sDate), true );
				else if (auditMethod.Equals("adverse"))
					printReport("", string.Format(rm.GetString("fsbasedAdvInterim"), period, sDate), true );
				else if (auditMethod != "") 
					printReport("", string.Format(rm.GetString("fsbasedInterim"), " " +sAdtMthVal +" ", period, sDate), true );
				else
					printReport("", string.Format(rm.GetString("fsbasedInterim"), " ", period, sDate), true );
			}
			#endregion Audit Desc

			#region Industry Category
			string s1 = "";
			switch (indCat)
			{
				case 0:
					s1 = rm.GetString("fsCompare3");
					break;
				case 1: 
					s1 = string.Format(rm.GetString("fsCompare1"), RG.IND_DESC);
					break;
				case 2: 
					goto case 1;
				case 3: 
					goto case 1;
				case 4:
					goto case 0;
				case 5:
					s1 =  string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpAssetsSize"), RG.IND_SIZE, RG.IND(7));
					break;
				case 6:
					s1 = string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpSalesSize"), RG.IND_SIZE, RG.IND(7));
					break;
				case 7:
					s1 = string.Format(rm.GetString("fsCompare4"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, RG.IND(7));
					break;
				default:
					break;
			}
			#endregion Industry Category

			
			//Currency 
			if (! RG.LANGCONSTANT(4)[pBaseID].ToString().Equals(""))
			{
				string targetCur = RG.TARGETCURRENCY(0)[0].ToString();
				s1 = string.Format(rm.GetString("qcFinInfoTarget"), targetCur) + " " + s1;
				printReport(header,  s1, true);
			}
			else
				printReport(header, s1, true );

			//interim statements comment
			if (period != 12)
				printReport(header, rm.GetString("fsInterimWarn"), true );
			
		}

		public void printSalesGrowth()
		{
			double ratio = RG.MACRO(M.NET_SALES_GROWTH)[pBaseID];
			double ratioLag = RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[pBaseID];
			double netSales = RG.MACRO(M.NET_SALES)[pBaseID];
			double netSalesLag = RG.MACRO(M.NET_SALES, RG.LAG)[pBaseID];
			double avgRatio = (ratio + ratioLag)/2;


			printReport(rm.GetString("fpa_oprPerformance"), "", true);

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, 0, 1, 2);
			string sentence = "";
			ArrayList analysis = new ArrayList();
			string A = string.Format(rm.GetString("fpa_SalesGrwA"), this.CurMonth, this.CurDate);
			string B = string.Format(rm.GetString("fpa_SalesGrwB"), strVal(avgRatio));
			string D3 = string.Format(rm.GetString("fpa_SalesGrwD3"), strVal(netSales,0), this.CurMonth, this.CurDate, strVal(netSalesLag,0), this.PrevMonth, this.PrevDate);
			string D2 = string.Format(rm.GetString("fpa_SalesGrwD2"), strVal(ratio));
			string D1 = string.Format(rm.GetString("fpa_SalesGrwD1"), strVal(ratio));
			string D = string.Format(rm.GetString("fpa_SalesGrwD"), rm.GetString(rt.increasedORdecreased("SLSG")), rm.GetString(rt.moderSigVsigly("SLSG")), strVal(ratio));
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
			{
				sentence = A + rm.GetString("fpa_SalesGrwC");
				analysis.Add(rm.GetString("fpa_SalesGrwF") + rm.GetString("fpa_SalesGrwG"));
				analysis.Add(rm.GetString("fpa_SalesGrwH")+ rm.GetString("fpa_SalesGrwI"));
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.increasing)
			{
				sentence = D2 + D3;
				analysis.Add(rm.GetString("fpa_SalesGrwF1") + rm.GetString("fpa_SalesGrwG"));
				analysis.Add(rm.GetString("fpa_SalesGrwH")+ rm.GetString("fpa_SalesGrwI"));
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing)
			{
				sentence = D1 + D3;
				if (RG.Statements.Count >= 3)
					sentence = sentence + B;
				analysis.Add(rm.GetString("fpa_SalesGrwF") + rm.GetString("fpa_SalesGrwG") +
					rm.GetString("fpa_SalesGrwH")+ rm.GetString("fpa_SalesGrwI"));
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate)
			{
				sentence = D + D3;
				if (RG.Statements.Count >= 3)
					sentence = sentence + B;
							
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate)
			{
				sentence = D + D3;
				if (RG.Statements.Count >= 3)
					sentence = sentence + B;
				
				analysis.Add(rm.GetString("fpa_SalesGrwJ") + rm.GetString("fpa_SalesGrwG"));
				analysis.Add(rm.GetString("fpa_SalesGrwH")+ rm.GetString("fpa_SalesGrwI"));
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				sentence = D + D3;
				if (RG.Statements.Count >= 3)
					sentence = sentence + B;
				analysis.Add(rm.GetString("fpa_SalesGrwK"));
				analysis.Add(rm.GetString("fpa_SalesGrwL"));
				analysis.Add(rm.GetString("fpa_SalesGrwM"));
				analysis.Add(rm.GetString("fpa_SalesGrwN"));
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
			{
				sentence = D + D3;
				if (RG.Statements.Count >= 3)
					sentence = sentence + B;
				analysis.Add(rm.GetString("fpa_SalesGrwO"));
				analysis.Add(rm.GetString("fpa_SalesGrwP") + rm.GetString("fpa_SalesGrwI") );
				analysis.Add(rm.GetString("fpa_SalesGrwQ"));
			}
			printReport("", sentence, true);
			for (int i=0; i < analysis.Count; i++)
			{
				if(i== 0)
					printReport("", rm.GetString("fpa_SalesGrwE"), true);
				printReport("", analysis[i].ToString(), true);
			}
			

		}
		public void calculateProfitability()
		{
			printReport(rm.GetString("fpa_profitability"), "", true);
			string sentence = "";
			string qtsentence = "";
			//Gross Margin
			double grossPrft = RG.MACRO(M.GROSS_PROFIT)[pBaseID];
			double grossPrftLag = RG.MACRO(M.GROSS_PROFIT, RG.LAG)[pBaseID];
			double ratio = RG.MACRO(M.GROSS_MARGIN)[pBaseID];
			double ratioLag = RG.MACRO(M.GROSS_MARGIN, RG.LAG)[pBaseID];

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 3, 4);
			
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_GSMA"), this.PrevDate, this.CurDate)+
					       string.Format(rm.GetString("fpa_GSME"), strVal(grossPrft,0), this.CurMonth, this.CurDate, strVal(ratio)) +
					       string.Format(rm.GetString("fpa_GSMF"), this.PrevMonth, this.PrevDate, strVal(grossPrftLag,0), strVal(ratioLag));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_GSMA"), this.PrevDate, this.CurDate)+
					string.Format(rm.GetString("fpa_GSME"), strVal(grossPrft,0), this.CurMonth, this.CurDate, strVal(ratio)) +
					string.Format(rm.GetString("fpa_GSMF"), this.PrevMonth, this.PrevDate, strVal(grossPrftLag,0), strVal(ratioLag));
			else 
				sentence = string.Format(rm.GetString("fpa_GSMC"), rm.GetString(rt.increasedORdecreased("GSM")), rm.GetString(rt.moderSigVsigly("GSM")), this.PrevDate, this.CurDate)+
							string.Format(rm.GetString("fpa_GSME"), strVal(grossPrft,0), this.CurMonth, this.CurDate, strVal(ratio)) +
							string.Format(rm.GetString("fpa_GSMF"), this.PrevMonth, this.PrevDate, strVal(grossPrftLag,0), strVal(ratioLag));
			
			printReport("", sentence, true);

			if(this.isSeviceInd)
				printReport("", rm.GetString("fpa_GSMJ"), true);
			else if(isProperPeer)
			{
				if (formatVal(ratio) > RG.IND(29))
					qtsentence = string.Format(rm.GetString("fpa_GSMH"), strIND(29));
				else if (formatVal(ratio) < RG.IND(29))
					qtsentence = string.Format(rm.GetString("fpa_GSMI"), strIND(29));
				else
					qtsentence = string.Format(rm.GetString("fpa_GSMG"), strIND(29));
				printReport("", qtsentence, true);
			}
			//End Gross Margin

			//Sales Growth + GrossMargin
			double salesGrowth = RG.MACRO(M.NET_SALES_GROWTH)[pBaseID];
			
			ratioAnalysis rts = new ratioAnalysis(RG, ratio, 0, 1, 2);
			if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || 
				(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
			{
				if ((rts.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rts.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
				{
					printReport("", rm.GetString("fpa_SlsGrwK"), true);
					printReport("", string.Format(rm.GetString("fpa_SlsGrwL"), strVal(salesGrowth, 2)), true);
				}
			}
			//End Sales Growth
			printOperatingExpense();
			ratioAnalysis opMargin = printOpProfitMargin();
			ratioAnalysis opLever =  printOpLeverage();
			printOpMarginAndOpLeverage(opMargin, opLever);
			printProfitB4TaxToSales(opMargin); //rt = grossMargin

		}

		
		private void printOperatingExpense()
		{
			double ratio = RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT)[pBaseID];
			double ratioLag = RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT, RG.LAG)[pBaseID];
			string sentence = "";
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 5, 6);
			
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_OpExpA"), strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_OpExpB1"), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else 
				sentence = string.Format(rm.GetString("fpa_OpExpB"), rm.GetString(rt.increasedORdecreased("OPEXP")), rm.GetString(rt.moderSigVsigly("OPEXP")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			printReport("", sentence, true);

			string chg = "";
			//string sentence1 = "";
			string noPeer = "";
			string E = string.Format(rm.GetString("fpa_OpExpE"),rm.GetString(rt.moderSigVsigly("OPEXP")));
			string F = "";
			
			if (this.isProperPeer)
			{
				if (formatVal(ratio) < RG.IND(30))
				{
					chg = rm.GetString("fpa_OPEXP_better");
				}
				else if (formatVal(ratio) > RG.IND(30))
				{
					chg = rm.GetString("fpa_OPEXP_worse");
				}
				else
					chg = rm.GetString("fpa_OPEXP_equal");

				F = string.Format(rm.GetString("fpa_OpExpF"), rm.GetString(rt.moderSigVsigly("OPEXP")), chg);
				
				printReport("", string.Format(rm.GetString("fpa_OpExpC"), chg, strIND(30)), true);
				
			}
			printReport("", rm.GetString("fpa_OpExpR"), true);
			if (!isProperPeer)  //not a proper peer
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					noPeer = rm.GetString("fpa_OpExpH")+ rm.GetString("fpa_OpExpG");
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) ||
					(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					noPeer = rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG") + rm.GetString("fpa_OpExpL");
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate)
					noPeer = E + rm.GetString("fpa_OpExpI") + rm.GetString("fpa_OpExpG")+
						rm.GetString("fpa_OpExpN") + rm.GetString("fpa_OpExpP") + rm.GetString("fpa_OpExpO");
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate) ||(rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
					(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
					noPeer = string.Format(rm.GetString("fpa_OpExpF1"),rm.GetString(rt.moderSigVsigly("OPEXP"))) + rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG");
                else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)
					noPeer = E + rm.GetString("fpa_OpExpI") + rm.GetString("fpa_OpExpN") + rm.GetString("fpa_OpExpL") + rm.GetString("fpa_OpExpO");
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					noPeer = E+ rm.GetString("fpa_OpExpI") + rm.GetString("fpa_OpExpG");

				printReport("", noPeer, true);
			
			}
			

			ArrayList analysis = new ArrayList();
			
			if (this.isProperPeer)
			{
				//printReport("", rm.GetString("fpa_OpExpR"), true); moved it up
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				{					
					if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"), rm.GetString("fpa_OPEXP_worse")) + rm.GetString("fpa_OpExpG") + rm.GetString("fpa_OpExpL"));
					}
					if (formatVal(ratio) < RG.IND(30)) // better than ind
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"),rm.GetString("fpa_OPEXP_better")) + rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG"));
					}
					else //equal to
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"),rm.GetString("fpa_OPEXP_equal")) + rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG"));
					}
				}
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing)||(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				{
					if (formatVal(ratio) < RG.IND(30)) //better than ind
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"), rm.GetString("fpa_OPEXP_better"))+ rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG"));
					}
					else if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"), rm.GetString("fpa_OPEXP_worse")) + rm.GetString("fpa_OpExpG") + rm.GetString("fpa_OpExpL"));
					}
					else // equal to ind
					{
						analysis.Add(string.Format(rm.GetString("fpa_OpExpD"), rm.GetString("fpa_OPEXP_equal")) + rm.GetString("fpa_OpExpG") + rm.GetString("fpa_OpExpH"));
					}
				}
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)||
					(rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
				{
					if (formatVal(ratio) < RG.IND(30)) //better than ind
					{
						analysis.Add(E + rm.GetString("fpa_OpExpK")+rm.GetString("fpa_OpExpI") + rm.GetString("fpa_OpExpG"));
					}
					else if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(E + rm.GetString("fpa_OpExpM") );
						analysis.Add(rm.GetString("fpa_OpExpN")+ rm.GetString("fpa_OpExpP"));
						analysis.Add(rm.GetString("fpa_OpExpO"));
					}
					else 
					{
						analysis.Add(E);
						analysis.Add(rm.GetString("fpa_OpExpI") + rm.GetString("fpa_OpExpG"));
					}
				}
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate)
				{
					if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpL"));
					}
					else
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpG") + rm.GetString("fpa_OpExpH"));
					}
				}
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant)
				{
					if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpQ") + rm.GetString("fpa_OpExpP"));
						analysis.Add(rm.GetString("fpa_OpExpO")); 
					}
					else 
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG"));
					}
				}
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant)
				{
					if (formatVal(ratio) > RG.IND(30)) // worse than ind
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpP"));
						analysis.Add(rm.GetString("fpa_OpExpO"));
					}
					else 
					{
						analysis.Add(F);
						analysis.Add(rm.GetString("fpa_OpExpH") + rm.GetString("fpa_OpExpG"));
					}
				}

				for(int i=0; i < analysis.Count; i++)
				{
					printReport("", analysis[i].ToString(), true);
				}

			}
			
		}

		private ratioAnalysis printOpProfitMargin()
		{
			double ratio =RG.MACRO(M.OPERATING_PROFIT_MARGIN)[pBaseID];
			double ratioLag = RG.MACRO(M.OPERATING_PROFIT_MARGIN, RG.LAG)[pBaseID];
			double OpProfit = RG.MACRO(M.NET_OPERATING_PROFIT)[pBaseID];
			double OpProfitLag = RG.MACRO(M.NET_OPERATING_PROFIT, RG.LAG)[pBaseID];
			string sentence = "";

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 40, 42);
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = rm.GetString("fpa_OpPrfME") + rm.GetString("fpa_OpPrfMA")+
					string.Format(rm.GetString("fpa_OpPrfMB"), strVal(OpProfit,0), this.CurMonth, this.CurDate, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = rm.GetString("fpa_OpPrfME") + 
					string.Format(rm.GetString("fpa_OpPrfMC1"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("OPPRF")), strVal(ratio))+
					string.Format(rm.GetString("fpa_OpPrfMB"), strVal(OpProfit,0), this.CurMonth, this.CurDate, strVal(ratio))+
					string.Format(rm.GetString("fpa_OpPrfMD"), this.PrevDate, strVal(OpProfit,0), strVal(ratioLag));
			else
				sentence = rm.GetString("fpa_OpPrfME") + 
					string.Format(rm.GetString("fpa_OpPrfMC"), rm.GetString(rt.increasedORdecreased("OPPRF")), rm.GetString(rt.moderSigVsigly("OPPRF")), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("OPPRF")), strVal(Math.Abs(ratioLag - ratio)))+
					string.Format(rm.GetString("fpa_OpPrfMB"), strVal(OpProfit,0), this.CurMonth, this.CurDate, strVal(ratio))+
					string.Format(rm.GetString("fpa_OpPrfMD"), this.PrevDate, strVal(OpProfitLag,0), strVal(ratioLag));

			printReport("", sentence, true);
			if (this.isProperPeer)
			{
				if (formatVal(ratio) < RG.IND(31))
					sentence = string.Format(rm.GetString("fpa_OpPrfMR"), strIND(31));
				else if (formatVal(ratio) > RG.IND(31))
					sentence = string.Format(rm.GetString("fpa_OpPrfMS"), strIND(31));
				else
					sentence = string.Format(rm.GetString("fpa_OpPrfMQ"), strIND(31));

				printReport("", sentence, true);
			}

			return rt;

		}

		private ratioAnalysis printOpLeverage()
		{
			double ratio = (RG.MACRO(M.TOTAL_OPERATING_EXP)/(RG.MACRO(M.TOTAL_OPERATING_EXP) + RG.MACRO(M.COST_OF_GOODS_SOLD)))[pBaseID]*100;
			double ratioLag =  (RG.MACRO(M.TOTAL_OPERATING_EXP, RG.LAG)/(RG.MACRO(M.TOTAL_OPERATING_EXP, RG.LAG) + RG.MACRO(M.COST_OF_GOODS_SOLD, RG.LAG)))[pBaseID]*100;
		
			string sentence = "";

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 41, 43);
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_OpLevrA"), strVal(ratio), this.CurMonth, this.CurDate) + 
					       string.Format(rm.GetString("fpa_OpLevrB"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_OpLevrA"), strVal(ratio), this.CurMonth, this.CurDate) +
					string.Format(rm.GetString("fpa_OpLevrB1"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else
				sentence = string.Format(rm.GetString("fpa_OpLevrA"), strVal(ratio), this.CurMonth, this.CurDate) + 
					string.Format(rm.GetString("fpa_OpLevrC"), rm.GetString(rt.moderSigVsig("OPLEV")), rm.GetString(rt.increaseORdecrease("OPLEV")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
					
			printReport("", sentence, true);

			return rt;
		}


		private void printOpMarginAndOpLeverage(ratioAnalysis opMargin, ratioAnalysis opLever)
		{
			double ratio = RG.MACRO(M.OPERATING_PROFIT_MARGIN)[pBaseID];
			string sentence = "";
			string p = string.Format(rm.GetString("fpa_OpMOpLP"), rm.GetString(opMargin.increasedORdecreased("OMOL")), rm.GetString(opMargin.moderSigVsigly("OMOL")));
			string pSlightly = string.Format(rm.GetString("fpa_OpMOpLP"), rm.GetString(opMargin.increasedORdecreased("OMOL")), rm.GetString("fpa_OMOL_slightly"));
			
			if (this.isProperPeer)
			{
				printReport("", rm.GetString("fpa_OpMOpLA"), true);
				if (formatVal(ratio) < RG.IND(31))
				{
					if(opMargin.GrowthType == ratioAnalysis.eGrowthType.noChange)
						sentence = rm.GetString("fpa_OpMOpLG") + rm.GetString("fpa_OpMOpLH");
					else if (opMargin.GrowthType == ratioAnalysis.eGrowthType.increasing)
						sentence = pSlightly + rm.GetString("fpa_OpMOpLH");
					else if (opMargin.GrowthType == ratioAnalysis.eGrowthType.decreasing)
						sentence = pSlightly + rm.GetString("fpa_OpMOpLJ");
					else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
						sentence = p + rm.GetString("fpa_OpMOpLH");
					else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.decrModerate) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
						sentence = p + rm.GetString("fpa_OpMOpLJ");
				}
				else if (formatVal(ratio) > RG.IND(31))
				{
					if(opMargin.GrowthType == ratioAnalysis.eGrowthType.noChange)
						sentence = rm.GetString("fpa_OpMOpLD");
					else if (opMargin.GrowthType == ratioAnalysis.eGrowthType.increasing)
						sentence = pSlightly + rm.GetString("fpa_OpMOpLE");
					else if (opMargin.GrowthType == ratioAnalysis.eGrowthType.decreasing)
						sentence = pSlightly + rm.GetString("fpa_OpMOpLF");
					else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
						sentence = p + rm.GetString("fpa_OpMOpLE");
					else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.decrModerate) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
						(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
						sentence = p + rm.GetString("fpa_OpMOpLF");
				}
					
				else
				{
					if(opMargin.GrowthType == ratioAnalysis.eGrowthType.noChange)
						sentence = rm.GetString("fpa_OpMOpLB");
					else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.increasing)|| (opMargin.GrowthType == ratioAnalysis.eGrowthType.decreasing))
						sentence = pSlightly+rm.GetString("fpa_OpMOpLC");
					else
						sentence = p+rm.GetString("fpa_OpMOpLC");
				}

				printReport("", sentence, true);
			}
			else //no peer
			{   sentence = "";
				printReport("", rm.GetString("fpa_OpMOpLA"), true);
				//if(opMargin.GrowthType == ratioAnalysis.eGrowthType.noChange)
					//sentence = p; //this one does not make sense
				if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.increasing)|| (opMargin.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					sentence = pSlightly;
				else 
					sentence = p;
				printReport("", sentence, true);
			}

			sentence = "";
			string sentence1 = "";
			string k = string.Format(rm.GetString("fpa_OpMOpLK"), rm.GetString(opMargin.moderSigVsigly("OMOL")));
			string kSlightly = string.Format(rm.GetString("fpa_OpMOpLK"), rm.GetString("fpa_OMOL_slightly"));
			string m = string.Format(rm.GetString("fpa_OpMOpLM"), rm.GetString(opMargin.moderSigVsigly("OMOL")));
			string mSlightly = string.Format(rm.GetString("fpa_OpMOpLM"), rm.GetString("fpa_OMOL_slightly"));
		
			if (opLever.GrowthType == ratioAnalysis.eGrowthType.increasing)
			{
				sentence = kSlightly;
				sentence1 = rm.GetString("fpa_OpMOpLL");
			}
			else if (opLever.GrowthType == ratioAnalysis.eGrowthType.decreasing)
				sentence = mSlightly;
			else if ((opLever.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||
				(opLever.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
				(opLever.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				sentence = k;
				sentence1 = rm.GetString("fpa_OpMOpLL");
			}
			else if ((opLever.GrowthType == ratioAnalysis.eGrowthType.decrModerate) ||
				(opLever.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
				(opLever.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
				sentence = m;

			printReport("", sentence, true);
			if (sentence1.Length > 0)
				printReport("", sentence1, true);

		}


		private void printProfitB4TaxToSales(ratioAnalysis opMargin)
		{
			string sentence = "";
			string qtsentence = "";
			double netPrftBTax = RG.MACRO(M.PROFIT_BEFORE_TAX)[pBaseID];
			double ratio = RG.MACRO(M.PROFIT_BEFORE_TAX_MARGIN)[pBaseID];
			double ratioLag = RG.MACRO(M.PROFIT_BEFORE_TAX_MARGIN, RG.LAG)[pBaseID];
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 13, 14);
			
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_PBTSalesB1"), this.PrevMonth, this.PrevDate);
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_PBTSalesB2"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else 
				sentence = string.Format(rm.GetString("fpa_PBTSalesB"), rm.GetString(rt.moderSigVsig("PBTS")), rm.GetString(rt.increaseORdecrease("PBTS")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			printReport("", string.Format(rm.GetString("fpa_PBTSalesA"), strVal(netPrftBTax,0), this.CurMonth, this.CurDate, strVal(ratio))+ sentence, true);

			if (this.isProperPeer)
			{
				if (formatVal(ratio) > RG.IND(33))
					qtsentence = string.Format(rm.GetString("fpa_PBTSalesD"), strIND(33));
				else if (formatVal(ratio) < RG.IND(33))
					qtsentence = string.Format(rm.GetString("fpa_PBTSalesE"), strIND(33));
				else
					qtsentence = string.Format(rm.GetString("fpa_PBTSalesC"), strIND(33));
				
				printReport("", qtsentence, true);
			}

			double grsMargin = RG.MACRO(M.GROSS_MARGIN)[pBaseID];
			double grsMarginLag = RG.MACRO(M.GROSS_MARGIN, RG.LAG)[pBaseID];
			double opExp = RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT)[pBaseID];
			double opExpLag = RG.MACRO(M.TOTAL_OPERATING_EXP_PERCENT, RG.LAG)[pBaseID];
			double intExp = (((RG.TYPE(170) - RG.TYPE(171))*RG.CONV_RATE()) / RG.MACRO(M.NET_SALES))[pBaseID];
			double intExpLag = (((RG.TYPE(170, RG.LAG) - RG.TYPE(171, RG.LAG))*RG.CONV_RATE(RG.LAG)) / RG.MACRO(M.NET_SALES, RG.LAG))[pBaseID];
			double othInc = (((RG.TYPE(182) + RG.TYPE(175)+ RG.TYPE(180) + RG.TYPE(184))*RG.CONV_RATE()) / RG.MACRO(M.NET_SALES))[pBaseID];
			double othIncLag = (((RG.TYPE(182,RG.LAG) + RG.TYPE(175,RG.LAG)+ RG.TYPE(180,RG.LAG) + RG.TYPE(184,RG.LAG))*RG.CONV_RATE(RG.LAG)) / 
				                                 RG.MACRO(M.NET_SALES,RG.LAG))[pBaseID];
			double othExp = (((RG.TYPE(185) + RG.TYPE(176))*RG.CONV_RATE()) / RG.MACRO(M.NET_SALES))[pBaseID];
			double othExpLag = (((RG.TYPE(185,RG.LAG) + RG.TYPE(176,RG.LAG))*RG.CONV_RATE(RG.LAG)) / RG.MACRO(M.NET_SALES,RG.LAG))[pBaseID];

			if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.decrModerate) ||
				(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
				(opMargin.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
			{
				printReport("", rm.GetString("fpa_PBTSalesG"), true);
				if (formatVal(grsMargin) < formatVal(grsMarginLag))
					printReport("", rm.GetString("fpa_PBTSalesH"), true);
				if (formatVal(opExp) > formatVal(opExpLag ))
					printReport("", rm.GetString("fpa_PBTSalesI"), true);
				if (formatVal(intExp*100) > formatVal(intExpLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesJ"),strVal(intExpLag*100),strVal(intExp*100)), true);
				if (formatVal(othInc*100) < formatVal(othIncLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesK"), strVal(othIncLag*100), strVal(othInc*100)), true);
				if (formatVal(othExp*100) > formatVal(othExpLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesL"), strVal(othExpLag*100), strVal(othExp*100)), true);
					
			}
			else if ((opMargin.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||
				(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
				(opMargin.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				printReport("", rm.GetString("fpa_PBTSalesM"), true);
				if (formatVal(grsMargin) > formatVal(grsMarginLag))
					printReport("", rm.GetString("fpa_PBTSalesN"), true);
				if (formatVal(opExp) < formatVal(opExpLag))
					printReport("", rm.GetString("fpa_PBTSalesO"), true);
				if (formatVal(intExp*100) < formatVal(intExpLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesP"), strVal(intExpLag*100), strVal(intExp*100)), true);
				if (formatVal(othInc*100) > formatVal(othIncLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesQ"), strVal(othInc*100), strVal(othIncLag*100)), true);
				if (formatVal(othExp*100) < formatVal(othExpLag*100))
					printReport("", string.Format(rm.GetString("fpa_PBTSalesR"), strVal(othExp*100), strVal(othExpLag*100)), true);
			}
			

		}

		private void printProfitB4TaxToTNW()
		{
			string sentence = "";
			string qtsentence = "";
			double netPrftBTax = RG.MACRO(M.PROFIT_BEFORE_TAX)[pBaseID];
			double tnw = RG.MACRO(M.TANGIBLE_NET_WORTH)[pBaseID];
			double netPrftBTaxLag = RG.MACRO(M.PROFIT_BEFORE_TAX, RG.LAG)[pBaseID];
			double tnwLag = RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG)[pBaseID];
			Calc cRatio = RG.MACRO(M.PROFIT_BEFORE_TAX)/RG.YEAR()% RG.MACRO(M.TANGIBLE_NET_WORTH);
			Calc cRatioLag = RG.MACRO(M.PROFIT_BEFORE_TAX, RG.LAG)/RG.YEAR(RG.LAG)% RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG);
			double ratio = cRatio[pBaseID];
			double ratioLag = cRatioLag[pBaseID];
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 32, 33);
			

			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_PBTNWF"), strVal(ratioLag));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_PBTNWG1"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else 
				sentence = string.Format(rm.GetString("fpa_PBTNWG"), rm.GetString(rt.moderSigVsig("PBTNW")), rm.GetString(rt.increaseORdecrease("PBTNW")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			printReport("", string.Format(rm.GetString("fpa_PBTNWB"), strVal(netPrftBTax,0), strVal(tnw,0), this.CurMonth, this.CurDate, strVal(ratio))+ sentence, true);

			if (this.isProperPeer)
			{
				if ((formatVal(tnw) < 0) || (formatVal(netPrftBTax) < 0))
					qtsentence = rm.GetString("fpa_PBTNWP");
				else if (RG.IND(66) < 1 && RG.IND(65) < 1 && RG.IND(64) < 1)
					qtsentence = rm.GetString("fpa_PBTNWO");
				else
				{
					ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 66, 65, 64, false);
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
						qtsentence = string.Format(rm.GetString("fpa_PBTNWK"), strIND(66), strVal(ratio));
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
						qtsentence = string.Format(rm.GetString("fpa_PBTNWL"), strIND(65), strIND(66), strVal(ratio));
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
						qtsentence = string.Format(rm.GetString("fpa_PBTNWM"), strIND(64), strIND(65), strVal(ratio));
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
						qtsentence = string.Format(rm.GetString("fpa_PBTNWN"), strIND(64), strVal(ratio));
				}
				
				printReport("", qtsentence, true);
			}
		}

		private void printProfitB4TaxTotAssets()
		{
			string sentence = "";
			string qtsentence = "";
			double ratio = RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS)[pBaseID];
			double ratioLag = RG.MACRO(M.PROFIT_BEFORE_TAX_TO_TOTAL_ASSETS, RG.LAG)[pBaseID];
			double netPrftBTax = RG.MACRO(M.PROFIT_BEFORE_TAX)[pBaseID];
			double totalAssets = RG.MACRO(M.TOTAL_ASSETS)[pBaseID];
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 34, 35);

			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_PBTF"), strVal(ratioLag));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_PBTG1"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else 
				sentence = string.Format(rm.GetString("fpa_PBTG"), rm.GetString(rt.moderSigVsig("PBT")), rm.GetString(rt.increaseORdecrease("PBT")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			printReport("", string.Format(rm.GetString("fpa_PBTB"), strVal(netPrftBTax,0), strVal(totalAssets,0), this.CurMonth, this.CurDate, strVal(ratio))+ sentence, true);

			if (this.isProperPeer)
			{
				ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 69, 68, 67, false);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					qtsentence = string.Format(rm.GetString("fpa_PBTK"), strIND(69), strVal(ratio));
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					qtsentence = string.Format(rm.GetString("fpa_PBTL"), strIND(68), strIND(69), strVal(ratio));
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_PBTM"), strIND(67), strIND(68), strVal(ratio));
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_PBTN"), strIND(67), strVal(ratio));
				
				printReport("", qtsentence, true);
			}
		}

		private void printNetSalesToTotalAssets()
		{
			string sentence = "";
			string qtsentence = "";
			string analysis = "";
			double ratio = RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS)[pBaseID];
			double ratioLag = RG.MACRO(M.NET_SALES_TO_TOTAL_ASSETS, RG.LAG)[pBaseID];
			
			printReport(rm.GetString("fpa_operEfficiency"), "", true);
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 38, 39);

			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
			{
				sentence = string.Format(rm.GetString("fpa_NSTAF"), strVal(ratioLag));
				analysis = string.Format(rm.GetString("fpa_NSTAO"));
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.increasing) //Seperated the decreasing from here 
			{
				sentence = string.Format(rm.GetString("fpa_NSTAG1"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
				analysis = string.Format(rm.GetString("fpa_NSTAP1"), rm.GetString(rt.increasingORdecreasing("NSTA"))) +
					string.Format(rm.GetString("fpa_NSTAQ"), rm.GetString("fpa_NSTA_more"));
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
			{
				sentence = string.Format(rm.GetString("fpa_NSTAG1"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
				analysis = string.Format(rm.GetString("fpa_NSTAP1"), rm.GetString(rt.increasingORdecreasing("NSTA"))) +
					string.Format(rm.GetString("fpa_NSTAQ"), rm.GetString("fpa_NSTA_fewer"));
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || 
				(rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				sentence = string.Format(rm.GetString("fpa_NSTAG"), rm.GetString(rt.moderSigVsig("NSTA")), rm.GetString(rt.increaseORdecrease("NSTA")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
				analysis = string.Format(rm.GetString("fpa_NSTAP"), rm.GetString(rt.increasedORdecreased("NSTA")), rm.GetString(rt.moderSigVsigly("NSTA"))) +
					string.Format(rm.GetString("fpa_NSTAQ"), rm.GetString("fpa_NSTA_more"));
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || 
				(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
			{
				sentence = string.Format(rm.GetString("fpa_NSTAG"), rm.GetString(rt.moderSigVsig("NSTA")), rm.GetString(rt.increaseORdecrease("NSTA")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
				analysis = string.Format(rm.GetString("fpa_NSTAP"), rm.GetString(rt.increasedORdecreased("NSTA")), rm.GetString(rt.moderSigVsigly("NSTA"))) +
					string.Format(rm.GetString("fpa_NSTAQ"), rm.GetString("fpa_NSTA_fewer"));
			}
			
			printReport("", string.Format(rm.GetString("fpa_NSTAB"), strVal(ratio), this.CurMonth, this.CurDate)+ sentence, true);

			//rtQuart = null;
			string qtAnalysis = "";
			string qtAnalysis1 = "";
			string qtAnalysis2 = "";
			if (this.isProperPeer)
			{
				ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 75, 74, 73, false);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				{
					qtsentence = string.Format(rm.GetString("fpa_NSTAJ"), strIND(75), strVal(ratio));
					qtAnalysis1 = rm.GetString("fpa_NSTA_sigLevel");
					qtAnalysis2 = rm.GetString("fpa_NSTA_fourth");
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
				{
					qtsentence = string.Format(rm.GetString("fpa_NSTAK"), strIND(74), strIND(75), strVal(ratio));
					qtAnalysis1 = rm.GetString("fpa_NSTA_lowLevel");
					qtAnalysis2 = rm.GetString("fpa_NSTA_third");
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				{
					qtsentence = string.Format(rm.GetString("fpa_NSTAL"), strIND(73), strIND(74), strVal(ratio));
					qtAnalysis1 = rm.GetString("fpa_NSTA_highLevel");
					qtAnalysis2 = rm.GetString("fpa_NSTA_second");
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
				{
					qtsentence = string.Format(rm.GetString("fpa_NSTAM"), strIND(73), strVal(ratio));
					qtAnalysis1 = rm.GetString("fpa_NSTA_sigHighLevel");
					qtAnalysis2 = rm.GetString("fpa_NSTA_first");
				}
				
				qtAnalysis = string.Format(rm.GetString("fpa_NSTAR"), qtAnalysis1, qtAnalysis2);
				printReport("", qtsentence, true);
			}

			printReport("", rm.GetString("fpa_NSTAN"), true);
			printReport("", analysis + qtAnalysis + rm.GetString("fpa_NSTAS"), true);

		}

		private void printActReceivable()
		{
			double ratio = RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[pBaseID];
			double ratioLag = RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[pBaseID];
				
			string sentence = "";
			string qtsentence = "";
			string sentence1 = "";

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 7, 8); 

			if ((formatVal(ratio) == 0) && (formatVal(ratioLag) == 0))
				sentence = rm.GetString("fpa_ARDaysA");
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_ARDaysB"), this.CurMonth, this.CurDate, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_ARDaysD"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("ARD")), strVal(ratioLag), strVal(ratio));
			else 
				sentence = string.Format(rm.GetString("fpa_ARDaysC"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD")), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("ARD")), strVal(ratioLag), strVal(ratio));

			if (formatVal(ratio) > formatVal(ratioLag))
				sentence1 = sentence + string.Format(rm.GetString("fpa_ARDaysL"), strVal(ARMgmt(), 0));
			else if (formatVal(ratio) < formatVal(ratioLag))
				sentence1 = sentence + string.Format(rm.GetString("fpa_ARDaysM"), strVal(ARMgmt(), 0));

			//IF no DB
			if (! isProperPeer)
			{
				printReport("", sentence1, true);
				printActReceivableNoPeer(ratio, ratioLag);
				return;
			}

			ratioAnalysis rtQuart = null;
			if (RG.IND(84) < 2 && RG.IND(83) < 2 && RG.IND(82) < 2)
				qtsentence = rm.GetString("fpa_ARDaysF");
			else
			{
				rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 84, 83, 82, true);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					 qtsentence = string.Format(rm.GetString("fpa_ARDaysG"), strIND(84,0), strVal(ratio));
				 else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					 qtsentence = string.Format(rm.GetString("fpa_ARDaysH"), strIND(83,0), strIND(84,0), strVal(ratio));
				 else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				 {
					 if (RG.IND(82) == 0)
						 qtsentence = string.Format(rm.GetString("fpa_ARDaysK"), strIND(83,0), strVal(ratio));
					 else
						 qtsentence = string.Format(rm.GetString("fpa_ARDaysI"), strIND(82,0), strIND(83,0), strVal(ratio));
				 }
				 else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					 qtsentence = string.Format(rm.GetString("fpa_ARDaysJ"), strIND(82,0), strVal(ratio));
			}
						
			printReport("", sentence + qtsentence, true);

			//Printing AR Mgmt
			sentence = "";
			if (formatVal(ratio) > formatVal(ratioLag))
				sentence = string.Format(rm.GetString("fpa_ARDaysL"), strVal(ARMgmt(), 0));
			else if (formatVal(ratio) < formatVal(ratioLag))
				sentence = string.Format(rm.GetString("fpa_ARDaysM"), strVal(ARMgmt(), 0));

			printReport("", sentence, true);

			if ((formatVal(ratio) == 0) && (formatVal(ratioLag) == 0))
				return;
			if (rtQuart == null) return;
			sentence = "";
			if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = rm.GetString("fpa_ARDaysS1") + rm.GetString("fpa_ARDaysT");
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					sentence = rm.GetString("fpa_ARDaysS2") + rm.GetString("fpa_ARDaysT");
				else 
				{
					if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)|| 
						(rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate))
						sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))) +
						rm.GetString("fpa_ARDaysU");
					else
						sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))) +
							rm.GetString("fpa_ARDaysT");

				}

				printReport("", sentence, true);
				if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
					printReport("", rm.GetString("fpa_ARDaysW"), true);
				printReport("", rm.GetString("fpa_ARDaysV"), true);
				printReport("", rm.GetString("fpa_ARDaysV1"), true);
				printReport("", rm.GetString("fpa_ARDaysV2"), true);
				printReport("", rm.GetString("fpa_ARDaysV3"), true);
				printReport("", rm.GetString("fpa_ARDaysV4"), true);
				printReport("", rm.GetString("fpa_ARDaysV5"), true);

			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = rm.GetString("fpa_ARDaysS1") + rm.GetString("fpa_ARDaysX");
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					sentence = rm.GetString("fpa_ARDaysS2") + rm.GetString("fpa_ARDaysX");
				else
				{
					sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))) +
						rm.GetString("fpa_ARDaysY");
					if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
						sentence = sentence + rm.GetString("fpa_ARDaysW");
					
					sentence = sentence + rm.GetString("fpa_ARDaysZ");
				}
				printReport("", sentence, true);
				
			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);
				sentence = "";
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				{
					printReport("", rm.GetString("fpa_ARDaysS1") + rm.GetString("fpa_ARDaysaa") +
						rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1"), true);
					//printReport("", rm.GetString("fpa_ARDaysaa"), true);
					//printReport("", rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1"), true);
				}
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				{
					printReport("", rm.GetString("fpa_ARDaysS2") + rm.GetString("fpa_ARDaysaa")+
						rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1"), true);
					//printReport("", rm.GetString("fpa_ARDaysaa"), true);
					//printReport("", rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1"), true);
				}
				else 
				{
					//printReport("", string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))), true);
					sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD")));
					if (ratio > ratioLag)
						//printReport("", rm.GetString("fpa_ARDayscc"), true);
						sentence = sentence + rm.GetString("fpa_ARDayscc");
					else
						sentence = sentence + rm.GetString("fpa_ARDaysaa");
					//printReport("", rm.GetString("fpa_ARDaysaa"), true);

					if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					{
						//printReport("", rm.GetString("fpa_ARDaysdd"), true);
						//printReport("", rm.GetString("fpa_ARDaysW"), true);
						sentence = sentence + rm.GetString("fpa_ARDaysdd")+ rm.GetString("fpa_ARDaysW");
					}
					else
					{
						if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
							//printReport("", rm.GetString("fpa_ARDaysW"), true);
							sentence = sentence + rm.GetString("fpa_ARDaysW");
						sentence = sentence + rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1");
						//printReport("", rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb1"), true);
					}
					printReport("", sentence, true);
				}
			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);

				if(RG.IND(82) == 0) //Undefined upper
				{
					sentence = "";
					//printReport("", string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))), true);
					sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD")));
					if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
					{
						//printReport("", rm.GetString("fpa_ARDaysaa") + rm.GetString("fpa_ARDaysdd"), true);
						//printReport("", rm.GetString("fpa_ARDaysW"), true);
						sentence = sentence + rm.GetString("fpa_ARDaysaa") + rm.GetString("fpa_ARDaysdd") + rm.GetString("fpa_ARDaysW");
					}
					else 
						sentence = sentence + rm.GetString("fpa_ARDaysaa") + rm.GetString("fpa_ARDaysbb") + rm.GetString("fpa_ARDaysbb1");
					//printReport("", rm.GetString("fpa_ARDaysaa") + rm.GetString("fpa_ARDaysbb") + rm.GetString("fpa_ARDaysbb1"), true);
				}
				else
				{
					sentence = "";
					if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					{
						//printReport("", rm.GetString("fpa_ARDaysS1"), true);
						//printReport("", rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb"), true);
						//printReport("", rm.GetString("fpa_ARDaysbb1")+rm.GetString("fpa_ARDaysgg"), true);
						sentence = rm.GetString("fpa_ARDaysS1") + rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb")+
							rm.GetString("fpa_ARDaysbb1")+rm.GetString("fpa_ARDaysgg");
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					{
						//printReport("", rm.GetString("fpa_ARDaysS2"), true);
						//printReport("", rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb"), true);
						//printReport("", rm.GetString("fpa_ARDaysbb1")+rm.GetString("fpa_ARDaysgg"), true);
						sentence =  rm.GetString("fpa_ARDaysS2")+rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb")+
							rm.GetString("fpa_ARDaysbb1")+rm.GetString("fpa_ARDaysgg");
					}
					else 
					{
						sentence = "";
						sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD")));
						//printReport("", string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD"))), true);
				    
						if (ratio > ratioLag)
							//printReport("", rm.GetString("fpa_ARDaysff") + rm.GetString("fpa_ARDayshh"), true); //change to hh from bb.
							sentence = sentence + rm.GetString("fpa_ARDaysff") + rm.GetString("fpa_ARDayshh");
						else
							//printReport("", rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb"), true);
							sentence = sentence + rm.GetString("fpa_ARDaysee") + rm.GetString("fpa_ARDaysbb");

						if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||  (rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate)||
							(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
						{
							//printReport("", rm.GetString("fpa_ARDaysbb1")+ rm.GetString("fpa_ARDaysgg"), true);
							sentence = sentence + rm.GetString("fpa_ARDaysbb1")+ rm.GetString("fpa_ARDaysgg");
						}
						else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant))
							//printReport("", rm.GetString("fpa_ARDaysW"), true);
							sentence = sentence + rm.GetString("fpa_ARDaysW");
							
					}
				}
				printReport("", sentence, true);
			}


		}

		private void printActReceivableNoPeer(double ratio, double ratioLag)
		{
			string sentence = "";
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 7, 8); 

			if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);
				printReport("", rm.GetString("fpa_ARDaysW"), true);
				printReport("", rm.GetString("fpa_ARDaysV10"), true);
				printReport("", rm.GetString("fpa_ARDaysV2"), true);
				printReport("", rm.GetString("fpa_ARDaysV3"), true);
				printReport("", rm.GetString("fpa_ARDaysV4"), true);
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
			{
				printReport("", rm.GetString("fpa_ARDaysR"), true);
				sentence = string.Format(rm.GetString("fpa_ARDaysS"), rm.GetString(rt.increasedORdecreased("ARD")), rm.GetString(rt.moderSigVsigly("ARD")));
				sentence = sentence + rm.GetString("fpa_ARDaysbb")+rm.GetString("fpa_ARDaysbb2");
				printReport("", sentence, true);
			}


		}

		public double ARMgmt()
		{
			//1600
			Calc netSlsByFlow = (RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS))*RG.CONV_RATE();
			//1600LAG
			Calc netSlsByFlowLag = (RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS, RG.LAG) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS, RG.LAG))*RG.CONV_RATE(RG.LAG);
			//1602
			Calc netSlsGrwByFlow = ((netSlsByFlow/RG.YEAR()) - (netSlsByFlowLag/RG.YEAR(RG.LAG)))%(netSlsByFlowLag/RG.YEAR(RG.LAG));
			//1650
			Calc ARGrowth = (RG.AND(15, RG.ANDFLOW, 5, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 5, RG.ANDCLASS) -
				             RG.AND(15, RG.ANDFLOW, 20, RG.ANDCLASS))*RG.CONV_RATE();
			//1650LAG
			Calc ARGrowthLag = (RG.AND(15, RG.ANDFLOW, 5, RG.ANDCLASS, RG.LAG) - RG.AND(20, RG.ANDFLOW, 5, RG.ANDCLASS, RG.LAG) -
				RG.AND(15, RG.ANDFLOW, 20, RG.ANDCLASS, RG.LAG))*RG.CONV_RATE(RG.LAG);
			//1655
			Calc calc1655 = -1 *ARGrowthLag*netSlsGrwByFlow/100;
			//1660
			Calc ARMgmt =ARGrowthLag - calc1655 - ARGrowth;
			return Math.Abs(ARMgmt[pBaseID]);
		}

		private double inventoryMgmt()
		{
			//1600
			Calc netSlsByFlow = (RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS))*RG.CONV_RATE();
			//1600LAG
			Calc netSlsByFlowLag = (RG.AND(15, RG.ANDFLOW, 30, RG.ANDCLASS, RG.LAG) - RG.AND(20, RG.ANDFLOW, 30, RG.ANDCLASS, RG.LAG))*RG.CONV_RATE(RG.LAG);
			//1602
			Calc netSlsGrwByFlow = ((netSlsByFlow/RG.YEAR()) - (netSlsByFlowLag/RG.YEAR(RG.LAG)))%(netSlsByFlowLag/RG.YEAR(RG.LAG));
			//1601
			Calc cashCOGS = (RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE());
			Calc cashCOGSLAG = RG.MODIFYCALC(cashCOGS, RG.LAG);
			//1605
			Calc cogsGrwth = ((cashCOGS/RG.YEAR()) - (cashCOGSLAG/RG.YEAR(RG.LAG)))%(cashCOGSLAG/RG.YEAR(RG.LAG));
			Calc LINE1606 = new Calc(0, RG.Statements.Count);
			//1700
			Calc invGrwDueToSls = (RG.AND(25, RG.ANDFLOW, 5, RG.ANDCLASS) * RG.CONV_RATE());
			Calc invGrwDueToSlsLAG = RG.MODIFYCALC(invGrwDueToSls, RG.LAG);

			for (int i=0; i < cashCOGS.Count; i++)
			{
				if (cashCOGS[i] == 0)
					LINE1606[i] = netSlsGrwByFlow[i];
				else
					LINE1606[i] = cogsGrwth[i];
			}
			//1705
			Calc grwDueToCOGS = -1*invGrwDueToSlsLAG*LINE1606/100;
			Calc mgmtOfInventory = invGrwDueToSlsLAG - grwDueToCOGS - invGrwDueToSls;

			return Math.Abs(mgmtOfInventory[pBaseID]);
		}

		public void printInventory()
		{
			if (this.isSeviceInd)
			{
				printReport("", rm.GetString("fpa_INVDaysServInd"), true);
				return;
			}
			string sentence = "";
			string qtsentence = "";
			double ratio = RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[pBaseID];
			double ratioLag = RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[pBaseID];

			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 9, 10);
			if ((formatVal(ratio) == 0)&& (formatVal(ratioLag) == 0))
			{
				printReport("", rm.GetString("fpa_INVDaysA"), true);
				return;
			}
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_INVDaysB"), this.CurYear, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_INVDaysC1"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, strVal(ratioLag), strVal(ratio));
			else 
				sentence = string.Format(rm.GetString("fpa_INVDaysC"), rm.GetString(rt.increasedORdecreased("INV")), rm.GetString(rt.moderSigVsigly("INV")), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("INV")), strVal(ratioLag), strVal(ratio));
			
			
			ratioAnalysis rtQuart = null;
			if (this.isProperPeer)
			{
				rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 87, 86, 85, true);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					qtsentence = string.Format(rm.GetString("fpa_INVDaysG"), strIND(87,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					qtsentence = string.Format(rm.GetString("fpa_INVDaysH"), strIND(86,0), strIND(87,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_INVDaysI"), strIND(85,0), strIND(86,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_INVDaysJ"), strIND(85,0), strVal(ratio));
				
				printReport("", sentence + qtsentence, true);
			}
			else
				printReport("", sentence, true);

			string invMgmt = strVal(inventoryMgmt(), 0);
			if (formatVal(ratio) > formatVal(ratioLag))
				printReport("", string.Format(rm.GetString("fpa_INVDaysK"), invMgmt, this.CurMonth, this.CurDate), true);
			else if (formatVal(ratio) < formatVal(ratioLag))
				printReport("", string.Format(rm.GetString("fpa_INVDaysL"), invMgmt, this.CurMonth, this.CurDate), true);

			double rawMaterial = (RG.TYPE(15)%(RG.TYPE(15) + RG.TYPE(16) + RG.TYPE(17)))[pBaseID];
			double WIP = (RG.TYPE(16) % (RG.TYPE(15) + RG.TYPE(16) + RG.TYPE(17)))[pBaseID];
			double finGoods = (RG.TYPE(17) % (RG.TYPE(15) + RG.TYPE(16) + RG.TYPE(17)))[pBaseID];
			double rawMaterialLag = (RG.TYPE(15, RG.LAG) % (RG.TYPE(15, RG.LAG) + RG.TYPE(16, RG.LAG) + RG.TYPE(17, RG.LAG)))[pBaseID];
			double WIPLag = (RG.TYPE(16, RG.LAG) % (RG.TYPE(15, RG.LAG) + RG.TYPE(16, RG.LAG) + RG.TYPE(17, RG.LAG)))[pBaseID];
			double finGoodsLag = (RG.TYPE(17, RG.LAG) % (RG.TYPE(15, RG.LAG) + RG.TYPE(16, RG.LAG) + RG.TYPE(17, RG.LAG)))[pBaseID];

			if (formatVal(rawMaterial) != formatVal(rawMaterialLag))
				printReport("", string.Format(rm.GetString("fpa_INVDaysM"), strVal(rawMaterial), CurMonth, CurDate, strVal(rawMaterialLag), PrevMonth, PrevDate), true);
			if (formatVal(WIP) != formatVal(WIPLag))
				printReport("", string.Format(rm.GetString("fpa_INVDaysN"), strVal(WIP), CurMonth, CurDate, strVal(WIPLag), PrevMonth, PrevDate), true);
			if (formatVal(finGoods) != formatVal(finGoodsLag))
				printReport("", string.Format(rm.GetString("fpa_INVDaysO"), strVal(finGoods), CurMonth, CurDate, strVal(finGoodsLag), PrevMonth, PrevDate), true);
		
			string common = rm.GetString("fpa_INVDaysP");
			
			if (this.isProperPeer)
			{
				string incrCommon = rm.GetString("fpa_INVDaysR")+rm.GetString("fpa_INVDaysS") +
					rm.GetString("fpa_INVDaysT") + rm.GetString("fpa_INVDaysU");
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				{
					printReport("", common, true);
					if ((rt.GrowthType == ratioAnalysis.eGrowthType.noChange) || (rt.GrowthType == ratioAnalysis.eGrowthType.increasing) ||
						(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					{
						printReport("", rm.GetString("fpa_INVDaysQ")+rm.GetString("fpa_INVDaysR")+rm.GetString("fpa_INVDaysS") +
							rm.GetString("fpa_INVDaysT") + rm.GetString("fpa_INVDaysU"), true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
						(rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
					{
						
						printReport("", rm.GetString("fpa_INVDaysV")+ incrCommon, true);
					}
					else
						printReport("", rm.GetString("fpa_INVDaysW")+ incrCommon, true);
						
					
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
				{
					//printReport("", common, true);
					if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					{
						printReport("", common, true);
						printReport("", rm.GetString("fpa_INVDaysX")+rm.GetString("fpa_INVDaysY") + incrCommon, true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) ||	(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					{
						printReport("", common, true);
						printReport("", rm.GetString("fpa_INVDaysZ")+rm.GetString("fpa_INVDaysY") + incrCommon, true);
					}
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV1") + rm.GetString("fpa_INVDaysS") +
							rm.GetString("fpa_INVDaysT") + rm.GetString("fpa_INVDaysS"), true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) ||
						(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysW1") + rm.GetString("INVDaysR") + rm.GetString("fpa_INVDaysS") +
							rm.GetString("fpa_INVDaysT") + rm.GetString("fpa_INVDaysU"), true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)|| (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV1") + rm.GetString("fpa_INVDaysS") + rm.GetString("fpa_INVDaysT") ,true); 
						printReport("", rm.GetString("fpa_INVDaysaa")+ rm.GetString("fpa_INVDaysU"), true);
					}
					
				}
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				{
					
					if (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV2") + rm.GetString("INVDaysbb") +rm.GetString("INVDaysaa"), true);
					}
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV2") + rm.GetString("INVDaysR1") +rm.GetString("INVDaysS")+ rm.GetString("INVDaysT"), true);
						printReport("", rm.GetString("INVDaysaa")+rm.GetString("INVDaysU"), true);
					}

				}
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
				{
					
					//printReport("", common, true);
					if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					{
						printReport("", common, true);
						printReport("", rm.GetString("fpa_INVDaysX")+rm.GetString("fpa_INVDayscc") + 
							rm.GetString("fpa_INVDaysd")+rm.GetString("fpa_INVDayse")+rm.GetString("fpa_INVDaysf"), true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) ||	(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					{
						printReport("", common, true);
						printReport("", rm.GetString("fpa_INVDaysZ")+rm.GetString("fpa_INVDayscc") + 
							rm.GetString("fpa_INVDaysd")+rm.GetString("fpa_INVDayse")+rm.GetString("fpa_INVDaysf"), true);
					}
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV3") + rm.GetString("fpa_INVDaysd"), true);
						printReport("",	rm.GetString("fpa_INVDaysgg") + rm.GetString("fpa_INVDaysf"), true);
					}
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate) || 
						(rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || 
						(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
					{
						printReport("", common, true);
						printReport("", rm.GetString("fpa_INVDaysW2") + rm.GetString("fpa_INVDaysd"), true);
						printReport("",rm.GetString("fpa_INVDaysgg") + rm.GetString("fpa_INVDaysf"), true);
					}
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV3") + rm.GetString("fpa_INVDaysd") +
							rm.GetString("fpa_INVDayshh") + rm.GetString("fpa_INVDaysf"), true);
					}
						//else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
						//printReport("", rm.GetString("fpa_INVDaysW2") + rm.GetString("fpa_INVDaysd") +
						//rm.GetString("fpa_INVDaysgg") + rm.GetString("fpa_INVDaysf"), true);
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					{
						printReport("", common, true);
						printReport("", rm.GetString("INVDaysV3") + rm.GetString("fpa_INVDayshh"), true);
						printReport("", rm.GetString("fpa_INVDaysaa") + rm.GetString("fpa_INVDaysU"), true);
					}
					
				}
				
			}
			else //NO Peer
			{
				//printReport("", common, true);
				string s = string.Format(rm.GetString("fpa_INVDaysii"), rm.GetString(rt.moderSigVsigly("INV"))) +
					rm.GetString("fpa_INVDaysbb") + rm.GetString("fpa_INVDaysS") +rm.GetString("fpa_INVDaysT");
				if (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate)
				{
					printReport("", common, true);
					printReport("", s, true);
				}
				else if((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
				{
					printReport("", common, true);
					printReport("", s , true);
					printReport("", rm.GetString("fpa_INVDaysaa"), true);
					printReport("", rm.GetString("fpa_INVDaysU"), true);
				}
			}
		    
		}


		private void printActPayable()
		{
			double ratio = RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[pBaseID];
			double ratioLag = RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[pBaseID];

			string sentence = "";
			string qtsentence = "";
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 11, 12);
			if ((formatVal(ratio) == 0) && (formatVal(ratioLag) == 0))
				sentence = rm.GetString("fpa_APDaysA");
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_APDaysB"), this.CurMonth, this.CurDate, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_APDaysC"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, strVal(ratioLag), strVal(ratio));
			else 
				sentence = string.Format(rm.GetString("fpa_APDaysD"), rm.GetString(rt.increasedORdecreased("APD")), rm.GetString(rt.moderSigVsigly("APD")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);

			
			ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 90, 89, 88, true);
			if ((isProperPeer) && (formatVal(ratio) > 0))
			{
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					qtsentence = string.Format(rm.GetString("fpa_APDaysE"), strIND(90,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					qtsentence = string.Format(rm.GetString("fpa_APDaysF"), strIND(89,0), strIND(90,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_APDaysG"), strIND(88,0), strIND(89,0), strVal(ratio));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_APDaysH"), strIND(88,0), strVal(ratio));
				printReport("", sentence + qtsentence, true);
			}
			else
				printReport("", sentence, true);
			
			//Cash Flow Effect on AP Days
			double apCashImpact = CashFlowEffect();
			if (!this.isSeviceInd)
			{
				if (formatVal(apCashImpact) > 0)
					printReport("", string.Format(rm.GetString("fpa_APDaysI"), strVal(Math.Abs(apCashImpact),0), this.CurMonth, this.CurDate), true);
				else if (formatVal(apCashImpact) < 0)
					printReport("", string.Format(rm.GetString("fpa_APDaysJ"), strVal(Math.Abs(apCashImpact),0), this.CurMonth, this.CurDate), true);
			}

			if ((formatVal(ratio) == 0) && (formatVal(ratioLag) == 0))
				return;

			ArrayList reason = new ArrayList();
			if (rt.GrowthType != ratioAnalysis.eGrowthType.noChange)
			{
				reason.Add(rm.GetString("fpa_APDAnalysisK"));
			}

			if (isProperPeer)
			{
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				{
				
					reason.Add(rm.GetString("fpa_APDAnalysisL")+rm.GetString("fpa_APDAnalysisM"));
					reason.Add(rm.GetString("fpa_APDAnalysisN") + rm.GetString("fpa_APDAnalysisO")+ rm.GetString("fpa_APDAnalysisP"));
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				{
					if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					{
						reason.Add(rm.GetString("fpa_APDAnalysisQ")+rm.GetString("fpa_APDAnalysisR") + rm.GetString("fpa_APDAnalysisS"));

					}
					else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant)
					{
						reason.Add(rm.GetString("fpa_APDAnalysisQ1")+rm.GetString("fpa_APDAnalysisR") + rm.GetString("fpa_APDAnalysisS"));
					}
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
				{
					if ((rt.GrowthType == ratioAnalysis.eGrowthType.noChange) || (rt.GrowthType == ratioAnalysis.eGrowthType.increasing) ||
						(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) ||
						(rt.GrowthType == ratioAnalysis.eGrowthType.decrModerate))
						reason.Add(rm.GetString("fpa_APDAnalysisQ2")+rm.GetString("fpa_APDAnalysisR") + rm.GetString("fpa_APDAnalysisS"));
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
						reason.Add(rm.GetString("fpa_APDAnalysisQ") + rm.GetString("fpa_APDAnalysisQ3")+rm.GetString("fpa_APDAnalysisR") + rm.GetString("fpa_APDAnalysisS"));
					else if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
						reason.Add(rm.GetString("fpa_APDAnalysisQ1") + rm.GetString("fpa_APDAnalysisQ3")+rm.GetString("fpa_APDAnalysisR") + rm.GetString("fpa_APDAnalysisS"));
				}
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) || (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant) ||
				(rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				reason.Add(rm.GetString("fpa_APDAnalysisQ")+rm.GetString("fpa_APDAnalysisR1"));
				reason.Add(rm.GetString("fpa_APDAnalysisN") + rm.GetString("fpa_APDAnalysisO")+ rm.GetString("fpa_APDAnalysisP"));
			}

			for (int i=0; i < reason.Count; i++)
			{
				printReport("", reason[i].ToString(), true);
			}
					
		}
		private double CashFlowEffect()
		{
			Calc NetSalesGwth = RG.MACRO(M.NET_SALES_GROWTH);
			Calc LINE974 = RG.AND(25, RG.ANDFLOW, 30, RG.ANDCLASS) * RG.CONV_RATE();
			Calc LINE974LAG = RG.MODIFYCALC(LINE974, RG.LAG);
			Calc LINE976 = new Calc(0, RG.Statements.Count);
			for (int i = 0; i < LINE974.Count; i++) 
			{
				if (LINE974[i] == 0)
					LINE976[i] = NetSalesGwth[i];
				else
					LINE976[i] = (((LINE974[i] / RG.YEAR()[i] - LINE974LAG[i] / RG.YEAR(RG.LAG)[i]) / (LINE974LAG[i] / RG.YEAR(RG.LAG)[i])) * 100);
			}

			Calc LINE1730 = RG.AND(25, RG.ANDFLOW, 15, RG.ANDCLASS) * RG.CONV_RATE();
			Calc LINE1730LAG = RG.MODIFYCALC(LINE1730, RG.LAG);
			Calc LINE1728 = LINE1730LAG*LINE976 / 100;
			Calc LINE1735 = LINE1730 - LINE1728 - LINE1730LAG;

			return LINE1735[pBaseID];
		}


		private void printNetSalesToNetFixAssets()
		{
			string sentence = "";
			string common = "";
			double ratio = (RG.MACRO(M.NET_SALES)[pBaseID]/RG.YEAR()[pBaseID])/RG.MACRO(M.NET_FIXED_ASSETS)[pBaseID];
			double ratioLag = (RG.MACRO(M.NET_SALES, RG.LAG)[pBaseID]/RG.YEAR(RG.LAG)[pBaseID])/RG.MACRO(M.NET_FIXED_ASSETS, RG.LAG)[pBaseID];
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 36, 37);
			
			common = string.Format(rm.GetString("fpa_salesToFxAsstsA"), strVal(ratio), this.CurMonth, this.CurDate);
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = rm.GetString("fpa_salesToFxAsstsB");
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_salesToFxAsstsC"), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			else
				sentence = string.Format(rm.GetString("fpa_salesToFxAsstsD"), rm.GetString(rt.moderSigVsig("NSFA")), rm.GetString(rt.increaseORdecrease("NSFA")), strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			printReport("", common+sentence, true);

			if (!isProperPeer)
				return;
			ArrayList reason = new ArrayList();
			ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 72, 71, 70, false);
			if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
			{
				reason.Add(string.Format(rm.GetString("fpa_NSAnalysisA"), strIND(72), strVal(ratio)));
				reason.Add(rm.GetString("fpa_NSAnalysisC")) ;
				reason.Add(rm.GetString("fpa_NSAnalysisD"));
			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
			{
				reason.Add(string.Format(rm.GetString("fpa_NSAnalysisE"), strIND(71), strIND(72), strVal(ratio)));
				reason.Add(rm.GetString("fpa_NSAnalysisC"));
				reason.Add(rm.GetString("fpa_NSAnalysisD"));			
			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
			{
				reason.Add(string.Format(rm.GetString("fpa_NSAnalysisF"), strIND(70), strIND(71), strVal(ratio)));
				reason.Add(rm.GetString("fpa_NSAnalysisG"));
				reason.Add(rm.GetString("fpa_NSAnalysisD"));
				reason.Add(rm.GetString("fpa_NSAnalysisH"));
			}
			else if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
			{
				reason.Add(string.Format(rm.GetString("fpa_NSAnalysisI"), strIND(70), strVal(ratio)));
				reason.Add(rm.GetString("fpa_NSAnalysisG"));
				reason.Add(rm.GetString("fpa_NSAnalysisD"));
				reason.Add(rm.GetString("fpa_NSAnalysisH"));
			}

			for (int i=0; i < reason.Count; i++)
			{
				if(i== 1)
					printReport("", rm.GetString("fpa_NSAnalysisB"), true);
				printReport("", reason[i].ToString(), true);
			}


		}
		
		private void calculateDebtService()
		{
			//Debt Service Intro
			double ratio = RG.MACRO(M.UCA_CASH_FLOW_COVERAGE)[pBaseID];
			double ratioLag = RG.MACRO(M.UCA_CASH_FLOW_COVERAGE, RG.LAG)[pBaseID];
			printDebtServiceIntro(ratio);
			string uca = printUCACFCoverage(ratio, ratioLag);
			printNetCashAftOp(ratio, uca);
			if(formatVal(ratio) > 0)
				printReport("", rm.GetString("fpa_debtSFund"), true);
			printNetIncDeprAmortDivCpltd();
			printInterestCoverage();
		}

		private void printDebtServiceIntro(double ucaCF)
		{
			printReport(rm.GetString("fpa_debtSDeprHdr"), "", true);
			printReport("", rm.GetString("fpa_debtSA"), true);
			printReport("", rm.GetString("fpa_debtSB"), true);
			
			//if (formatVal(ucaCF) <= 0)
				//printReport("", rm.GetString("fpa_debtSC"), true);
		}

		private string printUCACFCoverage(double ratio, double ratioLag)
		{
			string sentence = "";
			
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 15, 16);
			if (formatVal(ratio) <= 0)
				sentence = rm.GetString("fpa_ucaCFA");
			else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_ucaCFB"), this.CurYear, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_ucaCFC"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, strVal(ratioLag), strVal(ratio));
			else
				sentence = string.Format(rm.GetString("fpa_ucaCFD"), rm.GetString(rt.increasedORdecreased("ucaCF")), rm.GetString(rt.moderSigVsigly("ucaCF")), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, strVal(ratioLag), strVal(ratio));
			
			//printReport("", sentence, true);
			return sentence;
						
		}


		private void printNetCashAftOp(double ratio, string ucaString)
		{
			
			string sentence = "";
			string netCshOp = "";
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, 29);
			if (rt.Adequate == ratioAnalysis.eAdequate.ignoreAnalysis)
			{
				printReport("", ucaString, true);
				return;
			}
			else if(rt.Adequate == ratioAnalysis.eAdequate.notAdequate)
				sentence = rm.GetString("fpa_netCshNotAdq");
			else if ((rt.Adequate == ratioAnalysis.eAdequate.adequate) ||
				(rt.Adequate == ratioAnalysis.eAdequate.adequatePlus))
				sentence = rm.GetString("fpa_netCshAdq");
			else if (rt.Adequate == ratioAnalysis.eAdequate.adequatePlusPlus)
				sentence = rm.GetString("fpa_netCshMtAdq");
			if(sentence != "")
			{
				netCshOp = string.Format(rm.GetString("fpa_netCshOpA"), sentence, this.CurMonth, this.CurDate);
				printReport("", ucaString+netCshOp, true);
			}
			else
				printReport("", ucaString, true);
		}


		private void printNetIncDeprAmortDivCpltd()
		{
			double ratio = RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[pBaseID];
			double ratioLag = RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD, RG.LAG)[pBaseID];
			
			string chgsentence = "";
			string qtsentence = "";
			string adqsentence = "";
			string netIncDepr = "";

			//ModSigOrVerySig
			ratioAnalysis rtChgAmt = new ratioAnalysis(RG, ratio, ratioLag, 17, 18);
			if (rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				chgsentence = string.Format(rm.GetString("fpa_NetIncDeprA"), strVal(ratio));
			else if ((rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				chgsentence = string.Format(rm.GetString("fpa_NetIncDeprB"), rm.GetString(rtChgAmt.increasingORdecreasing("debtS")), strVal(ratio), strVal(ratioLag));
			else
				chgsentence = string.Format(rm.GetString("fpa_NetIncDeprC"), rm.GetString(rtChgAmt.increasedORdecreased("debtS")), rm.GetString(rtChgAmt.moderSigVsigly("debtS")), strVal(ratioLag), strVal(ratio));

			//QUART
			if (isProperPeer)
			{
				ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 57, 56, 55, false);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					qtsentence = string.Format(rm.GetString("fpa_NetIncDeprH"), strIND(57));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					qtsentence = string.Format(rm.GetString("fpa_NetIncDeprI"), strIND(56), strIND(57));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_NetIncDeprJ"), strIND(55), strIND(56));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_NetIncDeprK"), strIND(55));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.noRMA)
					qtsentence = string.Format(rm.GetString("fpa_NetIncDeprL"));
			}

			//Adequate
			ratioAnalysis rtAdq = new ratioAnalysis(RG, ratio, 30);
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.ignoreAnalysis)
				adqsentence = rm.GetString("fpa_NetIncDeprN");
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.notAdequate)
				adqsentence = string.Format(rm.GetString("fpa_NetIncDeprD"), strVal(RG.PARM(30),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequate)
				adqsentence = string.Format(rm.GetString("fpa_NetIncDeprE"), strVal(RG.PARM(30),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequatePlus)
				adqsentence = string.Format(rm.GetString("fpa_NetIncDeprF"), strVal(RG.PARM(30),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequatePlusPlus)
				adqsentence = string.Format(rm.GetString("fpa_NetIncDeprG"), strVal(RG.PARM(30),2));

			//if (adq < 45)
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.ignoreAnalysis)
			{
				printReport("", rm.GetString("fpa_NetIncDeprN"), true);
				return;
			}

			netIncDepr = chgsentence + qtsentence + adqsentence;
			printReport("", netIncDepr, true);
								
			printReport("", rm.GetString("fpa_NetIncDeprM"), true);

		}

		private void printInterestCoverage()
		{

			double ratio = RG.MACRO(M.INTEREST_COVERAGE)[pBaseID];
			double ratioLag = RG.MACRO(M.INTEREST_COVERAGE, RG.LAG)[pBaseID];
			double intExpense = RG.MACRO(M.INTEREST_EXPENSE_RC)[pBaseID];
			

			string chgsentence = "";
			string qtsentence = "";
			string adqsentence = "";
			string strExpense = "";
			
			//QUART
			if (isProperPeer)
			{
				ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 54, 53, 52, false);
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				{
					qtsentence = string.Format(rm.GetString("fpa_IntCovI"), strIND(54));
					strExpense = string.Format(rm.GetString("fpa_IntCovCC"), strIND(54));
					
				}
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
				{
					qtsentence = string.Format(rm.GetString("fpa_IntCovJ"), strIND(53), strIND(54));
					strExpense = string.Format(rm.GetString("fpa_IntCovDD"), strIND(53), strIND(54));
				}
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				{
					qtsentence = string.Format(rm.GetString("fpa_IntCovK"), strIND(52), strIND(53));
					strExpense = string.Format(rm.GetString("fpa_IntCovDD"), strIND(52), strIND(53));
				}
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_IntCovL"), strIND(52));
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.noRMA)
					qtsentence = string.Format(rm.GetString("fpa_IntCovM"));
			}

			//ModSigOrVerySig
			ratioAnalysis rtChgAmt = new ratioAnalysis(RG, ratio, ratioLag, 21, 22);
			if (formatVal(ratio) < 0)
				chgsentence = string.Format(rm.GetString("fpa_IntCovA"));
			else if (rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.noChange)
			{
				chgsentence = string.Format(rm.GetString("fpa_IntCovB"), strVal(ratio));
			}
			else if ((rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rtChgAmt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
			{
				chgsentence = string.Format(rm.GetString("fpa_IntCovC"), rm.GetString(rtChgAmt.increasingORdecreasing("INTC")), strVal(ratioLag), strVal(ratio));
			}
			else
				chgsentence = string.Format(rm.GetString("fpa_IntCovD"), rm.GetString(rtChgAmt.increasedORdecreased("INTC")), rm.GetString(rtChgAmt.moderSigVsigly("debtS")), strVal(ratioLag), strVal(ratio));
			
			//Adequate
			ratioAnalysis rtAdq = new ratioAnalysis(RG, ratio, 31);
			
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.notAdequate)
				adqsentence = string.Format(rm.GetString("fpa_IntCovE"), strVal(RG.PARM(31),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequate)
				adqsentence = string.Format(rm.GetString("fpa_IntCovF"), strVal(RG.PARM(31),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequatePlus)
				adqsentence = string.Format(rm.GetString("fpa_IntCovG"), strVal(RG.PARM(31),2));
			if (rtAdq.Adequate == ratioAnalysis.eAdequate.adequatePlusPlus)
				adqsentence = string.Format(rm.GetString("fpa_IntCovH"), strVal(RG.PARM(31),2));

			string intCoverage = chgsentence + qtsentence + adqsentence;
						
			if (this.isProperPeer)
			{
				if(formatVal(intExpense) == 0)
					printReport("", rm.GetString("fpa_IntCovBB"), true);
				else if(formatVal(ratioLag) == 0)
					printReport("", rm.GetString("fpa_IntCovAA"), true);
				else
					printReport("", intCoverage, true);
				
			}
			else
			{
				if(formatVal(ratioLag) == 0)
					printReport("", rm.GetString("fpa_IntCovN"), true);
				printReport("", intCoverage, true);
			}

			double netProfit = formatVal(RG.MACRO(M.NET_PROFIT)[pBaseID]);
			double cshFlowCov = formatVal(RG.MACRO(M.UCA_CASH_FLOW_COVERAGE)[pBaseID]);
			double netIncDep = formatVal(RG.MACRO(M.NET_INCOME_PLUS_DEPR_AND_AMORT_TO_CPLTD)[pBaseID]);
			//analysis
			ArrayList analysis = new ArrayList();
			if ((netProfit > 0)&&(cshFlowCov < RG.PARM(29)) && (netIncDep > RG.PARM(31))) //2322
				analysis.Add(rm.GetString("fpa_IntCovB1"));
			if ((cshFlowCov > RG.PARM(29)) && (netIncDep < RG.PARM(31)) && ((RG.TYPE(80)[pBaseID]+RG.TYPE(81)[pBaseID]) != 0)) //2323
				analysis.Add(rm.GetString("fpa_IntCovC1"));
			if ((cshFlowCov < RG.PARM(29)) && (netIncDep < RG.PARM(31)) && (cshFlowCov > 0)) //2324
				analysis.Add(rm.GetString("fpa_IntCovD1"));
			if ((cshFlowCov > RG.PARM(29)) && (ratio < RG.PARM(30)) && ((RG.TYPE(80)[pBaseID]+RG.TYPE(81)[pBaseID]) == 0))//2325
				analysis.Add(rm.GetString("fpa_IntCovE1"));
			if ((ratio < RG.PARM(30))&&(cshFlowCov < RG.PARM(29)) && (netIncDep > RG.PARM(31)))//2326
				analysis.Add(rm.GetString("fpa_IntCovF1") + rm.GetString("fpa_IntCovG1"));
			if ((cshFlowCov > RG.PARM(29)) && (netIncDep > RG.PARM(31)) && (ratio < RG.PARM(30))) //2328
				analysis.Add(rm.GetString("fpa_IntCovH1") + rm.GetString("fpa_IntCovI1"));
			
			
			for (int i=0; i < analysis.Count; i++)
			{
				if (i==0)
					printReport("", rm.GetString("fpa_IntCovA1"), true);
				printReport("", analysis[i].ToString(), true);

			}
		}

		private void printCurrentRatio()
		{
			string sentence = "";
			string qtsentence = "";
			double ratio = RG.MACRO(M.CURRENT_RATIO)[pBaseID];
			double ratioLag =RG.MACRO(M.CURRENT_RATIO, RG.LAG)[pBaseID];
			
			printReport(rm.GetString("fpa_Liquidity"), "" , true);
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 25, 26);
						
			if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
				sentence = string.Format(rm.GetString("fpa_CurRatioA"), this.CurMonth, this.CurDate, strVal(ratio));
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
				sentence = string.Format(rm.GetString("fpa_CurRatioB"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("CURR")), strVal(ratioLag), strVal(ratio));
			else
				sentence = string.Format(rm.GetString("fpa_CurRatioC"), rm.GetString(rt.increasedORdecreased("CURR")), rm.GetString(rt.moderSigVsigly("CURR")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			
			if(!this.isProperPeer)
			{
				printReport("", sentence, true);
				return;
			}

			ratioAnalysis rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 36, 35, 34, false);
			if(rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				qtsentence = string.Format(rm.GetString("fpa_CurRatioD"), strIND(36), strVal(ratio));
			else if(rtQuart.Quartile == ratioAnalysis.eQuartile.third)
				qtsentence  = string.Format(rm.GetString("fpa_CurRatioE"), strIND(35), strIND(36), strVal(ratio));
			else if(rtQuart.Quartile == ratioAnalysis.eQuartile.second)
				qtsentence = string.Format(rm.GetString("fpa_CurRatioF"), strIND(34), strIND(35), strVal(ratio));
			else if(rtQuart.Quartile == ratioAnalysis.eQuartile.first)
				qtsentence = string.Format(rm.GetString("fpa_CurRatioG"), strIND(34), strVal(ratio));

			printReport("", sentence + qtsentence, true);


			string sentence1 = "";
			if((rtQuart.Quartile == ratioAnalysis.eQuartile.fourth) || (rtQuart.Quartile == ratioAnalysis.eQuartile.third))
			{
				if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || 
					(rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
				{
					sentence = rm.GetString("fpa_CurRatiol1") + rm.GetString("fpa_CurRatiol");
					sentence1 = rm.GetString("fpa_CurRatioJ2");
				}
				else
				{
					sentence = rm.GetString("fpa_CurRatiol1") + rm.GetString("fpa_CurRatiol");
					sentence1 = rm.GetString("fpa_CurRatioJ1");
				}
			}
			else if((rtQuart.Quartile == ratioAnalysis.eQuartile.second) || (rtQuart.Quartile == ratioAnalysis.eQuartile.first))
			{
				sentence = rm.GetString("fpa_CurRatiol2") + rm.GetString("fpa_CurRatiol");
			}

			printReport("", rm.GetString("fpa_CurRatioH"), true);
			printReport("", rm.GetString("fpa_CurRatioH1") + sentence, true);
			if (sentence1.Length > 0)
				printReport("", sentence1, true);

		
		}


		private void printQuickRatio()
		{
			string sentence = "";
			string qtsentence = "";
			double ratio = RG.MACRO(M.QUICK_RATIO)[pBaseID];
			double ratioLag = RG.MACRO(M.QUICK_RATIO, RG.LAG)[pBaseID];
			double AR = RG.MACRO(M.TOT_ACCTS_REC_NET)[pBaseID];
			double totAssets = RG.MACRO(M.TOTAL_ASSETS)[pBaseID] * 0.1; //10 % of total Assets

			if ((this.isSeviceInd) &&  ( AR > totAssets))
			{
				printReport("", rm.GetString("fpa_QuikRatioA"), true);
			}
			
			if (this.isSeviceInd)
			{
				printReport("", rm.GetString("fpa_QuikRatioB"), true);
				return;
			}
			else
			{
			
				ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 27, 28);
						
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = string.Format(rm.GetString("fpa_QuikRatioC"), this.CurMonth, this.CurDate, strVal(ratio));
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					sentence = string.Format(rm.GetString("fpa_QuikRatioD"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, rm.GetString(rt.increasingORdecreasing("QUIK")), strVal(ratioLag), strVal(ratio));
				else
					sentence = string.Format(rm.GetString("fpa_QuikRatioE"), rm.GetString(rt.increasedORdecreased("QUIK")), rm.GetString(rt.moderSigVsigly("QUIK")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			}
			ratioAnalysis rtQuart = null;
			if(this.isProperPeer)
			{
				rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 39, 38, 37, false);
				if(rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
					qtsentence = string.Format(rm.GetString("fpa_QuikRatioF"), strIND(39), strVal(ratio));
				else if(rtQuart.Quartile == ratioAnalysis.eQuartile.third)
					qtsentence  = string.Format(rm.GetString("fpa_QuikRatioG"), strIND(38), strIND(39), strVal(ratio));
				else if(rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_QuikRatioH"), strIND(37), strIND(38), strVal(ratio));
				else if(rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_QuikRatioI"), strIND(37), strVal(ratio));

				printReport("", sentence + qtsentence, true);
			}
			else
				printReport("", sentence, true);

			if (ratio < 1)
			{
				if (this.isProperPeer)
				{
					sentence = rm.GetString("fpa_QuikRatioJ1") + rm.GetString("fpa_QuikRatioK"); // + rm.GetString("fpa_QuikRatiol");
					if ((rtQuart.Quartile == ratioAnalysis.eQuartile.second) || (rtQuart.Quartile == ratioAnalysis.eQuartile.first))
						sentence = sentence + rm.GetString("fpa_QuikRatiol");
				}
				else
					sentence = rm.GetString("fpa_QuikRatioJ1") + rm.GetString("fpa_QuikRatioK");
			}
			else
				sentence = rm.GetString("fpa_QuikRatioJ1");

			printReport("", rm.GetString("fpa_QuikRatioJ"), true);
			printReport("", sentence, true);
		
		}

		private void printLeverage()
		{
			string sentence = "";
			double ratio = RG.MACRO(M.DEBT_TO_TANG_WORTH)[pBaseID];
			double ratioLag = RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[pBaseID];
			
			double tnw = RG.MACRO(M.TANGIBLE_NET_WORTH)[pBaseID]; //900
			double tnwLag = RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG)[pBaseID];
			double tnwChg = Math.Abs(tnwLag - tnw);
			
			printReport(rm.GetString("fpa_CapitalStruct"), "", true);
			
			//printReport("", rm.GetString("fpa_TNWA8"), true);

			if (formatVal(tnw) > formatVal(tnwLag))
				sentence = string.Format(rm.GetString("fpa_TNWB"), rm.GetString("fpa_TNW_increased"), strVal(Math.Abs(tnwChg),0), this.CurMonth, this.CurDate, strVal(tnwLag,0), this.PrevMonth, this.PrevDate, strVal(tnw,0));
			else if (formatVal(tnw) < formatVal(tnwLag))
				sentence = string.Format(rm.GetString("fpa_TNWB"), rm.GetString("fpa_TNW_declined"), strVal(Math.Abs(tnwChg),0), this.CurMonth, this.CurDate, strVal(tnwLag,0), this.PrevMonth, this.PrevDate, strVal(tnw,0));
			else if ((formatVal(tnw) !=0 ) && (formatVal(tnwLag)!=0))
				sentence = string.Format(rm.GetString("fpa_TNWA"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, strVal(tnw,0));
			
			//printReport("", sentence, true);

			ArrayList analysis = new ArrayList();
			if (formatVal(tnw)- formatVal(tnwLag) != 0)
			{
				printReport("", sentence + rm.GetString("fpa_TNWC"), true);
			}
			
			//261
			double unxAdjRE = -1 * RG.MACRO(M.UNEXPL_ADJ_RE)[pBaseID];
				
			//Calc calc261 = (RG.MACRO(M.NET_WORTH)- RG.MACRO(M.ENDING_NET_WORTH_CALCD)) -
			//RG.MACRO(M.UNEXPL_ADJ_RE) -
			//(RG.AND(103, RG.ANDFLOW, 30, RG.ANDCLASS) + RG.AND(103, RG.ANDFLOW, 32, RG.ANDCLASS))*RG.CONV_RATE();
			//double d261 = calc261[pBaseID];
			Calc calc213 = (RG.AND(103, RG.ANDFLOW, 30, RG.ANDCLASS) + RG.AND(103, RG.ANDFLOW, 32, RG.ANDCLASS)) * RG.CONV_RATE() +
				RG.MACRO(M.ADJ_CHG_EXCHANG_RATE);

			double line761 = RG.MACRO(M.CHG_IN_INTANGIBLES)[pBaseID];

			double line212 = (RG.AND(103, RG.ANDFLOW, 30, RG.ANDCLASS) + RG.AND(103, RG.ANDFLOW, 32, RG.ANDCLASS))[pBaseID];
			double line95 = ((RG.TYPE(70) - RG.TYPE(71))* RG.CONV_RATE())[pBaseID];
			double line95Lag = ((RG.TYPE(70, RG.LAG) - RG.TYPE(71, RG.LAG))* RG.CONV_RATE(RG.LAG))[pBaseID];
			double netIncome = RG.MACRO(M.NET_PROFIT)[pBaseID];
			Calc calc245 = //241
				(RG.AND(105, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG) - 
				RG.AND(105, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE())+
				//243
				((RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS)) * RG.CONV_RATE() - 
				(RG.AND(102, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG) + RG.AND(109, RG.ANDFLOW, 22, RG.ANDCLASS, RG.LAG)) * RG.CONV_RATE(RG.LAG))+
				//244
				RG.AND(25, RG.ANDCLASS, 5, RG.ANDFLOW) * RG.CONV_RATE() - 
				RG.AND(25, RG.ANDCLASS, 5, RG.ANDFLOW, RG.LAG) * RG.CONV_RATE(RG.LAG)+
				//240
				(RG.AND(102, RG.ANDFLOW, 25, RG.ANDCLASS) * RG.CONV_RATE() - 
				RG.AND(102, RG.ANDFLOW, 25, RG.ANDCLASS, RG.LAG) * RG.CONV_RATE(RG.LAG))+
				//239
				RG.FLOW(118)*RG.CONV_RATE() - RG.FLOW(118, RG.LAG)*RG.CONV_RATE(RG.LAG);
			double line245 = calc245[pBaseID];
			Calc Calc222 =((-1*RG.AND(130, RG.ANDFLOW, 32, RG.ANDCLASS) - RG.AND(130, RG.ANDFLOW, 30, RG.ANDCLASS)) +
				(-1*RG.AND(102, RG.ANDFLOW, 32, RG.ANDCLASS) - RG.AND(102, RG.ANDFLOW, 30, RG.ANDCLASS)))*RG.CONV_RATE();
			double dividends = Calc222[pBaseID];
			/*
			ArrayList test = new ArrayList();
			test.Add(strVal(unxAdjRE, 0));
			test.Add(strVal(calc213[pBaseID], 0));
			test.Add(strVal(line761, 0));
			test.Add(strVal(netIncome, 0));
			test.Add(strVal(line245, 0));
			test.Add(strVal(dividends, 0));
			
			test.Sort();
			int len = test[0].ToString().Length;
			*/
			
			if (formatVal(Math.Abs(unxAdjRE)) > 1)
				analysis.Add(string.Format(rm.GetString("fpa_TNWD"), strVal(unxAdjRE, 0)));
			if (formatVal(Math.Abs(unxAdjRE)) == 1)
				analysis.Add(string.Format(rm.GetString("fpa_TNWE"), strVal(unxAdjRE, 0)));
			if (formatVal(line212) != 0) //3777
				analysis.Add(string.Format(rm.GetString("fpa_TNWF"), strVal(calc213[pBaseID], 0)));
			if (formatVal(line95) != formatVal(line95Lag))//3647
				analysis.Add(string.Format(rm.GetString("fpa_TNWG"), strVal(line761, 0)));
			if ((formatVal(netIncome) > 1) && (formatVal(tnw)- formatVal(tnwLag) != 0))//3660
				analysis.Add(string.Format(rm.GetString("fpa_TNWH"), strVal(netIncome, 0)));
			if (formatVal(netIncome) < 0) //3660
				analysis.Add(string.Format(rm.GetString("fpa_TNWI"), strVal(Math.Abs(netIncome), 0)));
			if (formatVal(line245) != 0) //3667
				analysis.Add(string.Format(rm.GetString("fpa_TNWJ"), strVal(line245, 0)));
			if (formatVal(dividends) != 0) //3677
				analysis.Add(string.Format(rm.GetString("fpa_TNWK"), strVal(dividends, 0)));
			if (Math.Abs(unxAdjRE) > 1)
				analysis.Add(rm.GetString("fpa_TNWL"));

			bool line = false;

			for(int i=0; i<analysis.Count; i++)
			{
				if (i == (analysis.Count - 2)) line = true;
				printReport("", analysis[i].ToString(), line);
			}
			
			
			if ((formatVal(tnw) > formatVal(tnwLag))&& (formatVal(tnw) < 0) && (formatVal(tnwLag) < 0))
				printReport("", rm.GetString("fpa_TNWR") +rm.GetString("fpa_TNWN") +rm.GetString("fpa_TNWO"), true);
			else if ((formatVal(tnw) < formatVal(tnwLag))&& (formatVal(tnw) < 0) && (formatVal(tnwLag) < 0))
				printReport("", rm.GetString("fpa_TNWP") +rm.GetString("fpa_TNWN") +rm.GetString("fpa_TNWO"), true);
			else if ((formatVal(tnw) == formatVal(tnwLag))&& (formatVal(tnw) < 0) && (formatVal(tnwLag) < 0))
				printReport("", rm.GetString("fpa_TNWQ") +rm.GetString("fpa_TNWN") +rm.GetString("fpa_TNWO"), true);

			double liabChgPer = ((RG.MACRO(M.TOTAL_LIABILITIES) - RG.MACRO(M.TOTAL_LIABILITIES, RG.LAG)) % 
				RG.MACRO(M.TOTAL_LIABILITIES, RG.LAG))[pBaseID];
			double totLiab = RG.MACRO(M.TOTAL_LIABILITIES)[pBaseID];
		    
			if (formatVal(liabChgPer) > 0)
				printReport("", string.Format(rm.GetString("fpa_TNWT"),rm.GetString("fpa_TNW_grew"), strVal(Math.Abs(liabChgPer)), this.CurMonth, this.CurDate), true);
			else if (formatVal(liabChgPer) < 0)
				printReport("", string.Format(rm.GetString("fpa_TNWT"),rm.GetString("fpa_TNW_declined"), strVal(Math.Abs(liabChgPer)), this.CurMonth, this.CurDate), true);
			else
				printReport("", string.Format(rm.GetString("fpa_TNWS"),strVal(totLiab,0)), true);

			//START Debt/TNW
			ratioAnalysis rt = new ratioAnalysis(RG, ratio, ratioLag, 19, 20);
			if (formatVal(ratioLag) > 0)
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = string.Format(rm.GetString("fpa_TNWA1"), this.CurYear, ratio);
				else if ((rt.GrowthType == ratioAnalysis.eGrowthType.increasing) || (rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
					sentence = string.Format(rm.GetString("fpa_TNWB1"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, ratioLag, ratio);
				else 
					sentence = string.Format(rm.GetString("fpa_TNWC1"), rm.GetString(rt.increasedORdecreased("TNW")), rm.GetString(rt.moderSigVsigly("TNW")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			}
			else if (formatVal(ratioLag) < 0)  ////*****???? I think this check should be < instead of <= and put the other check in else above
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.increasing)
					sentence = string.Format(rm.GetString("fpa_TNWB1"), this.PrevMonth, this.PrevDate, this.CurMonth, this.CurDate, ratioLag, ratio) +
						rm.GetString("fpa_TNWD1");
				else 
					sentence = string.Format(rm.GetString("fpa_TNWC1"), rm.GetString(rt.increasedORdecreased("TNW")), rm.GetString(rt.moderSigVsigly("TNW")), strVal(ratio), this.CurMonth, this.CurDate, strVal(ratioLag), this.PrevMonth, this.PrevDate);
			
			}
			else //*****???? I think the above check should be < instead of <= and put this check in else above
				printReport("", rm.GetString("fpa_TNWF2"), true);

			string qtsentence = "";

			ratioAnalysis rtQuart = null;
			if (formatVal(ratio) > 0)
			{
				rtQuart = new ratioAnalysis(RG, ratio, ratioLag, 61, 62, 63, true);
				
				if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
					qtsentence = string.Format(rm.GetString("fpa_TNWL1"), strIND(61));
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
					qtsentence = string.Format(rm.GetString("fpa_TNWK1"), strIND(61), strIND(62));
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
				{
					if (RG.IND(63) > 900)
						qtsentence = string.Format(rm.GetString("fpa_TNWJ1"), strIND(62));
					else
						qtsentence = string.Format(rm.GetString("fpa_TNWI1"), strIND(62), strIND(63));
				}
				else if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
				{
					if (RG.IND(63) > 900)
						qtsentence = string.Format(rm.GetString("fpa_TNWGH1"));
					else
						qtsentence = string.Format(rm.GetString("fpa_TNWG1"), strIND(63));
				}
			}
			
			if (isProperPeer)
				printReport("", sentence + qtsentence, true);
			else
				printReport("", sentence, true);

			if (formatVal(ratio) <= 0)
				return;

			analysis = new ArrayList();
			string qtReasons = "";
				
			if ((rt.GrowthType == ratioAnalysis.eGrowthType.noChange) || (rt.GrowthType == ratioAnalysis.eGrowthType.increasing)|| 
				(rt.GrowthType == ratioAnalysis.eGrowthType.decreasing))
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					qtReasons = rm.GetString("fpa_TNWN1");
				else
					qtReasons = rm.GetString("fpa_TNWQ1");
				if ((isProperPeer)) // && (formatVal(ratio) > 0))
				{
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
						qtReasons = qtReasons + rm.GetString("fpa_TNWO1") + rm.GetString("fpa_TNWP1");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA3") + rm.GetString("fpa_TNWP1");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA5") + rm.GetString("fpa_TNWA6");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA7") + rm.GetString("fpa_TNWA6");
				}
				//else
					//qtReasons = qtReasons + rm.GetString("fpa_TNWP1");
					
				analysis.Add(qtReasons);
			}
			else if ((rt.GrowthType == ratioAnalysis.eGrowthType.incrModerate) || 
				(rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)||(rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant))
			{
				qtReasons = string.Format(rm.GetString("fpa_TNWR1"), rm.GetString("fpa_TNW_increased"), rm.GetString(rt.moderSigVsigly("TNW")));
				
				if ((isProperPeer)) // && (formatVal(ratio) > 0))
				{
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
						qtReasons = qtReasons + rm.GetString("fpa_TNWS1")+rm.GetString("fpa_TNWP1");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA4") + rm.GetString("fpa_TNWP1");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA5") + rm.GetString("fpa_TNWA6");
					else if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA7") + rm.GetString("fpa_TNWA6");
				}
				//else
					//qtReasons = qtReasons +rm.GetString("fpa_TNWP1");
						
				analysis.Add(qtReasons);
						
				analysis.Add(rm.GetString("fpa_TNWT1"));
				analysis.Add(rm.GetString("fpa_TNWU1")); analysis.Add(rm.GetString("fpa_TNWV1")); 
				analysis.Add(rm.GetString("fpa_TNWW1")); analysis.Add(rm.GetString("fpa_TNWX1")); 
				analysis.Add(rm.GetString("fpa_TNWY1")); analysis.Add(rm.GetString("fpa_TNWZ1")); 
				analysis.Add(rm.GetString("fpa_TNWA2"));
			}
			else
			{
				qtReasons = string.Format(rm.GetString("fpa_TNWR1"), rm.GetString("fpa_TNW_decreased"), rm.GetString(rt.moderSigVsigly("TNW")));

				if ((isProperPeer)) // && (formatVal(ratio) > 0))
				{
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.first)
						qtReasons = qtReasons + rm.GetString("fpa_TNWO1")+ rm.GetString("fpa_TNWP1");
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.second)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA3") + rm.GetString("fpa_TNWP1");
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.third)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA5") + rm.GetString("fpa_TNWA6");
					if (rtQuart.Quartile == ratioAnalysis.eQuartile.fourth)
						qtReasons = qtReasons + rm.GetString("fpa_TNWA7") + rm.GetString("fpa_TNWA6");
				}
				//else
					//qtReasons = qtReasons + rm.GetString("fpa_TNWP1");
				analysis.Add(qtReasons);
			}

			for (int i=0; i < analysis.Count; i++)
			{
				if (i==0)
					printReport("", rm.GetString("fpa_TNWM1"), true);
				printReport("", analysis[i].ToString(), true);
			}
				
			
			
		}

		/*
		private string suffix(int len, string  val)
		{
			string space = " ";
			int ind = len - val.Length;

			for (int i=0; i < ind; i++)
				space = space + space;
			
			return space + val;

		}
		*/
		private void printSustainGrowth()
		{
			printReport(rm.GetString("fpa_sustGrowth"), rm.GetString("fpa_SustGrwA"), true);
            
			double netWorth = RG.MACRO(M.NET_WORTH)[pBaseID];
			double sustGrw = RG.MACRO(M.SUSTAINABLE_GROWTH)[pBaseID];//1550
			double sustGrwLag = RG.MACRO(M.SUSTAINABLE_GROWTH, RG.LAG)[pBaseID]; 
			double salesGrw = RG.MACRO(M.NET_SALES_GROWTH)[pBaseID]; //975
			double tnw = RG.MACRO(M.TANGIBLE_NET_WORTH)[pBaseID]; //915
			double tnwLag = RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG)[pBaseID];
			Calc c3680 = RG.MACRO(M.TANGIBLE_NET_WORTH) - (RG.MACRO(M.TOTAL_LIABILITIES) / (RG.MACRO(M.TOTAL_LIABILITIES,RG.LAG)/RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG)));
			double line3680 = Math.Abs(c3680[pBaseID]);
			double ratio = RG.MACRO(M.DEBT_TO_TANG_WORTH)[pBaseID];
			double ratioLag = RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[pBaseID];

			//if ( (this.CurMonth == 12) && (netWorth < 1) )
			bool print = true;	
			if ((formatVal(netWorth) < 1) && (this.CurMonth == 12))
			{
				printReport("", rm.GetString("fpa_SustGrwB"), true);
				print = false;
			}
			if ((formatVal(salesGrw) > formatVal(sustGrw *.9)) && (formatVal(salesGrw) < formatVal(sustGrw*1.1)) && print ) //3730
			{
				printReport("", string.Format(rm.GetString("fpa_SustGrwC"),strVal(salesGrw), this.CurMonth, this.CurDate, strVal(sustGrwLag)), true);
				printReport("", string.Format(rm.GetString("fpa_SustGrwD"), strVal(sustGrw)),true);
			}
			if ((formatVal(salesGrw) < formatVal(sustGrwLag *.9)) && print) //3721
			{
				printReport("", string.Format(rm.GetString("fpa_SustGrwE"),strVal(salesGrw), this.CurMonth, this.CurDate, strVal(sustGrwLag)), true);
				printReport("", string.Format(rm.GetString("fpa_SustGrwD"), strVal(sustGrw)), true);
			}
			else if ((formatVal(salesGrw) > formatVal(sustGrwLag *1.1)) && (formatVal(ratio) >= formatVal(ratioLag)) && print) //3726
			{
				printReport("", string.Format(rm.GetString("fpa_SustGrwF"), strVal(salesGrw), this.CurMonth, this.CurDate, strVal(sustGrwLag))+
					rm.GetString("fpa_SustGrwF1"), true);
				printReport("", string.Format(rm.GetString("fpa_SustGrwG"), strVal(salesGrw), this.CurYear, strVal(line3680,0)), true);
				printReport("", rm.GetString("fpa_SustGrwH1"), false);
				printReport("", rm.GetString("fpa_SustGrwH2"), false);
				printReport("", rm.GetString("fpa_SustGrwH3"), false);
				printReport("", rm.GetString("fpa_SustGrwH4"), false);
				printReport("", rm.GetString("fpa_SustGrwH5"), true);

				printReport("", string.Format(rm.GetString("fpa_SustGrwD"), strVal(sustGrw)), true);

			}
			else if ((formatVal(salesGrw) > formatVal(sustGrwLag *1.1)) && (formatVal(ratio) < formatVal(ratioLag)) && print) //3726
			{
				printReport("", string.Format(rm.GetString("fpa_SustGrwF"), strVal(salesGrw), this.CurMonth, this.CurDate, strVal(sustGrwLag))+
					rm.GetString("fpa_SustGrwF2"), true);
				printReport("", rm.GetString("fpa_SustGrwH1"), false);
				printReport("", rm.GetString("fpa_SustGrwH2"), false);
				printReport("", rm.GetString("fpa_SustGrwH3"), false);
				printReport("", rm.GetString("fpa_SustGrwH4a"), true);
				
				printReport("", string.Format(rm.GetString("fpa_SustGrwD"), strVal(sustGrw)), true);
			}
		}

		public void printCapitalExpMgmt()
		{
			printReport(rm.GetString("fpa_CapXMgmt"), "", true);

			double cfNumStmts = RG.CALC_ACCUMULATE(new Calc(1, RG.Statements.Count), 3)[pBaseID] - 1; //24
			//double line1780 = RG.CALC_ACCUMULATE(RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF), 3)[pBaseID];
			double line1780 = RG.CALC_ACCUMULATE(-1 * RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF), 1)[pBaseID];
			double ratio = RG.MACRO(M.CAPITAL_EXPENDITURES)[pBaseID];
			double ratioLag = RG.MACRO(M.CAPITAL_EXPENDITURES, RG.LAG)[pBaseID];
			//double avgRatio = RG.CALC_ACCUMULATE(-1 * RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF), 1)[pBaseID]/cfNumStmts;//(ratio + ratioLag) /line1780; /** Need to do this i think i need to calculate the avg of all the stmts in use**/
			//double line1789 = line1780/cfNumStmts;
			double avgRatio = line1780/cfNumStmts; //1789
			double line4149 = 0;
			double expCapExp = RG.MACRO(M.EXP_CAP_EXPEND)[pBaseID];
			double expCapExpLag = RG.MACRO(M.EXP_CAP_EXPEND, RG.LAG)[pBaseID];
			double avgExpCapX = RG.CALC_ACCUMULATE(RG.MACRO(M.EXP_CAP_EXPEND), 1)[pBaseID]/cfNumStmts;//(formatVal(expCapExp) + formatVal(expCapExpLag))/cfNumStmts; 
			double line2220 = (avgRatio - avgExpCapX)/avgExpCapX * 100;
			string st = "";
			if (formatVal(avgRatio) >= 0)
				line4149++;
			if (cfNumStmts <=1)
				line4149 = line4149 +2;
			if (line4149 ==0)
				st = string.Format(rm.GetString("fpa_CapXB"), cfNumStmts, strVal(Math.Abs(avgRatio),0));
			else if (line4149 ==1)
				st = string.Format(rm.GetString("fpa_CapXA"), cfNumStmts, strVal(Math.Abs(avgRatio),0));
			else if (line4149 ==2)
				st = string.Format(rm.GetString("fpa_CapXD"), strVal(Math.Abs(ratio),0));
			else if (line4149 ==3)
				st = string.Format(rm.GetString("fpa_CapXC"),strVal(Math.Abs(ratio),0));

			ratioAnalysis rt = new ratioAnalysis(RG, line2220, 0, 23, 24);
            
			string sentence = "";
			if (expCapExp >=0)
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					sentence = string.Format(rm.GetString("fpa_CapXE"), rm.GetString("fpa_CAPX_higher"), strVal(avgExpCapX,0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)
					sentence = string.Format(rm.GetString("fpa_CapXG"), rm.GetString("fpa_CAPX_higher"), strVal(avgExpCapX,0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant)
					sentence = string.Format(rm.GetString("fpa_CapXG"), rm.GetString("fpa_CAPX_lower"), strVal(avgExpCapX,0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant)
					sentence = string.Format(rm.GetString("fpa_CapXE"), rm.GetString("fpa_CAPX_lower"), strVal(avgExpCapX,0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = string.Format(rm.GetString("fpa_CapXF"), strVal(expCapExp, 0));
			}
			else
			{
				if (rt.GrowthType == ratioAnalysis.eGrowthType.incrVerySignificant)
					sentence = string.Format(rm.GetString("fpa_CapXE1"), rm.GetString("fpa_CAPX_higher"), strVal(Math.Abs(avgExpCapX),0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.incrSignificant)
					sentence = string.Format(rm.GetString("fpa_CapXG1"), rm.GetString("fpa_CAPX_higher"), strVal(Math.Abs(avgExpCapX),0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant)
					sentence = string.Format(rm.GetString("fpa_CapXG1"), rm.GetString("fpa_CAPX_lower"), strVal(Math.Abs(avgExpCapX),0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant)
					sentence = string.Format(rm.GetString("fpa_CapXE1"), rm.GetString("fpa_CAPX_lower"), strVal(Math.Abs(avgExpCapX),0));
				else if (rt.GrowthType == ratioAnalysis.eGrowthType.noChange)
					sentence = string.Format(rm.GetString("fpa_CapXF1"), strVal(Math.Abs(expCapExp), 0));
			}

			printReport("", st + sentence, true);
			if (!isProperPeer)
			{
				printReport("", rm.GetString("fpa_CapXO"), true);
				return;
			}

			printReport("", rm.GetString("fpa_CapXP"), true);

			double nstoFixAsts = (RG.MACRO(M.NET_SALES)[pBaseID]/RG.YEAR()[pBaseID])/RG.MACRO(M.NET_FIXED_ASSETS)[pBaseID];
			double nstoFixAstsLag = (RG.MACRO(M.NET_SALES, RG.LAG)[pBaseID]/RG.YEAR(RG.LAG)[pBaseID])/RG.MACRO(M.NET_FIXED_ASSETS, RG.LAG)[pBaseID];
			
			ratioAnalysis rtQuart = new ratioAnalysis(RG, nstoFixAsts, nstoFixAstsLag, 72, 71, 70, false);
			string qtsentence = "";
			string qtsentence1 = "";
			if ((rtQuart.Quartile == ratioAnalysis.eQuartile.fourth) || (rtQuart.Quartile == ratioAnalysis.eQuartile.third))
			{
				if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
				{
					qtsentence = rm.GetString("fpa_CapXH");
				}
				else
				{
					qtsentence = rm.GetString("fpa_CapXI") + rm.GetString("fpa_CapXJ");
					qtsentence1 =  rm.GetString("fpa_CapXK");
				}
			}
			else if ((rtQuart.Quartile == ratioAnalysis.eQuartile.second) || (rtQuart.Quartile == ratioAnalysis.eQuartile.first))
			{
				if ((rt.GrowthType == ratioAnalysis.eGrowthType.decrSignificant) || (rt.GrowthType == ratioAnalysis.eGrowthType.decrVerySignificant))
				{
					qtsentence = rm.GetString("fpa_CapXL") + rm.GetString("fpa_CapXM");
					qtsentence1 = rm.GetString("fpa_CapXK");
				}
				else
					qtsentence = rm.GetString("fpa_CapXN");

			}
			printReport("", qtsentence, true);
			printReport("", qtsentence1, true);
			printReport("", rm.GetString("fpa_CapXO"), true);

		
		}

		private bool isValidDB(ReportGenerator RG)
		{
			int id = RG.DATABASE_TYPE();
			if ((id == 4) || (id == 2) || (id == 12))
				return false;
			else
				return true;
			
		}

		public bool isServiceIndustry()
		{
			double[] ind1 = new double[13] {22, 48, 52, 53, 54, 55, 56, 61, 62, 71, 81, 92, 98};
			bool indFound = false;
            						
			for(int x=0; x < ind1.Length -1; x++)
			{
				if (RG.IND(1) == ind1[x])
				{
					indFound = true;
					break;
				}
			}
			if (indFound) return indFound;
			if (this.indCat == 3) //Default Database 
			{
				string sic = RG.IND_DIVISON;	
				//REALSTA = H, SERVICE = I, TRANSPOR = E
				if (sic != null)
				{
					if ((sic.Equals("H")) || (sic.Equals("I"))||
						(sic.Equals("E")))
					{
						indFound = true;
					}
				}
			}
			return indFound;
		}

		private string strIND(int id, int percision)
		{
			return strVal(RG.IND(id), percision);
		}
		//NO percision return with 1
		private string strIND(int id)
		{
			//return RG.IND(id).ToString("N1");
			return strVal(RG.IND(id), 1);
		}

		private string strVal(double val)
		{
			return strVal(val, 2);
		}
		private string strVal(double val, int percision)
		{
			if (double.IsInfinity(val))
				return double.NaN.ToString();
			if (double.IsNaN(val))
				return val.ToString();
			
			string format = "N" + percision;
			return val.ToString(format);
		}

		private static double formatVal(double val)
		{
			if (double.IsNaN(val) || double.IsInfinity(val))
					return 0;
			else
				return	Math.Round(val, 2);
		}

		public void printReport(string header, string body, bool extraLine)
		{
				if(! header.Equals(""))
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
					Utility.PrintParagraph(RG, header);
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
						
				}
				if ( ! body.Equals(""))
				{
					Utility.PrintParagraph(RG, body);
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
					
				}
					
		}


		
				
		public class ratioAnalysis
		{
			protected eGrowthType GType;
			protected eQuartile quart;
			protected eAdequate adeq;

									
			public enum eGrowthType
			{
				noChange = 0,
				increasing = 1,
				decreasing = 2,
				incrModerate = 3,
				decrModerate = 4,
				incrSignificant = 5,
				decrSignificant = 6,
				incrVerySignificant = 7,
				decrVerySignificant = 8
			}
			public enum eQuartile
			{
				first = 1,
				second = 2,
				third = 3,
				fourth = 4,
				noRMA = 5
			}

			public enum eAdequate
			{
				ignoreAnalysis = 0,
				notAdequate = 1,
				adequate = 2,
				adequatePlus = 3,
				adequatePlusPlus = 4
            }

			public eAdequate Adequate
			{
				get{ return adeq; }
				set{ adeq = value; }
			}

			public eQuartile Quartile
			{
				get{ return quart; }
				set{ quart = value; }
			}
			public eGrowthType GrowthType
			{
				get{ return GType; }
				set{ GType = value; }
			}

			//Check Change amount(moderately, significantly etc)
			public  ratioAnalysis(ReportGenerator RG, double ratio, double ratioLag, int ModParam, int SigParam)
			{
				ratio = formatVal(ratio);
				ratioLag = formatVal(ratioLag);
				double RatioDiff = (ratio - ratioLag);
				double RatioDiffAbs = 0;
				double p1 = RG.PARM(SigParam);
				if (RatioDiff == 0)
					GType = eGrowthType.noChange;
				else
				{

					RatioDiffAbs = Math.Abs(RatioDiff);
					//amit: 03/06/06 changed the sing to > from >= log 1613
					if (RatioDiffAbs > RG.PARM(SigParam)*2)
					{
						if (RatioDiff > 0)
							GType = eGrowthType.incrVerySignificant;
						else
							GType = eGrowthType.decrVerySignificant;
							
					}
					else if (RatioDiffAbs > RG.PARM(SigParam))
					{
						if (RatioDiff > 0)
							GType = eGrowthType.incrSignificant;
						else
							GType = eGrowthType.decrSignificant;
					}
					else if (RatioDiffAbs > RG.PARM(ModParam))
					{
						if (RatioDiff > 0)
							GType = eGrowthType.incrModerate;
						else
							GType = eGrowthType.decrModerate;
													
					}
					else if (RatioDiffAbs <= RG.PARM(ModParam))
					{
						if (RatioDiff > 0)
							GType = eGrowthType.increasing;
						else
							GType = eGrowthType.decreasing;
					}
				}

			}

			public string increaseORdecrease(string suffix)
			{
				string val = "fpa_"+suffix;
				if ((this.GType == eGrowthType.incrModerate) || (this.GType == eGrowthType.incrSignificant)||
					(this.GType == eGrowthType.incrVerySignificant))
					val = val+"_increase";
				else if ((this.GType == eGrowthType.decrSignificant) || (this.GType == eGrowthType.decrModerate)||
					(this.GType == eGrowthType.decrVerySignificant))
					val = val+"_decrease";
				return val;
			}

			public string increasedORdecreased(string suffix)
			{
				string val = "fpa_"+suffix;
				if ((this.GType == eGrowthType.incrModerate) || (this.GType == eGrowthType.incrSignificant)||
					(this.GType == eGrowthType.incrVerySignificant))
					val = val+"_increased";
				else if ((this.GType == eGrowthType.decrSignificant) || (this.GType == eGrowthType.decrModerate)||
					(this.GType == eGrowthType.decrVerySignificant))
					val = val+"_decreased";
				return val;
			}
			public string moderSigVsig(string suffix)
			{
				string val = "fpa_"+suffix;
				if ((this.GType == eGrowthType.incrModerate)|| (this.GType == eGrowthType.decrModerate))
					val = val+"_moderate";
				else if ((this.GType == eGrowthType.incrSignificant)||(this.GType == eGrowthType.decrSignificant))
					val = val+"_significant";
				else if ((this.GType == eGrowthType.incrVerySignificant) || (this.GType == eGrowthType.decrVerySignificant))
					val = val+"_verySignificant";
				return val;
			}
			public string moderSigVsigly(string suffix)
			{
				string val = "fpa_"+suffix;
				if ((this.GType == eGrowthType.incrModerate)|| (this.GType == eGrowthType.decrModerate))
					val = val+"_moderately";
				else if ((this.GType == eGrowthType.incrSignificant)||(this.GType == eGrowthType.decrSignificant))
					val = val+"_significantly";
				else if ((this.GType == eGrowthType.incrVerySignificant) || (this.GType == eGrowthType.decrVerySignificant))
					val = val+"_verySignificantly";
				return val;
			}
			public string increasingORdecreasing(string suffix)
			{
				string val = "fpa_"+suffix;
				if ((this.GType == eGrowthType.increasing)||(this.GType == eGrowthType.incrModerate) || 
					(this.GType == eGrowthType.incrSignificant)||(this.GType == eGrowthType.incrVerySignificant))
					val = val+"_increasing";
				else if ((this.GType == eGrowthType.decreasing) || (this.GType == eGrowthType.decrSignificant) || 
					(this.GType == eGrowthType.decrModerate)|| (this.GType == eGrowthType.decrVerySignificant))
					val = val+"_decreasing";
				return val;

			}

			//Check Quartile
			public ratioAnalysis(ReportGenerator RG, double ratio, double ratioLag, int indID, int indID1, int indID2, bool reverse)
			{
				int val = 0;
				double ind1 = RG.IND(indID);
				double ind2 = RG.IND(indID1);
				double ind3 = RG.IND(indID2);
				ratio = formatVal(ratio);
				ratioLag = formatVal(ratioLag);
				

				if (reverse) //for ratio which are better when value decreases (e.g. AP Days)
				{
					if ((ratio <= ind1) && (ind1 != 0))
						val = val + 9;
					if ((ratio <= ind2) && (ind2 != 0))
						val = val + 9;
					if ((ratio <= ind3) && (ind3 != 0))
						val = val + 9;
					
				}
				else
				{
					if (ratio >= ind1)
						val = val + 9;
					if (ratio >= ind2)
						val = val + 9;
					if (ratio >= ind3)
						val = val + 9;
					
				}
				if ((ind1 == 0)&& (ind2 == 0) && (ind3 == 0))
					quart = eQuartile.noRMA;
				else if (val == 0) quart = eQuartile.fourth;
				else if (val == 9) quart = eQuartile.third;
				else if (val == 18) quart = eQuartile.second;
				else if (val == 27) quart = eQuartile.first;
				//else if (val == 36) quart = eQuartile.noRMA;
				
			}

			//Check Adequacy
			public ratioAnalysis(ReportGenerator RG, double ratio, int paramid)
			{
				ratio = formatVal(ratio);
				
				double a = RG.PARM(paramid);
				if (ratio > 0)
				{
					if (ratio > RG.PARM(paramid)*2)
						adeq = eAdequate.adequatePlusPlus;
					else if (ratio > RG.PARM(paramid))
						adeq = eAdequate.adequatePlus;
					else if (ratio == RG.PARM(paramid))
						adeq = eAdequate.adequate;
					else if (ratio < RG.PARM(paramid))
						adeq = eAdequate.notAdequate;
				}
				else if ((ratio == 0) && (RG.PARM(paramid) == 0))
					adeq = eAdequate.notAdequate;
				else
					adeq = eAdequate.ignoreAnalysis;


			}


		}

		
	}
}
