using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class DET_UCA_CF:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);
			
			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: Start of the outer Group (Full Report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCashSales"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSalesAdjCF"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgRcvbls"));
			///CPF 01/12/06 Log 898:  Adding "Due from Rel Co - CP"
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueFmRelCoCP"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgBadDbtRes"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTBadDbtRes"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCstExcBill"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgBillExcCst"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefRev"));

			if (RG.GetCalc("CashCollFromSales").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("ucaCashCollSls"), RG.GetPrintOrderCalc(RG.GetCalc("CashCollFromSales")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCostOfSalesCF"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgInventory"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSupplies"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgPurchases"));
			///CPF 01/12/06 Log 898:  Adding "Due to Rel Co - CP"
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueToRelCoCP"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("CashPaidToSupp").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			// KCZ 7-22-03 moved this indent statement (previously before ucaCashFmTrd)
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("ucaCashPdSuppl"), RG.GetPrintOrderCalc(RG.GetCalc("CashPaidToSupp")));
			Utility.UnderlineColumn(RG, 1, 1);

			
			Utility.PrintLabel(RG, rm.GetString("ucaCashFmTrd"));
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			Utility.PrintSummary(RG, rm.GetString("ucaActivities"), RG.GetPrintOrderCalc(RG.GetCalc("CashFromTradAct")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTSellExp"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpExp"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgPrePds"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOvrdrfts"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgActPayOth"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOp"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("CashPdOpCost").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaCashPdOpCst"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdOpCost")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("ucaCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("CashAfterOps")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (RG.GetCalc("CashAfterOps").NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthIncAccts"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthIncAccts2"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOpInc"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIntIncome"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthExpAct"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOpAst"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgLTOpAst"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurOpLiab"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOpNonCurLiab"));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncomeTaxes"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncomeTaxCred"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIncTaxRcv"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefIncTaxRec"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIncTaxPay"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefFedIncTax"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("OthIncExpTxPd").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaOthIncExpTxPd"), RG.GetPrintOrderCalc(RG.GetCalc("OthIncExpTxPd")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("ucaNetCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashAfterOps")));
			Utility.UnderlinePage(RG, 2);
			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			
			//amit: 05/24/04 Removing hard page break. Cannot implement hard pagebreak with report
			//grouping (Keep togther)
			//Utility.PageBreak(RG);

			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			//amit: 05/24/04 No need to print this again since we removed the hard page break
			//Utility.PrintSummary(RG, rm.GetString("ucaNetCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashAfterOps")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTInterestExp"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIntPay"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTOthDeduct"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDividends"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDivPay"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("CashPdDivInt").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaCashPdDivInt"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdDivInt")));
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("ucaNetCashInc"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashInc")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCurPtnLTD"));

			if (RG.GetCalc("CashAftDebtAmrt").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("CurPtnLTD")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("ucaCashAftDbtAmt"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftDebtAmrt")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			if (RG.GetCalc("CashAftDebtAmrt").NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			if (RG.GetCalc("Flows96,97,98").NonZero)
			{
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTProcFrmAstSale"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapExpend"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCapInterestStat"));
			}

			for (int i = 0; i < RG.GetCalc("Flows96,97,98").Count; i++) 
			{
				if (RG.GetCalc("Flows96,97,98")[i] == 0)
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
					RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
                    Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFChgFxdAsts"));           
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFChgAccDepr"));
					RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFDepreciation"));
                    RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));		
                    Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgReserves"));
                    RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
                    
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFGnLsAstSale"));
					Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCFCapInterestUCA"));
					break;
				}
			}

			if (RG.GetCalc("ChgNetFxdAsts").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("ucaChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetFxdAsts")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.Skip(RG, 1);
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTIncFrmSubsid"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSTInvRelCo"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSTInvest"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgInvest"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCompInc"));

			Utility.PrintSummary(RG, rm.GetString("ucaOCIReclsAdj"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(212)")));
			Utility.PrintSummary(RG, rm.GetString("ucaOCIAdjChgExcRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(214)")));

			if (RG.GetCalc("ChgInvestments").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("ucaChgInvst"), RG.GetPrintOrderCalc(RG.GetCalc("ChgInvestments")));
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
				Utility.Skip(RG, 1);
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgIntang"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgAccAmrt"));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAmortization"));

			if (RG.GetCalc("ChgNetIntang").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "4");
				Utility.PrintSummary(RG, rm.GetString("ucaChgNetIntang"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetIntang")));
			}

            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
            Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAsstRvltn"));

			if (RG.GetCalc("CashPdPlntInvest").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaCashPdPlntInvst"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdPlntInvest")));

			if (RG.GetCalc("CashPdPlntInvest").NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTExtrIncAftTxInc"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTxIncome"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonCashIncome"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNonCashExpense"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTAftTxNnCashIncExp"));

			if (RG.GetCalc("ExtraordNonCashItems").NonZero)
			{
				Utility.UnderlineColumn(RG, 1, 1);
				RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
				Utility.PrintSummary(RG, rm.GetString("ucaExtraNonCashItm"), RG.GetPrintOrderCalc(RG.GetCalc("ExtraordNonCashItems")));
				Utility.Skip(RG, 1);
			}

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

//			THIS CODE IS PRESENT IN MFA CODE, BUT DOESN'T APPEAR TO EXECUTE
//			if (RG.GetCalc("FinancingSurplus").NonZero)
//				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaFinSplsRqmt"), RG.GetPrintOrderCalc(RG.GetCalc("FinancingSurplus")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSTBorr"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgNonOpCurLiabs"));

			Utility.PrintSummary(RG, rm.GetString("ucaChgLTD"), RG.GetPrintOrderCalc(RG.GetCalc("ChgLTD")));
	
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDefDebt"));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefIntExp"));
			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgDueRelCo"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubordDef"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubordDbtLiab"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgOthLiabGA"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintSummary(RG, rm.GetString("ucaUnexAdjNW"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(260)")));
			Utility.PrintSummary(RG, rm.GetString("ucaUnexAdjRE"), -1 * RG.GetPrintOrderCalc(RG.GetCalc("LINE(220)")));

			if (RG.GetDetailCalcs("LINE(217)") != null & RG.GetDetailCalcs("LINE(219)") != null)
			{
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(217)"));
				Utility.PrintDetail(RG, RG.GetDetailCalcs("LINE(219)"));
			}

			Utility.PrintSummary(RG, rm.GetString("ucaAdjChgExRt"), RG.GetPrintOrderCalc(RG.GetCalc("LINE(206)")));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, rm.GetString("fasChgIn"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCapItems"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgTreasStk"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubDebtEq"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgSubDefer"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTChgCurrTrans"));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDivStock"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDivOth"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTMinInt"));

			if (RG.GetCalc("TotExtFinanc").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("ucaTotExtFin"), RG.GetPrintOrderCalc(RG.GetCalc("TotExtFinanc")));

			if (RG.GetCalc("CashAftFinanc").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);
			
			Utility.PrintSummary(RG, rm.GetString("ucaCashAftFin"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftFinanc")));

			if (RG.GetCalc("CashAftFinanc").NonZero)
				Utility.Skip(RG, 1);

			//amit: End 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: Start 
			Utility.mT.AddStartRow(Utility.nRow + 1);

			///HERE WE WOULD SHUT OFF ST_CROSS_FOOT FOR STP.
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");

			if (RG.GetCalc("CFAdjstItems").NonZero)
				Utility.PrintLabel(RG, rm.GetString("ucaAdd"));

			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTCashCF"));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTNearCashCF"));

			Utility.PrintSummary(RG, rm.GetString("ucaCashAdj"), RG.GetPrintOrderCalc(RG.GetCalc("CashAdjustment")));
			Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("ucaEndCashEq"), RG.GetPrintOrderCalc(RG.GetCalc("EndCashEquiv")));

			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: End of  group 
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: End of the  Outer group(Full Report) 
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
