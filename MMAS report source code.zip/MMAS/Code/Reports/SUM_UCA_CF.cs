using System.Collections;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;

namespace MMAS
{
	public class SUM_UCA_CF:FinancialAnalyst.IReport
	{
		public void Execute(ReportGenerator RG)
		{
			CALCULATIONS Calcs = new CALCULATIONS();
			Calcs.DetReconCalcs(RG);
			Calcs.UCACFCalcs(RG);

			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			///This is where we load the standard column headers.
			Utility.LoadColumnHeadingDefaults(RG);
			//Remove the Audit Method & Accountant stmt constants added in the default.
			Utility.arrColHead.RemoveRange(2,2);

			// KCZ removed the suppress FALSE line 8-20-03 because this is causing some items to print when they have 0 entry
			// RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.WIDTH_LABEL, "2.75");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.OMIT, "First");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			RG.SetAuthorSetting(FORMATCOMMANDS.SPACING_COLUMNS, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "True");  // Must set to true before calling PrintStmtConstRows
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			Utility.CreatePageHeader(RG);

			///***CPF 3/11/02 This prints the statement constant rows
			Utility.PrintStmtConstRows(RG, 1);

			//amit: start outer group(full report)
			Utility.mT.AddStartRow(Utility.nRow + 1);
			//amit: start 1st group "Net Sales"
			Utility.mT.AddStartRow(Utility.nRow + 1);


			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sucaNetSales"), RG.GetPrintOrderCalc(RG.GetCalc("CFNetSales")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgActNtTrd"), RG.GetPrintOrderCalc(RG.GetCalc("CFChgARNet")));
			///CPF 04/11/06 Log 898:  Added print of Chg Due from Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueFmRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueFmRelCoCP").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaChgBillCst"), RG.GetPrintOrderCalc(RG.GetCalc("ChgBillVsCosts")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgDefRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDefRev").GetTotals(RG)));

			if (RG.GetCalc("CashCollFromSales").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");

			Utility.PrintSummary(RG, rm.GetString("sucaCashCollSls"), RG.GetPrintOrderCalc(RG.GetCalc("CashCollFromSales")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sucaCstSlsRev"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTCostOfSalesCF").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaChgInv"), RG.GetPrintOrderCalc(RG.GetCalc("ChgTotInventory")));
			///CPF 04/11/06 Log 1666:  Remove Chg Due to Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("sucaChgAPTrd"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgPurchases").GetTotals(RG)));
			///CPF 04/11/06 Log 898:  Added print of Chg Due to Rel Co-CP
			Utility.PrintSummary(RG, rm.GetString("sucaChgDueToRelCo"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueToRelCoCP").GetTotals(RG)));

			if (RG.GetCalc("CashPaidToSupp").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaCashPdSuppl"), RG.GetPrintOrderCalc(RG.GetCalc("CashPaidToSupp")));
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("sucaCashFmTrdAct"), RG.GetPrintOrderCalc(RG.GetCalc("CashFromTradAct")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sucaSGAExp"), RG.GetPrintOrderCalc(RG.GetCalc("CFSGAExp")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgPpdDfd"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgPrePds").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaChgOvdftBk"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgOvrdrfts").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaChgAccrOthPy"), RG.GetPrintOrderCalc(RG.GetCalc("ChgAccrlsOthPay")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("CashPdOpCost").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaCashPdOpCst"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdOpCost")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("sucaCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("CashAfterOps")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

            Utility.PrintSummary(RG, rm.GetString("sucaOthIncExp"), RG.GetPrintOrderCalc(RG.GetCalc("CFOthIncExp")));
			Utility.PrintSummary(RG, rm.GetString("sucaOthAstLiab"), RG.GetPrintOrderCalc(RG.GetCalc("ChgOthAstsLiabs")));
			Utility.PrintSummary(RG, rm.GetString("sucaTxPdInCash"), RG.GetPrintOrderCalc(RG.GetCalc("CFTaxesPIC")));

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("OthIncExpTxPd").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaOthIncExpTxPd"), RG.GetPrintOrderCalc(RG.GetCalc("OthIncExpTxPd")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("sucaNetCashAftOps"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashAfterOps")));


			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.Skip(RG, 1);


			//amit: end of 1st group "Net sales"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 2nd group "Interest Expense"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sucaIntExp"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTInterestExp").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaChgIntPay"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgIntPay").GetTotals(RG)));
			Utility.PrintSummary(RG, rm.GetString("sucaDivPdInCash"), RG.GetPrintOrderCalc(RG.GetCalc("CFDivsPIC")));

			RG.SetAuthorSetting(FORMATCOMMANDS.PREFIX, "");

			if (RG.GetCalc("CashPdDivInt").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaCashPdDivInt"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdDivInt")));
			Utility.UnderlineColumn(RG, 1, 1);

			Utility.PrintSummary(RG, rm.GetString("sucaNetCashInc"), RG.GetPrintOrderCalc(RG.GetCalc("NetCashInc")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			// KCZ Changed indent from 2 to 0 7-22-03
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaCPLTD"), RG.GetPrintOrderCalc(RG.GetCalc("CurPtnLTD")));
			Utility.UnderlineColumn(RG, 1, 1);
			Utility.PrintSummary(RG, rm.GetString("sucaCashAftDbtAmt"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftDebtAmrt")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
            RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");
			
			Utility.PrintSummary(RG, rm.GetString("sucaChgNFA"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetFxdAsts")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgInvest"), RG.GetPrintOrderCalc(RG.GetCalc("ChgInvestments")));
            Utility.PrintSummary(RG, rm.GetString("sucaChgNetIntang"), RG.GetPrintOrderCalc(RG.GetCalc("ChgNetIntang")));
            //add to GainLossAssRev
            Utility.PrintSummary(RG, rm.GetString("sucaGainLossAssRev"), RG.GetPrintOrderCalc(RG.GetCalc("GainLossAssRev")));
			
			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");

			if (RG.GetCalc("CashPdPlntInvest").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaCashPdPlntInvst"), RG.GetPrintOrderCalc(RG.GetCalc("CashPdPlntInvest")));

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");
			Utility.PrintSummary(RG, rm.GetString("sucaExtraNonCashItm"), RG.GetPrintOrderCalc(RG.GetCalc("ExtraordNonCashItems")));

			// SPA - removed the IF logic from the underline as we always print Fin Surplus
			//if (RG.GetCalc("FinancingSurplus").NonZero)
			Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaFinSplsRqmt"), RG.GetPrintOrderCalc(RG.GetCalc("FinancingSurplus")));
			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: end of 2nd group "Interest Expense"
			Utility.mT.AddEndRow(Utility.nRow);
			//Utility.PageBreak(RG);
			//amit: start of 3rd group "Chg in ST Loans"
			Utility.mT.AddStartRow(Utility.nRow + 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "2");

			Utility.PrintSummary(RG, rm.GetString("sucaChgSTLnsOthPay"), RG.GetPrintOrderCalc(RG.GetCalc("ChgSTLoansOthPay")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgLTSubDbt"), RG.GetPrintOrderCalc(RG.GetCalc("ChgLTSubDebt")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgOthNonCurLb"), RG.GetPrintOrderCalc(RG.GetDetailCalcs("DTChgDueRelCo").GetTotals(RG)));
			Utility.PrintDetail(RG, RG.GetDetailCalcs("DTDefIntExp"));
			Utility.PrintSummary(RG, rm.GetString("sucaChgGALiabs"), RG.GetPrintOrderCalc(RG.GetCalc("ChgGrayAreaLiab")));
			Utility.PrintSummary(RG, rm.GetString("sucaChgCap"), RG.GetPrintOrderCalc(RG.GetCalc("ChgCapLsNCInc")));

			if (RG.GetCalc("TotExtFinanc").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.INDENT, "0");
			Utility.PrintSummary(RG, rm.GetString("sucaTotExtFin"), RG.GetPrintOrderCalc(RG.GetCalc("TotExtFinanc")));

			if (RG.GetCalc("CashAftFinanc").NonZero)
				Utility.UnderlineColumn(RG, 1, 1);
			
			Utility.PrintSummary(RG, rm.GetString("sucaCashAftFin"), RG.GetPrintOrderCalc(RG.GetCalc("CashAftFinanc")));

			///HERE WE WOULD SHUT OFF ST_CROSS_FOOT FOR STP.
			RG.SetAuthorSetting(FORMATCOMMANDS.ST_CROSS_FOOT, "False");

			Utility.PrintSummary(RG, rm.GetString("sucaAddBegCashEq"), RG.GetPrintOrderCalc(RG.GetCalc("CFBegCashEquiv")));

			//SPA - my suppress is True and I do this IF, but Cash Adjustment still prints if zero
			 // must investigate and resolve later
			if (RG.GetCalc("CashAdjustment").NonZero)
			    Utility.PrintSummary(RG, rm.GetString("sucaCashAdj"), RG.GetPrintOrderCalc(RG.GetCalc("CashAdjustment")));
			
			Utility.UnderlineColumn(RG, 1, 1);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			Utility.PrintSummary(RG, rm.GetString("sucaEndCashEq"), RG.GetPrintOrderCalc(RG.GetCalc("EndCashEquiv")));

			Utility.UnderlinePage(RG, 2);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "True");

			//amit: end of 3rd group "Chg in ST Loans"
			Utility.mT.AddEndRow(Utility.nRow);
			//amit: end of outer group (full report);
			Utility.mT.AddEndRow(Utility.nRow);

			Utility.CloseReport(RG);
		}
	}
}
