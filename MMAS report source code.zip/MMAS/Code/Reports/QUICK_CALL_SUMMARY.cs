using System.Collections;
using System.Threading;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;

namespace MMAS
{
	public class QUICK_CALL_SUMMARY:FinancialAnalyst.IReport
	{
		private string m_sSalesGrowth = "";
		private string m_sCashStatus1 = "";
		private string m_sCashStatus2 = "";
		private int indCat         = 0; //Industry Category
		private ArrayList m_arrPosInd = new ArrayList();
		private ArrayList m_arrNegInd = new ArrayList();
		private FORMATCOMMANDS FC = new FORMATCOMMANDS();

		public void Execute(ReportGenerator RG)
		{			
			///***CPF 11/6/02 Load the resource manager.
			ResourceManager rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);

			///***CPF 3/11/02 This instantiates the Utility object.
			PRINTCOMMANDS Utility = new PRINTCOMMANDS();
			FORMATCOMMANDS FormatCommands = new FORMATCOMMANDS();

			FormatCommands.LoadFormatDefaults(RG);

			RG.SetAuthorSetting(FORMATCOMMANDS.SUPPRESS, "False");
			RG.SetAuthorSetting(FORMATCOMMANDS.COMMAS_ON_1, "True");
			RG.SetAuthorSetting(FORMATCOMMANDS.NEGATIVE_CHAR_1, "()");
			RG.SetAuthorSetting(FORMATCOMMANDS.ZEROS_STRING_1, "-");
			
			///***CPF 3/11/02 This creates the standard page header for the report.  If
			///this as new report, make sure the NewReport parm is "True"
			///Utility.CreateSystemPageHeader(RG,false);
			Utility.CreatePageHeader(RG, true);
			
			CALCULATIONS Calcs = new CALCULATIONS();

			FormatCommands.LoadFormatDefaults(RG);

			int PBaseId;
			int BaseId = RG.BaseStatementID;

//			foreach (Statement s in RG.Statements)
//			{
//				if (s.Peer == true)
//				{
//					PeerId = s.Id;
//					ps = (PeerStatement)s;
//					BaseId = ps.BaseStatementID;
//					break;
//				}
//			}

			///This variable will store the stmt index of the base comparison stmt
			PBaseId = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);

			///CPF 7/7/04 Added this logic to check for service industry
			int dbType = RG.DATABASE_TYPE();

			if (dbType == 3) indCat = dbType;

			int ind = (RG.IND(94) > 0) ? 4 : 0;

			if (dbType != 4) //4 = No Peer Database Selected
			{
				if (RG.IND_Category == (int)ePeerCategory.Assets)
					indCat= 1;
				else if (RG.IND_Category == (int)ePeerCategory.Sales)
					indCat= 2;
				else if (RG.IND_Category == (int)ePeerCategory.Totals)
					indCat = 3;
				indCat = indCat + ind;
			}

			string sCategory = "";

			///This if statement is used to store the selected IND_CATEGORY in a string variable
			if (RG.IND_Category == (int)ePeerCategory.Assets)
				sCategory= rm.GetString("sfpAssetsSize"); //ePeerCategory.Assets.ToString();
			else if (RG.IND_Category == (int)ePeerCategory.Sales)
				sCategory= rm.GetString("sfpSalesSize"); //ePeerCategory.Sales.ToString();
			else
				sCategory=ePeerCategory.Totals.ToString(); //not changing this one becasue its not used anywhere.
			
			//Utility.CreateTable(RG,(RG.POStatements.Count + 1));

			string s1="";
			///Cast a statement-constant object so that we can retrieve the name of it and store in the
			///string variable to follow.
			StatementConstant sc = (StatementConstant)RG.Customer.Model.StatementConstants[SCON.AuditMthd - 1];
			string sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToUpper();

			///If the audit method is Unqualified, Qualified, Reviewed, Compiled, or Company Prepared
			if ((sAdtMthVal == rm.GetString("civUnqUC")) || (sAdtMthVal == rm.GetString("civQualUC")) || (sAdtMthVal == rm.GetString("civRevUC")) || (sAdtMthVal == rm.GetString("civCompUC")) || (sAdtMthVal == rm.GetString("civCoPpdUC")))
			{
				///If the base stmt is annual, then describe the comparison stmt as such.
				if (RG.STMT_PERIODS()[PBaseId] == 12)
					s1 = string.Format(rm.GetString("qcAnylAnnual"), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
				else
					s1 = string.Format(rm.GetString("qcAnylInterim"), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), RG.STMT_PERIODS()[PBaseId].ToString(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
			}
			else
			{
				///This section is for if the audit method is anything other than those 
				///listed above...like Tax Return, Adverse Opinion, etc.  You still need to
				///check if the stmt is annual or not.
				if (RG.STMT_PERIODS()[PBaseId] == 12)
					s1 = string.Format(rm.GetString("qcAnylOthAnnual"), (sc.Label).ToLower(), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
				else
					s1 = string.Format(rm.GetString("qcAnylOthInterim"), (sc.Label).ToLower(), (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[PBaseId].ToString()).ToLower(), RG.STMT_PERIODS()[PBaseId].ToString(), Convert.ToDateTime(RG.STMT_DATE()[PBaseId]).ToShortDateString());
			}

			///Print the first line.
			Utility.PrintParagraph(RG, s1);

			///This is the equivalent of skip when you don't have a table yet.
			Utility.PrintParagraph(RG, " ");

			s1="";
			///If TargetCurrency is set, formulate the print line
			if (RG.LANGGLOBALCONSTANT(GCON.TargetCurrency)[PBaseId].ToString() != "")
				s1 = string.Format(rm.GetString("qcFinInfoTarget"), RG.TARGETCURRENCY(0)[0].ToString());


			string s2="";
			if (RG.IND(94) > 0)
			{
				if ((RG.IND_Category == (int)ePeerCategory.Assets) || (RG.IND_Category == (int)ePeerCategory.Sales))
					s2=string.Format(rm.GetString("qcForCompPur"), RG.IND(94), RG.PEER_CODE, (RG.IND_DESC).ToLower(), sCategory.ToLower(), (RG.IND_SIZE).ToLower(), RG.IND(7));
				else if (RG.IND_Category ==(int)ePeerCategory.Totals)
					s2=string.Format(rm.GetString("qcAllComp"), RG.IND(94), RG.PEER_CODE, (RG.IND_DESC).ToLower(), RG.IND(7));
				else
					s2=rm.GetString("qcNoCompData");
			}
			else
			{
				if (RG.PEER_TYPE() == ePeerType.None)
					s2=rm.GetString("qcNoCompData");
				else if ((RG.IND_Category == (int)ePeerCategory.Assets) || (RG.IND_Category == (int)ePeerCategory.Sales) || (RG.IND_Category ==(int)ePeerCategory.Totals))
					s2=string.Format(rm.GetString("qcForCompPurNoYr"), (RG.IND_DESC).ToLower());
		
			}

			if (RG.LANGGLOBALCONSTANT(GCON.TargetCurrency)[PBaseId].ToString() != "")
				///If there is a Target Currency set, then print both the currency line
				///and the comparison line
				Utility.PrintParagraph(RG, s1 + "  " + s2);
			else
				///If target not set, just print the comparison.
				Utility.PrintParagraph(RG, s2);

			if (RG.STMT_PERIODS()[PBaseId] != 12)
			{
				Utility.PrintParagraph(RG, " ");
				Utility.PrintParagraph(RG, rm.GetString("qcInterimDisclmr"));
			}


			Utility.PrintParagraph(RG, " ");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintParagraph(RG, rm.GetString("qcSalesGwth"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			///This is the equivalent of skip when you don't have a table yet.
			Utility.PrintParagraph(RG, " ");

			bool bLessTwoGwthPer = false;
			//amit: 11/29/05  Using Master Statement List instead of POStatements
			Calc clcGwthPerCnt = new Calc(1, RG.Statements.Count);
			Calc clcGP = RG.CALC_ACCUMULATE(clcGwthPerCnt, 1);

			//amit: 11/29/05
			foreach(Statement s in RG.Statements)
			{
				if (s.Id == PBaseId)
				{
					if (s.GetReconcileID(RG.Context) == -1)
						bLessTwoGwthPer = true;
					break;
				}
			}
												
			//if ((RG.GetPrintOrderCalc(clcGP)[PBaseId]-1) == 1)
				//bLessTwoGwthPer = true;

			RatioAnalysis SG = new RatioAnalysis(RG,RG.MACRO(M.NET_SALES_GROWTH)[PBaseId],RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],1,2,bLessTwoGwthPer);

			SalesGrowth(RG, rm, PBaseId, SG);
			Utility.PrintParagraph(RG, m_sSalesGrowth);
			
			//Here's where we will start the logic for the CASH STATUS
			
			double dNCAO = (double.IsNaN(RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId])) ? 0 : RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId];
			double dNCI = (double.IsNaN(RG.MACRO(M.NET_CASH_INCOME)[PBaseId])) ? 0 : RG.MACRO(M.NET_CASH_INCOME)[PBaseId];
			double dCADA = (double.IsNaN(RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION)[PBaseId])) ? 0 : RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION)[PBaseId];
			double dCPLTD = (double.IsNaN(RG.MACRO(M.CPLTD_FROM_UCA_CASH_FLOW)[PBaseId])) ? 0 : RG.MACRO(M.CPLTD_FROM_UCA_CASH_FLOW)[PBaseId];
			double dFinCosts = (double.IsNaN(RG.MACRO(M.CASH_PAID_FOR_DIVIDENDS_AND_INTEREST)[PBaseId])) ? 0 : RG.MACRO(M.CASH_PAID_FOR_DIVIDENDS_AND_INTEREST)[PBaseId];
			double dFinSrpls = (double.IsNaN(RG.MACRO(M.FIN_SURPLUS)[PBaseId])) ? 0 : RG.MACRO(M.FIN_SURPLUS)[PBaseId];
			double dCashPdPltInv = (double.IsNaN(RG.MACRO(M.CASH_PAID_PLANT_INVEST)[PBaseId])) ? 0 : RG.MACRO(M.CASH_PAID_PLANT_INVEST)[PBaseId];

			CashStatus(RG, rm, PBaseId, dNCAO, dNCI, dFinCosts, dCADA, dCPLTD, dFinSrpls, dCashPdPltInv);
						
			Utility.PrintParagraph(RG, " ");
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
			Utility.PrintParagraph(RG, rm.GetString("qcCashStat"));
			RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
			Utility.PrintParagraph(RG, " ");

			Utility.PrintParagraph(RG, m_sCashStatus1 + "  " + m_sCashStatus2);
			//Utility.PrintParagraph(RG, m_sCashStatus2);

			//Gross Margin
			RatioAnalysis GM = new RatioAnalysis(RG,RG.MACRO(M.GROSS_MARGIN)[PBaseId],RG.MACRO(M.GROSS_MARGIN, RG.LAG)[PBaseId],3,4);
			//Operating Expense
			RatioAnalysis OE = new RatioAnalysis(RG,RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES)[PBaseId],RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES, RG.LAG)[PBaseId],5,6);
			//Operating Profit Margin
			RatioAnalysis OPM = new RatioAnalysis(RG,RG.MACRO(M.OPERATING_PROFIT_MARGIN)[PBaseId],RG.MACRO(M.OPERATING_PROFIT_MARGIN, RG.LAG)[PBaseId],40,42);
			//Net Profit
			RatioAnalysis NP = new RatioAnalysis(RG,RG.MACRO(M.PROFIT_MARGIN)[PBaseId],RG.MACRO(M.PROFIT_MARGIN, RG.LAG)[PBaseId],13,14,bLessTwoGwthPer);
			//AR Days
			RatioAnalysis ARD = new RatioAnalysis(RG,RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId],RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[PBaseId],7,8);
			//Inventory Days
			RatioAnalysis ID = new RatioAnalysis(RG,RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId],RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[PBaseId],9,10);
			//Accounts Payable Days
			RatioAnalysis APD = new RatioAnalysis(RG,RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId],RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[PBaseId],11,12);
			//Current Ratio
			RatioAnalysis CR = new RatioAnalysis(RG,RG.MACRO(M.CURRENT_RATIO)[PBaseId],RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId],25,26);
			//Debt/TNW
			RatioAnalysis DTNW = new RatioAnalysis(RG,RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId],RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId],19,20);

			GrossMargin(RG, rm, PBaseId, GM);
			OperatingExpenses(RG, rm, PBaseId, OE);
			OpProfitMargin(RG, rm, PBaseId, OPM);
			NetProfitMargin(RG, rm, PBaseId, NP);
			ARDays(RG, rm, PBaseId, ARD);
			BadDebtReserve(RG, rm, PBaseId);
			///CPF 7/7/04 Log 818:  Aded logic to not print Inv or AP days if Service industry.
			if (isServiceIndustry(RG) == false)
			{
				InventoryDays(RG, rm, PBaseId, ID);
				AccountsPayableDays(RG, rm, PBaseId, APD);
			}
			CurrentRatio(RG, rm, PBaseId, CR);
			TangNetWorth(RG, rm, PBaseId);
			DebtTNW(RG, rm, PBaseId, DTNW);
			DebtTNWQuartileCheck(RG, rm, PBaseId);

			if (m_arrPosInd.Count != 0)
			{
				Utility.PrintParagraph(RG, " ");
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintParagraph(RG, rm.GetString("qcPosInd"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
				Utility.PrintParagraph(RG, " ");
			}

			for (int i = 0; i < m_arrPosInd.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrPosInd[i].ToString());

				if (i + 1 < m_arrPosInd.Count)
					Utility.PrintParagraph(RG, " ");
			}

			if (m_arrNegInd.Count != 0)
			{
				Utility.PrintParagraph(RG, " ");
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
				Utility.PrintParagraph(RG, rm.GetString("qcNegInd"));
				RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
				Utility.PrintParagraph(RG, " ");
			}

			for (int i = 0; i < m_arrNegInd.Count; i++)
			{
				Utility.PrintParagraph(RG, m_arrNegInd[i].ToString());

				if (i + 1 < m_arrNegInd.Count)
					Utility.PrintParagraph(RG, " ");
			}

			//Utility.CloseReport(RG);

			Utility.PrintParagraph(RG, " ");
			Utility.PrintNotes(RG);

		}
		private string SignifString (RatioAnalysis RA, ResourceManager rm)
		{
			string s;
			if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Little)
				s =rm.GetString("qcSlightly");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Moderate)
				s =rm.GetString("qcModerately");
			else if (RA.GrowthSignificance == RatioAnalysis.eGrowthSignificance.Significant)
				s =rm.GetString("qcSignificantly");
			else 
				s =rm.GetString("qcVerySignif");

			return s;
		}
		private string TrendString (RatioAnalysis RA, ResourceManager rm)
		{
			string s;
			if (RA.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
				s =rm.GetString("qcCompTo");
			else if (RA.GrowthTrend == RatioAnalysis.eGrowthTrend.GreaterThanLastYear)
				s =rm.GetString("qcHigher");
			else if (RA.GrowthTrend == RatioAnalysis.eGrowthTrend.LessThanLastYear)
				s =rm.GetString("qcBelow");
			else 
				s =rm.GetString("qcEqual");

			return s;
		}
		private void CashStatus (ReportGenerator RG, ResourceManager rm, int PBaseId, double dNCAO, double dNCI, double dFinCosts, double dCADA, double dCPLTD, double dFinSrpls, double dCashPdPltInv)
		{
			m_sCashStatus1 = "";
			m_sCashStatus2 = "";
			string sCFSub = string.Format(rm.GetString("qcCSCasFlowSub"), FC.RoundToReport(RG, RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId]).ToString("N0"), RG.STMT_YEAR()[PBaseId].ToString());
			///String 1
			if 
				(
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls >= 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls >= 0))
				)
			{
				m_sCashStatus1 = string.Format(rm.GetString("qcCSInsuf1"), FC.RoundToReport(RG,RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId]).ToString("N0"));
				
				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 2qcCSInsuf1
			else if 
				(
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = string.Format(rm.GetString("qcCSInsufNoCashFinCost2"), FC.RoundToReport(RG,RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId]).ToString("N0"));

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 3 & string 4
			else if 
				(
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0))
				||
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO < 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls >= 0))
				)
			{
				m_sCashStatus1 = string.Format(rm.GetString("qcCSInsufNoCashSvcRq4"), FC.RoundToReport(RG,RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId]).ToString("N0"));

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 5
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSInsuf5");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 6
			else if 
				(
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD >= 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSInsuf6");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 7
			else if 
				(
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSInsuf7");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 8
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA < 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf8");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 9
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				)
			{
				m_sCashStatus1 = string.Format(rm.GetString("qcCSNoDivDbtSvc9"), FC.RoundToReport(RG,RG.MACRO(M.NET_CASH_AFTER_OPERATIONS)[PBaseId]).ToString("N0"), RG.STMT_YEAR()[PBaseId].ToString());

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSCapSoldInsuff"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 10 or string 14 (same string)
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD >= 0) && (dFinSrpls < 0)) 
				||
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD >= 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf10");

				if (dCashPdPltInv < 0)
				{
					///If the following cash then it's 14 and not 10
					if ((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD >= 0) && (dFinSrpls >= 0) && (dCashPdPltInv < 0)) 
						m_sCashStatus2 = string.Format(rm.GetString("qcCSMeetCapExp"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
					else
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapSoldInsuff"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 11 or string 15 (same string)
			else if 
				(
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				||
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				|| 
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf11");

				if (dCashPdPltInv < 0)
				{
					///If the following cash then it's 15 and not 11
					if (((dNCAO >= 0) && (dNCI < 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0) && (dCashPdPltInv < 0)) || ((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0) && (dCashPdPltInv < 0)))
						m_sCashStatus2 = string.Format(rm.GetString("qcCSMeetCapExp"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
					else
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapSoldInsuff"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 12
			else if 
				(
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				|| 
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls < 0)) 
				||  
				((dNCAO >= 0) && (dNCI < 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0))
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf12");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSCapSoldInsuff"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 13
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts >= 0) && (dCADA >= 0) && (dCPLTD >= 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf13");

				///There is no case for 8215 in #13
				///if (dCashPdPltInv < 0)
				///	m_sCashStatus2 = string.Format(rm.GetString("qcCSThere4NewDebt"), Math.Abs(dCashPdPltInv));
				///else 
				if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
				///String 16
			else if 
				(
				((dNCAO >= 0) && (dNCI >= 0) && (dFinCosts < 0) && (dCADA >= 0) && (dCPLTD < 0) && (dFinSrpls >= 0)) 
				)
			{
				m_sCashStatus1 = sCFSub + rm.GetString("qcCSSuf16");

				if (dCashPdPltInv < 0)
					m_sCashStatus2 = string.Format(rm.GetString("qcCSMeetCapExp"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				else if (dCashPdPltInv > 0)
				{
					if (RG.MACRO(M.CHG_IN_NET_FIXED_ASSETS_CF)[PBaseId] == 0)
						m_sCashStatus2 = string.Format(rm.GetString("qcCSCapInvestSold"), Math.Abs(FC.RoundToReport(RG,dCashPdPltInv)).ToString("N0"));
				}
			}
		}
		private bool isServiceIndustry(ReportGenerator RG)
		{
			double[] ind1 = new double[13] {22, 48, 52, 53, 54, 55, 56, 61, 62, 71, 81, 92, 98};
			bool indFound = false;
						
			for(int x=0; x < ind1.Length -1; x++)
			{
				if (RG.IND(1) == ind1[x])
				{
					indFound = true;
					break;
				}
			}
			if (indFound) return indFound;
			if (this.indCat == 3) //Default Database 
			{
				string sic = RG.IND_DIVISON;	
				//REALSTA = H, SERVICE = I, TRANSPOR = E
				if (sic != null)
				{
					if ((sic.Equals("H")) || (sic.Equals("I"))||
						(sic.Equals("E")))
					{
						indFound = true;
					}
				}
			}
			return indFound;
		}
		private void SalesGrowth(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis SG)
		{			
			string sSalesGwth = "";

			if (SG.GrowthType == RatioAnalysis.eGrowthType.NoGrowth)
			{
				if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGUnchangComp"), Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],2), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
				else if (SG.GrowthTrend != RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGUnchang"), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString(),Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],2));
				else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGNoChgPP"));
			}
			else if (SG.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGIncrComp"), SignifString(SG, rm), Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2), Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],2), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
				else if (SG.GrowthTrend != RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGIncr"), SignifString(SG, rm),Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2), TrendString(SG, rm), Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],2), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
				else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGIncNoPP"), rm.GetString("qcIncreased"), SignifString(SG, rm), rm.GetString("qcGrowing"), Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2));
			}
			else
			{
				if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.CloseToLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGDecrComp"),  SignifString(SG, rm), Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2), Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId],2), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
				else if (SG.GrowthTrend != RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGDecr"),  SignifString(SG, rm), Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2),TrendString(SG, rm), Math.Round(RG.MACRO(M.NET_SALES_GROWTH, RG.LAG)[PBaseId], 2), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
				else if (SG.GrowthTrend == RatioAnalysis.eGrowthTrend.NoGrowthLastYear)
					sSalesGwth = string.Format(rm.GetString("qcSGIncNoPP"), rm.GetString("qcDecreased"), SignifString(SG, rm), rm.GetString("qcDeclining"), Math.Round(Math.Abs(RG.MACRO(M.NET_SALES_GROWTH)[PBaseId]),2));
			}

			m_sSalesGrowth = sSalesGwth;
		}
		private void GrossMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis GM)
		{
			string s1="";
			double dGM = Math.Round(RG.MACRO(M.GROSS_MARGIN_EXCL_DEPRECIATION)[PBaseId], 2);
			double dGMLag = Math.Round(RG.MACRO(M.GROSS_MARGIN_EXCL_DEPRECIATION, RG.LAG)[PBaseId], 2);
			string sDateLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			double dGMCE = RG.MACRO(M.QC_GM_CASH_EFFECT)[PBaseId];
			Calc c = RG.MACRO(M.QC_GROSS_MARGIN_CASH) % RG.MACRO(M.QC_NET_SALES_BY_FLOW);
			double d = c[PBaseId];

			if (GM.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if (GM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little)
				{
					s1 = string.Format(rm.GetString("qcGMPosNeg"),rm.GetString("qcIncreased"), SignifString(GM, rm), dGM.ToString("N2"), dGMLag.ToString("N2"), sDateLag, rm.GetString("qcInflow"), FC.RoundToReport(RG,dGMCE).ToString("N0"));
					if (RG.PEER_TYPE() == ePeerType.RMA)
						s1 = s1 + "  " + string.Format(rm.GetString("qcPeerGrpMed"), RG.IND(29).ToString("N1"));
					
					if (s1 != "")
						m_arrPosInd.Add(s1);
				}
			}
			else if (GM.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if (GM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little)
				{
					s1 = string.Format(rm.GetString("qcGMPosNeg"),rm.GetString("qcDecreased"), SignifString(GM, rm), dGM.ToString("N2"), dGMLag.ToString("N2"), sDateLag, rm.GetString("qcOutflow"), FC.RoundToReport(RG,dGMCE).ToString("N0"));
					if (RG.PEER_TYPE() == ePeerType.RMA)
						s1 = s1 + "  " + string.Format(rm.GetString("qcPeerGrpMed"), RG.IND(29).ToString("N1"));

					if (s1 != "")
						m_arrNegInd.Add(s1);
				}
			}
			else if (dGM < 0)
			{
				//AMP 04/21/04: Fix of the log #620
				//s1 = string.Format(rm.GetString("qcGMNoChg"), RG.STMT_YEAR(RG.LAG)[PBaseId], dGM);
				s1 = string.Format(rm.GetString("qcGMNoChg"), RG.STMT_YEAR()[PBaseId], dGM.ToString("N2"));

				if (s1 != "")
					///CPF 6/22/04 Log 793:  This is a Negative Indicator, chgd array from Pos to Neg
					m_arrNegInd.Add(s1);
			}

		}

		private void OperatingExpenses(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis OE)
		{
			string s1="";
			double dOE = Math.Round(RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES)[PBaseId], 2);
			double dOELag = Math.Round(RG.MACRO(M.OPERATING_EXP_EXCL_DEPR_TO_SALES, RG.LAG)[PBaseId], 2);
			string sDateLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			double dOECE = Math.Abs(RG.MACRO(M.QC_OE_CASH_EFFECT)[PBaseId]);

			if (OE.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if (OE.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little)
				{
					s1 = string.Format(rm.GetString("qcOEPosNeg"),rm.GetString("qcDecreased"), SignifString(OE, rm), dOELag, sDateLag, dOE, rm.GetString("qcInflow"), FC.RoundToReport(RG,dOECE).ToString("N0"));
//					if (RG.PEER_TYPE() == ePeerType.RMA)
//						s1 = s1 + "  " + string.Format(rm.GetString("qcPeerGrpMed"), RG.IND(30).ToString("N1"));

					if (s1 != "")
						m_arrPosInd.Add(s1);
				}
			}
			else if (OE.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if (OE.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little)
				{
					s1 = string.Format(rm.GetString("qcOEPosNeg"),rm.GetString("qcIncreased"), SignifString(OE, rm), dOELag, sDateLag, dOE, rm.GetString("qcOutflow"), FC.RoundToReport(RG,dOECE).ToString("N0"));
					if ((RG.PEER_TYPE() == ePeerType.RMA) && (dOE > RG.IND(30)))
						s1 = s1 + "  " + string.Format(rm.GetString("qcPeerGrpMed"), RG.IND(30).ToString("N1"));

					if (s1 != "")
						m_arrNegInd.Add(s1);
				}
			}

		}
		private void OpProfitMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis OPM)
		{
			string s1="";
			string s2="";
			double dNOP = Math.Round(RG.MACRO(M.NET_OPERATING_PROFIT)[PBaseId], 2);
			double dNOPLag = Math.Round(RG.MACRO(M.NET_OPERATING_PROFIT, RG.LAG)[PBaseId], 2);
			double dOPM = Math.Round(RG.MACRO(M.OPERATING_PROFIT_MARGIN)[PBaseId], 2);
			double dOPMLag = Math.Round(RG.MACRO(M.OPERATING_PROFIT_MARGIN, RG.LAG)[PBaseId], 2);
			string sDate = RG.STMT_YEAR()[PBaseId].ToString();
			string sDateLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();
			//double dOECE = Math.Abs(RG.MACRO(M.QC_OE_CASH_EFFECT)[PBaseId]);

			if (OPM.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				///CPF 7/8/04 Log 824:  Moved this check from negative section because growth is
				///actually positive, though both items are still negative.  This should go in the 
				///negative indicators array.
				if ((dNOP < 0) && (dNOPLag <0) && (dNOP > dNOPLag))
				{
					s1 = string.Format(rm.GetString("qcOPContNeg"), rm.GetString("qcIncreased"), FC.RoundToReport(RG, dNOP).ToString("N0"));
					m_arrNegInd.Add(s1 + s2);	
				}
				else
				{
					if ((dNOP > 0) && (dNOPLag < 0))
						s1 = string.Format(rm.GetString("qcOPTurned"), rm.GetString("qcPositive"), sDate, FC.RoundToReport(RG,dNOP).ToString("N0"), dOPM);

					///CPF 7/8/04 Log 822:  This check was missing the moderate check.  Should only print if sig, very sig
					if ((OPM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (OPM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate))
						s2 = string.Format(rm.GetString("qcOPPosNeg"), FC.RoundToReport(RG, dNOP).ToString("N0"), rm.GetString("qcIncreased"), SignifString(OPM, rm), dOPM, dOPMLag, sDateLag);
			
					if ((s1 != "") && (s2 != ""))
						m_arrPosInd.Add(s1 + "  " + s2);
					else 
						m_arrPosInd.Add(s1 + s2);
				}
			}
			else if (OPM.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if ((dNOP < 0) && (dNOPLag > 0))
					s1 = string.Format(rm.GetString("qcOPTurned"), rm.GetString("qcNegative"), sDate, FC.RoundToReport(RG, dNOP).ToString("N0"), dOPM);
				///CPF 7/8/04 Log 824:  Moved this check up into the positive growth section
//				else if ((dNOP < 0) && (dNOPLag <0) && (dNOP > dNOPLag))
//					s1 = string.Format(rm.GetString("qcOPContNeg"), rm.GetString("qcIncreased"), FC.RoundToReport(RG, dNOP).ToString("N0"));
				else if ((dNOP < 0) && (dNOPLag <0) && (dNOP < dNOPLag))
					s1 = string.Format(rm.GetString("qcOPContNeg"), rm.GetString("qcDecreased"), FC.RoundToReport(RG, dNOP).ToString("N0"));

				if ((OPM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (OPM.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
					s2 = string.Format(rm.GetString("qcOPPosNeg"), FC.RoundToReport(RG, dNOP).ToString("N0"), rm.GetString("qcDecreased"), SignifString(OPM, rm), dOPM, dOPMLag, sDateLag);

				if ((s1 != "") && (s2 != ""))
					m_arrNegInd.Add(s1 + "  " + s2);
				else 
					m_arrNegInd.Add(s1 + s2);
			}
			
		}
		private void NetProfitMargin(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis NPM)
		{
			string s1="";
			double dNP = Math.Round(RG.MACRO(M.NET_PROFIT)[PBaseId], 2);
			double dNPLag = Math.Round(RG.MACRO(M.NET_PROFIT, RG.LAG)[PBaseId], 2);
			double dNPM = Math.Round(RG.MACRO(M.PROFIT_MARGIN)[PBaseId], 2);
			double dNPMLag = Math.Round(RG.MACRO(M.PROFIT_MARGIN, RG.LAG)[PBaseId], 2);
			double dNPMLag2 = Math.Round(RG.MACRO(M.PROFIT_MARGIN, RG.LAG, 2)[PBaseId], 2);

			string sDate = RG.STMT_YEAR()[PBaseId].ToString();
			string sDateLag = RG.STMT_YEAR(RG.LAG)[PBaseId].ToString();

			if ((dNP > 0) && (dNPLag < 0))
			{
				s1 = string.Format(rm.GetString("qcNPMTurned"), rm.GetString("qcPositive"), dNPM.ToString("N2"), FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrPosInd.Add(s1);
			}
			else if ((dNP < 0) && (dNPLag > 0))
			{
				s1 = string.Format(rm.GetString("qcNPMTurned"), rm.GetString("qcNegative"), dNPM.ToString("N2"), FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if ((dNP < 0) && (dNPLag < 0) && (dNP > dNPLag))
			{
				s1 = string.Format(rm.GetString("qcNPMConstPosNeg"), rm.GetString("qcNegative"), dNPM.ToString("N2"), rm.GetString("qcIncreased"), dNPMLag.ToString("N2"), sDateLag, FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if ((dNP < 0) && (dNPLag < 0) && (dNP < dNPLag))
			{
				s1 = string.Format(rm.GetString("qcNPMConstPosNeg"), rm.GetString("qcNegative"), dNPM.ToString("N2"), rm.GetString("qcDecreased"), dNPMLag.ToString("N2"), sDateLag, FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if ((dNP < 0) && (dNPLag < 0) && (dNPM == dNPMLag))
			{
				s1 = string.Format(rm.GetString("qcNPMContNeg"), dNPM.ToString("N2"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if ((dNP > 0) && (dNPLag > 0) && (dNPM < dNPMLag))
			{
				s1 = string.Format(rm.GetString("qcNPMDeclined"), dNPM.ToString("N2"), FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if (((dNP > 0) && (dNPLag > 0) && (dNPM > dNPMLag)) && (RG.POStatements.Count >= 2) && (dNPMLag2 > 0))
			{
				s1 = string.Format(rm.GetString("qcNPMPosNeg"), rm.GetString("qcIncreased"), dNPM.ToString("N2"), FC.RoundToReport(RG,dNP).ToString("N0"));
				if (s1 != "")
					m_arrPosInd.Add(s1);
			}
			
		}
		private void ARDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis ARD)
		{
			string s1="";
			double d1 = (double.IsNaN(RG.MACRO(M.QC_AR_GROWTH)[PBaseId])) ? 0 : RG.MACRO(M.QC_AR_GROWTH)[PBaseId];
			double d2 = (double.IsNaN(RG.MACRO(M.QC_AR_GROWTH_TO_SALES)[PBaseId])) ? 0 : RG.MACRO(M.QC_AR_GROWTH_TO_SALES)[PBaseId];
			double dARD = (double.IsNaN(Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS)[PBaseId], 2);
			double dARDLag = (double.IsNaN(Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.NET_ACCOUNTS_RECEIVABLE_DAYS, RG.LAG)[PBaseId], 2);
			double dARDCE = RG.MACRO(M.QC_AR_CASH_EFFECT)[PBaseId];

			if (ARD.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if ((ARD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (ARD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
				{
					s1 = string.Format(rm.GetString("qcARPosNeg"), rm.GetString("qcDecreased"), SignifString(ARD, rm), dARD, rm.GetString("qcProviding"), FC.RoundToReport(RG,dARDCE).ToString("N0"));
				}
				if (s1 != "")
					m_arrPosInd.Add(s1);
			}
			else if (ARD.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((ARD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (ARD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
				{
					s1 = string.Format(rm.GetString("qcARPosNeg"), rm.GetString("qcIncreased"), SignifString(ARD, rm), dARD, rm.GetString("qcAbsorbing"), FC.RoundToReport(RG,dARDCE).ToString("N0"));
				}

				if (dARD > RG.PARM(223))
				{
					if (s1 == "")
						s1 = rm.GetString("qcARHighLev");
					else
						s1 = s1 + "  " + rm.GetString("qcARHighLev");
				}

				if (s1 != "")
					m_arrNegInd.Add(s1);
			}

		}
		private void InventoryDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis ID)
		{
			string s1="";
			double dINVD = Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND)[PBaseId], 2);
			double dINVDLag = Math.Round(RG.MACRO(M.INVENTORY_DAYS_ON_HAND, RG.LAG)[PBaseId], 2);
			double dINVDCE = RG.MACRO(M.QC_MGMT_OF_INVENTORY)[PBaseId];

			if (ID.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				if ((ID.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (ID.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
				{
					s1 = string.Format(rm.GetString("qcInvDaysPosNeg"), rm.GetString("qcDecreased"), SignifString(ID, rm), dINVD.ToString("N2"), rm.GetString("qcInflow"), FC.RoundToReport(RG,dINVDCE).ToString("N0"));
				}
				if (s1 != "")
					m_arrPosInd.Add(s1);
			}
			else if (ID.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((ID.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (ID.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
				{
					s1 = string.Format(rm.GetString("qcInvDaysPosNeg"), rm.GetString("qcIncreased"), SignifString(ID, rm), dINVD.ToString("N2"), rm.GetString("qcOutflow"), FC.RoundToReport(RG,dINVDCE).ToString("N0"));
				}
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}

		}
		private void BadDebtReserve(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			string s1="";
			double dBDR = Math.Round(RG.MACRO(M.QC_BAD_DEBT_RESERVE_TO_AR)[PBaseId], 2);
			double dBDRLag = Math.Round(RG.MACRO(M.QC_BAD_DEBT_RESERVE_TO_AR, RG.LAG)[PBaseId], 2);

			if (dBDR > dBDRLag)
			{
				if (dBDR > RG.PARM(220)) 
				{
					s1 = rm.GetString("qcBDRHighIncr");
				}
			}
			else if (dBDR == dBDRLag)
			{
				if (dBDR > RG.PARM(220))
				{
					s1 = rm.GetString("qcBDRHigh");
				}
			}
			else if (dBDR < dBDRLag)
			{
				if (dBDR > RG.PARM(220))
				{
					s1 = rm.GetString("qcBDRHighDecr");
				}
			}

			if (s1 != "")
				m_arrNegInd.Add(s1);
		}
		private void AccountsPayableDays(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis APD)
		{
			string s1="";
			string s2="";
			double dAPD = (double.IsNaN(Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS)[PBaseId], 2);
			double dAPDLag = (double.IsNaN(Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.ACCOUNTS_PAYABLE_DAYS, RG.LAG)[PBaseId], 2);
			double dAPDCE = (double.IsNaN(RG.MACRO(M.QC_MGMT_OF_AP)[PBaseId])) ? 0 : RG.MACRO(M.QC_MGMT_OF_AP)[PBaseId];

			if (APD.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				///8101 = 6 or 8
				if (dAPD >= RG.PARM(224) && dAPD <= RG.PARM(225))
					s1 = string.Format(rm.GetString("qcAPDIncDec"), rm.GetString("qcDecreased"), SignifString(APD, rm), dAPD.ToString("N2"), rm.GetString("qcAbsorbing"), FC.RoundToReport(RG,dAPDCE).ToString("N0"));
					///8101 = 102, 104, 106, 108 - Decline & Low Level
				else if (dAPD < RG.PARM(224) && dAPD <= RG.PARM(225))
					s1 = string.Format(rm.GetString("qcAPDDecLL"), dAPD.ToString("N2"), dAPDCE.ToString("N0"));
					///8101 = 202, 204, 206, 208 - Decline & High Level
				else if (dAPD >= RG.PARM(224) && dAPD > RG.PARM(225))
					s1 = string.Format(rm.GetString("qcAPDDecHL"), dAPD.ToString("N2"), dAPDCE.ToString("N0"));

				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if (APD.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				if ((APD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Little) && (APD.GrowthSignificance != RatioAnalysis.eGrowthSignificance.Moderate)) 
				{
					s1 = string.Format(rm.GetString("qcAPDIncDec"), rm.GetString("qcIncreased"), SignifString(APD, rm), dAPD.ToString("N2"), rm.GetString("qcProviding"), FC.RoundToReport(RG,dAPDCE).ToString("N0"));
					if (s1 != "")
						m_arrPosInd.Add(s1);
				}
					///8101 = 101, 103, 105, 107 - Increase & Low Level
				if (dAPD < RG.PARM(224) && dAPD <= RG.PARM(225))
					s2 = string.Format(rm.GetString("qcAPDRemLL"), dAPD.ToString("N2"));
					///8101 = 201, 203, 205, 207 - Increase & High Level
				else if (dAPD >= RG.PARM(224) && dAPD > RG.PARM(225))
					s2 = string.Format(rm.GetString("qcAPDIncHL"), dAPD.ToString("N2"), FC.RoundToReport(RG,dAPDCE).ToString("N0"));

				if (s2 != "")
					m_arrNegInd.Add(s2);
			}
			else if (APD.GrowthType == RatioAnalysis.eGrowthType.NoGrowth)
			{
				///8101 = 100 - No Change & Low Level
				if ((dAPD != dAPDLag) && (dAPD != 0))
				{
					if (dAPD < RG.PARM(224) && dAPD <= RG.PARM(225))
						s1 = string.Format(rm.GetString("qcAPDRemLL"), dAPD.ToString("N2"));
					if (s1 != "")
						m_arrNegInd.Add(s1);
				}
			}
		}
		private void CurrentRatio(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis CR)
		{
			string s1="";
			double dCR = (double.IsNaN(Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2);
			double dCRLag = (double.IsNaN(Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2);
			///CPF 7/8/04  Log 822:  Added infinity check.
			dCR = (double.IsInfinity(Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO)[PBaseId], 2);
			dCRLag = (double.IsInfinity(Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.CURRENT_RATIO, RG.LAG)[PBaseId], 2);
			
			if (CR.GrowthType == RatioAnalysis.eGrowthType.Negative)
			{
				/// CR < CRLAG, CR < 1 and CRLAG >= 1
				if (dCR < 1  && dCRLag >= 1)
					s1 = string.Format(rm.GetString("qcCRDecBel1"), dCR);
				/// CR < CRLAG, CR < 1 and CRLAG < 1
				else if (dCR < 1  && dCRLag < 1)
					s1 = string.Format(rm.GetString("qcCRDecRemBel1"), dCR);

				if (s1 != "")
					m_arrNegInd.Add(s1);
			}
			else if (CR.GrowthType == RatioAnalysis.eGrowthType.Positive)
			{
				/// CR > CRLAG, CR >= 1 and CRLAG < 1
				if (dCR >= 1  && dCRLag < 1)
				{
					s1 = string.Format(rm.GetString("qcCRIncAbv1"), dCR);
					if (s1 != "")
						m_arrPosInd.Add(s1);
				}
				/// CR > CRLAG, CR < 1 and CRLAG < 1
				else if (dCR < 1  && dCRLag < 1)
				{
					s1 = string.Format(rm.GetString("qcCRIncBel1"), dCR);
					if (s1 != "")
						m_arrNegInd.Add(s1);
				}
			}
			else if (CR.GrowthType == RatioAnalysis.eGrowthType.NoGrowth)
			{
				/// CR > CRLAG, CR < 1 and CRLAG < 1
				if (dCR < 1)
					s1 = string.Format(rm.GetString("qcCRRemBel1"), dCR);
				if (s1 != "")
					m_arrNegInd.Add(s1);

			}
		}
		private void TangNetWorth(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			string s1="";
			double dTNW = RG.MACRO(M.TANGIBLE_NET_WORTH)[PBaseId];
			double dTNWLag = RG.MACRO(M.TANGIBLE_NET_WORTH, RG.LAG)[PBaseId];


			if (dTNWLag > 0 && dTNW < 0)
				///CPF 7/8/04 Log 828:  We should have been passing current year, not lag.
				s1 = string.Format(rm.GetString("qcTNWTurnNeg"), RG.STMT_YEAR()[PBaseId].ToString());
			
			if (s1 != "")
				m_arrNegInd.Add(s1);
		}
		private void DebtTNW(ReportGenerator RG, ResourceManager rm, int PBaseId, RatioAnalysis DTNW)
		{
			string s1="";
			double dDTNW = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId], 2);
			double dDTNWLag = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId], 2);
			double d2181 = Math.Abs(dDTNW - dDTNWLag);   /*GET ABS OF CHG IN DTNW*/
			double d2183 = (dDTNW <= 0) ? -54 : 0;   /*SEE IF DTNW IS < 0*/
			double d2184 = (dDTNWLag <=0) ? 18 : 0;  /*SEE IF DTNWLAG IS < 0*/
			double d2187 = (dDTNW > dDTNWLag) ? 1 : 0;   /*SEE IF CP > PP*/
			double d2189 = (dDTNW < dDTNWLag) ? 2 : 0;   /*SEE IF CP < PP*/
			double d2190 = (d2181 > RG.PARM(19)) ? 2 : 0;  /*COMPARE CHG TO MODERATE PARM*/
			double d2194 = (d2181 > RG.PARM(20)) ? 2 : 0;  /*COMPARE CHG TO SIGNIFICANT PARM*/
			double d2196 = (d2181 > (RG.PARM(20) * 2)) ? 2 : 0;  /*COMPARE CHG TO VERY SIGNIFICANT PARM*/
			double d2199 = d2190 + d2194 + d2196 + d2187 + d2189 + d2183 + d2184;  /*CALCULATE THE SIGNIFICANCE FACTOR*/
			double d8075 = (dDTNW < RG.PARM(221)) ? 9 : 0;   /*COMPARE DTNW TO LOW LEVEL PARM*/
			double d8076 = (dDTNW > RG.PARM(222)) ? 108 : 0;  /*COMPARE DTNW TO HI LEVEL PARM*/
			///8330 is an "adjusment factor" to 2199 to make a unique numbering sequence.  Basically, when
			///both CP and PP are negative, 2199 = -36, but we need to turn it to 36 by adding 72.  Otherwise
			///we can get overlapping cases.
			double d8330 = (d2199 == -36) ? 72 : 0;
			double d8770 = d2199 + d8075 + d8076 + d8330;

			switch((int)d8770)
			{
				case 6: case 8:
					s1 = string.Format(rm.GetString("qcDTNWIncDec"), rm.GetString("qcDecreased"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrPosInd.Add(s1);
					break;
				case 9: case 10: case 11: case 12: case 13:
					s1 = string.Format(rm.GetString("qcDTNWRemLL"), dDTNW);
					if (s1 != "")
						m_arrPosInd.Add(s1);
					;break;
				case 15: case 17:
					s1 = string.Format(rm.GetString("qcDTNWLLDec"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrPosInd.Add(s1);
					break;
				case 14: case 16:
					s1 = string.Format(rm.GetString("qcDTNWLLInc"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrPosInd.Add(s1);
					break;
				case 108: case 126: case 109: case 127: case 110: case 128: case 111: case 129: case 112: case 130: case 131: case 132: case 133: case 134:
					s1 = string.Format(rm.GetString("qcDTNWAbvLimit"), dDTNW,  RG.PARM(222).ToString("F2"));
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				case -45: case -54: case 54: case -44: case -53: case 55: case -43: case -52: case 56: case -42: case -51: case 57: case -41: case -50: case 58:
				case -40: case -49: case 59: case -39: case -48: case 60: case -38: case -47: case 61: case -37: case -46: case 62:
					s1 = string.Format(rm.GetString("qcDTNWZeroCP"), RG.STMT_YEAR()[PBaseId].ToString());
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				case 45: case 36: case 144: case 46: case 37: case 145: case 47: case 38: case 146: case 48: case 39: case 147: case 49: case 40: case 148:
				case 50: case 41: case 149: case 51: case 42: case 150: case 52: case 43: case 151: case 53: case 44: case 152:
					s1 = string.Format(rm.GetString("qcDTNWZeroCPPP"), RG.STMT_YEAR()[PBaseId].ToString(), RG.STMT_YEAR(RG.LAG)[PBaseId].ToString());
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				case 113: case 115:
					s1 = string.Format(rm.GetString("qcDTNWAbvLimInc"), RG.PARM(222).ToString("F2"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				case 114: case 116:
					s1 = string.Format(rm.GetString("qcDTNWAbvLimDec"), RG.PARM(222).ToString("F2"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				case 5:  case 7:
					s1 = string.Format(rm.GetString("qcDTNWIncDec"), rm.GetString("qcIncreased"), SignifString(DTNW, rm), dDTNW);
					if (s1 != "")
						m_arrNegInd.Add(s1);
					break;
				default:break;
			}
				
		}
		private void DebtTNWQuartileCheck(ReportGenerator RG, ResourceManager rm, int PBaseId)
		{
			string s1="";
			double dDTNW = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH)[PBaseId], 2);
			double dDTNWLag = (double.IsNaN(Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId], 2))) ? 0 : Math.Round(RG.MACRO(M.DEBT_TO_TANG_WORTH, RG.LAG)[PBaseId], 2);

			double d2183 = (dDTNW <= 0) ? -54 : 0;   /*SEE IF DTNW IS < 0*/
			double d2546 = (dDTNW >= RG.IND(61)) ? 9 : 0;
			double d2547 = (dDTNW >= RG.IND(62)) ? 9 : 0;
			double d2548 = (dDTNW >= RG.IND(63)) ? 9 : 0;
			double d2551 = (RG.IND(63) > 900) ? 27 : 0;
			double d2550 = d2546 + d2548 + d2547 + d2183 + d2551;
			double d999 = (RG.PEER_TYPE() == ePeerType.RMA) ? 1 : 0;
			double d998 = (RG.PEER_TYPE() == ePeerType.Default) ? 1 : 0;
			double d8288 = d2550 + d999 + d998;
			double d8289 = (d2550 == 27) ? (d999 + d998) : 0;
		
			if (d8288 == 1)
			{
				s1 = string.Format(rm.GetString("qcDTNWFirstQuart"), dDTNW, RG.IND(61).ToString("F2"));
				if (s1 != "")
					m_arrPosInd.Add(s1);
			}
			else if (d8289 == 1)
			{
				s1 = string.Format(rm.GetString("qcDTNWLowQuart"), dDTNW, RG.IND(63).ToString("F2"));
				if (s1 != "")
					m_arrNegInd.Add(s1);
			}

		}
	}
}
