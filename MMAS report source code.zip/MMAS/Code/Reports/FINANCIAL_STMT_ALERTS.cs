using System.Collections;
using System.Threading;
using FinancialAnalyst;
using MKMV.RiskAnalyst.ReportAuthoring.PrintUtility;
using System.IO;
using System.Text;
using System.Reflection;
using System.Resources;
using System;

namespace MMAS
{
	/// <summary>
	/// Creates the Financial statement Alert Report for consultant.
	/// </summary>
	public class FINANCIAL_STMT_ALERTS: FinancialAnalyst.IReport
	{
		//All the Variables in this program correspond to the specific
		//line numbers in MFA calculations. (e.g c260 or d260 = line 260 etc)
		//Although it is not a conventional variable names, it did provide
		//a significant help during developing this program and will help for future
		//refrences with MFA. 

		//These are used in various calculations
		private Calc c260  = null; //Actual Ending Net Worth - ending net worth
		private Calc c261  = null; //(indicated-actual adj to nw) - unexplained adjustments - adj to r/e
		private Calc c91   = null; //Total Investments
		private Calc c100  = null; //Total Assets
		private Calc c170  = null; //Net Profit
		private Calc c3001 = null; //NET CAPITAL EXPENDITURES
		private Calc c3002 = null;
		private Calc c710  = null; //Cash After Debt Amortization
		private Calc c2434 = null; //ST DEBT CHANGE
		
		private ResourceManager rm       = null;
		private FORMATCOMMANDS FmtCmnd   = null;
		private ReportGenerator RG       = null;
		private PRINTCOMMANDS Utility    = null;

		private int pBaseID = 0; //statement ID
		private int period  = 0; //statement period

		private string sAdtMthVal  = ""; //Audit Method
		private string sDate       = null; //Statement Date
		private string auditMethod = ""; //audit method
		int indCat = 0; //Industry Category


		public FINANCIAL_STMT_ALERTS()
		{
		}

		public void Execute(ReportGenerator RGG)
		{
			RG = RGG;
			
			//Each method corresponds to the different sections of the
			//report.
			init();
			findStmtID();
			intro(); 
			qualified(); 
			industryAnalysis();
			interestExpense(); 
			netWorth(); 
			industryValues(); 
			incomeTaxes(); 
			retainedEarningsRecon(); 
			unexplainedAdjustment(); 
			cashFlows(); 
			currentAssets(); 
			currentLiabilities(); 
			nonCurrentAssets(); 
			cashFlowReliance(); 
			grossFixedAssets(); 
			capitalExpenditures(); 
			accruals(); 
			stockRetirements(); 
			investmentIncome(); 
			shortTermDebt();
			longTermDebt(); 
			dividends(); 
			Utility.PrintParagraph(RG, " ");
			Utility.PrintNotes(RG);
			//Utility.CloseReport(RG);
		}

		private void init ()
		{
			rm = FORMATCOMMANDS.GetResourceManager(Assembly.GetExecutingAssembly().GetName().Name);
			FmtCmnd = new FORMATCOMMANDS();
			Utility = new PRINTCOMMANDS();
			FmtCmnd.LoadFormatDefaults(RG);
			Utility.CreatePageHeader(RG, true);
			//Utility.CreateTable(RG,(RG.POStatements.Count + 1));

			c91   = RG.MACRO(M.FS_TOT_INVESTMENTS);;
			c100  = RG.MACRO(M.TOTAL_ASSETS);
			c170  = RG.MACRO(M.NET_PROFIT);
			c3001 = RG.MACRO(M.FS_NET_CAPITAL_EXPEND);
			c3002 = RG.MACRO(M.FS_EXPENDITURE);
			c710  = RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION);
			c2434 = RG.MACRO(M.FS_ST_DEBT_CHG);
			//amit: 11/29/05  Using Master Statement List instead of POStatements
			c260  = new Calc(0, RG.Statements.Count);
			c261  = new Calc(0, RG.Statements.Count);
			       
		}
		
		private void findStmtID()
		{
			int BaseId = RG.BaseStatementID;
			///This variable will store the stmt index of the base comparison stmt
			pBaseID = RG.Statements.IndexOf(RG.Context.Statements[BaseId.ToString()]);
			
		}

		private void intro ()
		{
			string header = "";
							
				sAdtMthVal = (RG.LANGSTMTCONSTANT(SCON.AuditMthd)[pBaseID].ToString()).ToLower();
				period = (int)(RG.STMT_PERIODS()[pBaseID]);
				sDate = Convert.ToDateTime(RG.STMT_DATE()[pBaseID]).ToShortDateString();
				int month = (int)(RG.STMT_MONTH()[pBaseID]);
				int year = (int)(RG.STMT_YEAR()[pBaseID]);
				int ind = (RG.IND(94) > 0) ? 4 : 0;
				int dbType = RG.DATABASE_TYPE();

				if (dbType == 3) indCat = dbType;

			    if ( ind != 0)
			    {
					if (RG.IND_Category == (int)ePeerCategory.Assets)
						indCat= 1;
					else if (RG.IND_Category == (int)ePeerCategory.Sales)
						indCat= 2;
					else if (RG.IND_Category == (int)ePeerCategory.Totals)
						indCat = 3;
					indCat = indCat + ind;
				}
								
				if (rm.GetString("fsUnqUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsUnQalified").ToLower();
					auditMethod = "unqualified";
				}
				else if (rm.GetString("fsTxRetUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsTxRetUC").ToLower();
					auditMethod = "taxreturn";
				}
				else if (rm.GetString("fsRevUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsRevUC").ToLower();
					auditMethod = "reviewed";
				}
			
				else if (rm.GetString("fsQualUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsQualUC").ToLower();
					auditMethod = "qualified";
				}
				else if (rm.GetString("fsCompUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsCompUC").ToLower();
					auditMethod = "compiled";
				}
				else if (rm.GetString("fsCoPpdUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsCoPpd");
					auditMethod = "companyprepared";
				}
				else if (rm.GetString("fscivProj").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fscivProj");
					auditMethod = "projection";
				}
				else if (rm.GetString("fsDiscUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsDiscUC").ToLower();
					auditMethod = "disclaimer";
				}
				else if (rm.GetString("fsAdvUC").ToLower().Equals(sAdtMthVal) )
				{
					sAdtMthVal = rm.GetString("fsAdvUC").ToLower();
					auditMethod = "adverse";
				}

				if (period == 12)
				{
					if (auditMethod.Equals("taxreturn"))
						this.printReport("", rm.GetString("fsBsdTxRtFY") + " " + year, true);
					else if (auditMethod.Equals("disclaimer"))
						this.printReport("", rm.GetString("fsBsdDscFY") + " " + year, true);
					else if (auditMethod.Equals("adverse"))
						this.printReport("", rm.GetString("fsBsdAdvOp") + " " + year, true);
					else if (auditMethod != "")
						this.printReport("", string.Format(rm.GetString("fsbasedAnnual"), " " +sAdtMthVal+" ", year), true );
					else 
						this.printReport("", string.Format(rm.GetString("fsbasedAnnual"), " ", year), true );
					
				}
				else
				{
					if (auditMethod.Equals("taxreturn"))
						this.printReport("", string.Format(rm.GetString("fsbaseTaxInterim"), period, sDate), true);
					else if (auditMethod.Equals("disclaimer"))
						this.printReport("", string.Format(rm.GetString("fsbaseDisInterim"), period, sDate), true );
					else if (auditMethod.Equals("adverse"))
						this.printReport("", string.Format(rm.GetString("fsbasedAdvInterim"), period, sDate), true );
					else if (auditMethod != "") 
						this.printReport("", string.Format(rm.GetString("fsbasedInterim"), " " +sAdtMthVal +" ", period, sDate), true );
					else
						this.printReport("", string.Format(rm.GetString("fsbasedInterim"), " ", period, sDate), true );
				}

				string s1 = "";
				switch (indCat)
				{
					case 0:
						s1 = rm.GetString("fsCompare3");
						break;
					case 1: 
						s1 = string.Format(rm.GetString("fsCompare1"), RG.IND_DESC);
						break;
					case 2: 
						goto case 1;
					case 3: 
						goto case 1;
					case 4:
						goto case 0;
					case 5:
						s1 =  string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpAssetsSize"), RG.IND_SIZE, RG.IND(7));
						break;
					case 6:
						s1 = string.Format(rm.GetString("fsCompare2"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, rm.GetString("sfpSalesSize"), RG.IND_SIZE, RG.IND(7));
						break;
					case 7:
						s1 = string.Format(rm.GetString("fsCompare4"), RG.IND(94), RG.PEER_CODE, RG.IND_DESC, RG.IND(7));
						break;
					default:
						break;
				}

				if (! RG.LANGCONSTANT(4)[pBaseID].ToString().Equals(""))
				{
					
					string targetCur = RG.TARGETCURRENCY(0)[0].ToString();
					s1 = string.Format(rm.GetString("qcFinInfoTarget"), targetCur) + " " + s1;
					//s1 = string.Format(rm.GetString("qcFinInfoTarget"), RG.LANGCONSTANT(4)[pBaseID].ToString()) + " " + s1;
					this.printReport(header,  s1, true);
				}
				else
					this.printReport(header, s1, true );
				
				if (period != 12)
					this.printReport(header, rm.GetString("fsInterimWarn"), true );
				//Text intro
				this.printReport( header, (string.Format(rm.GetString("fsIntro"), RG.Customer.LongName)), true);
		}


		private void qualified()
		{
			if (period != 12) return;

			string header = null;
					
			if ( auditMethod.ToLower().Equals("qualified") )
			{
				header = ( rm.GetString("fsOpHdr") );
				this.printReport(header, rm.GetString("fsQualified"), true );
			}
			else if ( auditMethod.ToLower().Equals("compiled") )
			{
				header = ( rm.GetString("fsOpHdr") );
				this.printReport(header, rm.GetString("fsCompiled1"), true );
				this.printReport("", rm.GetString("fsCompiled2"), true );
				this.printReport("", rm.GetString("fsCompiled3"), true );
			}
			else if ( auditMethod.ToLower().Equals("disclaimer") )
			{
				header =  ( rm.GetString("fsOpHdr") );
				this.printReport(header, rm.GetString("fsDisclaimer"), true );
			}
			else if ( auditMethod.ToLower().Equals("adverse"))
			{
				header = ( rm.GetString("fsOpHdr") );
				this.printReport(header, rm.GetString("fsAdverse"), true );
			}
			
		}

		private void industryAnalysis()
		{
			string header = null;
			double[] ind1 = new double[13] {22, 48, 52, 53, 54, 55, 56, 61, 62, 71, 81, 92, 98};
			
			int indFound = 0;
			
			for(int x=0; x < ind1.Length -1; x++)
			{
				if (RG.IND(1) == ind1[x])
				{
					indFound = 1;
					break;
				}
			}

			//Total Cost Of Sales Revenue
			double totCOSR = Math.Abs(RG.MACRO(M.TOT_COST_OF_SALES_REV)[pBaseID]);

			if ((totCOSR > 0) && (indFound == 1))
			{
				header = ( rm.GetString("fsAnalysisHdr") );
				this.printReport(header, rm.GetString("fsIndAnalysis"), true );

			}

			
		}

		private void interestExpense()
		{
			double interestIncome = RG.TYPE(165)[pBaseID];
			double interestExpense = RG.MACRO(M.FS_INTEREST_EXPENSE)[pBaseID];
			int interestInc = 0;
			int interestExp = 0;
			string header = null;

			if (interestIncome == 0)	interestInc = 1;
			else if (interestIncome < 0) interestInc = 2;

			if (interestExpense == 0)	interestExp = 3; 
			else if (interestExpense < 0) interestExp = 6;

			int interestIncExpense = interestInc + interestExp;
			header = ( rm.GetString("fsintExpHdr") );
			switch(interestIncExpense)
			{
				case 2:
					this.printReport(header, rm.GetString("fsIntExp2"), true );
					break;
				case 3:
					this.printReport(header, rm.GetString("fsIntExp3"), true );
					break;
				case 4:
					this.printReport(header, rm.GetString("fsIntExp4"), true );
					break;
				case 5:
					this.printReport(header, rm.GetString("fsIntExp5"), true );
					break;
				case 6:
					this.printReport(header, rm.GetString("fsIntExp6"), true );
					break;
				case 7:
					this.printReport(header, rm.GetString("fsIntExp7a"), true );
					this.printReport("", rm.GetString("fsIntExp7b"), true );
					break;
				case 8:
					this.printReport(header, rm.GetString("fsIntExp8"), true );
					break;
				default:
					break;
			}
			
		}


		private void netWorth()
		{
			string header = null;

			if (period == 12) 
			{
                //log# 1583: Do not use the absolute value.
				//double netWorth =  Math.Abs(RG.MACRO(M.NET_WORTH)[pBaseID]);
                double netWorth =RG.MACRO(M.NET_WORTH)[pBaseID];
																												
				if (netWorth < 1)
				{
					header = ( rm.GetString("fsNetWorthHdr") );
					this.printReport(header, rm.GetString("fsNetWorth"), true );
				}

			}

		}

		private void industryValues()
		{
			string header = null;
            
			if (indCat == 0)
				return;

			if ( (RG.IND(55) < 1)&& (RG.IND(56) < 1) && (RG.IND(57)< 1) )
			{
				header = ( rm.GetString("fsIndValHdr") );
				this.printReport(header, rm.GetString("fsIndVala"), true );
			}

			if ( (RG.IND(52) == 0)&& (RG.IND(53) == 0) && (RG.IND(54)==0) ) 
			{
					this.printReport(header, rm.GetString("fsIndValb"), true );
			}

		}


		private void incomeTaxes()
		{

			int i2413 = 0;
			int i2412 = 0;
			int i2410 = 0;
			int i2411 = 0;
			int i2491 = 0;
			int i2492 = 0;
			int i2405 = 0;
			string header = null;
			
			//Effective Tax Rate * 100
			//06/09/04: no need to multiply by 100, done in Macro
			Calc c2399 = RG.MACRO(M.EFFECTIVE_TAX_RATE);//; * 100;
            //Determine how many statements we are dealing with
			Calc c2400 = RG.CALC_ACCUMULATE(c2399, 1);
			//Calc calc = new Calc(1, RG.POStatements.Count);
			//Getting the number of statements
			Calc c22 = RG.CALC_ACCUMULATE(c2400, 3);
			Calc c2404 = c2400/c22;
			//Profit Before Taxes
			Calc c150 = RG.MACRO(M.PROFIT_BEFORE_TAX);

			//Deferred Inc Tax + Taxes Payable/Total Income Tax Expense
			Calc c2489 = RG.MACRO(M.FS_TAXES);
						
			if ( (Double.IsNaN(c150[pBaseID])? 0 : c150[pBaseID]) != 0) i2410  = 1;
			if ( (Double.IsNaN(c2399[pBaseID])? 0 : c2399[pBaseID]) < 30) i2411 = 1;
			if ( (Double.IsNaN(c2404[pBaseID])? 0 : c2404[pBaseID]) < 30) i2405 = 2;
			i2412 = i2410 + i2411 + i2405;
			if (i2412 > 1) i2413 = 2;

			if (c2489[pBaseID] > 1.25) i2491 = 1;

			i2492 = i2491 + i2413;
			
			if (i2492 >= 1)
			{
				header = ( rm.GetString("fsInTaxHdr") );
				this.printReport(header, "", true);
			}
			if (i2492 > 1)
			{
				this.printReport("", rm.GetString("fsInTaxa"), true );
				this.printReport("", rm.GetString("fsInTaxb"), true );
				this.printReport("", rm.GetString("fsInTaxc"), false );
				this.printReport("", rm.GetString("fsInTaxd"), false );
				this.printReport("", rm.GetString("fsInTaxe"), true );
				this.printReport("", rm.GetString("fsInTaxf"), true );
			}
			if (i2491 == 1)
			{
				this.printReport("", rm.GetString("fsInTaxg"), true );
				
			}
		}

		private void retainedEarningsRecon()
		{
			
			int i203  = 0;
			int i207  = 0;
			string header = null;
				
			    //prior period net worth
			    Calc c225 = RG.MACRO(M.FS_PRIOR_NET_WORTH);
			   	//c170 = RG.MACRO(M.NET_PROFIT);
				Calc c150 = RG.MACRO(M.PROFIT_BEFORE_TAX);
				Calc c155 = RG.MACRO(M.TOT_INC_TAX_EXP);
			    //Div & Withdrawals Cash
				Calc c216 = RG.MACRO(M.FS_DIV_WITHDRAW_CASH);
			    //change in capital account items
			    Calc c240 = RG.MACRO(M.FS_CHG_IN_CAP_ACT_ITEMS);
			    //chg in accumulated oci
				Calc c239 = RG.MACRO(M.FS_CHG_IN_ACC_OCI);
                //Gray area items
                Calc c243 = RG.MACRO(M.FS_GRAY_AREA_ITEMS);
			    //Currency Translation
				Calc c244 = RG.MACRO(M.FS_CURRENCY_TRANS);
			    //Treasury Stock
				Calc c241 = RG.MACRO(M.FS_TREASURY_STOCK);

			    //Change in stock, ETC
				Calc c245 = c240 + c243 + c244 + c241 + c239;
			    
				Calc c215 = RG.MACRO(M.OCI_ADJ_FROM_EXCHANGE_RATE);
				Calc c214 = RG.MACRO(M.OCI_RECLASS_ADJ);
				Calc c242 = RG.AND(117, RG.ANDFLOW, 31, RG.ANDCLASS) * RG.CONV_RATE();

			    //Dividends - Stock
                Calc c218 = RG.MACRO(M.FS_DIVD_STOCK);
			   	//This prints adjustments to R/E
			    Calc c212 = RG.MACRO(M.FS_ADJ_RE);
			    //is there a currency conversion and has it changed from period to period
				Calc c202 = RG.ACCOUNT(9950) - RG.ACCOUNT(9950,RG.LAG);
				
				if ( FmtCmnd.DetailCount(RG, RG.DETAILCLASS(30)) + FmtCmnd.DetailCount(RG, RG.DETAILCLASS(32)) > 0)
					i207 = 1;
				//amit: 11/29/05 Using Master List instead of POStatements	
				Calc c204 = new Calc(0, RG.Statements.Count); //null;
				Calc c206 = new Calc(0, RG.Statements.Count); //null;
				Calc c210 = new Calc(0, RG.Statements.Count); //null;
				Calc c208 = new Calc(0, RG.Statements.Count); //null;
						
				if (c202[pBaseID] != 0)	i203 = 1;
				 			
				int i209 = i203 + i207;

				if (i209 != 0)
                    c204 = RG.MACRO(M.FS_RETAINED_EARNINGS, RG.LAG);
            // lh  parens inaccurate; changed to macro; log 1965 5/9/07
                if (c202[pBaseID] != 0)
                    c206 = RG.MACRO(M.ADJ_CHG_EXCHANG_RATE);
                      
                if (c204[pBaseID] == 0)
					c210 = RG.MACRO(M.FS_RETAINED_EARNINGS, RG.LAG);
				if (i209 != 0)
					c208 = c204 + c206;

			    //Unexplained Adj to RE
				Calc c220 = c208 + c210 + c170 + c216 + c218 - RG.MACRO(M.FS_RETAINED_EARNINGS);
					
           	    Calc c230 = (c220)* -1 + c206;
				
			    //This computes the indicated ending net worth
				Calc c250 = c225 + c170 + c216 + c218 + c230 + c240 + c241+ c243+
					c244 + c214 + c215 + c242;
				
			    //Actual Ending Net Worth
			  	Calc c265 = RG.MACRO(M.FS_ACT_END_NETWORTH);
			
			    //difference between indicated and actual Unexplained Adj to Net Worth
				c260 = c265 - c250;

				//(indicated-actual adj to nw) - unexplained adjustments - adj to r/e
				c261 = c260 - c220 - c212;
			
			    if ((c261[pBaseID] > 1) || (c261[pBaseID] < -1))
				{
					//header = "RETAINED EARNINGS RECONCILIATIONS";
					header = ( rm.GetString("fsRetainEarReconHdr") );
					this.printReport(header, rm.GetString("fsRetainEarRecon"), true );
					
				}
		}

				
		private void unexplainedAdjustment()
		{
			string header = null;

			if ((c260[pBaseID] > 1) || (c260[pBaseID] < -1))
			{
				header = ( rm.GetString("fsUnExplAdjHdr") );
				this.printReport(header, string.Format(rm.GetString("fsUnExplAdj"), 
					                     FmtCmnd.RoundToReport(RG,c261[pBaseID]).ToString("N0")), true );
			}
		}

		private void cashFlows()
		{
			string header = null;
			
			//Cash After Financing
			double d870 = RG.MACRO(M.CASH_AFTER_FINANCING)[pBaseID];
			//CashAdjustment 
			double d880 = RG.MACRO(M.CASH_ADJUSTMENT)[pBaseID];
			//Actual Change in Cash Flow			
			double d878 = RG.MACRO(M.FS_ACTUAL_CHG_CASH_FLOW)[pBaseID];

			if ((d880 > 1) || (d880 < -1))
			{
				header = ( rm.GetString("fsCashFlowHdr") );
				this.printReport(header, string.Format(rm.GetString("fsCashFlowa"), 
					                     FmtCmnd.RoundToReport(RG, d870).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, d878).ToString("N0")), true );
				this.printReport("", rm.GetString("fsCashFlowb"), true );
				this.printReport("", rm.GetString("fsCashFlowc"), true );
			}


		}


		private void currentAssets()
		{
			string header = null;

			//Total current assets
			Calc c60 = RG.MACRO(M.TOTAL_CURRENT_ASSETS); //RG.CLASS(5) * RG.CONV_RATE();
			//Other current assets
			Calc c2474 = RG.MACRO(M.FS_OTH_CURRENT_ASSETS);
  			Calc c2475 = c2474 % c60;

			if (Double.IsPositiveInfinity(c2474[pBaseID]) || (Double.IsNaN(c2474[pBaseID])))
				return;	
	        
			if ( c2475[pBaseID] > 10 )
			{
				header = ( rm.GetString("fsCurAssetHdr") );
				this.printReport(header, string.Format(rm.GetString("fsCurAsset"), 
					                     FmtCmnd.RoundToReport(RG, c2474[pBaseID]).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, c60[pBaseID]).ToString("N0")), true);
			}
            
		}


		
		private void currentLiabilities()
		{
			string header = null;

			//Total Current Liabilites
			Calc c102 = RG.MACRO(M.TOTAL_CURRENT_LIABILITIES);
			//Other Current Liabilities
			Calc c2482 = RG.MACRO(M.FS_OTH_CURRENT_LIAB);
			Calc c2485 = c2482 % c102;
			if (Double.IsPositiveInfinity(c2485[pBaseID]) || (Double.IsNaN(c2485[pBaseID])))
				return;	
			if ( c2485[pBaseID] > 10)
			{
				header = ( rm.GetString("fsCurLiabHdr") );
				this.printReport(header, string.Format(rm.GetString("fsCurLiab"), 
					                     FmtCmnd.RoundToReport(RG, c2482[pBaseID]).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, c102[pBaseID]).ToString("N0")), true );
			}

		}


		private void nonCurrentAssets()
		{
			string header = null;

			//Total Investments
			//c91 = RG.MACRO(M.FS_TOT_INVESTMENTS);
			//Total other non-current assets
			double d92 = RG.MACRO(M.FS_OTH_NON_CUR_ASSET)[pBaseID];
			//Total Intangibles - Net
			double d95 = RG.MACRO(M.FS_TOT_INTANGIBLES)[pBaseID];
			//Total other Non-Current Assets
			double d96 = d95 +c91[pBaseID] + d92;
			//Total Assets
			//c100 = RG.MACRO(M.TOTAL_ASSETS);

			if ( d96 > (c100[pBaseID] * .1) )
			{
				header = ( rm.GetString("fsNonCurAssetHdr") );
				this.printReport(header, string.Format(rm.GetString("fsNonCurAsset"), 
					                     FmtCmnd.RoundToReport(RG, d92).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, c91[pBaseID]).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, d95).ToString("N0"), 
					                     FmtCmnd.RoundToReport(RG, c100[pBaseID]).ToString("N0")), true );
			}
		}

		private void cashFlowReliance()
		{
			string header = null;

			//Cash After Debt Amortization
			//c710 = RG.MACRO(M.CASH_AFTER_DEBT_AMORTIZATION);
			double d710 = c710[pBaseID];
			// Other Operating cash flow 
            //log# 1584: This item is being multiplied by -1 in the Macro. We are multiplying here again with
            //-1 to cancel the effect of first -1
			double d3855 = RG.MACRO(M.FS_OTH_OPER_CASH_FLOW)[pBaseID] * -1;
		
			if ( ((d710 - d3855) < 0) && (d710 > 0) )
			{
				header = ( rm.GetString("fsCashFlowRelHdr") );
				this.printReport(header, string.Format(rm.GetString("fsCashFlowRel"), 
					                     FmtCmnd.RoundToReport(RG, d3855).ToString("N0")), true );
			}

		}


		private void grossFixedAssets()
		{
			string header = null;

			//Depreciation / Gross Fixed 
			double d2712 = RG.MACRO(M.FS_DEPR_BY_GROSS_FIXED)[pBaseID];

			if (Double.IsPositiveInfinity(d2712) || (Double.IsNaN(d2712)))
				return;	
			if ( d2712 > 50)
			{
				header = ( rm.GetString("fsGFixedAssetHdr") );
				this.printReport(header, string.Format(rm.GetString("fsGFixedAsseta"), 
					                     FmtCmnd.RoundToReport(RG, d2712).ToString("N2")), true );
				this.printReport("", rm.GetString("fsGFixedAssetb"), true );
			}

		}

		private void capitalExpenditures()
		{
			string header = null;

			double d731 = RG.MACRO(M.FS_CHG_FXD_ASSETS)[pBaseID];

			if ( (d731 != 0) && (c3001[pBaseID] > 0) ||
				 (d731 == 0) && (c3002[pBaseID] > 0))
			{
				header = ( rm.GetString("fsCapitalExpndHdr") );
				this.printReport(header, string.Format(rm.GetString("fsCapitalExpnd"), 
			    (d731 != 0) ? FmtCmnd.RoundToReport(RG, c3001[pBaseID]).ToString("N0"): FmtCmnd.RoundToReport(RG, c3002[pBaseID]).ToString("N0")), true );
			}
			
		}


		private void accruals()
		{
			string header = null;

			double d101 = RG.MACRO(M.TOTAL_ACCRD_LIABS)[pBaseID];
			double d103 = RG.MACRO(M.TOTAL_ACCRD_LIABS, RG.LAG)[pBaseID];
			//Total Accruals
			double d2483 = RG.MACRO(M.FS_TOT_ACCURALS)[pBaseID];

			if (Double.IsPositiveInfinity(d2483) || Double.IsNaN(d2483) || Double.IsNegativeInfinity(d2483))
				return;	

			if (d2483 < -50)
			{
				header = ( rm.GetString("fsAccuralsHdr") );
				this.printReport(header, rm.GetString("fsAccuralsa"), true );
				this.printReport("", string.Format(rm.GetString("fsAccuralsb"), 
					                 FmtCmnd.RoundToReport(RG, d103).ToString("N0"), 
					                 FmtCmnd.RoundToReport(RG, d101).ToString("N0")), true );
			}

		}

		private void stockRetirements()
		{
			string header = null;

			if ( (RG.TYPE(130)[pBaseID] < (RG.TYPE(130,RG.LAG)[pBaseID] * 0.95)) || 
				(RG.TYPE(129)[pBaseID] < (RG.TYPE(129, RG.LAG)[pBaseID] * 0.95)) ||
				(RG.TYPE(131)[pBaseID] < (RG.TYPE(131, RG.LAG)[pBaseID] * 0.95)) )
			{
				header = ( rm.GetString("fsStockRetHdr") );
				this.printReport(header, string.Format(rm.GetString("fsStockRet"), RG.TYPE(130)[pBaseID].ToString("N0"),
					FmtCmnd.RoundToReport(RG, RG.TYPE(129)[pBaseID]).ToString("N0"),
					FmtCmnd.RoundToReport(RG, RG.TYPE(131)[pBaseID]).ToString("N0"),
					FmtCmnd.RoundToReport(RG, RG.TYPE(130, RG.LAG)[pBaseID]).ToString("N0"),
					FmtCmnd.RoundToReport(RG, RG.TYPE(129, RG.LAG)[pBaseID]).ToString("N0"),
					FmtCmnd.RoundToReport(RG, RG.TYPE(131, RG.LAG)[pBaseID]).ToString("N0")), true);
			}
		}


		private void investmentIncome()
		{
			string header = null;

			//Other income & Investments
			double d2420 = RG.MACRO(M.FS_OTH_INCOME_INVEST)[pBaseID];

			if ( (d2420 > (c170[pBaseID]* 0.5)) && (c91[pBaseID] > (c100[pBaseID] * 0.05)) )
			{
 				header = ( rm.GetString("fsInvIncomeHdr") );
				this.printReport(header, rm.GetString("fsInvIncomea"), true );
				this.printReport("", string.Format(rm.GetString("fsInvIncomeb"),
					                 FmtCmnd.RoundToReport(RG, d2420).ToString("N0"),
					                 FmtCmnd.RoundToReport(RG, c170[pBaseID]).ToString("N0"),
					                 FmtCmnd.RoundToReport(RG, c91[pBaseID]).ToString("N0"),
					                 FmtCmnd.RoundToReport(RG, c100[pBaseID]).ToString("N0")), true);
			}
            
		}

		private void shortTermDebt()
		{
			if (period != 12)
				return;
			string header = null;

            double d710 = c710[pBaseID];
			double d731 = RG.MACRO(M.FS_CHG_FXD_ASSETS)[pBaseID];
			//amit: 11/29/05. using Master Statement list instead of POStatements
			Calc c3003 = new Calc(0, RG.Statements.Count);
            if (d731 == 0)
              c3003 = c3002;
			else
			  c3003 = c3001;
			//ST Debt Change
			//c2434 = RG.MACRO(M.FS_ST_DEBT_CHG);
			if ( (c3003[pBaseID]< 0) && (d710 >= 0) &&
				( c2434[pBaseID] > 0) )
			{
				header = ( rm.GetString("fsShortTDebtHdr") );
				this.printReport(header, rm.GetString("fsShortTDebt"), true );
			}
		}


		private void longTermDebt()
		{
			if (period != 12)
				return;
			string header = null;

			double d710 = c710[pBaseID];
			//absolute value of cash after debt amortization
			double d715 = Math.Abs(d710);
			double d2442 = (d715 - c2434[pBaseID])/d715;

			//Change in LTD / CAPITAL Expenditure
			Calc c2455 = RG.MACRO(M.FS_CHG_LTD) / ((-1) * RG.MACRO(M.CAPITAL_EXPENDITURES));
					
			if ( (d710  < 0) && (d2442 > 0.2) && (c2455[pBaseID] > 0.9))
			{
				header = ( rm.GetString("fsLongTDebtHdr") );
				this.printReport(header, rm.GetString("fsLongTDebta"), true );
				this.printReport("", rm.GetString("fsLongTDebtb"), true );
			}


		}

		private void dividends()
		{
			double d3861 = 0;
			double d3844 = 0;
			double d3845 = 0;
			double d3850 = 0;
			double d3841 = 0;
			double d3840 = 0;
			double d3843 = 0;
			string header = null;
						
			double d682 = RG.MACRO(M.FS_CASH_PAID_DIVDENDS)[pBaseID];

			//Profit Before Extraordinary Items
			double d160 = RG.MACRO(M.PROFIT_BEFORE_EXTRAORDINARY_ITEMS)[pBaseID];
			
			if (d682 > 0) d3844 = 1;
			if (d160 < 0) d3845 = 1;
			if ((d3845 + d3844) == 2) d3850 = 4;

			//Cash After Operations
			double d580 = RG.MACRO(M.CASH_AFTER_OPERATIONS)[pBaseID];
			//Dividend Payout Rate
			double d192 = RG.MACRO(M.FS_DIV_PAYOUT_RATE)[pBaseID];

			if (d580 < 0) d3840 = 1;
			if (d192 > 0) d3841 = 1;

			double d3842 = d3840 + d3841;
			if (d3842 == 2) d3843 = 1;

			double d3848 = 0;
			if (d3840 + d3841 + d3844 + d3845 == 4)
				d3848 = 2;

			//Dividend payout Ratio 
			//macro is named as Rate just an anomaly
			double d945 = Double.IsPositiveInfinity(RG.MACRO(M.DIVIDEND_PAYOUT_RATE)[pBaseID]) ? 0: RG.MACRO(M.DIVIDEND_PAYOUT_RATE)[pBaseID];
			
			if (d945 > 100) d3861 = 1;

			if ((d3850 + d3848 + d3843 + d3861) > 0)
			{
				header = rm.GetString("fsdividendsHdr");
				this.printReport(header, "", true);
				if ( (d3850 + d3843 + d3848) == 1)
					this.printReport("", string.Format(rm.GetString("fsDividendsa"),FmtCmnd.RoundToReport(RG, d192).ToString("N0")), true);
				else if ((d3850 + d3843 + d3848) == 7)
					this.printReport("", string.Format(rm.GetString("fsDividendsb"),FmtCmnd.RoundToReport(RG, d192).ToString("N0")), true);
				else if ((d3850 + d3843 + d3848) == 4)
					this.printReport("", string.Format(rm.GetString("fsDividendsc"),FmtCmnd.RoundToReport(RG, d192).ToString("N0")), true);

				if (d3861 == 1)
				{
					this.printReport("", rm.GetString("fsDividendsd"), false);
				}

			}

		}


		private void printReport(string header, string body, bool extraLine)
		{
			if ( !(header == null))
			{
				if(! header.Equals(""))
				{
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "True");
					Utility.PrintParagraph(RG, header);
					RG.SetAuthorSetting(FORMATCOMMANDS.UNDERLINEON, "False");
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
				}
				if ( ! body.Equals(""))
				{
					Utility.PrintParagraph(RG, body);
					if (extraLine)
						Utility.PrintParagraph(RG, " ");
				}
				

			}
			
		}

	}
}
